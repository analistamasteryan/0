# V11.34 — Integridade de ingredientes TBCA

## Corrigido

- A busca do compositor de receitas agora tem propósito explícito (`general` ou `recipe-ingredient`). O modo de ingrediente filtra elegibilidade antes de ranking e limite; o modo geral continua encontrando todos os registros para lançamento avulso no diário.
- A política de ingrediente passa a usar a classificação `food_type` da fonte TBCA: `ALIMENTO` é elegível; `PREPARACAO_COMPOSTA` é excluída; tipo desconhecido falha fechado. Não há heurística pelo nome do prato.
- A regra é aplicada também no Zustand store, tanto ao adicionar ingrediente quanto ao substituir/decompor uma preparação, impedindo bypass pela UI.
- A elegibilidade é avaliada no nível do modelo de receita: todas as linhas precisam resolver para ingredientes permitidos. Os seis modelos legados que incluem snapshots compostos são removidos das buscas/seleções novas e das substituições; as duas receitas com linhas elegíveis permanecem disponíveis.
- As ações de estado também rejeitam modelos compostos ao adicionar, trocar, substituir refeição ou aplicar combinação sugerida. Registros históricos e planos persistidos não são apagados nem reescritos.
- O compositor reconhece preparações compostas diretamente pelo tipo do registro TBCA, além dos IDs históricos locais.
- Três IDs antigos de alimentos simples agora resolvem para registros TBCA canônicos: ovo mexido → BRC0065J; pão integral → BRC0149A; banana prata → BRC0011C. O `food_id` histórico permanece estável para receitas salvas, mas a origem e os nutrientes vêm da linha TBCA correta.
- Três snapshots de refeições compostas que apontavam para códigos inexistentes/incorretos deixaram de declarar origem TBCA e foram preservados como `TITAN_LEGACY`, `unverified` e `PREPARACAO_COMPOSTA`. Eles continuam disponíveis para registro avulso, não para ingredientes.
- Auditoria de catálogo/proveniência e relatório de cobertura agora separam TBCA, Open Food Facts, USDA FDC e snapshots locais legados.

## Dados e escopo

- Catálogo TBCA 7.2 presente no repositório: 5.830 registros; 2.717 `ALIMENTO` e 3.113 `PREPARACAO_COMPOSTA`; nenhum tipo ausente/desconhecido.
- Visão agregada após segregação: 5.835 registros — TBCA 5.830, Open Food Facts 2, USDA FDC 0 e TITAN_LEGACY 3.
- Nenhum valor analítico da tabela compacta TBCA foi reescrito. Esta versão corrige a forma como os registros são classificados, localizados e selecionados.

## Validação

- Novos testes cobrem política de elegibilidade, filtro de busca, guardas de estado, classificação dinâmica, aliases históricos, proveniência dos legados e contagem integral do catálogo.
- O auditor `npm run audit:tbca-ingredients` verifica a distribuição de tipos e códigos duplicados.
- O auditor `npm run audit:recipe-catalog-eligibility` verifica modelos elegíveis e linhas que bloqueiam cada template.
- Nenhuma dependência de runtime foi adicionada.
