# TITAN V11.23 — Nonlinear Meniscus & Scope Cleanup

Data: 25/11/2026  
Base: `TITAN_V11_22_ULTRA_REALISM.zip`.

## Implementado

### Água e vidro
- Adicionada `capillaryMeniscusHeightNonlinear` como perfil 2D Young–Laplace não linear limitado, com altura de contato derivada da primeira integral, inclinação inicial de contato e transição exponencial corrigida.
- `evalYoungLaplaceMeniscus` no GLSL ES 3.00 agora espelha a fórmula CPU.
- Duas chamadas existentes (copo e reservatório) usam a função compartilhada.
- Teste compara dez ângulos e sete distâncias contra integração RK4; exige erro relativo máximo de 8% para o conjunto definido.
- Não é solver 3D; unidades de cena ainda não são SI.

### Corpo 3D
- Removida geometria escondida de coluna, costelas, crânio, membros, dedos e pés.
- Removido material esquelético sem uso e alternância de visibilidade do skeleton group.
- Preservados corpo-base, músculos superficiais e profundos, 14 IDs musculares, morphs, picking, seleção, oclusão e dual-body.
- Nenhum osso, tendão ou estrutura semelhante é construída. `cheekBone` tornou-se `cheekContour` para descrever apenas o contorno facial da superfície.

### Redução de scaffolding de API
- Removida a aplicação Express inteira: as rotas health, receita (GET/recalculate), cardápio e TDEE não tinham consumidores no frontend. Não há backend de produto nesta versão.
- Removidos `server.ts`, `server.js`, dependências Express/compression, `http-client.ts`, `sync-queue.ts` e `event-tracker.ts`, todos sem consumidor de produto confirmado.
- Removido `@google/genai`, `GEMINI_API_KEY` e flag de metadata de Gemini sem código consumidor.
- `dev` usa Vite; `start` usa `vite preview` somente para inspeção local; produção publica `dist/` em hosting estático/CDN. Não existe servidor próprio.
- Removido `buildOpenFoodFactsV3Url`, que não tinha consumidor. Preservados os registros locais Open Food Facts usados no catálogo nutricional.
- Retirado painel que exibia candidatos de repositórios como se fossem integração de produto; metadados/licenças por exercício permanecem.

### Pesquisa
- Criado `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_23.md`, consolidando Top 5 de referência GitHub por sete especialidades e stack avançada aplicável.
- Nenhuma dependência externa ou ativo anatômico foi importado.

## Gates de validação

- Passaram: `test:rendering-v11-23`, `test:rendering-realism`, `test:review`, `typecheck:calculations` e contratos estáticos de anatomia/escopo.
- Bloqueados por dependências ausentes: `npm test`/`test:anatomy` (`tsx` e `three`), `lint` (`vite/client`) e `build` (`vite`).
- `test:gpu-shaders` foi ignorado pelo gate porque Chromium não inicializou WebGL/SwiftShader (`ETIMEDOUT`); compilação em GPU real e avaliação visual 360° seguem sem validação.
- WebGL2 real, inspeção visual 360° e GPU profiling só podem ser aprovados em host que inicialize o contexto GPU.
