# V11.26 — Nutrition optimizer completeness

## Added

- Expanded healthy-adult DRI references from 23 to 29 nutrients: choline, iodine, chloride, molybdenum, chromium and fluoride were added with sex/age-specific adult values where available.
- Added source-aware DRI metadata version label (`1997–2023 · edições por nutriente`) to avoid presenting several nutrient-specific DRI editions as a single 2019/2023 edition.
- Passed daily micronutrient targets into the daily meal optimization model when all positive ingredient quantities have compatible, quantified nutrient values.
- Modeled RDA/AI as soft lower goals, CDRR as a soft preferred ceiling, and true total-intake UL as a hard upper constraint in the HiGHS LP builder and TypeScript fallback.
- Preserved day-only scope for DRI constraints. A full-day reference is never silently applied to a single meal.
- Added per-nutrient optimization diagnostics and explicit reasons for insufficient coverage, scope mismatch and infeasible upper limits.
- Added defensive behavior for locked ingredients or minimum portions that already exceed a hard UL and for half-gram rounding that could reintroduce an UL violation.
- Corrected mixed-unit micronutrient aggregation: values such as folate µg and folate µg DFE are not summed; niacin values are only compared with mg NE when the source provides total niacin equivalents.
- Removed false nutrient-deficit messages when the intake value is missing, unanalyzed, trace-only, or unit-incompatible.
- Added tests for 29 adult reference entries, six newly added DRI nutrients, no fabricated zeros, incompatible units, scope, HiGHS LP constraints, and fallback UL projections.
- Added GitHub research ledger and remaining-gap register.

## Important data coverage limitation

The six new DRI references do not imply the TBCA catalog contains those nutrients. In the inspected TBCA food records, choline, iodine, chloride, molybdenum, chromium and fluoride remain `not_analyzed`; they are visible as unsupported and excluded from optimization until compatible food-source values are available. Likewise, this release does not add amino-acid-specific digestibility data or a DIAAS score.

## Verification in this environment

- Focused micronutrient tests: run and record in `.superpowers/sdd/2026-11-25-v11-26-nutrition-closure/progress.md`.
- Full test suite / Vite build / lint / HiGHS WASM runtime depend on installation of the declared npm dependencies. No `node_modules` directory was available and package installation did not complete in this environment. Do not interpret unavailable commands as passing.
- No clinical validation or external calibration of RMR, TDEE, Hall, or adaptive TDEE is claimed.
