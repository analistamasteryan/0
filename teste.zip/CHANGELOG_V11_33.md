# TITAN V11.33 — ingestão USDA segura e auditoria por fonte

## Adicionado
- Downloader para releases oficiais FDC pinadas: Foundation 2026-10-29/FDC 16.0, SR Legacy 2018-04 e FNDDS 2024-10-31.
- Download limitado por tamanho/tempo, redirect desabilitado, validação de origem HTTPS/hostname/path, content-type, Content-Length, assinatura ZIP e SHA-256.
- Persistência de arquivo externa imutável: gravação temporária + hard link atômico, idempotência sob concorrência e bloqueio de sobrescrita divergente; SHA-256 revalidado antes da promoção e diretório real verificado para ficar sob o projeto.
- Importador offline aceita `.json` ou `.zip`; leitura em streaming limitada a 256 MB para JSON e 64 MB para ZIP, extração em memória de exatamente um JSON, validação CRC32 e hash sobre o arquivo original. Cada tipo/release gera arquivo separado e o adaptador compõe os catálogos ativos; reimportar Foundation não apaga SR Legacy/FNDDS.
- Saídas são validadas pelo diretório físico (`realpath`) para impedir escape por symlink; auditorias são content-addressed, imutáveis e promovidas atomicamente, rejeitando colisões divergentes.
- Leitor ZIP restrito a stored/deflate, sem ZIP64/multidisk/criptografia/symlink/path traversal; valida CRC, data descriptor com/sem assinatura, flags, tamanhos e regiões sobrepostas; limites de arquivo/JSON/razão de compressão.
- Downloader exige resposta streaming para que o limite de bytes seja aplicado durante a leitura, sem fallback `arrayBuffer()` não limitado; valida a URL final completa.
- Auditoria de cobertura passa a incluir TBCA, Open Food Facts e USDA em namespaces separados; novo relatório `NUTRIENT_COVERAGE_ALL_SOURCES_V11_33.json`.
- Workflow de CI fixa Bun 1.4.5 e expõe gates específicos de cálculo, hardening nutricional, contrato ZIP/download e CLI USDA.

## Reforçado
- Importação inválida não substitui o catálogo atual.
- Manifesto preserva `archiveEntry`, hash do ZIP, versão/release e origem.
- Arquivos brutos baixados ficam em `data/external/usda-fdc/`, ignorados pelo Git para evitar inclusão acidental de arquivos grandes.

## Limites conhecidos
- Download real USDA não foi concluído no ambiente (tentativa direta do ZIP Foundation também falhou); o catálogo gerado permanece vazio.
- Não foi verificado o uso de memória/tempo em SR Legacy (205 MB JSON) nem em FNDDS (64 MB JSON) com arquivos reais.
- O relatório de cobertura agora agrega corretamente as três fontes, mas não aumenta o número USDA sem import real.
- Crosswalk TBCA↔USDA, retenção por preparo, DIAAS com dados reais, ingestão total de suplementos/fortificados e otimização multidiária continuam incompletos.
- Build/lint global e runtime WASM HiGHS exigem instalação de dependências e execução em ambiente CI/host completo.
