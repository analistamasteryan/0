import type { FoodSourceItem } from '../entities/nutrient';
import { validateFoodMacroComposition } from './food-data-quality.ts';
import { evaluateRecipeIngredientEligibility } from './food-ingredient-policy.ts';

export interface FoodSearchEntry {
  food: FoodSourceItem;
  normalizedName: string;
  normalizedSearchText: string;
  normalizedSource: string;
  normalizedText: string;
}

const NON_ASCII_RE = /[^\x20-\x7e]/;
const DIACRITICS_RE = /[\u0300-\u036f]/g;
const ASCII_SEP_RE = /[^a-z0-9]+/g;
const UNICODE_SEP_RE = /[^\p{L}\p{N}]+/gu;
const PT_BR_COLLATOR = new Intl.Collator('pt-BR', { sensitivity: 'base', numeric: true });

export function normalizeFoodSearchText(value: string): string {
  if (!value) return '';
  if (!NON_ASCII_RE.test(value)) {
    return value.toLowerCase().replace(ASCII_SEP_RE, ' ').trim();
  }
  return value
    .normalize('NFD')
    .replace(DIACRITICS_RE, '')
    .toLowerCase()
    .replace(UNICODE_SEP_RE, ' ')
    .trim();
}

export function buildFoodSearchIndex(foods: readonly FoodSourceItem[]): FoodSearchEntry[] {
  const sorted = foods.filter((food) => validateFoodMacroComposition(food).valid)
    .sort((a, b) => PT_BR_COLLATOR.compare(a.name, b.name));
  const result = new Array<FoodSearchEntry>(sorted.length);
  for (let i = 0; i < sorted.length; i += 1) {
    const food = sorted[i]!;
    const normalizedName = normalizeFoodSearchText(food.name);
    const normalizedSearchText = normalizeFoodSearchText(food.search_text ?? '');
    const normalizedSource = normalizeFoodSearchText(`${food.source_record_id} ${food.source_id}`);
    result[i] = {
      food,
      normalizedName,
      normalizedSearchText,
      normalizedSource,
      normalizedText: `${normalizedName} ${normalizedSearchText} ${normalizedSource}`.trim(),
    };
  }
  return result;
}

export interface FoodSearchOptions {
  purpose?: 'general' | 'recipe-ingredient';
}

export function searchFoodIndex(
  index: readonly FoodSearchEntry[],
  query: string,
  limit = 60,
  options: FoodSearchOptions = {},
): FoodSourceItem[] {
  const normalizedQuery = normalizeFoodSearchText(query);
  const safeLimit = Number.isFinite(limit) ? Math.max(0, Math.min(250, Math.floor(limit))) : 60;
  if (safeLimit === 0) return [];
  const eligibleEntries = options.purpose === 'recipe-ingredient'
    ? index.filter((entry) => evaluateRecipeIngredientEligibility(entry.food).eligible)
    : index;
  if (!normalizedQuery) return eligibleEntries.slice(0, safeLimit).map((entry) => entry.food);

  const terms = normalizedQuery.split(' ').filter(Boolean);
  const ranked: Array<{ food: FoodSourceItem; score: number; order: number }> = [];

  for (let order = 0; order < eligibleEntries.length; order += 1) {
    const entry = eligibleEntries[order];
    if (!entry) continue;
    let score = Number.POSITIVE_INFINITY;
    if (entry.normalizedName === normalizedQuery) score = 0;
    else if (entry.normalizedName.startsWith(normalizedQuery)) score = 1;
    else if (entry.normalizedName.includes(normalizedQuery)) score = 2;
    else if (terms.every((term) => entry.normalizedName.includes(term))) score = 3;
    else if (terms.every((term) => entry.normalizedSearchText.includes(term))) score = 4;
    else if (terms.every((term) => entry.normalizedSource.includes(term))) score = 5;
    else if (terms.every((term) => entry.normalizedText.includes(term))) score = 6;

    if (Number.isFinite(score)) ranked.push({ food: entry.food, score, order });
  }

  ranked.sort((a, b) => a.score - b.score || a.order - b.order);
  return ranked.slice(0, safeLimit).map((entry) => entry.food);
}
