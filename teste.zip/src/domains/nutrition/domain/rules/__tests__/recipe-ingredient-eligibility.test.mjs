import assert from 'node:assert/strict';
import { RECIPE_CATALOG } from '../../../data/recipes/recipe-catalog.ts';
import {
  evaluateRecipeTemplateEligibility,
  isEligibleRecipeTemplate,
  searchSubstitutionRecipes,
} from '../recipe-engine.ts';

const cafe = RECIPE_CATALOG.find((recipe) => recipe.id === 'rec-cafe-completo');
const yoghurt = RECIPE_CATALOG.find((recipe) => recipe.id === 'rec-lanche-iogurte');
const chicken = RECIPE_CATALOG.find((recipe) => recipe.id === 'rec-almoco-frango');

assert.ok(cafe && yoghurt && chicken);
assert.deepEqual(evaluateRecipeTemplateEligibility(yoghurt), {
  eligible: true,
  blockedFoodIds: [],
});
assert.equal(isEligibleRecipeTemplate(yoghurt), true);
assert.deepEqual(evaluateRecipeTemplateEligibility(cafe), {
  eligible: false,
  blockedFoodIds: ['tbca-mamao-aveia'],
});
assert.equal(isEligibleRecipeTemplate(chicken), false);

const selectable = RECIPE_CATALOG.filter(isEligibleRecipeTemplate).map((recipe) => recipe.id);
assert.deepEqual(selectable, ['rec-lanche-iogurte', 'rec-sub-iogurte-leve']);

const substitutions = searchSubstitutionRecipes('', 'rec-sub-iogurte-leve');
assert.ok(substitutions.length > 0);
assert.ok(substitutions.every((summary) => isEligibleRecipeTemplate(summary.recipe)));
assert.ok(!substitutions.some((summary) => summary.recipe.id === 'rec-almoco-frango'));

// Legacy meal templates remain calculable for persisted plans and diary history.
assert.ok(RECIPE_CATALOG.some((recipe) => recipe.id === 'rec-almoco-frango'));
console.log('recipe-ingredient-eligibility: PASS');
