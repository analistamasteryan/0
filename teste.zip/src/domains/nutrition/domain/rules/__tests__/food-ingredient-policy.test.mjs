import assert from 'node:assert/strict';
import {
  evaluateRecipeIngredientEligibility,
  isCompositeFood,
} from '../food-ingredient-policy.ts';
import { buildFoodSearchIndex, searchFoodIndex } from '../food-search.ts';

const food = (food_id, source_id, food_type, extra = {}) => ({
  food_id,
  name: food_id,
  source_id,
  source_record_id: food_id,
  source_version: 'fixture',
  quality_status: source_id === 'TITAN_LEGACY' ? 'unverified' : 'reference_database',
  food_type,
  macros: { kcalPerBasis: 100, proteinGPerBasis: 10, carbsGPerBasis: 10, fatGPerBasis: 2, basisQuantityG: 100 },
  micronutrients: {},
  ...extra,
});

const tbcaSimple = food('tbca-simple', 'TBCA', 'ALIMENTO');
const tbcaCompound = food('tbca-compound', 'TBCA', 'PREPARACAO_COMPOSTA');
const tbcaUnknown = food('tbca-unknown', 'TBCA', undefined);
const offNoType = food('off-product', 'OPEN_FOOD_FACTS', undefined);
const usdaNoType = food('usda-product', 'USDA_FDC', undefined);
const localComposite = food('legacy-meal', 'TITAN_LEGACY', 'PREPARACAO_COMPOSTA');

assert.deepEqual(evaluateRecipeIngredientEligibility(tbcaSimple), { eligible: true, reason: 'eligible' });
assert.equal(evaluateRecipeIngredientEligibility(tbcaCompound).eligible, false);
assert.equal(evaluateRecipeIngredientEligibility(tbcaCompound).reason, 'tbca_composite_preparation');
assert.equal(evaluateRecipeIngredientEligibility(tbcaUnknown).eligible, false, 'unknown TBCA classification fails closed');
assert.equal(evaluateRecipeIngredientEligibility(offNoType).eligible, true, 'do not infer OFF type from product name');
assert.equal(evaluateRecipeIngredientEligibility(usdaNoType).eligible, true, 'do not infer USDA type from product name');
assert.equal(evaluateRecipeIngredientEligibility(localComposite).eligible, false);
assert.equal(isCompositeFood(tbcaCompound), true);
assert.equal(isCompositeFood(localComposite), true);
assert.equal(isCompositeFood(tbcaSimple), false);

const index = buildFoodSearchIndex([tbcaSimple, tbcaCompound, offNoType, localComposite]);
assert.deepEqual(
  searchFoodIndex(index, '', 20, { purpose: 'recipe-ingredient' }).map((item) => item.food_id),
  ['off-product', 'tbca-simple'],
  'recipe ingredient search excludes TBCA preparations and local composite meal snapshots',
);
assert.deepEqual(
  searchFoodIndex(index, '', 20).map((item) => item.food_id),
  ['legacy-meal', 'off-product', 'tbca-compound', 'tbca-simple'],
  'general search preserves whole-food/meal discoverability',
);

console.log('food-ingredient-policy: PASS');
