export const FAO_2013_DIAAS_REFERENCE_PATTERNS = {
  young_children_6m_3y: {
    id: 'FAO_2013_YOUNG_CHILDREN_6M_3Y',
    ageGroup: '6 months to 3 years',
    histidine: 20,
    isoleucine: 32,
    leucine: 66,
    lysine: 57,
    sulfur_amino_acids: 27,
    aromatic_amino_acids: 52,
    threonine: 31,
    tryptophan: 8.5,
    valine: 43,
  },
  older_children_adults: {
    id: 'FAO_2013_OLDER_CHILDREN_ADULTS',
    ageGroup: 'older children, adolescents and adults',
    histidine: 16,
    isoleucine: 30,
    leucine: 61,
    lysine: 48,
    sulfur_amino_acids: 23,
    aromatic_amino_acids: 41,
    threonine: 25,
    tryptophan: 6.6,
    valine: 40,
  },
} as const;

export type DIAASReferencePatternId = keyof typeof FAO_2013_DIAAS_REFERENCE_PATTERNS;
export type IndispensableAminoAcid =
  | 'histidine'
  | 'isoleucine'
  | 'leucine'
  | 'lysine'
  | 'methionine'
  | 'cysteine'
  | 'phenylalanine'
  | 'tyrosine'
  | 'threonine'
  | 'tryptophan'
  | 'valine';

export interface AminoAcidCompositionEvidence {
  foodId: string;
  foodState: string;
  sourceName: string;
  sourceVersion: string;
  reference: string;
  referenceUrl: string;
  basis: 'mg_per_g_protein';
}

export interface IlealDigestibilityEvidence {
  foodId: string;
  fraction: number;
  species: 'human' | 'pig';
  method: 'true_ileal' | 'standardized_ileal';
  reference: string;
  sourceName: string;
  sourceVersion: string;
  referenceUrl: string;
  testedState: string;
}

export interface ProteinQualitySourceEvidence {
  foodId: string;
  foodState: string;
  proteinGrams: number;
  aminoAcidsMgPerGProtein: Record<IndispensableAminoAcid, number>;
  aminoAcidEvidence: AminoAcidCompositionEvidence;
  ilealDigestibility: Record<IndispensableAminoAcid, IlealDigestibilityEvidence>;
  lysineDamageRisk: 'not_suspected' | 'suspected' | 'unknown';
  lysineBasis: 'reactive' | 'total';
}

export interface DietaryDIAASRequest {
  proteinSources: readonly ProteinQualitySourceEvidence[];
  referencePattern: DIAASReferencePatternId;
}

export interface DietaryDIAASResult {
  status: 'calculated' | 'insufficient_evidence' | 'invalid_input';
  referencePattern: string;
  diaas: number | null;
  untruncatedDiaas: number | null;
  isMixedDiet: boolean;
  limitingAminoAcid: string | null;
  aminoAcidScores: Record<string, number>;
  evidenceSpecies: string[];
  evidenceReferences: string[];
  reasons: string[];
}

const AMINO_ACID_GROUPS = {
  histidine: ['histidine'],
  isoleucine: ['isoleucine'],
  leucine: ['leucine'],
  lysine: ['lysine'],
  sulfur_amino_acids: ['methionine', 'cysteine'],
  aromatic_amino_acids: ['phenylalanine', 'tyrosine'],
  threonine: ['threonine'],
  tryptophan: ['tryptophan'],
  valine: ['valine'],
} as const satisfies Record<keyof (typeof FAO_2013_DIAAS_REFERENCE_PATTERNS)['older_children_adults'] extends never ? never : Exclude<keyof (typeof FAO_2013_DIAAS_REFERENCE_PATTERNS)['older_children_adults'], 'id' | 'ageGroup'>, readonly IndispensableAminoAcid[]>;

const AMINO_ACIDS = Object.keys({
  histidine: 1,
  isoleucine: 1,
  leucine: 1,
  lysine: 1,
  methionine: 1,
  cysteine: 1,
  phenylalanine: 1,
  tyrosine: 1,
  threonine: 1,
  tryptophan: 1,
  valine: 1,
}) as IndispensableAminoAcid[];

function emptyResult(
  status: DietaryDIAASResult['status'],
  pattern: DIAASReferencePatternId | undefined,
  reasons: string[],
): DietaryDIAASResult {
  return {
    status,
    referencePattern: pattern ? FAO_2013_DIAAS_REFERENCE_PATTERNS[pattern]?.id ?? 'UNKNOWN_REFERENCE_PATTERN' : 'UNKNOWN_REFERENCE_PATTERN',
    diaas: null,
    untruncatedDiaas: null,
    isMixedDiet: false,
    limitingAminoAcid: null,
    aminoAcidScores: {},
    evidenceSpecies: [],
    evidenceReferences: [],
    reasons,
  };
}

/**
 * Calculates a source-backed DIAAS-style score from amino-acid-specific ileal evidence.
 * The function never estimates amino-acid profiles or digestibility from total protein.
 */
export function calculateDietaryDIAAS(request: DietaryDIAASRequest): DietaryDIAASResult {
  const patternId = request?.referencePattern;
  const pattern = patternId ? FAO_2013_DIAAS_REFERENCE_PATTERNS[patternId] : undefined;
  if (!Array.isArray(request?.proteinSources) || request.proteinSources.length === 0 || !pattern) {
    return emptyResult('invalid_input', patternId, ['Informe ao menos uma fonte proteica e um padrão FAO válido.']);
  }

  const reasons: string[] = [];
  let totalProteinG = 0;
  const digestibleAminoAcidsMg = new Map<string, number>();
  const species = new Set<string>();
  const references = new Set<string>();

  for (const source of request.proteinSources) {
    if (!source || typeof source.foodId !== 'string' || !source.foodId.trim() ||
        typeof source.foodState !== 'string' || !source.foodState.trim() ||
        !Number.isFinite(source.proteinGrams) || source.proteinGrams <= 0 ||
        !source.aminoAcidsMgPerGProtein || !source.ilealDigestibility) {
      const sourceId = source && typeof source.foodId === 'string' && source.foodId.trim() ? source.foodId : '(sem ID)';
      return emptyResult('invalid_input', request.referencePattern, [`Fonte ${sourceId} possui identidade, estado, quantidade de proteína ou evidência inválidos.`]);
    }
    const aminoAcidEvidence = source.aminoAcidEvidence;
    if (!aminoAcidEvidence || aminoAcidEvidence.foodId !== source.foodId ||
        aminoAcidEvidence.foodState !== source.foodState ||
        aminoAcidEvidence.basis !== 'mg_per_g_protein' ||
        typeof aminoAcidEvidence.sourceName !== 'string' || !aminoAcidEvidence.sourceName.trim() ||
        typeof aminoAcidEvidence.sourceVersion !== 'string' || !aminoAcidEvidence.sourceVersion.trim() ||
        typeof aminoAcidEvidence.reference !== 'string' || !aminoAcidEvidence.reference.trim() ||
        typeof aminoAcidEvidence.referenceUrl !== 'string' || !/^https?:\/\//i.test(aminoAcidEvidence.referenceUrl)) {
      reasons.push(`${source.foodId}: composição de aminoácidos sem evidência vinculada ao alimento, estado e base mg/g de proteína.`);
    } else {
      references.add(aminoAcidEvidence.reference);
    }
    if (source.lysineDamageRisk !== 'not_suspected' && source.lysineBasis !== 'reactive') {
      reasons.push(`${source.foodId}: risco de dano térmico à lisina exige teor de lisina reativa, não apenas lisina total.`);
    }
    for (const aminoAcid of AMINO_ACIDS) {
      const amount = source.aminoAcidsMgPerGProtein[aminoAcid];
      const evidence = source.ilealDigestibility[aminoAcid];
      if (!Number.isFinite(amount) || amount < 0) {
        reasons.push(`${source.foodId}: teor ausente ou inválido para ${aminoAcid}.`);
        continue;
      }
      if (!evidence || !Number.isFinite(evidence.fraction) || evidence.fraction < 0 || evidence.fraction > 1 ||
          !['human', 'pig'].includes(evidence.species) ||
          !['true_ileal', 'standardized_ileal'].includes(evidence.method) ||
          evidence.foodId !== source.foodId ||
          typeof evidence.reference !== 'string' || !evidence.reference.trim() ||
          typeof evidence.sourceName !== 'string' || !evidence.sourceName.trim() ||
          typeof evidence.sourceVersion !== 'string' || !evidence.sourceVersion.trim() ||
          typeof evidence.referenceUrl !== 'string' || !/^https?:\/\//i.test(evidence.referenceUrl) ||
          evidence.testedState !== source.foodState) {
        reasons.push(`${source.foodId}: digestibilidade ileal de ${aminoAcid} ausente, inválida ou medida em estado diferente (${source.foodState}).`);
        continue;
      }
      const previous = digestibleAminoAcidsMg.get(aminoAcid) ?? 0;
      digestibleAminoAcidsMg.set(aminoAcid, previous + source.proteinGrams * amount * evidence.fraction);
      species.add(evidence.species);
      references.add(evidence.reference);
    }
    totalProteinG += source.proteinGrams;
  }

  const sourceMethods = new Set(request.proteinSources.flatMap((source) =>
    AMINO_ACIDS.map((aminoAcid) => source.ilealDigestibility[aminoAcid]?.method).filter(Boolean),
  ));
  const sourceSpecies = new Set(request.proteinSources.flatMap((source) =>
    AMINO_ACIDS.map((aminoAcid) => source.ilealDigestibility[aminoAcid]?.species).filter(Boolean),
  ));
  if (sourceMethods.size > 1 || sourceSpecies.size > 1) {
    reasons.push('As fontes combinam métodos ou espécies de digestibilidade ileal diferentes; não é adequado somá-los como se fossem a mesma medição.');
  }

  if (reasons.length > 0) {
    return emptyResult('insufficient_evidence', request.referencePattern, [...new Set(reasons)]);
  }
  if (!Number.isFinite(totalProteinG) || totalProteinG <= 0) {
    return emptyResult('invalid_input', request.referencePattern, ['A quantidade total de proteína deve ser maior que zero.']);
  }

  const aminoAcidScores: Record<string, number> = {};
  for (const [group, aminoAcids] of Object.entries(AMINO_ACID_GROUPS)) {
    const digestibleMgPerGProtein = aminoAcids.reduce(
      (sum, aminoAcid) => sum + (digestibleAminoAcidsMg.get(aminoAcid) ?? 0) / totalProteinG,
      0,
    );
    const referenceMgPerG = pattern[group as keyof typeof AMINO_ACID_GROUPS];
    aminoAcidScores[group] = (digestibleMgPerGProtein / referenceMgPerG) * 100;
  }

  const limitingAminoAcid = Object.entries(aminoAcidScores).sort((a, b) => a[1] - b[1])[0]?.[0] ?? null;
  const uniqueFoodStates = new Set(request.proteinSources.map((source) => `${source.foodId}::${source.foodState}`));
  const isMixedDiet = uniqueFoodStates.size > 1;
  const untruncatedDiaas = limitingAminoAcid ? Number(aminoAcidScores[limitingAminoAcid]!.toFixed(2)) : null;
  return {
    status: 'calculated',
    referencePattern: pattern.id,
    untruncatedDiaas,
    isMixedDiet,
    // FAO allows >100 for an individual food, but caps mixed-diet DIAAS at 100.
    diaas: untruncatedDiaas === null ? null : isMixedDiet ? Math.min(100, untruncatedDiaas) : untruncatedDiaas,
    limitingAminoAcid,
    aminoAcidScores: Object.fromEntries(Object.entries(aminoAcidScores).map(([key, value]) => [key, Number(value.toFixed(2))])),
    evidenceSpecies: [...species].sort(),
    evidenceReferences: [...references].sort(),
    reasons: [],
  };
}
