import { memo } from 'react';
import { BufferedNumberInput } from '@/src/shared/ui/BufferedNumberInput';
import type {
  ComposerDayPlan,
  MealTargetAllocation,
  NutritionTargets,
} from '../../../domain/entities/nutrient';
import { evaluateMealAllocations } from '../../../domain/rules/cardapio-composer-engine';

interface MealTargetAllocationProps {
  dayPlan: ComposerDayPlan;
  targets: NutritionTargets;
  allocations: readonly MealTargetAllocation[];
  onChangeAllocations: (next: MealTargetAllocation[]) => void;
}

type AllocationKey = 'energySharePercent' | 'proteinSharePercent' | 'carbsSharePercent' | 'fatSharePercent';

export const MealTargetAllocationPanel = memo(function MealTargetAllocationPanel({
  dayPlan,
  targets,
  allocations,
  onChangeAllocations,
}: MealTargetAllocationProps) {
  const evaluation = evaluateMealAllocations(dayPlan, targets, allocations);
  const macroEnabled = evaluation.hasMacroDistribution;

  const buildUpdatedAllocations = (
    updater: (slot: (typeof evaluation.slots)[number], idx: number) => MealTargetAllocation,
  ) => evaluation.slots.map(updater);

  const handleShareChange = (slotId: string, field: AllocationKey, nextPercent: number) => {
    const clean = Math.max(0, Math.min(100, Number(nextPercent.toFixed(1))));
    const updated = buildUpdatedAllocations((slot) => ({
      slotId: slot.slotId,
      energySharePercent: field === 'energySharePercent' && slot.slotId === slotId ? clean : slot.sharePercent,
      proteinSharePercent:
        field === 'proteinSharePercent' && slot.slotId === slotId
          ? clean
          : slot.proteinSharePercent,
      carbsSharePercent:
        field === 'carbsSharePercent' && slot.slotId === slotId
          ? clean
          : slot.carbsSharePercent,
      fatSharePercent:
        field === 'fatSharePercent' && slot.slotId === slotId
          ? clean
          : slot.fatSharePercent,
    }));
    onChangeAllocations(updated);
  };

  const handleToggleMacroDistribution = (enable: boolean) => {
    const updated = buildUpdatedAllocations((slot) => ({
      slotId: slot.slotId,
      energySharePercent: slot.sharePercent,
      proteinSharePercent: enable ? (slot.proteinSharePercent ?? slot.sharePercent) : null,
      carbsSharePercent: enable ? (slot.carbsSharePercent ?? slot.sharePercent) : null,
      fatSharePercent: enable ? (slot.fatSharePercent ?? slot.sharePercent) : null,
    }));
    onChangeAllocations(updated);
  };

  const handleProportionalNormalizeField = (field: AllocationKey) => {
    const count = evaluation.slots.length;
    if (count === 0) return;

    const getVal = (s: (typeof evaluation.slots)[number]) => {
      if (field === 'energySharePercent') return s.sharePercent;
      if (field === 'proteinSharePercent') return s.proteinSharePercent ?? 0;
      if (field === 'carbsSharePercent') return s.carbsSharePercent ?? 0;
      return s.fatSharePercent ?? 0;
    };

    const sum = evaluation.slots.reduce((acc, s) => acc + getVal(s), 0);
    let running = 0;

    const updated = buildUpdatedAllocations((slot, idx) => {
      const base: MealTargetAllocation = {
        slotId: slot.slotId,
        energySharePercent: slot.sharePercent,
        proteinSharePercent: slot.proteinSharePercent,
        carbsSharePercent: slot.carbsSharePercent,
        fatSharePercent: slot.fatSharePercent,
      };
      if (idx === count - 1) {
        base[field] = Math.max(0, Number((100 - running).toFixed(1)));
      } else if (sum <= 0) {
        const eq = Math.floor((100 / count) * 10) / 10;
        running += eq;
        base[field] = eq;
      } else {
        const scaled = Math.round(((getVal(slot) / sum) * 100) * 10) / 10;
        running += scaled;
        base[field] = scaled;
      }
      return base;
    });

    onChangeAllocations(updated);
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.1em] text-[var(--titan-text-secondary)]">
            Distribuição entre refeições
          </h3>
          <p className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] mt-0.5">
            Energia: {evaluation.totalSharePercent.toFixed(1)}% ·{' '}
            {evaluation.isBalanced ? (
              <span className="text-[var(--titan-status-success)]">100% distribuído</span>
            ) : evaluation.unallocatedPercent > 0 ? (
              <span className="text-[var(--titan-champagne)]">
                Não alocado: {evaluation.unallocatedPercent.toFixed(1)}%
              </span>
            ) : (
              <span className="text-[var(--titan-status-error)]">
                Excedente: +{Math.abs(evaluation.unallocatedPercent).toFixed(1)}%
              </span>
            )}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          {!evaluation.isBalanced && (
            <button
              type="button"
              onClick={() => handleProportionalNormalizeField('energySharePercent')}
              className="titan-button titan-button--secondary !min-h-[38px] !px-2.5 !text-[11px]"
            >
              Fechar 100%
            </button>
          )}
        </div>
      </div>

      {/* Explicit Energy-Only vs Energy + P/C/G Mode Switch */}
      <div className="flex items-center justify-between gap-2 rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] p-1.5">
        <div role="group" aria-label="Escopo de alocação por refeição" className="titan-segmented w-full grid grid-cols-2">
          <button
            type="button"
            aria-pressed={!macroEnabled}
            onClick={() => handleToggleMacroDistribution(false)}
            className={`titan-segment !min-h-[34px] !text-[11px] ${!macroEnabled ? 'is-active' : ''}`}
          >
            Apenas energia (%)
          </button>
          <button
            type="button"
            aria-pressed={macroEnabled}
            onClick={() => handleToggleMacroDistribution(true)}
            className={`titan-segment !min-h-[34px] !text-[11px] ${macroEnabled ? 'is-active' : ''}`}
          >
            Energia + P / C / G
          </button>
        </div>
      </div>

      {!macroEnabled && (
        <p className="text-[11px] text-[var(--titan-text-muted)]">
          Proteína, carboidratos e gorduras sem fração por horário permanecem avaliados no total do dia.
        </p>
      )}

      {macroEnabled && (
        <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] font-mono-metric text-[var(--titan-text-muted)]">
          <span>
            P {(evaluation.totalProteinSharePercent ?? 0).toFixed(0)}% · C{' '}
            {(evaluation.totalCarbsSharePercent ?? 0).toFixed(0)}% · G{' '}
            {(evaluation.totalFatSharePercent ?? 0).toFixed(0)}%
          </span>
          {(evaluation.totalProteinSharePercent !== null && Math.abs(evaluation.totalProteinSharePercent - 100) > 0.5) ||
            (evaluation.totalCarbsSharePercent !== null && Math.abs(evaluation.totalCarbsSharePercent - 100) > 0.5) ||
            (evaluation.totalFatSharePercent !== null && Math.abs(evaluation.totalFatSharePercent - 100) > 0.5) ? (
            <span className="w-full text-[10px] text-[var(--titan-status-warning)]">
              O otimizador só aplica metas de P/C/G por refeição quando cada distribuição fecha 100%; enquanto isso, usa apenas as metas diárias e de energia.
            </span>
          ) : null}
          {(Math.abs((evaluation.totalProteinSharePercent ?? 100) - 100) > 0.5 ||
            Math.abs((evaluation.totalCarbsSharePercent ?? 100) - 100) > 0.5 ||
            Math.abs((evaluation.totalFatSharePercent ?? 100) - 100) > 0.5) && (
            <button
              type="button"
              onClick={() => {
                const sumP = evaluation.totalProteinSharePercent ?? 0;
                const sumC = evaluation.totalCarbsSharePercent ?? 0;
                const sumF = evaluation.totalFatSharePercent ?? 0;
                const norm = (val: number | null, s: number, fallback: number) =>
                  s > 0 ? Math.round((((val ?? 0) / s) * 100) * 10) / 10 : fallback;
                const next = evaluation.slots.map((slot) => ({
                  slotId: slot.slotId,
                  energySharePercent: slot.sharePercent,
                  proteinSharePercent: norm(slot.proteinSharePercent, sumP, slot.sharePercent),
                  carbsSharePercent: norm(slot.carbsSharePercent, sumC, slot.sharePercent),
                  fatSharePercent: norm(slot.fatSharePercent, sumF, slot.sharePercent),
                }));
                onChangeAllocations(next);
              }}
              className="text-[var(--titan-champagne)] underline"
            >
              Fechar 100% P/C/G
            </button>
          )}
        </div>
      )}

      <div className="space-y-2.5">
        {evaluation.slots.map((slot) => (
          <div
            key={slot.slotId}
            className="border-b border-[var(--titan-border-subtle)] pb-2.5 last:border-b-0 last:pb-0 space-y-2"
          >
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
              <div className="min-w-0">
                <p className="text-xs font-medium text-[var(--titan-text-primary)] truncate">
                  {slot.slotTime} · {slot.slotTitle}
                </p>
                <p className="text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
                  Atual {slot.actualKcal} kcal / Alvo {slot.targetKcal} kcal{' '}
                  <span
                    className={
                      Math.abs(slot.deltaKcal) <= 45
                        ? 'text-[var(--titan-status-success)]'
                        : 'text-[var(--titan-text-secondary)]'
                    }
                  >
                    ({slot.deltaKcal >= 0 ? `+${slot.deltaKcal}` : slot.deltaKcal})
                  </span>
                </p>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <BufferedNumberInput
                  min={0}
                  max={100}
                  step={1}
                  value={slot.sharePercent}
                  ariaLabel={`Percentual de energia para ${slot.slotTitle}`}
                  onCommit={(val) => handleShareChange(slot.slotId, 'energySharePercent', val)}
                  className="w-18 rounded-lg border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-2 font-mono-metric text-right text-[var(--titan-text-primary)]"
                />
                <span className="text-xs font-mono-metric text-[var(--titan-text-muted)]">%</span>
              </div>
            </div>

            {macroEnabled && (
              <div className="grid grid-cols-3 gap-2 text-[10px] font-mono-metric">
                <label className="text-[var(--titan-accent)]">
                  Prot. ({slot.targetProteinG ?? 0} g)
                  <BufferedNumberInput
                    min={0}
                    max={100}
                    step={1}
                    value={slot.proteinSharePercent ?? slot.sharePercent}
                    ariaLabel={`Percentual de proteína para ${slot.slotTitle}`}
                    onCommit={(val) => handleShareChange(slot.slotId, 'proteinSharePercent', val)}
                    className="mt-0.5 w-full rounded-lg border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] px-2 text-right text-[var(--titan-text-primary)]"
                  />
                </label>
                <label className="text-[var(--titan-info)]">
                  Carb. ({slot.targetCarbsG ?? 0} g)
                  <BufferedNumberInput
                    min={0}
                    max={100}
                    step={1}
                    value={slot.carbsSharePercent ?? slot.sharePercent}
                    ariaLabel={`Percentual de carboidratos para ${slot.slotTitle}`}
                    onCommit={(val) => handleShareChange(slot.slotId, 'carbsSharePercent', val)}
                    className="mt-0.5 w-full rounded-lg border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] px-2 text-right text-[var(--titan-text-primary)]"
                  />
                </label>
                <label className="text-[var(--titan-copper)]">
                  Gord. ({slot.targetFatG ?? 0} g)
                  <BufferedNumberInput
                    min={0}
                    max={100}
                    step={1}
                    value={slot.fatSharePercent ?? slot.sharePercent}
                    ariaLabel={`Percentual de gorduras para ${slot.slotTitle}`}
                    onCommit={(val) => handleShareChange(slot.slotId, 'fatSharePercent', val)}
                    className="mt-0.5 w-full rounded-lg border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] px-2 text-right text-[var(--titan-text-primary)]"
                  />
                </label>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
});
