import { memo } from 'react';
import { Sliders, ChevronUp } from 'lucide-react';
import type { ComposerMacroTotals, NutritionTargets } from '../../../domain/entities/nutrient';
import { formatKcal } from '@/src/shared/utils/formatters';

interface ComposerActionDockProps {
  planned: ComposerMacroTotals;
  targets: NutritionTargets;
  isOptimizing: boolean;
  onSimulateBalance: () => void;
  onJumpToBalance: () => void;
}

export const ComposerActionDock = memo(function ComposerActionDock({
  planned,
  targets,
  isOptimizing,
  onSimulateBalance,
  onJumpToBalance,
}: ComposerActionDockProps) {
  const deltaKcal = Math.round(planned.kcal - targets.kcal);

  return (
    <div
      role="region"
      aria-label="Resumo rápido do balanço nutricional"
      className="lg:hidden fixed inset-x-0 bottom-[calc(64px+env(safe-area-inset-bottom,0px))] md:bottom-0 z-30 border-t border-[var(--titan-border)] bg-[var(--titan-surface)] px-3 py-2"
    >
      <div className="mx-auto max-w-2xl flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={onJumpToBalance}
          className="min-h-[44px] flex-1 min-w-0 text-left flex items-center justify-between gap-2 pr-2"
        >
          <div className="min-w-0">
            <p className="text-xs font-mono-metric font-semibold text-[var(--titan-text-primary)] truncate">
              {formatKcal(Math.round(planned.kcal))} / {formatKcal(targets.kcal)} kcal{' '}
              <span
                className={
                  Math.abs(deltaKcal) <= 60
                    ? 'text-[var(--titan-status-success)]'
                    : deltaKcal > 0
                      ? 'text-[var(--titan-champagne)]'
                      : 'text-[var(--titan-info)]'
                }
              >
                ({deltaKcal >= 0 ? `+${deltaKcal}` : deltaKcal})
              </span>
            </p>
            <p className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] truncate">
              P {planned.proteinG.toFixed(0)}/{targets.proteinG}g · C {planned.carbsG.toFixed(0)}/{targets.carbsG}g · G{' '}
              {planned.fatG.toFixed(0)}/{targets.fatG}g
            </p>
          </div>
          <ChevronUp className="w-4 h-4 text-[var(--titan-text-muted)] shrink-0" aria-hidden="true" />
        </button>

        <button
          type="button"
          disabled={isOptimizing}
          onClick={onSimulateBalance}
          className="titan-button titan-button--primary !min-h-[44px] !px-3.5 !text-xs shrink-0 disabled:opacity-60"
        >
          <Sliders className="w-3.5 h-3.5" aria-hidden="true" />
          <span>{isOptimizing ? 'Calculando…' : 'Simular'}</span>
        </button>
      </div>
    </div>
  );
});
