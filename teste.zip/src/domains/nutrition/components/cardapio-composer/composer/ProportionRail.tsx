import { memo, useCallback, useDeferredValue, useEffect, useId, useMemo, useRef, useState } from 'react';
import { Lock, Plus, Scale, Search, Sliders, SlidersHorizontal, Split, Trash2, X } from 'lucide-react';
import { BufferedNumberInput } from '@/src/shared/ui/BufferedNumberInput';
import {
  ensureSharedFoodSearchIndexReady,
  getSharedFoodSearchIndex,
} from '../../../data/sources/food-search-index';
import { searchFoodIndex } from '../../../domain/rules/food-search';
import { useSharedFoodSearchVersion } from '../../../application/use-shared-food-search-version.ts';
import type {
  IngredientAdjustment,
  IngredientLockMode,
  IngredientQuantityStatus,
} from '../../../domain/entities/nutrient';
import {
  computeIngredientNutritionImpact,
  getEffectiveIngredientBounds,
  getScaledReferenceGrams,
  roundGramsHalf,
} from '../../../domain/rules/cardapio-composer-engine';

interface ProportionRailProps {
  ingredient: IngredientAdjustment;
  scaleFactor: number;
  showMacros?: boolean;
  disabled?: boolean;
  onUpdateIngredient: (
    patch: Partial<
      Pick<
        IngredientAdjustment,
        'currentQuantityG' | 'mode' | 'minQuantityG' | 'maxQuantityG' | 'quantityStatus'
      >
    >,
  ) => void;
  onReplaceComposite?: (replacements: Array<{ foodId: string; quantityG: number }>) => boolean;
  onRemove?: () => void;
}

const MODE_OPTIONS: ReadonlyArray<{
  mode: IngredientLockMode;
  label: string;
  shortLabel: string;
  icon: typeof Scale;
}> = [
  { mode: 'proportional', label: 'Proporcional ao rendimento', shortLabel: 'Prop.', icon: Scale },
  { mode: 'locked', label: 'Fixo (bloqueado no solver)', shortLabel: 'Fixo', icon: Lock },
  { mode: 'flexible', label: 'Flexível dentro da faixa', shortLabel: 'Flex.', icon: SlidersHorizontal },
];

export const ProportionRail = memo(function ProportionRail({
  ingredient,
  scaleFactor,
  showMacros = true,
  disabled = false,
  onUpdateIngredient,
  onReplaceComposite,
  onRemove,
}: ProportionRailProps) {
  const railRef = useRef<HTMLDivElement | null>(null);
  const [editingNumeric, setEditingNumeric] = useState(false);
  const [boundsOpen, setBoundsOpen] = useState(false);
  const [compositeOpen, setCompositeOpen] = useState(false);
  const [splitQuery, setSplitQuery] = useState('');
  const [splitDraftGrams, setSplitDraftGrams] = useState(120);
  const [splitRows, setSplitRows] = useState<Array<{ foodId: string; foodName: string; quantityG: number }>>([]);
  const [isDragging, setIsDragging] = useState(false);
  const catalogVersion = useSharedFoodSearchVersion();
  const labelId = useId();

  useEffect(() => {
    if (!compositeOpen) return;
    void ensureSharedFoodSearchIndexReady();
  }, [compositeOpen]);

  const deferredSplitQuery = useDeferredValue(splitQuery);
  const foodIndex = useMemo(
    () => (compositeOpen ? getSharedFoodSearchIndex() : null),
    [compositeOpen, catalogVersion],
  );
  const splitSearchResults = useMemo(
    () => (foodIndex && deferredSplitQuery.trim() ? searchFoodIndex(foodIndex, deferredSplitQuery, 8, { purpose: 'recipe-ingredient' }) : []),
    [deferredSplitQuery, foodIndex],
  );

  const impact = computeIngredientNutritionImpact(ingredient, scaleFactor);
  const refG = getScaledReferenceGrams(ingredient, scaleFactor);
  const bounds = getEffectiveIngredientBounds(ingredient, scaleFactor);
  const span = Math.max(1, bounds.maxG - bounds.minG);
  const activeG =
    ingredient.currentQuantityG !== null && Number.isFinite(ingredient.currentQuantityG)
      ? ingredient.currentQuantityG
      : (refG ?? bounds.minG);

  const clampedActive = Math.max(bounds.minG, Math.min(bounds.maxG, activeG));
  const activePct = ((clampedActive - bounds.minG) / span) * 100;
  const refPct = refG !== null ? Math.max(0, Math.min(100, ((refG - bounds.minG) / span) * 100)) : activePct;

  const isLocked = ingredient.mode === 'locked' || disabled;
  const deltaG = refG !== null ? Number((clampedActive - refG).toFixed(1)) : 0;
  const deltaPct = refG !== null && refG > 0 ? Math.round(((clampedActive - refG) / refG) * 100) : 0;

  const emitQuantity = useCallback(
    (nextG: number) => {
      onUpdateIngredient({
        currentQuantityG: nextG,
        quantityStatus: 'known',
        mode: ingredient.mode === 'proportional' ? 'flexible' : ingredient.mode,
      });
    },
    [ingredient.mode, onUpdateIngredient],
  );

  const updateFromClientX = useCallback(
    (clientX: number) => {
      if (isLocked || !railRef.current || ingredient.quantityStatus !== 'known') return;
      const rect = railRef.current.getBoundingClientRect();
      if (rect.width <= 0) return;
      const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
      let rawG = bounds.minG + ratio * span;
      if (refG !== null && Math.abs(rawG - refG) <= 2) {
        rawG = refG;
      } else {
        rawG = roundGramsHalf(rawG);
      }
      const nextG = Math.max(bounds.minG, Math.min(bounds.maxG, rawG));
      if (nextG !== clampedActive) {
        emitQuantity(nextG);
      }
    },
    [bounds.maxG, bounds.minG, clampedActive, emitQuantity, ingredient.quantityStatus, isLocked, refG, span],
  );

  // Honest non-numeric state for "to_taste" and "missing" ingredients
  if (ingredient.quantityStatus !== 'known') {
    return (
      <div className="py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-sm font-medium text-[var(--titan-text-primary)] truncate">
            {impact.foodName}
          </p>
          <p className="text-[11px] text-[var(--titan-text-muted)]">
            {ingredient.quantityStatus === 'to_taste'
              ? 'Tempero / preparo a gosto · mantido fora do cálculo numérico'
              : 'Quantidade pendente · informe peso em gramas para incluir no cálculo'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => emitQuantity(100)}
            className="titan-button titan-button--secondary !min-h-[40px] !px-3 !text-xs"
          >
            Definir gramas
          </button>
          <span className="text-xs font-mono-metric text-[var(--titan-text-muted)]">
            {ingredient.quantityStatus === 'to_taste' ? 'a gosto' : 'Quantidade pendente'}
          </span>
          {onRemove && (
            <button
              type="button"
              onClick={onRemove}
              aria-label={`Remover ${impact.foodName}`}
              className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-status-error)]"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    );
  }

  const fillStartPct = Math.min(refPct, activePct);
  const fillWidthPct = Math.abs(activePct - refPct);
  const isIncreased = clampedActive >= (refG ?? clampedActive);

  return (
    <div className="py-3.5 space-y-2.5">
      {/* 5-Column Analytical Row on Desktop (xl+), cleanly stacked on smaller widths */}
      <div className="grid grid-cols-1 xl:grid-cols-[minmax(190px,1.25fr)_74px_102px_minmax(260px,1.8fr)_minmax(148px,0.9fr)] gap-3 items-center">
        {/* Col 1: Food identity + authoritative source */}
        <div className="min-w-0">
          <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5">
            <span id={labelId} className="text-sm font-medium text-[var(--titan-text-primary)]">
              {impact.foodName}
            </span>
          </div>
          <p className="text-[11px] font-mono-metric text-[var(--titan-text-muted)] mt-0.5">
            {impact.calculable
              ? `${impact.sourceId} · ${impact.sourceRecordId}`
              : 'Fonte não resolvida'}
            {ingredient.isCompositeDish ? ' · Prato composto' : ''}
          </p>
          <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px]">
            <button
              type="button"
              onClick={() => setBoundsOpen((prev) => !prev)}
              aria-expanded={boundsOpen}
              className="inline-flex items-center gap-1 text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]"
            >
              <Sliders className="w-3 h-3" aria-hidden="true" />
              <span>Faixa {bounds.minG}–{bounds.maxG} g</span>
            </button>

            {ingredient.isCompositeDish && onReplaceComposite && (
              <button
                type="button"
                onClick={() => setCompositeOpen((prev) => !prev)}
                aria-expanded={compositeOpen}
                className="inline-flex items-center gap-1 text-[var(--titan-champagne)] hover:underline"
              >
                <Split className="w-3 h-3" aria-hidden="true" />
                <span>Escolher alimentos separados</span>
              </button>
            )}
          </div>
        </div>

        {/* Col 2: Scaled Base Reference q_i^{ref} */}
        <div className="flex xl:block items-baseline justify-between font-mono-metric text-xs">
          <span className="xl:hidden text-[11px] text-[var(--titan-text-muted)]">Base escalada</span>
          <div>
            <p className="font-medium text-[var(--titan-text-secondary)]">
              {refG !== null ? `${refG} g` : '—'}
            </p>
            {deltaG !== 0 && (
              <p
                className={`text-[10px] ${
                  deltaG > 0 ? 'text-[var(--titan-champagne)]' : 'text-[var(--titan-info)]'
                }`}
              >
                {deltaG > 0 ? `+${deltaG}` : deltaG} g ({deltaPct > 0 ? `+${deltaPct}%` : `${deltaPct}%`})
              </p>
            )}
          </div>
        </div>

        {/* Col 3: Active Editable Weight x_i */}
        <div className="flex items-center justify-between xl:justify-start gap-1.5">
          <span className="xl:hidden text-[11px] text-[var(--titan-text-muted)]">Atual</span>
          {editingNumeric ? (
            <div className="flex items-center gap-1">
              <BufferedNumberInput
                min={bounds.minG}
                max={bounds.maxG}
                step={0.5}
                value={clampedActive}
                ariaLabel={`Quantidade em gramas para ${impact.foodName}`}
                onCommit={(val) => {
                  emitQuantity(val);
                  setEditingNumeric(false);
                }}
                className="w-20 px-2 rounded-lg border border-[var(--titan-champagne)]/60 bg-[var(--titan-surface-inset)] font-mono-metric text-right text-[var(--titan-text-primary)]"
              />
              <button
                type="button"
                onClick={() => setEditingNumeric(false)}
                className="titan-button titan-button--ghost !min-h-[38px] !px-2 !text-[11px]"
              >
                OK
              </button>
            </div>
          ) : (
            <button
              type="button"
              disabled={isLocked}
              onClick={() => setEditingNumeric(true)}
              title="Editar gramas exatas"
              className="min-h-[44px] px-2.5 rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] font-mono-metric text-sm font-semibold text-[var(--titan-text-primary)] hover:border-[var(--titan-champagne)]/50 disabled:opacity-70"
            >
              {clampedActive} g
            </button>
          )}
        </div>

        {/* Col 4: Calibrated ProportionRail + 3-State Mode Toggle */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 min-w-0">
          <div
            ref={railRef}
            role="slider"
            tabIndex={isLocked ? -1 : 0}
            aria-labelledby={labelId}
            aria-valuemin={bounds.minG}
            aria-valuemax={bounds.maxG}
            aria-valuenow={clampedActive}
            aria-valuetext={`${clampedActive} gramas${refG !== null ? `, base ${refG} gramas` : ''}`}
            aria-disabled={isLocked}
            onPointerDown={(event) => {
              if (isLocked) return;
              event.currentTarget.setPointerCapture(event.pointerId);
              setIsDragging(true);
              updateFromClientX(event.clientX);
            }}
            onPointerMove={(event) => {
              if (!isDragging || isLocked) return;
              updateFromClientX(event.clientX);
            }}
            onPointerUp={(event) => {
              if (isDragging) {
                if (event.currentTarget.hasPointerCapture(event.pointerId)) {
                  event.currentTarget.releasePointerCapture(event.pointerId);
                }
                setIsDragging(false);
              }
            }}
            onPointerCancel={() => setIsDragging(false)}
            onKeyDown={(event) => {
              if (isLocked) return;
              const step = event.shiftKey ? 10 : 1;
              if (event.key === 'ArrowRight' || event.key === 'ArrowUp') {
                event.preventDefault();
                emitQuantity(Math.min(bounds.maxG, roundGramsHalf(clampedActive + step)));
              } else if (event.key === 'ArrowLeft' || event.key === 'ArrowDown') {
                event.preventDefault();
                emitQuantity(Math.max(bounds.minG, roundGramsHalf(clampedActive - step)));
              } else if (event.key === 'Home') {
                event.preventDefault();
                emitQuantity(bounds.minG);
              } else if (event.key === 'End') {
                event.preventDefault();
                emitQuantity(bounds.maxG);
              } else if (event.key === '0' && refG !== null) {
                event.preventDefault();
                emitQuantity(refG);
              }
            }}
            className={`relative flex-1 min-w-[140px] min-h-[44px] flex items-center select-none touch-none rounded-xl px-2.5 border transition-colors ${
              isLocked
                ? 'border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)]/60 opacity-65 cursor-not-allowed'
                : isDragging
                  ? 'border-[var(--titan-champagne)]/70 bg-[var(--titan-surface-inset)] cursor-grabbing'
                  : 'border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] hover:border-[var(--titan-accent)]/40 cursor-grab'
            }`}
          >
            <div className="relative w-full h-5 flex items-center">
              <svg
                aria-hidden="true"
                className="absolute inset-0 w-full h-full pointer-events-none"
                preserveAspectRatio="none"
                viewBox="0 0 200 20"
              >
                <line x1="0" y1="10" x2="200" y2="10" stroke="rgba(193, 204, 196, 0.16)" strokeWidth="1.5" />
                {[0, 25, 50, 75, 100, 125, 150, 175, 200].map((x) => (
                  <line
                    key={x}
                    x1={x}
                    y1={x % 50 === 0 ? 5 : 7}
                    x2={x}
                    y2={x % 50 === 0 ? 15 : 13}
                    stroke="rgba(183, 193, 186, 0.22)"
                    strokeWidth="1"
                  />
                ))}
              </svg>

              {fillWidthPct > 0.4 && (
                <div
                  aria-hidden="true"
                  style={{
                    left: `${fillStartPct}%`,
                    width: `${fillWidthPct}%`,
                  }}
                  className={`absolute h-1.5 rounded-sm transition-[left,width] duration-75 ${
                    isIncreased ? 'bg-[var(--titan-champagne)]/75' : 'bg-[var(--titan-info)]/75'
                  }`}
                />
              )}

              <div
                aria-hidden="true"
                style={{ left: `${refPct}%` }}
                title={refG !== null ? `Referência escalada: ${refG} g` : undefined}
                className="absolute top-0.5 bottom-0.5 w-[2px] -translate-x-1/2 bg-[var(--titan-text-primary)]/70"
              />

              <div
                aria-hidden="true"
                style={{ left: `${activePct}%` }}
                className={`absolute -translate-x-1/2 w-3.5 h-5 rounded-[4px] border shadow-sm transition-transform duration-75 ${
                  isLocked
                    ? 'bg-[var(--titan-surface-elevated)] border-[var(--titan-text-muted)]'
                    : isDragging
                      ? 'scale-110 bg-[var(--titan-champagne)] border-[var(--titan-text-primary)]'
                      : 'bg-[var(--titan-accent)] border-[var(--titan-bg-canvas)]'
                }`}
              />
            </div>
          </div>

          <div
            role="group"
            aria-label={`Modo de ajuste para ${impact.foodName}`}
            className="titan-segmented shrink-0"
          >
            {MODE_OPTIONS.map((opt) => {
              const Icon = opt.icon;
              const active = ingredient.mode === opt.mode;
              return (
                <button
                  key={opt.mode}
                  type="button"
                  aria-pressed={active}
                  title={opt.label}
                  onClick={() => onUpdateIngredient({ mode: opt.mode })}
                  className={`titan-segment !min-h-[38px] !px-2 !text-[11px] ${active ? 'is-active' : ''}`}
                >
                  <Icon className="w-3 h-3" aria-hidden="true" />
                  <span>{opt.shortLabel}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Col 5: Nutritional Impact + Remove */}
        <div className="flex items-center justify-between xl:justify-end gap-2">
          <div className="text-left xl:text-right font-mono-metric min-w-0">
            {impact.calculable ? (
              <>
                <p className="text-xs font-semibold text-[var(--titan-text-primary)]">
                  {Math.round(impact.activeMacros.kcal)} kcal
                  {Math.abs(impact.deltaMacros.kcal) >= 1 && (
                    <span
                      className={`ml-1 text-[11px] ${
                        impact.deltaMacros.kcal > 0
                          ? 'text-[var(--titan-champagne)]'
                          : 'text-[var(--titan-info)]'
                      }`}
                    >
                      ({impact.deltaMacros.kcal > 0 ? '+' : ''}
                      {Math.round(impact.deltaMacros.kcal)})
                    </span>
                  )}
                </p>
                {showMacros && (
                  <p className="text-[11px] text-[var(--titan-text-muted)]">
                    P {impact.activeMacros.proteinG.toFixed(1)} · C {impact.activeMacros.carbsG.toFixed(1)} · G {impact.activeMacros.fatG.toFixed(1)}
                  </p>
                )}
              </>
            ) : (
              <p className="text-[11px] text-[var(--titan-status-warning)]">{impact.reason}</p>
            )}
          </div>

          {onRemove && (
            <button
              type="button"
              onClick={onRemove}
              aria-label={`Remover ${impact.foodName}`}
              className="min-w-[40px] min-h-[40px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-status-error)] hover:bg-[rgba(210,143,135,0.08)] shrink-0"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Expandable Ingredient Bounds & Status Config */}
      {boundsOpen && (
        <div className="rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] p-3 grid grid-cols-1 sm:grid-cols-3 gap-2.5 items-end">
          <label className="text-[11px] text-[var(--titan-text-muted)]">
            Porção mínima (g)
            <BufferedNumberInput
              min={1}
              max={bounds.maxG}
              step={5}
              value={bounds.minG}
              onCommit={(minQuantityG) =>
                onUpdateIngredient({
                  minQuantityG,
                  currentQuantityG: Math.max(minQuantityG, clampedActive),
                })
              }
              className="mt-1 w-full rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2.5 font-mono-metric text-[var(--titan-text-primary)]"
            />
          </label>
          <label className="text-[11px] text-[var(--titan-text-muted)]">
            Porção máxima (g)
            <BufferedNumberInput
              min={bounds.minG}
              max={2000}
              step={5}
              value={bounds.maxG}
              onCommit={(maxQuantityG) =>
                onUpdateIngredient({
                  maxQuantityG,
                  currentQuantityG: Math.min(maxQuantityG, clampedActive),
                })
              }
              className="mt-1 w-full rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2.5 font-mono-metric text-[var(--titan-text-primary)]"
            />
          </label>
          <label className="text-[11px] text-[var(--titan-text-muted)]">
            Estado da quantidade
            <select
              value={ingredient.quantityStatus}
              onChange={(event) => {
                const status = event.target.value as IngredientQuantityStatus;
                onUpdateIngredient({
                  quantityStatus: status,
                  currentQuantityG: status === 'known' ? clampedActive : null,
                });
                if (status !== 'known') setBoundsOpen(false);
              }}
              className="mt-1 w-full min-h-[42px] rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2 text-xs text-[var(--titan-text-primary)]"
            >
              <option value="known">Peso numérico (calculável)</option>
              <option value="to_taste">A gosto (sem estimativa falsa)</option>
              <option value="missing">Pendente (sem peso definido)</option>
            </select>
          </label>
        </div>
      )}

      {/* Honest Composite Dish Decomposition Workflow (Explicit TBCA/OFF Selection Only) */}
      {compositeOpen && onReplaceComposite && (
        <div className="rounded-xl border border-[var(--titan-champagne)]/40 bg-[var(--titan-surface-inset)] p-3.5 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-xs font-semibold text-[var(--titan-text-primary)]">
                Substituir prato composto por alimentos separados
              </p>
              <p className="text-[11px] text-[var(--titan-text-secondary)]">
                O TITAN nunca inventa ingredientes implícitos. Selecione os alimentos reais TBCA/OFF que compõem este prato.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setCompositeOpen(false)}
              aria-label="Fechar substituição de prato composto"
              className="min-w-[36px] min-h-[36px] inline-flex items-center justify-center rounded-lg text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-[1fr_100px] gap-2 items-end">
            <label className="text-[11px] text-[var(--titan-text-secondary)]">
              Buscar alimento para adicionar à substituição
              <div className="relative mt-1">
                <Search className="w-3.5 h-3.5 text-[var(--titan-text-muted)] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="search"
                  value={splitQuery}
                  onChange={(event) => setSplitQuery(event.target.value)}
                  placeholder="Ex.: arroz cozido, feijão carioca, bife grelhado"
                  className="w-full rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] pl-8 pr-2.5 text-xs text-[var(--titan-text-primary)]"
                />
              </div>
            </label>
            <label className="text-[11px] text-[var(--titan-text-secondary)]">
              Gramas
              <BufferedNumberInput
                min={1}
                max={2000}
                step={5}
                value={splitDraftGrams}
                onCommit={setSplitDraftGrams}
                className="mt-1 w-full rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2 font-mono-metric text-[var(--titan-text-primary)]"
              />
            </label>
          </div>

          {splitQuery.trim() && splitSearchResults.length > 0 && (
            <div className="max-h-40 overflow-y-auto rounded-lg border border-[var(--titan-border-subtle)] bg-[var(--titan-bg-canvas)] divide-y divide-[var(--titan-border-subtle)]">
              {splitSearchResults.map((food) => (
                <button
                  key={food.food_id}
                  type="button"
                  onClick={() => {
                    setSplitRows((prev) => [
                      ...prev,
                      { foodId: food.food_id, foodName: food.name, quantityG: splitDraftGrams },
                    ]);
                    setSplitQuery('');
                  }}
                  className="w-full px-3 py-2 text-left flex items-center justify-between gap-2 hover:bg-[var(--titan-surface)] text-xs"
                >
                  <span className="truncate text-[var(--titan-text-primary)]">{food.name}</span>
                  <span className="inline-flex items-center gap-1 text-[11px] font-mono-metric text-[var(--titan-champagne)] shrink-0">
                    <Plus className="w-3 h-3" /> {splitDraftGrams} g
                  </span>
                </button>
              ))}
            </div>
          )}

          {splitRows.length > 0 && (
            <div className="space-y-1.5">
              <p className="text-[11px] font-medium text-[var(--titan-text-secondary)]">
                Alimentos selecionados ({splitRows.length}):
              </p>
              <div className="space-y-1">
                {splitRows.map((row, idx) => (
                  <div
                    key={`${row.foodId}-${idx}`}
                    className="flex items-center justify-between gap-2 rounded-lg bg-[var(--titan-bg-canvas)] px-2.5 py-1.5 text-xs"
                  >
                    <span className="truncate text-[var(--titan-text-primary)]">{row.foodName}</span>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-mono-metric text-[var(--titan-text-secondary)]">
                        {row.quantityG} g
                      </span>
                      <button
                        type="button"
                        onClick={() => setSplitRows((prev) => prev.filter((_, i) => i !== idx))}
                        aria-label={`Remover ${row.foodName}`}
                        className="text-[var(--titan-text-muted)] hover:text-[var(--titan-status-error)]"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={() => {
                  if (
                    onReplaceComposite(
                      splitRows.map((r) => ({ foodId: r.foodId, quantityG: r.quantityG })),
                    )
                  ) {
                    setSplitRows([]);
                    setCompositeOpen(false);
                  }
                }}
                className="titan-button titan-button--primary !min-h-[40px] !px-4 !text-xs w-full"
              >
                Substituir "{impact.foodName}" pelos alimentos selecionados
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
});
