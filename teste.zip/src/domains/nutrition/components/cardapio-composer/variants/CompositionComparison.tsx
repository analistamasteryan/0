import { memo, useMemo, useState } from 'react';
import { X } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import type {
  CardapioPlan,
  ComposerDayPlan,
} from '../../../domain/entities/nutrient';
import {
  buildOriginalBaselineDayPlan,
  computeCompositionDiff,
  computeWeeklyPlanSummary,
} from '../../../domain/rules/cardapio-composer-engine';

interface CompositionComparisonProps {
  plans: readonly CardapioPlan[];
  activePlan: CardapioPlan;
  activeDay: ComposerDayPlan;
  activeDateKey: string;
  onClose: () => void;
}

export const CompositionComparison = memo(function CompositionComparison({
  plans,
  activePlan,
  activeDay,
  activeDateKey,
  onClose,
}: CompositionComparisonProps) {
  const otherPlans = plans.filter((p) => p.id !== activePlan.id);
  const [targetRef, setTargetRef] = useState<string>(() => {
    if (activePlan.variants[0]) return `var:${activePlan.variants[0].id}`;
    if (otherPlans[0]) return `plan:${otherPlans[0].id}`;
    return 'baseline:1x';
  });
  const [selectedCompareDate, setSelectedCompareDate] = useState<string>(activeDateKey);

  const comparedPlan = useMemo(() => {
    if (!targetRef.startsWith('plan:')) return null;
    const id = targetRef.slice(5);
    return plans.find((p) => p.id === id) ?? null;
  }, [plans, targetRef]);

  const comparedPlanDates = useMemo(
    () => (comparedPlan ? Object.keys(comparedPlan.days).sort() : []),
    [comparedPlan],
  );

  const candidateSelection = useMemo(() => {
    if (targetRef === 'baseline:1x') {
      return {
        label: 'Receitas originais (1× sem desvios)',
        dayPlan: buildOriginalBaselineDayPlan(activeDay),
      };
    }
    if (targetRef.startsWith('var:')) {
      const id = targetRef.slice(4);
      const variant = activePlan.variants.find((v) => v.id === id);
      if (variant) {
        return {
          label: `Variante: ${variant.name}`,
          dayPlan: variant.dayPlan,
        };
      }
    }
    if (comparedPlan) {
      const resolvedKey =
        (comparedPlan.days[selectedCompareDate] ? selectedCompareDate : undefined) ??
        (comparedPlan.days[activeDateKey] ? activeDateKey : undefined) ??
        comparedPlanDates[0];
      const day = resolvedKey ? comparedPlan.days[resolvedKey] : undefined;
      if (day) {
        return {
          label: `${comparedPlan.name} (${resolvedKey})`,
          dayPlan: day,
        };
      }
    }
    return {
      label: 'Receitas originais (1×)',
      dayPlan: buildOriginalBaselineDayPlan(activeDay),
    };
  }, [activeDateKey, activeDay, activePlan.variants, comparedPlan, comparedPlanDates, selectedCompareDate, targetRef]);

  const diff = useMemo(
    () => computeCompositionDiff(activeDay, candidateSelection.dayPlan),
    [activeDay, candidateSelection.dayPlan],
  );

  const weeklySummary = useMemo(() => {
    if (!comparedPlan) return null;
    return {
      active: computeWeeklyPlanSummary(activePlan),
      compared: computeWeeklyPlanSummary(comparedPlan),
    };
  }, [activePlan, comparedPlan]);

  const fmtSigned = (value: number, unit: string, decimals = 0) => {
    const abs = decimals > 0 ? Math.abs(value).toFixed(decimals) : Math.round(Math.abs(value));
    const sign = value > 0 ? '+' : value < 0 ? '−' : '';
    return `${sign}${abs} ${unit}`;
  };

  return (
    <Surface
      data-elevation="2"
      aria-label="Comparação lado a lado"
      className="p-4 sm:p-5 space-y-4 border-[var(--titan-accent)]/40"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <p className="titan-eyebrow">Comparação estrutural</p>
          <h2 className="text-lg font-semibold text-[var(--titan-text-primary)] mt-0.5">
            Comparar planos, variantes e base original
          </h2>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            Base atual: {activePlan.name} ({activeDateKey})
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <select
            aria-label="Selecionar plano ou variante para comparar"
            value={targetRef}
            onChange={(event) => setTargetRef(event.target.value)}
            className="min-h-[44px] rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 text-sm text-[var(--titan-text-primary)]"
          >
            <option value="baseline:1x">Receitas originais (1× do dia atual)</option>
            {otherPlans.map((plan) => (
              <option key={plan.id} value={`plan:${plan.id}`}>
                Plano: {plan.name}
              </option>
            ))}
            {activePlan.variants.map((variant) => (
              <option key={variant.id} value={`var:${variant.id}`}>
                Variante: {variant.name}
              </option>
            ))}
          </select>

          {comparedPlan && comparedPlanDates.length > 0 && (
            <select
              aria-label="Dia do plano comparado"
              value={
                comparedPlan.days[selectedCompareDate]
                  ? selectedCompareDate
                  : (comparedPlan.days[activeDateKey] ? activeDateKey : comparedPlanDates[0]!)
              }
              onChange={(event) => setSelectedCompareDate(event.target.value)}
              className="min-h-[44px] rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 font-mono-metric text-xs text-[var(--titan-text-primary)]"
            >
              {comparedPlanDates.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          )}

          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar comparação"
            className="min-w-[44px] min-h-[44px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Side-by-side Macro Totals & Deltas */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 rounded-2xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] p-3.5 font-mono-metric">
        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            Atual · {activePlan.name}
          </p>
          <p className="text-base font-semibold text-[var(--titan-text-primary)] mt-1">
            {Math.round(diff.baselineMacros.kcal)} kcal
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            P {diff.baselineMacros.proteinG.toFixed(0)} g · C {diff.baselineMacros.carbsG.toFixed(0)} g · G{' '}
            {diff.baselineMacros.fatG.toFixed(0)} g
          </p>
          <p className="text-[11px] text-[var(--titan-text-muted)] mt-1">
            Desvio D: {diff.baselineDeviationPercent.toFixed(1)}% · Cobertura {diff.baselineCoveragePercent.toFixed(0)}% ·{' '}
            {diff.baselineSources.join(', ') || '—'}
          </p>
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-champagne)]">
            Comparado · {candidateSelection.label}
          </p>
          <p className="text-base font-semibold text-[var(--titan-text-primary)] mt-1">
            {Math.round(diff.candidateMacros.kcal)} kcal
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            P {diff.candidateMacros.proteinG.toFixed(0)} g · C {diff.candidateMacros.carbsG.toFixed(0)} g · G{' '}
            {diff.candidateMacros.fatG.toFixed(0)} g
          </p>
          <p className="text-[11px] text-[var(--titan-text-muted)] mt-1">
            Desvio D: {diff.candidateDeviationPercent.toFixed(1)}% · Cobertura {diff.candidateCoveragePercent.toFixed(0)}% ·{' '}
            {diff.candidateSources.join(', ') || '—'}
          </p>
        </div>

        <div>
          <p className="text-[10px] uppercase tracking-[0.08em] text-[var(--titan-text-muted)]">
            Diferença líquida (Comparado − Atual)
          </p>
          <p className="text-base font-semibold text-[var(--titan-champagne)] mt-1">
            {fmtSigned(diff.deltaMacros.kcal, 'kcal')}
          </p>
          <p className="text-xs text-[var(--titan-text-secondary)]">
            P {fmtSigned(diff.deltaMacros.proteinG, 'g')} · C {fmtSigned(diff.deltaMacros.carbsG, 'g')} · G{' '}
            {fmtSigned(diff.deltaMacros.fatG, 'g')}
          </p>
          {weeklySummary && (
            <p className="text-[11px] text-[var(--titan-text-muted)] mt-1">
              Média {weeklySummary.compared.dayCount}d: {Math.round(weeklySummary.compared.avgMacros.kcal)} vs{' '}
              {Math.round(weeklySummary.active.avgMacros.kcal)} kcal/dia
            </p>
          )}
        </div>
      </div>

      {/* Per-Meal Slot Side-by-Side Comparison */}
      {diff.slotDiffs.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Comparação por refeição do dia
          </h3>
          <div className="rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] divide-y divide-[var(--titan-border-subtle)]">
            {diff.slotDiffs.map((slotRow) => (
              <div
                key={slotRow.slotId}
                className="px-3 py-2.5 grid grid-cols-1 sm:grid-cols-[minmax(0,1.2fr)_1fr_1fr_auto] gap-2 items-center text-xs"
              >
                <div className="min-w-0">
                  <p className="font-medium text-[var(--titan-text-primary)] truncate">
                    {slotRow.slotTime} · {slotRow.slotTitle}
                  </p>
                  <p className="text-[11px] text-[var(--titan-text-muted)] truncate">
                    {slotRow.baselineRecipeNames.join(' + ') || '—'} → {slotRow.candidateRecipeNames.join(' + ') || '—'}
                  </p>
                </div>
                <span className="font-mono-metric text-[var(--titan-text-secondary)]">
                  Atual: {slotRow.baselineKcal} kcal · P {slotRow.baselineProteinG} g
                </span>
                <span className="font-mono-metric text-[var(--titan-text-primary)]">
                  Comp.: {slotRow.candidateKcal} kcal · P {slotRow.candidateProteinG} g
                </span>
                <span
                  className={`font-mono-metric font-semibold text-right ${
                    slotRow.deltaKcal > 0
                      ? 'text-[var(--titan-champagne)]'
                      : slotRow.deltaKcal < 0
                        ? 'text-[var(--titan-info)]'
                        : 'text-[var(--titan-text-muted)]'
                  }`}
                >
                  {slotRow.deltaKcal === 0
                    ? '0 kcal'
                    : `${slotRow.deltaKcal > 0 ? '+' : '−'}${Math.abs(slotRow.deltaKcal)} kcal`}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Added / Removed Recipes + Ingredient Gram Diffs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Diferenças por alimento (gramas)
          </h3>
          <div className="max-h-60 overflow-y-auto rounded-xl border border-[var(--titan-border-subtle)] bg-[var(--titan-surface-inset)] divide-y divide-[var(--titan-border-subtle)]">
            {diff.ingredientDiffs.filter((row) => row.status !== 'unchanged').length === 0 ? (
              <p className="p-3 text-xs text-[var(--titan-text-muted)]">
                Nenhuma diferença de peso entre os ingredientes selecionados.
              </p>
            ) : (
              diff.ingredientDiffs
                .filter((row) => row.status !== 'unchanged')
                .map((row) => (
                  <div
                    key={row.foodId}
                    className="px-3 py-2 flex items-center justify-between gap-2 text-xs"
                  >
                    <span className="text-[var(--titan-text-primary)] truncate">{row.foodName}</span>
                    <span className="font-mono-metric text-[var(--titan-text-secondary)] shrink-0">
                      {row.baselineGrams} g → {row.candidateGrams} g{' '}
                      <strong
                        className={
                          row.deltaGrams > 0
                            ? 'text-[var(--titan-champagne)]'
                            : 'text-[var(--titan-info)]'
                        }
                      >
                        ({row.deltaGrams > 0 ? `+${row.deltaGrams}` : row.deltaGrams} g)
                      </strong>
                    </span>
                  </div>
                ))
            )}
          </div>
        </div>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
              Receitas adicionadas / removidas
            </h3>
            {diff.addedRecipes.length === 0 && diff.removedRecipes.length === 0 ? (
              <p className="text-xs text-[var(--titan-text-muted)]">
                Mesmas receitas nos dois cenários; apenas as quantidades variam.
              </p>
            ) : (
              <div className="text-xs space-y-1">
                {diff.addedRecipes.map((name) => (
                  <p key={`add-${name}`} className="text-[var(--titan-status-success)]">
                    + {name}
                  </p>
                ))}
                {diff.removedRecipes.map((name) => (
                  <p key={`rem-${name}`} className="text-[var(--titan-status-error)]">
                    − {name}
                  </p>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-1.5 pt-2 border-t border-[var(--titan-border-subtle)]">
            <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
              Micronutrientes quantificados
            </h3>
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono-metric">
              {diff.micronutrientDeltas.map((m) => (
                <div
                  key={m.nutrientId}
                  className="flex items-baseline justify-between border-b border-[var(--titan-border-subtle)] pb-1"
                >
                  <span className="text-[var(--titan-text-muted)]">{m.label}</span>
                  <span className="text-[var(--titan-text-primary)]">
                    {m.baselineValue !== null ? m.baselineValue.toFixed(1) : 'NA'} →{' '}
                    {m.candidateValue !== null ? m.candidateValue.toFixed(1) : 'NA'} {m.unit}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Surface>
  );
});
