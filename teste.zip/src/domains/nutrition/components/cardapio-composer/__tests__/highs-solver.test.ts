import assert from 'node:assert/strict';
import {
  solveDiscreteSubstitutionsWithHighsMIP,
  solveNutritionalBalanceWithHighsQP,
} from '../../../application/highs-nutrition-solver.ts';
import {
  buildDefaultMealAllocations,
  buildInitialComposerPlans,
  computeDayNutrition,
} from '../../../domain/rules/cardapio-composer-engine.ts';
import { RECIPE_CATALOG } from '../../../data/recipes/recipe-catalog.ts';
import { isEligibleRecipeTemplate } from '../../../domain/rules/recipe-engine.ts';
import type { ComposerDayPlan } from '../../../domain/entities/nutrient.ts';

function buildCanonicalVerifiedDay(): ComposerDayPlan {
  return {
    dateKey: '2026-11-26',
    slots: [
      {
        id: 'slot-cafe',
        time: '08:00',
        title: 'Café da manhã',
        recipes: [
          {
            id: 'rec-canon-1',
            name: 'Ovos mexidos e pão integral',
            category: 'cafe',
            baseServings: 1,
            targetServings: 1,
            adjustmentMode: 'flexible',
            ingredients: [
              { id: 'ing-ovo', foodId: 'tbca-ovo-mexido', baseQuantityG: 160, currentQuantityG: 160, quantityStatus: 'known', mode: 'flexible' },
              { id: 'ing-pao', foodId: 'tbca-pao-integral', baseQuantityG: 90, currentQuantityG: 90, quantityStatus: 'known', mode: 'flexible' },
            ],
          },
        ],
      },
      {
        id: 'slot-lanche',
        time: '16:00',
        title: 'Lanche',
        recipes: [
          {
            id: 'rec-canon-2',
            name: 'Banana prata e ovo',
            category: 'lanche',
            baseServings: 1,
            targetServings: 1,
            adjustmentMode: 'flexible',
            ingredients: [
              { id: 'ing-ban', foodId: 'tbca-banana-prata', baseQuantityG: 150, currentQuantityG: 150, quantityStatus: 'known', mode: 'flexible' },
              { id: 'ing-ovo-2', foodId: 'tbca-ovo-mexido', baseQuantityG: 120, currentQuantityG: 120, quantityStatus: 'known', mode: 'flexible' },
            ],
          },
        ],
      },
    ],
  };
}

async function main() {
  const verifiedDay = buildCanonicalVerifiedDay();
  const verifiedTargets = {
    kcal: 900,
    proteinG: 52,
    carbsG: 95,
    fatG: 32,
    kcalMin: 820,
    kcalMax: 980,
    sourceLabel: 'Meta verificada HiGHS',
  };

  const verifiedAllocations = buildDefaultMealAllocations(verifiedDay.slots).map((a) => ({
    ...a,
    proteinSharePercent: a.energySharePercent,
  }));
  const qpProposal = await solveNutritionalBalanceWithHighsQP(verifiedDay, verifiedTargets, {
    goalFocus: 'balanced',
    mealAllocations: verifiedAllocations,
  });

  assert.equal(qpProposal.solverEngine, 'HiGHS QP (WASM)');
  assert.ok(
    qpProposal.certificate === 'optimal' || qpProposal.certificate === 'feasible',
    `Expected optimal/feasible certificate on verified TBCA plan, got ${qpProposal.certificate}`,
  );
  assert.ok(qpProposal.changes.length > 0, 'QP should evaluate flexible variables');

  const beforeDist = Math.abs(qpProposal.beforeMacros.kcal - verifiedTargets.kcal);
  const afterDist = Math.abs(qpProposal.afterMacros.kcal - verifiedTargets.kcal);
  assert.ok(
    afterDist <= beforeDist + 10,
    `Expected HiGHS QP to stay at or reduce kcal gap (before=${beforeDist}, after=${afterDist})`,
  );

  for (const ch of qpProposal.changes) {
    assert.ok(ch.proposedQuantityG > 0, 'Proposed quantity must be positive');
  }

  // Legacy initial plan contains unverified/partial-label items and must intentionally downgrade certificate to approximate.
  const plans = buildInitialComposerPlans(
    '2026-11-25',
    { kcal: 2550, proteinG: 170, carbsG: 285, fatG: 76 },
    [],
  );
  const legacyDay = plans[0]!.days['2026-11-25']!;
  const legacyTargets = {
    kcal: 2450,
    proteinG: 175,
    carbsG: 260,
    fatG: 72,
    kcalMin: 2350,
    kcalMax: 2550,
    sourceLabel: 'Meta de teste HiGHS',
  };
  const legacyProposal = await solveNutritionalBalanceWithHighsQP(legacyDay, legacyTargets, {
    goalFocus: 'balanced',
    mealAllocations: buildDefaultMealAllocations(legacyDay.slots),
  });
  assert.equal(legacyProposal.solverEngine, 'HiGHS QP (WASM)');
  assert.equal(legacyProposal.certificate, 'approximate');

  // Test infeasible corridor relaxation warning gracefully falls back without crashing
  const infeasibleCorridorProposal = await solveNutritionalBalanceWithHighsQP(verifiedDay, {
    kcal: 900,
    proteinG: 52,
    carbsG: 95,
    fatG: 32,
    kcalMin: 120,
    kcalMax: 150,
  });
  assert.equal(infeasibleCorridorProposal.solverEngine, 'HiGHS QP (WASM)');
  assert.equal(infeasibleCorridorProposal.certificate, 'approximate');

  // Test Level 3 Binary MILP and P0-A recipe template eligibility filtering
  const eligibleIds = new Set(RECIPE_CATALOG.filter(isEligibleRecipeTemplate).map((r) => r.id));
  const mip = await solveDiscreteSubstitutionsWithHighsMIP(legacyDay, {
    kcal: 2200,
    proteinG: 165,
    carbsG: 210,
    fatG: 68,
  });
  assert.ok(Array.isArray(mip.singleSlotSwaps), 'Should compute single slot swaps');
  for (const swap of mip.singleSlotSwaps) {
    assert.ok(
      eligibleIds.has(swap.candidateRecipeId),
      `singleSlotSwaps must never propose blocked legacy recipe template ${swap.candidateRecipeId}`,
    );
  }
  if (mip.jointProposal) {
    assert.equal(mip.jointProposal.solverEngine, 'HiGHS MILP (WASM)');
    assert.ok(mip.jointProposal.swaps.length >= 1, 'Joint MILP swaps should be non-empty');
    for (const swap of mip.jointProposal.swaps) {
      assert.ok(
        eligibleIds.has(swap.candidateRecipeId),
        `jointProposal must never propose blocked legacy recipe template ${swap.candidateRecipeId}`,
      );
    }
    assert.ok(
      mip.jointProposal.targetGapAfter < mip.jointProposal.targetGapBefore,
      'MILP must strictly improve normalized target gap',
    );
  }

  const recheck = computeDayNutrition(qpProposal.proposedDayPlan);
  assert.ok(Math.abs(recheck.macros.kcal - qpProposal.afterMacros.kcal) < 1);
  console.log('highs-solver.test.ts PASSED', {
    qpEngine: qpProposal.solverEngine,
    certificate: qpProposal.certificate,
    durationMs: qpProposal.solveDurationMs,
    mipSwaps: mip.jointProposal?.swaps.length ?? 0,
  });
}

main();
