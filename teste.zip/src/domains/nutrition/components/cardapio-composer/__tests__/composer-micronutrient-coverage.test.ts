import assert from 'node:assert/strict';
import { buildComposerDayFromMeals, computeDayNutrition, computeRecipeNutrition, computeSlotNutrition } from '../../../domain/rules/cardapio-composer-engine.ts';
import { MICRONUTRIENT_ORDER } from '../../../domain/entities/nutrient.ts';
import type { RecipeInstance } from '../../../domain/entities/nutrient.ts';

const recipe: RecipeInstance = {
  id: 'test-all-micros',
  name: 'Abacate de teste',
  category: 'cafe',
  baseServings: 1,
  targetServings: 1,
  adjustmentMode: 'balanced',
  ingredients: [{
    id: 'avocado',
    foodId: 'tbca:BRC0001C',
    displayName: 'Abacate',
    baseQuantityG: 100,
    currentQuantityG: 100,
    quantityStatus: 'known',
    mode: 'flexible',
  }],
};
const summary = computeRecipeNutrition(recipe);
assert.equal(MICRONUTRIENT_ORDER.length, 29);
assert.equal(Object.keys(summary.micronutrients).length, 29);
assert.ok((summary.micronutrients.vitamin_e.value ?? 0) > 0, 'the composer must calculate non-key micronutrients when source data exists');
assert.ok(summary.micronutrients.vitamin_e.quantifiedCount > 0);
assert.ok(Math.abs((summary.dietaryMetrics.fiberG.value ?? 0) - 4.03) < 1e-9);
assert.ok(Math.abs((summary.dietaryMetrics.saturatedFatG.value ?? 0) - 1.7) < 1e-9);
assert.equal(summary.dietaryMetrics.cholesterolMg.value, 0);
const mixedDietaryMetricSummary = computeRecipeNutrition({
  ...recipe,
  id: 'mixed-dietary-metric-coverage',
  ingredients: [
    recipe.ingredients[0]!,
    { id: 'tongue-unknown-metrics', foodId: 'tbca:BRC0777B', displayName: 'Língua de vaca cozida', baseQuantityG: 100, currentQuantityG: 100, quantityStatus: 'known', mode: 'flexible' },
    { id: 'chantilly-unknown-metrics', foodId: 'tbca:BRC0037K', displayName: 'Chantilly preparado', baseQuantityG: 100, currentQuantityG: 100, quantityStatus: 'known', mode: 'flexible' },
  ],
});
assert.equal(mixedDietaryMetricSummary.dietaryMetrics.fiberG.value, null, 'an unanalyzed ingredient must invalidate the recipe fiber total instead of displaying a partial sum');
assert.equal(mixedDietaryMetricSummary.dietaryMetrics.fiberG.dataStatus, 'not_analyzed');
assert.equal(mixedDietaryMetricSummary.dietaryMetrics.fiberG.quantifiedCount, 1);
assert.equal(mixedDietaryMetricSummary.dietaryMetrics.fiberG.sourceCount, 3);
assert.equal(mixedDietaryMetricSummary.dietaryMetrics.saturatedFatG.value, null, 'an unanalyzed ingredient must invalidate the saturated-fat total');
assert.equal(mixedDietaryMetricSummary.dietaryMetrics.cholesterolMg.value, null, 'an unanalyzed ingredient must invalidate the cholesterol total');
const missingQuantityMetricSummary = computeRecipeNutrition({
  ...recipe,
  id: 'missing-quantity-dietary-metric-coverage',
  ingredients: [
    { ...recipe.ingredients[0]!, id: 'missing-portion', quantityStatus: 'missing', currentQuantityG: null },
    recipe.ingredients[0]!,
  ],
});
assert.equal(missingQuantityMetricSummary.dietaryMetrics.fiberG.value, null);
assert.equal(missingQuantityMetricSummary.dietaryMetrics.fiberG.dataStatus, 'missing', 'missing ingredient quantities must remain distinct from not-analyzed source records');
assert.equal(missingQuantityMetricSummary.dietaryMetrics.fiberG.sourceCount, 2);
assert.equal(summary.micronutrients.vitamin_k.value, null, 'not-analyzed source values must remain null, never become zero');
assert.equal(summary.micronutrients.iodine.value, null, 'TBCA 7.2 does not publish an iodine value in the current compact schema');
assert.equal(summary.micronutrients.choline.dataStatus, 'not_analyzed');
console.log('composer-micronutrient-coverage.test.ts passed.');

const partiallyAnalyzedRecipe: RecipeInstance = {
  ...recipe,
  id: 'test-not-analyzed-status',
  ingredients: [{
    ...recipe.ingredients[0]!,
    id: 'banana',
    foodId: 'tbca:BRC0259E',
    displayName: 'Camarão, Pitu, cru',
  }],
};
const partiallyAnalyzedSummary = computeRecipeNutrition(partiallyAnalyzedRecipe);
assert.equal(partiallyAnalyzedSummary.micronutrients.sodium.dataStatus, 'not_analyzed');
assert.equal(partiallyAnalyzedSummary.micronutrients.vitamin_a.dataStatus, 'not_analyzed');

const day = buildComposerDayFromMeals('2026-11-25', []);
day.slots[0]!.recipes = [recipe];
day.slots[1]!.recipes = [partiallyAnalyzedRecipe];
day.slots.splice(2); // Only the analyzed and partially analyzed meal fixtures participate.
const slotSummary = computeSlotNutrition(day.slots[0]!);
const daySummary = computeDayNutrition(day);
assert.ok(Math.abs((slotSummary.dietaryMetrics.fiberG.value ?? 0) - 4.03) < 1e-9);
assert.equal(daySummary.dietaryMetrics.fiberG.value, null, 'day aggregation must not restore a partial sum from a different meal');
assert.equal(daySummary.dietaryMetrics.fiberG.quantifiedCount, 1);
assert.equal(daySummary.dietaryMetrics.fiberG.sourceCount, 2);
assert.equal(daySummary.dietaryMetrics.fiberG.dataStatus, 'not_analyzed');
