import assert from 'node:assert/strict';
import {
  buildComposerDayFromMeals,
  buildDefaultMealAllocations,
  evaluateMealAllocations,
  prepareQPModel,
} from '../../../domain/rules/cardapio-composer-engine.ts';

const day = buildComposerDayFromMeals('2026-11-25', []);
const defaultAllocs = buildDefaultMealAllocations(day.slots);

const targets = {
  kcal: 2500,
  proteinG: 170,
  carbsG: 280,
  fatG: 75,
};

const balanced = evaluateMealAllocations(day, targets, defaultAllocs);
assert.equal(balanced.isBalanced, true);
assert.equal(balanced.totalSharePercent, 100);
assert.equal(balanced.unallocatedPercent, 0);
assert.equal(balanced.slots.length, 4);
assert.equal(balanced.hasMacroDistribution, false, 'Macros must stay null unless configured');
assert.equal(balanced.slots[0]!.proteinSharePercent, null);
assert.equal(balanced.slots[0]!.targetProteinG, null);

// Flag unallocated share explicitly when percentages do not sum to 100%
const underAllocated = defaultAllocs.map((a, idx) =>
  idx === 0 ? { ...a, energySharePercent: 10 } : a,
);
const evaluatedUnder = evaluateMealAllocations(day, targets, underAllocated);
assert.equal(evaluatedUnder.isBalanced, false);
assert.equal(evaluatedUnder.unallocatedPercent, 12);

// Explicit Energy + P/C/G distribution
const macroAllocs = defaultAllocs.map((a) => ({
  ...a,
  proteinSharePercent: a.energySharePercent,
  carbsSharePercent: a.energySharePercent,
  fatSharePercent: a.energySharePercent,
}));
const evaluatedMacros = evaluateMealAllocations(day, targets, macroAllocs);
assert.equal(evaluatedMacros.hasMacroDistribution, true);
assert.equal(evaluatedMacros.totalProteinSharePercent, 100);
assert.ok(evaluatedMacros.slots[0]!.targetProteinG !== null && evaluatedMacros.slots[0]!.targetProteinG > 0);

console.log('target-allocation.test.ts passed.');

// Per-meal macro targets are used only when each macro distribution closes 100%.
const partialMacroAllocations = defaultAllocs.map((allocation) => ({
  ...allocation,
  proteinSharePercent: 10,
  carbsSharePercent: 25,
  fatSharePercent: 25,
}));
const partialMacroModel = prepareQPModel(day, targets, { mealAllocations: partialMacroAllocations });
assert.ok(partialMacroModel.slotTargets.length > 0);
assert.equal(partialMacroModel.slotTargets[0]!.targetProteinG, null, 'partial protein allocation must not create conflicting meal-level targets');
assert.ok(partialMacroModel.slotTargets[0]!.targetCarbsG !== null);

const closedMacroAllocations = defaultAllocs.map((allocation) => ({
  ...allocation,
  proteinSharePercent: 25,
  carbsSharePercent: 25,
  fatSharePercent: 25,
}));
const closedMacroModel = prepareQPModel(day, targets, { mealAllocations: closedMacroAllocations });
assert.ok(closedMacroModel.slotTargets[0]!.targetProteinG !== null);
console.log('meal-level macro allocation gating passed.');
