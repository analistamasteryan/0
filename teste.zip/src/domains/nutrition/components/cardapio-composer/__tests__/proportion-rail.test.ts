import assert from 'node:assert/strict';
import {
  applyYieldScaleToRecipe,
  computeIngredientNutritionImpact,
  computeWeightedDeviationPercent,
  createRecipeInstanceFromCatalog,
  getEffectiveIngredientBounds,
  isCompositeFoodId,
} from '../../../domain/rules/cardapio-composer-engine.ts';
import { findRecipeById } from '../../../data/recipes/recipe-catalog.ts';
import type { IngredientAdjustment } from '../../../domain/entities/nutrient.ts';

// 1. Recipe yield scaling & weighted deviation D formula
const cafeRecipe = findRecipeById('rec-cafe-completo');
assert.ok(cafeRecipe, 'rec-cafe-completo must exist in catalog');

const instance = createRecipeInstanceFromCatalog(cafeRecipe, 'test-cafe-1', 1, 'balanced');
assert.equal(computeWeightedDeviationPercent(instance.ingredients, 1), 0);

// Scale yield from 1.0x to 1.5x in proportional mode
const propInstance = {
  ...instance,
  adjustmentMode: 'proportional' as const,
  ingredients: instance.ingredients.map((i) => ({ ...i, mode: 'proportional' as const })),
};
const scaledUp = applyYieldScaleToRecipe(propInstance, 1.5);
assert.equal(scaledUp.ingredients[0]?.currentQuantityG, 210); // 140 * 1.5
assert.equal(scaledUp.ingredients[1]?.currentQuantityG, 150); // 100 * 1.5
assert.equal(scaledUp.ingredients[2]?.currentQuantityG, 225); // 150 * 1.5
assert.equal(
  computeWeightedDeviationPercent(scaledUp.ingredients, 1.5),
  0,
  'Pure proportional scaling yields 0% weighted deviation relative to scaled baseline',
);

// Manual modification verifies exact D = sum(|x_i - q_i^{ref}|) / sum(q_i^{ref}) * 100
const deviatedIngredients: IngredientAdjustment[] = instance.ingredients.map((ing, idx) =>
  idx === 0 ? { ...ing, currentQuantityG: 179 } : ing,
);
// sum(|x_i - q_i^ref|) = |179 - 140| = 39; sum(q_i^ref) = 140 + 100 + 150 = 390 -> 39/390 = 10.0%
assert.equal(computeWeightedDeviationPercent(deviatedIngredients, 1), 10);

// 2. Bounds clamping preserves [minQuantityG, maxQuantityG]
const bounds = getEffectiveIngredientBounds(instance.ingredients[0]!, 1);
assert.ok(bounds.minG >= 5 && bounds.minG < 140);
assert.ok(bounds.maxG > 140 && bounds.maxG <= 2000);

// 3. Composite dish food stays marked as composite single row
assert.equal(isCompositeFoodId('tbca-frango-arroz-legumes'), true);
assert.equal(isCompositeFoodId('tbca-ovo-mexido'), false);

// 4. "to_taste", "missing", and unresolved foods never fabricate macro numbers
const toTasteImpact = computeIngredientNutritionImpact(
  {
    id: 'ing-taste',
    foodId: 'tbca-ovo-mexido',
    baseQuantityG: null,
    currentQuantityG: null,
    quantityStatus: 'to_taste',
    mode: 'locked',
  },
  1,
);
assert.equal(toTasteImpact.calculable, false);

const missingFoodImpact = computeIngredientNutritionImpact(
  {
    id: 'ing-unknown',
    foodId: 'non-existent-food',
    baseQuantityG: 100,
    currentQuantityG: 100,
    quantityStatus: 'known',
    mode: 'flexible',
  },
  1,
);
assert.equal(missingFoodImpact.calculable, false);
assert.equal(missingFoodImpact.reason, 'Impacto não calculável');

console.log('proportion-rail.test.ts passed.');
