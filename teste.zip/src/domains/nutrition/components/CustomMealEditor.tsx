import { useDeferredValue, useMemo, useState } from 'react';
import { useSharedFoodSearchVersion } from '../application/use-shared-food-search-version.ts';
import { Plus, Trash2, X } from 'lucide-react';
import { BufferedNumberInput } from '@/src/shared/ui/BufferedNumberInput';
import { Surface } from '@/src/shared/ui/Surface';
import { getSharedFoodSearchIndex } from '../data/sources/food-search-index';
import { searchFoodIndex } from '../domain/rules/food-search';
import { resolveFoodById } from '../domain/rules/nutrition-calculator';
import { useNutritionStore, getMealMacros } from '../state/nutrition.store';
import type { MealItem } from '../domain/entities/nutrient';

export function CustomMealEditor({ meals }: { meals: MealItem[] }) {
  const createPlannedMeal = useNutritionStore((state) => state.createPlannedMeal);
  const updatePlannedMeal = useNutritionStore((state) => state.updatePlannedMeal);
  const addFoodToPlannedMeal = useNutritionStore((state) => state.addFoodToPlannedMeal);
  const updatePlannedMealFood = useNutritionStore((state) => state.updatePlannedMealFood);
  const removeFoodFromPlannedMeal = useNutritionStore((state) => state.removeFoodFromPlannedMeal);
  const deletePlannedMeal = useNutritionStore((state) => state.deletePlannedMeal);
  const confirmMealConsumed = useNutritionStore((state) => state.confirmMealConsumed);
  const skipMeal = useNutritionStore((state) => state.skipMeal);
  const [title, setTitle] = useState('Refeição personalizada');
  const [time, setTime] = useState('18:00');
  const [draftByMeal, setDraftByMeal] = useState<Record<string, { query: string; foodId: string; quantity: string }>>({});
  const deferredDraftByMeal = useDeferredValue(draftByMeal);
  const customMeals = useMemo(() => meals.filter((meal) => meal.id.startsWith('custom-meal-')), [meals]);
  const catalogVersion = useSharedFoodSearchVersion();
  const hasActiveSearch = useMemo(
    () => customMeals.length > 0 && Object.values(deferredDraftByMeal).some((d) => d.query.trim().length > 0),
    [customMeals.length, deferredDraftByMeal],
  );
  const foodIndex = useMemo(() => (hasActiveSearch ? getSharedFoodSearchIndex() : null), [hasActiveSearch, catalogVersion]);

  const create = () => {
    if (createPlannedMeal(title, time)) setTitle('Refeição personalizada');
  };

  return <section className="space-y-3" aria-label="Editor de refeições personalizadas">
    <Surface className="p-4 space-y-3">
      <div><h2 className="text-sm font-semibold text-[var(--titan-text-primary)]">Montar refeição</h2><p className="text-[11px] text-[var(--titan-text-muted)]">Crie uma refeição e adicione alimentos do catálogo com quantidades em gramas.</p></div>
      <div className="grid grid-cols-1 sm:grid-cols-[1fr_110px_auto] gap-2 items-end">
        <label className="text-[11px] text-[var(--titan-text-secondary)]">Nome<input value={title} onChange={(event) => setTitle(event.target.value)} maxLength={80} className="mt-1 w-full min-h-[42px] rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-3 text-sm text-[var(--titan-text-primary)]" /></label>
        <label className="text-[11px] text-[var(--titan-text-secondary)]">Horário<input type="time" value={time} onChange={(event) => setTime(event.target.value)} className="mt-1 w-full min-h-[42px] rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2 text-sm text-[var(--titan-text-primary)]" /></label>
        <button type="button" disabled={!title.trim()} onClick={create} className="min-h-[42px] rounded-lg bg-[var(--titan-accent)] px-3 text-xs font-semibold text-[var(--titan-bg-canvas)] disabled:opacity-40"><Plus className="mr-1 inline h-4 w-4" /> Criar</button>
      </div>
    </Surface>

    {customMeals.map((meal) => {
      const draft = draftByMeal[meal.id] ?? { query: '', foodId: '', quantity: '100' };
      const deferredDraft = deferredDraftByMeal[meal.id] ?? draft;
      const results = foodIndex && deferredDraft.query.trim() ? searchFoodIndex(foodIndex, deferredDraft.query, 8) : [];
      const macros = getMealMacros(meal);
      return <Surface key={meal.id} className="p-4 space-y-3">
        <div className="flex flex-wrap items-end justify-between gap-2">
          <label className="min-w-[180px] flex-1 text-[11px] text-[var(--titan-text-secondary)]">Nome da refeição<input value={meal.title} onChange={(event) => updatePlannedMeal(meal.id, { title: event.target.value })} maxLength={80} className="mt-1 w-full min-h-[38px] rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2 text-sm text-[var(--titan-text-primary)]" /></label>
          <label className="text-[11px] text-[var(--titan-text-secondary)]">Horário<input type="time" value={meal.time} onChange={(event) => updatePlannedMeal(meal.id, { time: event.target.value })} className="mt-1 min-h-[38px] rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2 text-sm text-[var(--titan-text-primary)]" /></label>
          <button type="button" onClick={() => deletePlannedMeal(meal.id)} aria-label={`Excluir ${meal.title}`} className="min-h-[38px] px-2 rounded-lg text-[var(--titan-status-error)]"><Trash2 className="h-4 w-4" /></button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-[1fr_90px_auto] gap-2 items-end">
          <label className="text-[11px] text-[var(--titan-text-secondary)]">Buscar alimento
            <input value={draft.query} onChange={(event) => setDraftByMeal((state) => ({ ...state, [meal.id]: { ...draft, query: event.target.value, foodId: '' } }))} placeholder="Nome, sinônimo ou código" className="mt-1 w-full min-h-[40px] rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2 text-sm text-[var(--titan-text-primary)]" />
          </label>
          <label className="text-[11px] text-[var(--titan-text-secondary)]">Quantidade (g)<input type="number" min="1" max="2000" value={draft.quantity} onChange={(event) => setDraftByMeal((state) => ({ ...state, [meal.id]: { ...draft, quantity: event.target.value } }))} className="mt-1 w-full min-h-[40px] rounded-lg border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2 text-sm text-[var(--titan-text-primary)]" /></label>
          <button type="button" disabled={!draft.foodId || !Number.isFinite(Number(draft.quantity)) || Number(draft.quantity) < 1 || Number(draft.quantity) > 2000} onClick={() => { if (addFoodToPlannedMeal(meal.id, draft.foodId, Number(draft.quantity))) setDraftByMeal((state) => ({ ...state, [meal.id]: { ...draft, query: '', foodId: '' } })); }} className="min-h-[40px] rounded-lg border border-[var(--titan-border)] px-3 text-xs font-semibold text-[var(--titan-text-primary)] disabled:opacity-40"><Plus className="mr-1 inline h-3.5 w-3.5" /> Adicionar</button>
        </div>
        {draft.query.trim() && <div className="max-h-48 overflow-y-auto rounded-lg border border-[var(--titan-border)] divide-y divide-[var(--titan-border)]">
          {results.map((food) => <button key={food.food_id} type="button" onClick={() => setDraftByMeal((state) => ({ ...state, [meal.id]: { ...draft, foodId: food.food_id, query: food.name } }))} className={`block w-full p-2 text-left ${draft.foodId === food.food_id ? 'bg-[var(--titan-surface-elevated)]' : ''}`}>
            <span className="block text-xs font-medium text-[var(--titan-text-primary)]">{food.name}</span><span className="block text-[10px] text-[var(--titan-text-muted)]">{food.source_id} · {food.source_record_id} · {food.source_version} · {food.quality_status}</span>
          </button>)}
          {results.length === 0 && <p className="p-3 text-xs text-[var(--titan-text-muted)]">Nenhum alimento encontrado.</p>}
        </div>}
        {meal.planned_foods.length > 0 ? <div className="space-y-2">
          {meal.planned_foods.map((portion) => {
            const food = resolveFoodById(portion.foodId);
            if (!food) return null;
            return <div key={portion.foodId} className="rounded-lg border border-[var(--titan-border)] p-2">
              <div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="text-xs font-medium text-[var(--titan-text-primary)]">{food.name}</p><p className="text-[10px] text-[var(--titan-text-muted)]">Fonte: {food.source_id} · Registro: {food.source_record_id} · {food.source_version} · {food.quality_status}{food.source_url ? ` · ${food.source_url}` : ''}</p></div><button type="button" onClick={() => removeFoodFromPlannedMeal(meal.id, portion.foodId)} aria-label={`Remover ${food.name}`} className="text-[var(--titan-status-error)]"><X className="h-4 w-4" /></button></div>
              <label className="mt-2 block text-[10px] text-[var(--titan-text-muted)]">Quantidade (g)<BufferedNumberInput min={1} max={2000} step={1} integer inputMode="numeric" value={portion.quantityG} onCommit={(val) => updatePlannedMealFood(meal.id, portion.foodId, val)} className="mt-1 min-h-[34px] w-28 rounded-md border border-[var(--titan-border)] bg-[var(--titan-bg-canvas)] px-2 text-xs text-[var(--titan-text-primary)]" /></label>
            </div>;
          })}
        </div> : <p className="text-xs text-[var(--titan-text-muted)]">Adicione pelo menos um alimento para completar esta refeição.</p>}
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-[var(--titan-border)] pt-2">
          <p className="text-xs font-mono-metric text-[var(--titan-text-secondary)]">{macros.kcal} kcal · P {macros.proteinG} g · C {macros.carbsG} g · G {macros.fatG} g</p>
          <div className="flex gap-2"><button type="button" disabled={meal.planned_foods.length === 0} onClick={() => confirmMealConsumed(meal.id)} className="min-h-[36px] rounded-lg bg-[var(--titan-accent)] px-3 text-xs font-semibold text-[var(--titan-bg-canvas)] disabled:opacity-40">Consumida</button><button type="button" onClick={() => skipMeal(meal.id)} className="min-h-[36px] rounded-lg border border-[var(--titan-border)] px-3 text-xs text-[var(--titan-text-secondary)]">Pular</button></div>
        </div>
      </Surface>;
    })}
  </section>;
}
