import { z } from 'zod';

export const dailyMacroGoalsSchema = z.object({
  kcal: z.number().finite().positive('Calorias devem ser maiores que zero.').max(10000),
  proteinG: z.number().finite().min(0).max(1000),
  carbsG: z.number().finite().min(0).max(1500),
  fatG: z.number().finite().min(0).max(500),
});

export const portionPercentSchema = z
  .number()
  .finite('Informe um percentual entre 10% e 200%.')
  .min(10, 'Percentual deve ficar entre 10% e 200%.')
  .max(200, 'Percentual deve ficar entre 10% e 200%.');

export const composerTargetsSchema = z.object({
  kcal: z.number().finite().min(500).max(10000),
  proteinG: z.number().finite().min(0).max(1000),
  carbsG: z.number().finite().min(0).max(1500),
  fatG: z.number().finite().min(0).max(500),
  kcalMin: z.number().finite().min(400).max(10000).nullable().optional(),
  kcalMax: z.number().finite().min(400).max(12000).nullable().optional(),
  proteinMinG: z.number().finite().min(0).max(1000).nullable().optional(),
  proteinMaxG: z.number().finite().min(0).max(1200).nullable().optional(),
  carbsMinG: z.number().finite().min(0).max(1500).nullable().optional(),
  carbsMaxG: z.number().finite().min(0).max(1800).nullable().optional(),
  fatMinG: z.number().finite().min(0).max(500).nullable().optional(),
  fatMaxG: z.number().finite().min(0).max(600).nullable().optional(),
});

