import assert from 'node:assert/strict';
import { TBCA_FOODS } from '../tbca-adapter.ts';
import { buildFoodSearchIndex, searchFoodIndex } from '../../../domain/rules/food-search.ts';
import { isCompositeFoodId } from '../../../domain/rules/cardapio-composer-engine.ts';
import { evaluateRecipeIngredientEligibility } from '../../../domain/rules/food-ingredient-policy.ts';

const eggs = TBCA_FOODS['tbca-ovo-mexido'];
const bread = TBCA_FOODS['tbca-pao-integral'];
const banana = TBCA_FOODS['tbca-banana-prata'];
assert.equal(eggs.source_record_id, 'BRC0065J');
assert.match(eggs.name, /Ovo, galinha, mexido/);
assert.equal(bread.source_record_id, 'BRC0149A');
assert.match(bread.name, /Pão, trigo, integral/);
assert.equal(banana.source_record_id, 'BRC0011C');
assert.match(banana.name, /Banana, prata/);
assert.equal(eggs.food_type, 'ALIMENTO');
assert.equal(bread.food_type, 'ALIMENTO');
assert.equal(banana.food_type, 'ALIMENTO');

for (const id of ['tbca-mamao-aveia', 'tbca-frango-arroz-legumes', 'tbca-salmao-batata-doce']) {
  const legacyMeal = TBCA_FOODS[id];
  assert.equal(legacyMeal.source_id, 'TITAN_LEGACY');
  assert.equal(legacyMeal.source_record_id.startsWith('TITAN-LEGACY-'), true);
  assert.equal(legacyMeal.quality_status, 'unverified');
  assert.equal(legacyMeal.food_type, 'PREPARACAO_COMPOSTA');
  assert.equal(evaluateRecipeIngredientEligibility(legacyMeal).eligible, false);
  assert.equal(isCompositeFoodId(id), true);
}

const fullCatalog = Object.values(TBCA_FOODS);
const canonicalTbca = fullCatalog.filter((food) => food.source_id === 'TBCA' && food.food_id === `tbca:${food.source_record_id}`);
const typeCounts = canonicalTbca.reduce((acc, food) => {
  acc[food.food_type ?? 'UNKNOWN'] = (acc[food.food_type ?? 'UNKNOWN'] ?? 0) + 1;
  return acc;
}, {});
assert.equal(canonicalTbca.length, 5830);
assert.equal(typeCounts.ALIMENTO, 2717);
assert.equal(typeCounts.PREPARACAO_COMPOSTA, 3113);
assert.equal(typeCounts.UNKNOWN ?? 0, 0);

assert.equal(isCompositeFoodId('tbca:BRC0680B'), true, 'dynamic composite detection covers standard TBCA catalog rows');
assert.equal(isCompositeFoodId('tbca:BRC0001C'), false, 'a simple ALIMENTO row is not treated as a composite');

const foodIndex = buildFoodSearchIndex(fullCatalog);
const compoundQuery = 'abobora cabotian japonesa quiabo refogado';
assert.ok(searchFoodIndex(foodIndex, compoundQuery, 10).some((food) => food.food_id === 'tbca:BRC0680B'), 'general search must preserve compound foods for diary logging');
assert.equal(searchFoodIndex(foodIndex, compoundQuery, 10, { purpose: 'recipe-ingredient' }).some((food) => food.food_id === 'tbca:BRC0680B'), false, 'recipe ingredient search must exclude compound foods');
assert.ok(searchFoodIndex(foodIndex, 'abacate polpa', 10, { purpose: 'recipe-ingredient' }).some((food) => food.food_id === 'tbca:BRC0001C'), 'recipe search retains simple TBCA foods');

console.log('TBCA ingredient integrity: PASS');
