import assert from 'node:assert/strict';
import { TBCA_FOODS } from '../tbca-adapter.ts';
import { OPEN_FOOD_FACTS_PRODUCTS } from '../open-food-facts-adapter.ts';

const foods = Object.values({ ...TBCA_FOODS, ...OPEN_FOOD_FACTS_PRODUCTS });
assert.ok(foods.length > 0, 'food catalog must not be empty');
const ids = new Set();
for (const food of foods) {
  assert.ok(food.food_id && !ids.has(food.food_id), `food id must be unique: ${food.food_id}`);
  ids.add(food.food_id);
  assert.ok(food.name.trim(), `${food.food_id} needs a display name`);
  assert.ok(['TBCA', 'OPEN_FOOD_FACTS', 'TITAN_LEGACY'].includes(food.source_id), `${food.food_id} needs a known source`);
  assert.ok(food.source_record_id.trim(), `${food.food_id} needs a source record id`);
  if (food.source_id === 'TITAN_LEGACY') {
    assert.equal(food.quality_status, 'unverified', `${food.food_id} local legacy records must not claim verified laboratory status`);
    assert.match(food.source_record_id, /^TITAN-LEGACY-/);
    assert.equal(food.food_type, 'PREPARACAO_COMPOSTA');
  }
  assert.ok(food.source_version.trim(), `${food.food_id} needs a source version`);
  assert.ok(['verified_lab', 'reference_database', 'label_complete', 'label_partial', 'unverified'].includes(food.quality_status), `${food.food_id} needs explicit quality status`);
  assert.ok(Number.isFinite(food.macros.basisQuantityG) && food.macros.basisQuantityG > 0, `${food.food_id} needs a positive basis quantity`);
  if (food.source_url) assert.match(food.source_url, /^https?:\/\//i, `${food.food_id} source URL must be HTTP(S)`);
  for (const [nutrientId, nutrient] of Object.entries(food.micronutrients)) {
    assert.ok(nutrient && typeof nutrient.data_status === 'string', `${food.food_id}/${nutrientId} needs an explicit data status`);
    if (nutrient.data_status === 'quantified') {
      assert.ok(Number.isFinite(nutrient.original_value) && Number.isFinite(nutrient.normalized_value), `${food.food_id}/${nutrientId} quantified values must be finite`);
    }
  }
}
console.log(`Catalog provenance tests passed (${foods.length} food records).`);
