import assert from 'node:assert/strict';

class StubHangingWorker {
  onmessage = null;
  onerror = null;
  onmessageerror = null;
  terminated = false;
  posted = [];
  postMessage(payload) {
    this.posted.push(payload);
  }
  terminate() {
    this.terminated = true;
  }
}

class StubMessageErrorWorker extends StubHangingWorker {
  postMessage(payload) {
    super.postMessage(payload);
    setTimeout(() => {
      this.onmessageerror?.(new MessageEvent('messageerror'));
    }, 5);
  }
}

async function main() {
  const {
    resetComposerOptimizerClientForTests,
    runComposerOptimizationAsync,
  } = await import('../composer-optimizer-client.ts');
  const { buildComposerDayFromMeals } = await import('../../domain/rules/cardapio-composer-engine.ts');

  const day = buildComposerDayFromMeals('2026-11-26', []);
  const targets = { kcal: 2200, proteinG: 160, carbsG: 240, fatG: 70 };

  // 1. Timeout must abort hung worker requests, terminate worker, and fall back to TS QP cleanly.
  const origWorker = globalThis.Worker;
  let createdHanging = null;
  try {
    globalThis.Worker = function FakeWorker() {
      createdHanging = new StubHangingWorker();
      return createdHanging;
    };
    resetComposerOptimizerClientForTests?.();
    assert.equal(typeof resetComposerOptimizerClientForTests, 'function', 'client must expose test reset hook or clean Worker lifecycle');

    const t0 = performance.now();
    const res = await runComposerOptimizationAsync(day, targets, { timeoutMs: 30 }, false);
    const elapsed = performance.now() - t0;
    assert.ok(elapsed < 500, `hung worker must fall back within timeoutMs, took ${elapsed.toFixed(1)}ms`);
    assert.ok(createdHanging?.terminated, 'timed-out worker must be terminated');
    assert.ok(res.proposal.afterMacros.kcal > 0, 'fallback TS solver must still produce valid proposal');

    // 2. Transient onerror/onmessageerror must resolve pending requests via fallback without wedging permanently.
    let workerConstructs = 0;
    globalThis.Worker = function FakeMsgErrWorker() {
      workerConstructs += 1;
      return new StubMessageErrorWorker();
    };
    resetComposerOptimizerClientForTests();
    const resErr = await runComposerOptimizationAsync(day, targets, { timeoutMs: 200 }, false);
    assert.ok(resErr.proposal.afterMacros.kcal > 0, 'onmessageerror must resolve to TS fallback');
    assert.equal(workerConstructs, 1);
  } finally {
    globalThis.Worker = origWorker;
  }

  console.log('composer-optimizer-client.test.mjs: PASS');
}

main();
