export interface HighsPrimalColumn {
  Primal?: unknown;
}

export interface ContinuousPrimalBounds {
  minG: number;
  maxG: number;
}

function validTolerance(tolerance: number): boolean {
  return Number.isFinite(tolerance) && tolerance >= 0 && tolerance <= 0.01;
}

function readPrimal(columns: Record<string, unknown>, name: string): number | null {
  const column = columns[name];
  if (!column || typeof column !== 'object' || Array.isArray(column)) return null;
  const primal = (column as HighsPrimalColumn).Primal;
  return typeof primal === 'number' && Number.isFinite(primal) ? primal : null;
}

/** Returns a complete, bounds-checked primal vector or null; never synthesizes missing values. */
export function extractValidatedContinuousPrimalValues(
  columns: Record<string, unknown>,
  variables: readonly ContinuousPrimalBounds[],
  tolerance = 1e-5,
): number[] | null {
  if (!validTolerance(tolerance) || variables.length === 0) return null;
  const values: number[] = [];
  for (let index = 0; index < variables.length; index += 1) {
    const variable = variables[index];
    if (!variable || !Number.isFinite(variable.minG) || !Number.isFinite(variable.maxG) ||
      variable.minG < 0 || variable.maxG < variable.minG) return null;
    const value = readPrimal(columns, `x${index}`);
    if (value === null || value < variable.minG - tolerance || value > variable.maxG + tolerance) return null;
    values.push(Math.min(variable.maxG, Math.max(variable.minG, value)));
  }
  return values;
}

/** Returns one selected zero-based option per slot or null for any incomplete/non-integral one-hot vector. */
export function extractValidatedBinarySlotSelections(
  columns: Record<string, unknown>,
  optionCounts: readonly number[],
  tolerance = 1e-5,
): number[] | null {
  if (!validTolerance(tolerance) || optionCounts.length === 0) return null;
  const selections: number[] = [];
  for (let slotIndex = 0; slotIndex < optionCounts.length; slotIndex += 1) {
    const count = optionCounts[slotIndex];
    if (!Number.isInteger(count) || count === undefined || count < 1 || count > 100) return null;
    let selected = -1;
    for (let optionIndex = 0; optionIndex < count; optionIndex += 1) {
      const value = readPrimal(columns, `b_${slotIndex}_${optionIndex}`);
      if (value === null || value < -tolerance || value > 1 + tolerance) return null;
      const snapped = value <= tolerance ? 0 : value >= 1 - tolerance ? 1 : null;
      if (snapped === null) return null;
      if (snapped === 1) {
        if (selected !== -1) return null;
        selected = optionIndex;
      }
    }
    if (selected === -1) return null;
    selections.push(selected);
  }
  return selections;
}
