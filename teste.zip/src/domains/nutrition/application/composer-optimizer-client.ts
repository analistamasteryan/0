import type {
  ComposerDayPlan,
  DiscreteCombinationProposal,
  DiscreteSubstitutionProposal,
  NutritionTargets,
  OptimizationProposal,
} from '../domain/entities/nutrient';
import {
  proposeDiscreteSubstitutions,
  solveNutritionalBalanceQP,
  type OptimizeBalanceOptions,
} from '../domain/rules/cardapio-composer-engine';
import type {
  OptimizerWorkerRequest,
  OptimizerWorkerResponse,
} from './composer-optimizer.worker';

let sharedWorker: Worker | null = null;
let workerUnavailable = false;
let nextRequestId = 1;

const pendingRequests = new Map<
  number,
  {
    resolve: (result: Omit<OptimizerWorkerResponse, 'requestId'>) => void;
    reject: (reason: Error) => void;
  }
>();

function getOrCreateWorker(): Worker | null {
  if (workerUnavailable || typeof Worker === 'undefined') return null;
  if (sharedWorker) return sharedWorker;

  try {
    const worker = new Worker(
      new URL('./composer-optimizer.worker.ts', import.meta.url),
      { type: 'module' },
    );
    worker.onmessage = (event: MessageEvent<OptimizerWorkerResponse>) => {
      const entry = pendingRequests.get(event.data.requestId);
      if (!entry) return;
      pendingRequests.delete(event.data.requestId);
      entry.resolve({
        proposal: event.data.proposal,
        substitutions: event.data.substitutions,
        jointCombination: event.data.jointCombination ?? null,
      });
    };
    worker.onerror = () => {
      workerUnavailable = true;
      for (const [, pending] of pendingRequests) {
        pending.reject(new Error('Falha no worker de otimização nutricional.'));
      }
      pendingRequests.clear();
      worker.terminate();
      sharedWorker = null;
    };
    sharedWorker = worker;
    return worker;
  } catch {
    workerUnavailable = true;
    return null;
  }
}

export async function runComposerOptimizationAsync(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: OptimizeBalanceOptions = {},
  includeSubstitutions = true,
): Promise<{
  proposal: OptimizationProposal;
  substitutions: DiscreteSubstitutionProposal[];
  jointCombination: DiscreteCombinationProposal | null;
}> {
  const worker = getOrCreateWorker();
  if (!worker) {
    return {
      proposal: solveNutritionalBalanceQP(dayPlan, targets, options),
      substitutions: includeSubstitutions ? proposeDiscreteSubstitutions(dayPlan, targets, 4) : [],
      jointCombination: null,
    };
  }

  const requestId = nextRequestId++;
  return new Promise<Omit<OptimizerWorkerResponse, 'requestId'>>((resolve, reject) => {
    pendingRequests.set(requestId, { resolve, reject });
    const payload: OptimizerWorkerRequest = {
      requestId,
      dayPlan,
      targets,
      options,
      includeSubstitutions,
    };
    worker.postMessage(payload);
  }).catch(() => ({
    proposal: solveNutritionalBalanceQP(dayPlan, targets, options),
    substitutions: includeSubstitutions ? proposeDiscreteSubstitutions(dayPlan, targets, 4) : [],
    jointCombination: null,
  }));
}
