import type {
  ComposerDayPlan,
  DiscreteCombinationProposal,
  DiscreteSubstitutionProposal,
  NutritionTargets,
  OptimizationProposal,
} from '../domain/entities/nutrient.ts';
import {
  proposeDiscreteSubstitutions,
  solveNutritionalBalanceQP,
  type OptimizeBalanceOptions,
} from '../domain/rules/cardapio-composer-engine.ts';
import {
  solveDiscreteSubstitutionsWithHighsMIP,
  solveNutritionalBalanceWithHighsQP,
} from './highs-nutrition-solver.ts';

export interface OptimizerWorkerRequest {
  requestId: number;
  dayPlan: ComposerDayPlan;
  targets: NutritionTargets;
  options?: OptimizeBalanceOptions;
  includeSubstitutions?: boolean;
}

export interface OptimizerWorkerResponse {
  requestId: number;
  proposal: OptimizationProposal;
  substitutions: DiscreteSubstitutionProposal[];
  jointCombination: DiscreteCombinationProposal | null;
}

const HIGHS_WASM_URL = '/wasm/highs.wasm';

const workerScope = globalThis as unknown as {
  onmessage: ((event: MessageEvent<OptimizerWorkerRequest>) => void) | null;
  postMessage: (message: OptimizerWorkerResponse) => void;
};

if (typeof workerScope.postMessage === 'function') {
  workerScope.onmessage = async (event: MessageEvent<OptimizerWorkerRequest>) => {
    const { requestId, dayPlan, targets, options, includeSubstitutions } = event.data;

    let proposal: OptimizationProposal;
    try {
      proposal = await solveNutritionalBalanceWithHighsQP(
        dayPlan,
        targets,
        options,
        HIGHS_WASM_URL,
      );
    } catch {
      proposal = solveNutritionalBalanceQP(dayPlan, targets, options);
    }

    let substitutions: DiscreteSubstitutionProposal[] = [];
    let jointCombination: DiscreteCombinationProposal | null = null;

    if (includeSubstitutions) {
      try {
        const discrete = await solveDiscreteSubstitutionsWithHighsMIP(
          dayPlan,
          targets,
          options,
          HIGHS_WASM_URL,
        );
        substitutions = discrete.singleSlotSwaps;
        jointCombination = discrete.jointProposal;
      } catch {
        substitutions = proposeDiscreteSubstitutions(dayPlan, targets, 4);
      }
    }

    workerScope.postMessage({
      requestId,
      proposal,
      substitutions,
      jointCombination,
    });
  };
}
