import { parseLocaleNumber } from '@/src/shared/utils/formatters';
import { MICRONUTRIENT_CHEMISTRY } from '../data/chemistry/micronutrient-chemistry';
import { RECIPE_CATALOG } from '../data/recipes/recipe-catalog';
import { DRI_REFERENCE_PROFILES } from '../data/references/dri-profiles';
import type {
  MealConsumptionStatus,
  MealFoodPortion,
  MealItem,
  NutrientId,
  RecipeItem,
  ReferenceProfileId,
} from '../domain/entities/nutrient';
import {
  computeDailyMacroAndEnergyBreakdown,
  computeDayPlanSummary,
  type DailyMacroAndEnergyBreakdown,
  type DayPlanSummary,
  type FoodMacroBreakdownItem,
  type MealMacroBreakdownItem,
} from '../domain/rules/nutrition-calculator';
import {
  computeRecipeSummary,
  searchSubstitutionRecipes,
  type ComputedRecipeSummary,
} from '../domain/rules/recipe-engine';
import {
  dailyMacroGoalsSchema,
  portionPercentSchema,
} from '../schemas/nutrition.schema';
import {
  computeNutritionTotals,
  getDailyEnergyIntakeHistory,
  getDailyMicronutrientDisplays,
  getMealMacros,
  useNutritionStore,
} from '../state/nutrition.store';

export type {
  ComputedRecipeSummary,
  DailyMacroAndEnergyBreakdown,
  DayPlanSummary,
  FoodMacroBreakdownItem,
  MealConsumptionStatus,
  MealFoodPortion,
  MealItem,
  MealMacroBreakdownItem,
  NutrientId,
  RecipeItem,
  ReferenceProfileId,
};

export function getNutrientChemistry(nutrientId: NutrientId) {
  return MICRONUTRIENT_CHEMISTRY[nutrientId];
}

export function getDriReferenceProfiles() {
  return DRI_REFERENCE_PROFILES;
}

export function getRecipeCatalog() {
  return RECIPE_CATALOG;
}

export function validateMacroGoals(raw: {
  kcal: string;
  proteinG: string;
  carbsG: string;
  fatG: string;
}):
  | { ok: true; data: { kcal: number; proteinG: number; carbsG: number; fatG: number } }
  | { ok: false; error: string } {
  if (
    raw.kcal.trim() === '' ||
    raw.proteinG.trim() === '' ||
    raw.carbsG.trim() === '' ||
    raw.fatG.trim() === ''
  ) {
    return { ok: false, error: 'Preencha todos os campos numéricos antes de salvar.' };
  }
  const parsed = dailyMacroGoalsSchema.safeParse({
    kcal: parseLocaleNumber(raw.kcal),
    proteinG: parseLocaleNumber(raw.proteinG),
    carbsG: parseLocaleNumber(raw.carbsG),
    fatG: parseLocaleNumber(raw.fatG),
  });
  if (!parsed.success) {
    return {
      ok: false,
      error:
        parsed.error.issues[0]?.message ??
        'Informe metas válidas para calorias e macronutrientes.',
    };
  }
  return {
    ok: true,
    data: {
      kcal: Math.round(parsed.data.kcal),
      proteinG: Math.round(parsed.data.proteinG),
      carbsG: Math.round(parsed.data.carbsG),
      fatG: Math.round(parsed.data.fatG),
    },
  };
}

export function validatePortionPercent(raw: string):
  | { ok: true; factor: number }
  | { ok: false; error: string } {
  if (raw.trim() === '') {
    return { ok: false, error: 'Informe um percentual entre 10% e 200%.' };
  }
  const parsed = portionPercentSchema.safeParse(parseLocaleNumber(raw));
  if (!parsed.success) {
    return {
      ok: false,
      error: parsed.error.issues[0]?.message ?? 'Percentual deve ficar entre 10% e 200%.',
    };
  }
  return { ok: true, factor: parsed.data / 100 };
}

export {
  computeDailyMacroAndEnergyBreakdown,
  computeDayPlanSummary,
  computeNutritionTotals,
  computeRecipeSummary,
  getDailyEnergyIntakeHistory,
  getDailyMicronutrientDisplays,
  getMealMacros,
  searchSubstitutionRecipes,
  useNutritionStore,
};

export {
  calculateDietaryDIAAS,
  FAO_2013_DIAAS_REFERENCE_PATTERNS,
} from '../domain/rules/protein-quality';
export type {
  DietaryDIAASRequest,
  DietaryDIAASResult,
  DIAASReferencePatternId,
  IndispensableAminoAcid,
  IlealDigestibilityEvidence,
  ProteinQualitySourceEvidence,
} from '../domain/rules/protein-quality';
export {
  derivePreparedFoodComposition,
  FOOD_PREPARATION_RETENTION_V1,
} from '../domain/rules/food-preparation-transform';
export type {
  FoodPreparationFactorEvidence,
  FoodPreparationRetentionProvenance,
  FoodPreparationTransform,
  PreparedFoodCompositionResult,
} from '../domain/rules/food-preparation-transform';
export { buildNutritionDataCoverage } from '../domain/rules/nutrition-data-coverage';
export type {
  NutritionCoverageSourceSummary,
  NutritionCoverageTarget,
  NutritionDataCoverageEntry,
} from '../domain/rules/nutrition-data-coverage';

export { parseUsdaFdcFoods, registerUsdaFdcFoods, getRegisteredUsdaFdcFoods } from '../data/sources/usda-fdc-adapter';
export type { USDAFdcDataType, USDAFdcImportOptions, USDAFdcImportResult, USDAFdcQuarantinedNutrient } from '../data/sources/usda-fdc-adapter';
export { aggregateSupplementMicronutrientExposure, convertSupplementMassUnit, isValidSupplementMicronutrientIntake } from '../domain/rules/supplement-intake';
export type { SupplementChemicalForm, SupplementMicronutrientIntake, SupplementExposureSummary } from '../domain/rules/supplement-intake';
