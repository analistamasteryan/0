import * as THREE from 'three';
import type { BodyComparisonMode } from '../../domain/body-identity';

export class DualBodyCompositor {
  private rtCurrent: THREE.WebGLRenderTarget;
  private rtGoal: THREE.WebGLRenderTarget;
  private readonly quadScene: THREE.Scene;
  private readonly quadCamera: THREE.OrthographicCamera;
  private readonly quadGeo: THREE.PlaneGeometry;
  private readonly quadMat: THREE.ShaderMaterial;
  private readonly quadMesh: THREE.Mesh;
  private readonly savedClearColor = new THREE.Color();
  private disposed = false;

  constructor(width: number, height: number, pixelRatio: number) {
    const rw = Math.max(1, Math.floor(width * pixelRatio));
    const rh = Math.max(1, Math.floor(height * pixelRatio));

    this.rtCurrent = this.createTarget(rw, rh, 'titan-rt-current-body');
    this.rtGoal = this.createTarget(rw, rh, 'titan-rt-goal-body');

    this.quadScene = new THREE.Scene();
    this.quadCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this.quadGeo = new THREE.PlaneGeometry(2, 2);
    this.quadMat = new THREE.ShaderMaterial({
      uniforms: {
        tCurrentColor: { value: this.rtCurrent.texture },
        tCurrentDepth: { value: this.rtCurrent.depthTexture },
        tGoalColor: { value: this.rtGoal.texture },
        tGoalDepth: { value: this.rtGoal.depthTexture },
        uMode: { value: 0 },
        uNear: { value: 0.1 },
        uFar: { value: 40.0 },
        uResolution: { value: new THREE.Vector2(rw, rh) },
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = vec4(position.xy, 0.0, 1.0);
        }
      `,
      fragmentShader: `
        uniform sampler2D tCurrentColor;
        uniform sampler2D tCurrentDepth;
        uniform sampler2D tGoalColor;
        uniform sampler2D tGoalDepth;
        uniform int uMode;
        uniform float uNear;
        uniform float uFar;
        uniform vec2 uResolution;
        varying vec2 vUv;

        float linearizeDepth(float d) {
          float z = d * 2.0 - 1.0;
          return (2.0 * uNear * uFar) / max(0.0001, (uFar + uNear - z * (uFar - uNear)));
        }

        vec3 sampleSkinDiffusionTap(
          sampler2D colorTex,
          sampler2D depthTex,
          vec2 uv,
          float centerZ,
          vec3 kernelWeight,
          out vec3 acceptedWeight
        ) {
          vec4 tapColor = texture2D(colorTex, uv);
          float tapDepth = texture2D(depthTex, uv).r;
          float depthDelta = abs(linearizeDepth(tapDepth) - centerZ);
          float depthGate = 1.0 - smoothstep(0.008, 0.050, depthDelta);
          acceptedWeight = kernelWeight * depthGate * step(0.01, tapColor.a);
          return tapColor.rgb * acceptedWeight;
        }

        // Depth-aware RGB three-lobe diffusion for skin only. Red carries the
        // longest low-frequency tail; green/blue remain tighter to preserve detail.
        // Three bounded cardinal radii reduce the two-ring radial banding while the
        // depth gate rejects samples across silhouettes and intersecting body layers.
        // This is a screen-space approximation, not a full irradiance-space BSSRDF.
        vec3 applyScreenSpaceSkinDiffusion(
          sampler2D colorTex,
          sampler2D depthTex,
          vec2 uv,
          vec4 centerColor,
          float centerDepth
        ) {
          float skinRedGreen = centerColor.r - centerColor.g;
          float skinGreenBlue = centerColor.g - centerColor.b;
          float skinHueGate = smoothstep(0.035, 0.15, skinRedGreen) * smoothstep(0.006, 0.095, skinGreenBlue);
          if (skinHueGate <= 0.001 || centerColor.a <= 0.01) return centerColor.rgb;

          vec2 texel = 1.0 / max(uResolution, vec2(1.0));
          float centerZ = linearizeDepth(centerDepth);
          vec3 centerWeight = vec3(0.54, 0.64, 0.74);
          vec3 nearKernel = vec3(0.13, 0.105, 0.080);
          vec3 midKernel = vec3(0.095, 0.065, 0.035);
          vec3 farKernel = vec3(0.045, 0.018, 0.006);
          vec3 accumulated = centerColor.rgb * centerWeight;
          vec3 totalWeight = centerWeight;

          for (int i = 0; i < 4; i++) {
            float angle = float(i) * 1.57079632679;
            vec2 direction = vec2(cos(angle), sin(angle));
            vec3 acceptedWeight;
            vec3 nearTap = sampleSkinDiffusionTap(
              colorTex, depthTex, uv + direction * texel * 0.9, centerZ, nearKernel, acceptedWeight
            );
            accumulated += nearTap;
            totalWeight += acceptedWeight;
            vec3 midTap = sampleSkinDiffusionTap(
              colorTex, depthTex, uv + direction * texel * 2.6, centerZ, midKernel, acceptedWeight
            );
            accumulated += midTap;
            totalWeight += acceptedWeight;
            vec3 farTap = sampleSkinDiffusionTap(
              colorTex, depthTex, uv + direction * texel * 5.8, centerZ, farKernel, acceptedWeight
            );
            accumulated += farTap;
            totalWeight += acceptedWeight;
          }

          vec3 diffused = accumulated / max(totalWeight, vec3(1e-4));
          return mix(centerColor.rgb, diffused, skinHueGate * 0.24);
        }

        vec3 sampleBloomTap(sampler2D tex, vec2 uv) {
          vec4 s = texture2D(tex, uv);
          float luma = dot(s.rgb, vec3(0.299, 0.587, 0.114));
          return s.rgb * s.a * smoothstep(0.36, 0.90, luma);
        }

        vec3 computeHoloBloom(vec2 uv) {
          vec2 texel = 1.0 / max(uResolution, vec2(1.0));
          vec3 bloomCurr = vec3(0.0);
          vec3 bloomGoal = vec3(0.0);

          vec2 r1 = texel * 1.4;
          vec2 r2 = texel * 3.1;
          vec2 r3 = texel * 5.6;

          for (int i = 0; i < 4; i++) {
            float angle = float(i) * 1.5707963;
            vec2 dir1 = vec2(cos(angle), sin(angle));
            vec2 dir2 = vec2(cos(angle + 0.785398), sin(angle + 0.785398));
            vec2 dir3 = vec2(cos(angle + 0.392699), sin(angle + 0.392699));
            if (uMode != 2) {
              bloomCurr += sampleBloomTap(tCurrentColor, uv + dir1 * r1) * 0.092;
              bloomCurr += sampleBloomTap(tCurrentColor, uv + dir2 * r2) * 0.052;
              bloomCurr += sampleBloomTap(tCurrentColor, uv + dir3 * r3) * 0.026;
            }
            if (uMode != 1) {
              bloomGoal += sampleBloomTap(tGoalColor, uv + dir1 * r1) * 0.092;
              bloomGoal += sampleBloomTap(tGoalColor, uv + dir2 * r2) * 0.052;
              bloomGoal += sampleBloomTap(tGoalColor, uv + dir3 * r3) * 0.026;
            }
          }
          return bloomCurr + bloomGoal;
        }

        void main() {
          vec4 curr = texture2D(tCurrentColor, vUv);
          vec4 goal = texture2D(tGoalColor, vUv);
          float currHit = step(0.01, curr.a);
          float goalHit = step(0.01, goal.a);
          vec3 bloom = computeHoloBloom(vUv);

          if (uMode == 1) {
            if (currHit < 0.5) {
              float bLuma = max(bloom.r, max(bloom.g, bloom.b));
              if (bLuma < 0.006) discard;
              gl_FragColor = vec4(bloom * 0.70, clamp(bLuma * 0.56, 0.0, 0.24));
              return;
            }
            vec3 currentSkin = applyScreenSpaceSkinDiffusion(
              tCurrentColor, tCurrentDepth, vUv, curr, texture2D(tCurrentDepth, vUv).r
            );
            gl_FragColor = vec4(currentSkin + bloom * 0.26, 0.97);
            return;
          }
          if (uMode == 2) {
            if (goalHit < 0.5) {
              float bLuma = max(bloom.r, max(bloom.g, bloom.b));
              if (bLuma < 0.006) discard;
              gl_FragColor = vec4(bloom * 0.70, clamp(bLuma * 0.56, 0.0, 0.24));
              return;
            }
            vec3 goalSkin = applyScreenSpaceSkinDiffusion(
              tGoalColor, tGoalDepth, vUv, goal, texture2D(tGoalDepth, vUv).r
            );
            gl_FragColor = vec4(goalSkin + bloom * 0.26, 0.97);
            return;
          }

          if (currHit < 0.5 && goalHit < 0.5) {
            float bLuma = max(bloom.r, max(bloom.g, bloom.b));
            if (bLuma < 0.006) discard;
            gl_FragColor = vec4(bloom * 0.70, clamp(bLuma * 0.56, 0.0, 0.24));
            return;
          }

          if (currHit > 0.5 && goalHit < 0.5) {
            vec3 currentSkin = applyScreenSpaceSkinDiffusion(
              tCurrentColor, tCurrentDepth, vUv, curr, texture2D(tCurrentDepth, vUv).r
            );
            gl_FragColor = vec4(currentSkin + bloom * 0.22, 0.96);
            return;
          }
          if (goalHit > 0.5 && currHit < 0.5) {
            float gLuma = dot(goal.rgb, vec3(0.299, 0.587, 0.114));
            float lineMask = smoothstep(0.22, 0.80, gLuma);
            vec3 goalSkin = applyScreenSpaceSkinDiffusion(
              tGoalColor, tGoalDepth, vUv, goal, texture2D(tGoalDepth, vUv).r
            );
            vec3 goalAura = goalSkin * mix(1.08, 1.38, lineMask) + bloom * 0.28;
            gl_FragColor = vec4(goalAura, mix(0.74, 0.97, lineMask));
            return;
          }

          // Both bodies cover this pixel: crisp depth-aware dual synthesis
          float currDepthSample = texture2D(tCurrentDepth, vUv).r;
          float goalDepthSample = texture2D(tGoalDepth, vUv).r;
          float currZ = linearizeDepth(currDepthSample);
          float goalZ = linearizeDepth(goalDepthSample);
          vec3 currentSkin = applyScreenSpaceSkinDiffusion(tCurrentColor, tCurrentDepth, vUv, curr, currDepthSample);
          vec3 goalSkin = applyScreenSpaceSkinDiffusion(tGoalColor, tGoalDepth, vUv, goal, goalDepthSample);
          float diff = currZ - goalZ;
          float eps = 0.0022;

          if (abs(diff) <= eps) {
            float cLuma = dot(curr.rgb, vec3(0.299, 0.587, 0.114));
            float gLuma = dot(goal.rgb, vec3(0.299, 0.587, 0.114));
            vec3 blended = mix(currentSkin, goalSkin, 0.28) + max(currentSkin, goalSkin) * 0.22 * smoothstep(0.30, 0.88, max(cLuma, gLuma)) + bloom * 0.18;
            gl_FragColor = vec4(blended, 0.97);
            return;
          }

          if (diff > eps) {
            float depthDelta = clamp(diff * 10.5, 0.0, 1.0);
            float gLuma = dot(goal.rgb, vec3(0.299, 0.587, 0.114));
            float goalContourStrength = smoothstep(0.22, 0.80, gLuma);
            float goalFrontWeight = mix(0.18, 0.34, depthDelta) + goalContourStrength * 0.38;
            vec3 comp = mix(currentSkin, goalSkin * 1.15, clamp(goalFrontWeight, 0.0, 0.74))
                      + goalSkin * (0.16 * depthDelta + 0.24 * goalContourStrength)
                      + bloom * 0.18;
            gl_FragColor = vec4(comp, 0.98);
          } else {
            float depthDelta = clamp((-diff) * 10.5, 0.0, 1.0);
            vec3 comp = mix(goalSkin, currentSkin, mix(0.76, 0.93, depthDelta)) + bloom * 0.18;
            gl_FragColor = vec4(comp, 0.98);
          }
        }
      `,
      transparent: true,
      depthTest: false,
      depthWrite: false,
    });
    this.quadMesh = new THREE.Mesh(this.quadGeo, this.quadMat);
    this.quadMesh.frustumCulled = false;
    this.quadScene.add(this.quadMesh);
  }

  private createTarget(width: number, height: number, name: string): THREE.WebGLRenderTarget {
    const depthTexture = new THREE.DepthTexture(width, height, THREE.UnsignedIntType);
    depthTexture.name = `${name}-depth`;
    const target = new THREE.WebGLRenderTarget(width, height, {
      minFilter: THREE.LinearFilter,
      magFilter: THREE.LinearFilter,
      format: THREE.RGBAFormat,
      type: THREE.UnsignedByteType,
      depthBuffer: true,
      stencilBuffer: false,
      depthTexture,
    });
    target.texture.name = `${name}-color`;
    return target;
  }

  resize(width: number, height: number, pixelRatio: number): void {
    if (this.disposed) return;
    const rw = Math.max(1, Math.floor(width * pixelRatio));
    const rh = Math.max(1, Math.floor(height * pixelRatio));
    const uResolution = this.quadMat.uniforms.uResolution;
    if (uResolution && uResolution.value instanceof THREE.Vector2) {
      uResolution.value.set(rw, rh);
    }
    if (this.rtCurrent.width === rw && this.rtCurrent.height === rh) return;
    this.rtCurrent.setSize(rw, rh);
    this.rtGoal.setSize(rw, rh);
  }

  render(
    renderer: THREE.WebGLRenderer,
    scene: THREE.Scene,
    camera: THREE.PerspectiveCamera,
    currentRoot: THREE.Object3D,
    goalRoot: THREE.Object3D,
    backdropObjects: THREE.Object3D[],
    mode: BodyComparisonMode,
  ): void {
    if (this.disposed) return;

    const { uMode, uNear, uFar } = this.quadMat.uniforms;
    if (uMode) uMode.value = mode === 'current' ? 1 : mode === 'goal' ? 2 : 0;
    if (uNear) uNear.value = camera.near;
    if (uFar) uFar.value = camera.far;

    const prevAutoClear = renderer.autoClear;
    const prevClearAlpha = renderer.getClearAlpha();
    renderer.getClearColor(this.savedClearColor);

    const prevCurrentVis = currentRoot.visible;
    const prevGoalVis = goalRoot.visible;

    try {
      // Pass 1: CurrentBody isolated (opaque internal depth occlusion)
      if (mode !== 'goal') {
        backdropObjects.forEach((o) => {
          o.visible = false;
        });
        currentRoot.visible = true;
        goalRoot.visible = false;
        renderer.setRenderTarget(this.rtCurrent);
        renderer.setClearColor(0x000000, 0);
        renderer.clear(true, true, false);
        renderer.render(scene, camera);
      }

      // Pass 2: GoalBody isolated (opaque internal depth occlusion)
      if (mode !== 'current') {
        backdropObjects.forEach((o) => {
          o.visible = false;
        });
        currentRoot.visible = false;
        goalRoot.visible = true;
        renderer.setRenderTarget(this.rtGoal);
        renderer.setClearColor(0x000000, 0);
        renderer.clear(true, true, false);
        renderer.render(scene, camera);
      }

      // Pass 3: Main framebuffer — single diffuse backdrop halo behind the bodies
      backdropObjects.forEach((o) => {
        o.visible = true;
      });
      currentRoot.visible = false;
      goalRoot.visible = false;
      renderer.setRenderTarget(null);
      renderer.setClearColor(this.savedClearColor, prevClearAlpha);
      renderer.clear(true, true, false);
      renderer.render(scene, camera);

      // Pass 4: Depth-aware dual-hologram composite over backdrop
      renderer.autoClear = false;
      renderer.render(this.quadScene, this.quadCamera);
    } finally {
      renderer.autoClear = prevAutoClear;
      renderer.setRenderTarget(null);
      renderer.setClearColor(this.savedClearColor, prevClearAlpha);
      backdropObjects.forEach((o) => {
        o.visible = true;
      });
      currentRoot.visible = prevCurrentVis;
      goalRoot.visible = prevGoalVis;
    }
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.rtCurrent.depthTexture?.dispose();
    this.rtCurrent.dispose();
    this.rtGoal.depthTexture?.dispose();
    this.rtGoal.dispose();
    this.quadGeo.dispose();
    this.quadMat.dispose();
  }
}
