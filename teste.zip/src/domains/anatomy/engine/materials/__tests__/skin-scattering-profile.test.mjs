import assert from 'node:assert/strict';
import { buildMultiGaussianScatteringPixels, downsampleRgbaForScattering, scaleSkinScatteringProfile, DEFAULT_SKIN_SCATTERING_PROFILE } from '../skin-scattering-profile.ts';

function variance(values) {
  let mean = 0;
  for (const value of values) mean += value;
  mean /= values.length;
  let total = 0;
  for (const value of values) total += (value - mean) ** 2;
  return total / values.length;
}

const size = 32;
const flat = new Uint8Array(size * size * 4);
for (let i = 0; i < flat.length; i += 4) {
  flat[i] = 160;
  flat[i + 1] = 120;
  flat[i + 2] = 100;
  flat[i + 3] = 255;
}
const flatBlur = buildMultiGaussianScatteringPixels(flat, size);
assert.equal(flatBlur.length, flat.length, 'output keeps the RGBA layout');
for (let i = 0; i < flat.length; i += 4) {
  assert.equal(flatBlur[i], flat[i], 'normalized convolution preserves constant red input');
  assert.equal(flatBlur[i + 1], flat[i + 1], 'normalized convolution preserves constant green input');
  assert.equal(flatBlur[i + 2], flat[i + 2], 'normalized convolution preserves constant blue input');
  assert.equal(flatBlur[i + 3], 255, 'alpha remains opaque');
}

const impulse = new Uint8Array(size * size * 4);
for (let i = 0; i < impulse.length; i += 4) impulse[i + 3] = 255;
const center = ((size >> 1) * size + (size >> 1)) * 4;
impulse[center] = 255;
impulse[center + 1] = 255;
impulse[center + 2] = 255;
const blurred = buildMultiGaussianScatteringPixels(impulse, size);
const red = [], green = [], blue = [];
for (let i = 0; i < blurred.length; i += 4) {
  red.push(blurred[i]);
  green.push(blurred[i + 1]);
  blue.push(blurred[i + 2]);
}
assert.ok(variance(red) < 255 ** 2 / (size * size), 'blur spreads the high-frequency red impulse');
assert.ok(variance(red) < variance(blue), 'the broader red profile lowers high-frequency variance more than blue');
assert.ok(variance(red) < variance(green) && variance(green) < variance(blue), 'diffusion width follows red > green > blue');
assert.ok(Math.max(...red) < Math.max(...blue), 'the narrower blue profile retains a sharper central peak');

const seam = new Uint8Array(size * size * 4);
for (let y = 0; y < size; y++) {
  for (let x = 0; x < size; x++) {
    const i = (y * size + x) * 4;
    const value = x < 2 || x > size - 3 ? 240 : 12;
    seam[i] = value;
    seam[i + 1] = value;
    seam[i + 2] = value;
    seam[i + 3] = 255;
  }
}
const seamBlur = buildMultiGaussianScatteringPixels(seam, size);
const left = seamBlur[((size >> 1) * size) * 4];
const right = seamBlur[((size >> 1) * size + size - 1) * 4];
assert.ok(Math.abs(left - right) <= 24, 'periodic UV convolution wraps across the U seam');

assert.throws(() => buildMultiGaussianScatteringPixels(new Uint8Array(4), 8), /dimensions|size|RGBA/i);

const downsampleSource = new Uint8Array(8 * 8 * 4);
for (let i = 0; i < downsampleSource.length; i += 4) { downsampleSource[i] = 180; downsampleSource[i + 1] = 130; downsampleSource[i + 2] = 95; downsampleSource[i + 3] = 255; }
const downsampled = downsampleRgbaForScattering(downsampleSource, 8, 4);
assert.equal(downsampled.length, 4 * 4 * 4, 'low-frequency SSS map is a compact RGBA image');
assert.ok(Math.abs(downsampled[0] - 180) <= 1, 'linear-light downsample preserves a constant albedo');
assert.throws(() => downsampleRgbaForScattering(new Uint8Array(7 * 7 * 4), 7, 4), /divisible/i);
const scaled = scaleSkinScatteringProfile(DEFAULT_SKIN_SCATTERING_PROFILE, 0.5);
assert.ok(scaled.red.wideSigma < DEFAULT_SKIN_SCATTERING_PROFILE.red.wideSigma, 'Gaussian UV radius scales with the reduced texture size');
console.log('PASS: UV multi-Gaussian skin scattering pixels');
