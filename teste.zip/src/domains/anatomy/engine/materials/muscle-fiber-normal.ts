/** Generate a tangent-space, longitudinal muscle-fiber normal map without external assets. */
export function createMuscleFiberNormalPixels(size = 256): Uint8Array {
  if (!Number.isInteger(size) || size < 16 || (size & (size - 1)) !== 0) {
    throw new RangeError(`Normal-map size must be a power of two >= 16; received ${size}`);
  }

  const heights = new Float32Array(size * size);
  const data = new Uint8Array(size * size * 4);
  const tau = Math.PI * 2;
  const heightAt = (u: number, v: number): number => {
    const warp =
      0.038 * Math.sin(tau * v * 3) +
      0.014 * Math.sin(tau * (u * 6 + v * 5)) +
      0.007 * Math.cos(tau * (u * 10 - v * 2));
    const perimysium = Math.sin(tau * (u * 10 + warp * 0.7)) * 0.42;
    const fascicle = Math.sin(tau * (u * 20 + warp));
    const fibril = Math.sin(tau * (u * 30 + warp * 1.25)) * 0.34;
    const sarcomere = Math.sin(tau * (v * 28 + Math.sin(tau * u * 10) * 0.14)) * 0.28;
    const belly = Math.sin(tau * (u * 11 + v * 3)) * 0.26;
    const fiberBellyFalloff = 0.8 + 0.2 * Math.sin(Math.PI * v);
    return fiberBellyFalloff * (0.022 * fascicle + 0.011 * fibril + 0.014 * perimysium + 0.011 * sarcomere + 0.012 * belly);
  };

  for (let y = 0; y < size; y += 1) {
    const v = y / size;
    for (let x = 0; x < size; x += 1) heights[y * size + x] = heightAt(x / size, v);
  }

  const strength = 0.045;
  for (let y = 0; y < size; y += 1) {
    const y0 = (y - 1 + size) % size;
    const y1 = (y + 1) % size;
    for (let x = 0; x < size; x += 1) {
      const x0 = (x - 1 + size) % size;
      const x1 = (x + 1) % size;
      const dx = (heights[y * size + x1]! - heights[y * size + x0]!) * size * 0.5;
      const dy = (heights[y1 * size + x]! - heights[y0 * size + x]!) * size * 0.5;
      let nx = -dx * strength;
      let ny = -dy * strength;
      let nz = 1;
      const length = Math.hypot(nx, ny, nz) || 1;
      nx /= length;
      ny /= length;
      nz /= length;
      const offset = (y * size + x) * 4;
      data[offset] = Math.round((nx * 0.5 + 0.5) * 255);
      data[offset + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      data[offset + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      data[offset + 3] = 255;
    }
  }
  return data;
}
