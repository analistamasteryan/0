import assert from 'node:assert/strict';
import { ANATOMICAL_STRUCTURE_MAP } from '../mapping/anatomical-structure-map.ts';

const ids = new Set();
const independentDeltoids = new Set();
for (const entry of ANATOMICAL_STRUCTURE_MAP) {
  assert.ok(!ids.has(entry.structureId), `duplicate structure id ${entry.structureId}`);
  ids.add(entry.structureId);
  assert.ok(['independent-training-group', 'shared-training-group'].includes(entry.geometryStatus), `${entry.structureId} must state geometry granularity`);
  assert.ok(['independent-training-group', 'shared-training-group'].includes(entry.deformationStatus), `${entry.structureId} must state morph granularity`);
  const isDeltoid = entry.structureId.startsWith('deltoid_');
  assert.equal(entry.geometryStatus, isDeltoid ? 'independent-training-group' : 'shared-training-group', `${entry.structureId} geometry status matches current per-group mesh contract`);
  assert.equal(entry.deformationStatus, isDeltoid ? 'independent-training-group' : 'shared-training-group', `${entry.structureId} deformation status matches current regional morph contract`);
  if (isDeltoid) independentDeltoids.add(entry.trainingGroupId);
}
assert.equal(independentDeltoids.size, 3, 'anterior, lateral and posterior deltoid retain three separate training/morph groups');
console.log(`PASS: ${ANATOMICAL_STRUCTURE_MAP.length} anatomical labels report honest topology/deformation granularity`);
