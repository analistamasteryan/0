const MIN_CONTACT_ANGLE_RAD = 0.05;
const MAX_CONTACT_ANGLE_RAD = Math.PI - MIN_CONTACT_ANGLE_RAD;

function capillaryParameters(capillaryLength: number, contactAngleRadians: number): [number, number] {
  if (!Number.isFinite(capillaryLength) || capillaryLength <= 0) {
    throw new RangeError('Capillary length must be a positive finite value');
  }
  if (!Number.isFinite(contactAngleRadians)) {
    throw new RangeError('Contact angle must be finite');
  }
  const angle = Math.min(MAX_CONTACT_ANGLE_RAD, Math.max(MIN_CONTACT_ANGLE_RAD, contactAngleRadians));
  return [capillaryLength, Math.cos(angle) / Math.sin(angle)];
}

/**
 * Small-slope planar Young–Laplace boundary profile:
 * h'' = h / lambda_c², h'(0) = -cot(theta), h(d→∞)=0.
 * This is a 1D capillary approximation, not a full nonlinear 2D/3D meniscus solve.
 */
export function capillaryMeniscusHeight(
  wallDistance: number,
  capillaryLength: number,
  contactAngleRadians: number,
): number {
  if (!Number.isFinite(wallDistance)) throw new RangeError('Wall distance must be finite');
  const [length, contactSlope] = capillaryParameters(capillaryLength, contactAngleRadians);
  return length * contactSlope * Math.exp(-Math.max(0, wallDistance) / length);
}

/**
 * Bounded nonlinear 2D Young–Laplace profile approximation for the UI glass meniscus.
 * The wall height comes from the nonlinear first integral, the initial slope matches
 * the contact angle, and the far field decays exponentially. Its transition is calibrated
 * against RK4 integration of y'' = y * (1 + y'^2)^(3/2); it is not a full 3D CFD solve.
 */
export function capillaryMeniscusHeightNonlinear(
  wallDistance: number,
  capillaryLength: number,
  contactAngleRadians: number,
): number {
  if (!Number.isFinite(wallDistance)) throw new RangeError('Wall distance must be finite');
  const [length] = capillaryParameters(capillaryLength, contactAngleRadians);
  const theta = Math.min(MAX_CONTACT_ANGLE_RAD, Math.max(MIN_CONTACT_ANGLE_RAD, contactAngleRadians));
  const sinTheta = Math.sin(theta);
  const cosTheta = Math.cos(theta);
  const wallHeightRatio = Math.sqrt(Math.max(0, 2 * (1 - sinTheta)));
  if (wallHeightRatio < 1e-8) return 0;

  const normalizedDistance = Math.max(0, wallDistance) / length;
  const contactSlope = Math.abs(cosTheta) / Math.max(sinTheta, 0.04997917);
  const transitionRate = contactSlope / wallHeightRatio;
  const sign = cosTheta < 0 ? -1 : 1;
  const exponent = -normalizedDistance - (transitionRate - 1) * (1 - Math.exp(-4 * normalizedDistance)) / 4;
  return length * sign * wallHeightRatio * Math.exp(exponent);
}

/** Exact second derivative of the linearized profile, in inverse-length units. */
export function capillaryMeniscusSecondDerivative(
  wallDistance: number,
  capillaryLength: number,
  contactAngleRadians: number,
): number {
  const [length] = capillaryParameters(capillaryLength, contactAngleRadians);
  return capillaryMeniscusHeight(wallDistance, length, contactAngleRadians) / (length * length);
}

/** Returns theta that preserves a prior wall-height calibration for a selected capillary length. */
export function contactAngleForWallHeight(wallHeight: number, capillaryLength: number): number {
  if (!Number.isFinite(wallHeight) || !Number.isFinite(capillaryLength) || capillaryLength <= 0) {
    throw new RangeError('Wall height must be finite and capillary length must be positive');
  }
  if (Math.abs(wallHeight) < 1e-8) return Math.PI / 2;
  return Math.atan2(capillaryLength, wallHeight);
}


export interface DynamicContactAnglePair {
  leadingRadians: number;
  trailingRadians: number;
}

/**
 * Advances/recedes a moving contact line within a bounded hysteresis band.
 * Positive speed means the leading edge advances; negative speed reverses it.
 */
export function updateContactAngleHysteresis(
  previous: DynamicContactAnglePair,
  signedContactLineSpeed: number,
  elapsedSeconds: number,
  recedingRadians: number,
  advancingRadians: number,
  responseRate = 12,
): DynamicContactAnglePair {
  if (![previous.leadingRadians, previous.trailingRadians, signedContactLineSpeed, elapsedSeconds, recedingRadians, advancingRadians, responseRate].every(Number.isFinite)) {
    throw new RangeError('Contact-angle hysteresis inputs must be finite');
  }
  if (recedingRadians <= MIN_CONTACT_ANGLE_RAD || advancingRadians >= MAX_CONTACT_ANGLE_RAD || recedingRadians >= advancingRadians) {
    throw new RangeError('Contact-angle hysteresis requires 0 < receding < advancing < pi');
  }
  const dt = Math.max(0, Math.min(0.05, elapsedSeconds));
  const speed = Math.min(1, Math.abs(signedContactLineSpeed) * 8);
  if (dt === 0 || speed < 1e-5) return { ...previous };
  const alpha = 1 - Math.exp(-Math.max(0.1, responseRate) * dt * speed);
  const forward = signedContactLineSpeed > 0;
  const leadingTarget = forward ? advancingRadians : recedingRadians;
  const trailingTarget = forward ? recedingRadians : advancingRadians;
  const clampAngle = (value: number) => Math.min(advancingRadians, Math.max(recedingRadians, value));
  return {
    leadingRadians: clampAngle(previous.leadingRadians + (leadingTarget - previous.leadingRadians) * alpha),
    trailingRadians: clampAngle(previous.trailingRadians + (trailingTarget - previous.trailingRadians) * alpha),
  };
}

/** Phenomenological contact-line retention factor derived from cos(theta_r)-cos(theta_a). */
export function contactAnglePinningMultiplier(
  leadingRadians: number,
  trailingRadians: number,
  gain = 0.42,
): number {
  if (![leadingRadians, trailingRadians, gain].every(Number.isFinite) || gain < 0) {
    throw new RangeError('Contact-angle pinning inputs must be finite and gain non-negative');
  }
  const retention = Math.max(0, Math.cos(trailingRadians) - Math.cos(leadingRadians));
  return 1 + Math.min(1, gain) * retention;
}
