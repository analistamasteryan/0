import assert from 'node:assert/strict';
import { METAL_SPECTRAL_SAMPLES, sampleMetalOptics, spectralConductorFresnel, METAL_SPECTRAL_FRESNEL_GLSL } from '../metal-optics-spectrum.ts';

for (const preset of ['silver', 'chromium', 'gold']) {
  const samples = METAL_SPECTRAL_SAMPLES[preset];
  assert.equal(samples.length, 9, `${preset} carries nine measured visible-band samples`);
  for (let i = 1; i < samples.length; i++) assert.ok(samples[i].wavelengthNm > samples[i - 1].wavelengthNm, 'wavelength samples are strictly increasing');
  for (const sample of samples) {
    const actual = sampleMetalOptics(preset, sample.wavelengthNm);
    assert.ok(Math.abs(actual.n - sample.n) < 1e-9 && Math.abs(actual.k - sample.k) < 1e-9, 'measured anchor data is preserved exactly');
  }
}
const goldGreen = sampleMetalOptics('gold', 520.9);
assert.ok(Math.abs(goldGreen.n - 0.62) < 1e-9 && Math.abs(goldGreen.k - 2.081) < 1e-9, 'gold green-band anchor comes from Johnson-Christy');
const midpoint = sampleMetalOptics('gold', (520.9 + 548.6) / 2);
assert.ok(Math.abs(midpoint.n - (0.62 + 0.43) / 2) < 1e-9, 'spectral interpolation is piecewise linear');
assert.ok(spectralConductorFresnel(1.0, goldGreen.n, goldGreen.k) > 0, 'Fresnel reflectance remains positive');
const normalIncidence = spectralConductorFresnel(1.0, goldGreen.n, goldGreen.k);
const expectedNormalIncidence = ((goldGreen.n - 1) ** 2 + goldGreen.k ** 2) / ((goldGreen.n + 1) ** 2 + goldGreen.k ** 2);
assert.ok(Math.abs(normalIncidence - expectedNormalIncidence) < 1e-12, 'normal-incidence Fresnel matches the analytical complex-IOR formula');
assert.ok(Math.abs(spectralConductorFresnel(0.0, goldGreen.n, goldGreen.k) - 1) < 1e-12, 'grazing incidence approaches unit reflectance');
assert.throws(() => spectralConductorFresnel(1.0, -1, 0.2), /non-negative/i, 'negative optical constants are rejected');
assert.ok(normalIncidence > 0 && normalIncidence < 1, 'Fresnel reflectance remains bounded');
assert.match(METAL_SPECTRAL_FRESNEL_GLSL, /measuredMetalFresnelSpectral/);
console.log('PASS: nine-band measured conductor optics and GLSL spectral quadrature');
