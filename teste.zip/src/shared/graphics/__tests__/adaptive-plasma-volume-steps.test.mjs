import assert from 'node:assert/strict';
import { adaptivePlasmaVolumeStepCount } from '../fluid-shader-engine.ts';

assert.equal(adaptivePlasmaVolumeStepCount(-1), 8, 'negative/empty segments use the safe minimum');
assert.equal(adaptivePlasmaVolumeStepCount(0), 8, 'zero-length segments never return zero samples');
assert.equal(adaptivePlasmaVolumeStepCount(0.25), 8, 'short segments use the low-cost tier');
assert.equal(adaptivePlasmaVolumeStepCount(0.85), 12, 'typical cavity chords preserve the V11.19 baseline');
assert.equal(adaptivePlasmaVolumeStepCount(1.2), 16, 'long segments receive the maximum refinement');
assert.equal(adaptivePlasmaVolumeStepCount(100), 16, 'sample count is always statically bounded');
console.log('Adaptive plasma volume-step behavior passed.');
