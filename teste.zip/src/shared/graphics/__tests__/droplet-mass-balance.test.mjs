import assert from 'node:assert/strict';
import { CardDropletSim } from '../hydration-fluid-solver.ts';

const sim = new CardDropletSim();
const baseline = sim.getMassBalance();
assert.ok(baseline.currentMass > 0, 'the initial drop pool has positive mass');
assert.equal(baseline.residual, 0, 'the baseline is exact');

// Force one deterministic coalescence without changing the initial masses.
const [survivor, donor] = sim.bodies;
assert.ok(survivor && donor);
survivor.x = donor.x = 0.5;
survivor.y = donor.y = 0.5;
survivor.pinned = false;
donor.pinned = true;
const donorMassBefore = donor.mass;
sim.step(0.002);
const afterMerge = sim.getMassBalance();
assert.ok(afterMerge.coalescedMass >= donorMassBefore, 'coalescence records the full donor mass transferred internally');
assert.ok(afterMerge.residual < 1e-10 && afterMerge.residual > -1e-10, 'internal coalescence and reseeding close the mass ledger');
assert.ok(afterMerge.currentMass > 0, 'the visual pool remains populated');

// Exercise all explicit source/sink paths over a deterministic run.
sim.setColliders([{ id: 'gauge', kind: 'droplet-pool', xMin: 0.2, yMin: 0.2, xMax: 0.8, yMax: 0.9 }]);
sim.triggerCondensationBurst(1.0);
const impacts = [];
for (let i = 0; i < 240; i++) sim.step(1 / 60, 0.04, (event) => impacts.push(event));
const final = sim.getMassBalance();
assert.ok(final.sourceMass > 0, 'condensation and explicit reseeding are recorded as sources');
assert.ok(final.sinkMass > 0, 'trail deposition and outflow are recorded as sinks');
assert.ok(final.transferredMass > 0, 'mass entering the gauge is recorded as a transfer');
assert.ok(final.residual < 1e-9 && final.residual > -1e-9, 'mass ledger closes after repeated simulation steps');
assert.ok(impacts.some((event) => event.target === 'droplet' && event.massTransferred > 0), 'gauge impact exposes the transferred mass to its consumer');
console.log('PASS: droplet mass ledger, conservative coalescence and explicit flux accounting');
