import assert from 'node:assert/strict';
import { projectIncompressibleVelocity2D } from '../fluid-pressure-projection.ts';

const width = 48;
const height = 24;
const u = new Float32Array(width * height);
const v = new Float32Array(width * height);
for (let y = 1; y < height - 1; y++) {
  for (let x = 1; x < width - 1; x++) {
    const i = y * width + x;
    u[i] = Math.sin(x * 0.31) * Math.cos(y * 0.19) * 1.4;
    v[i] = Math.cos(x * 0.17) * Math.sin(y * 0.27) * 1.1;
  }
}
const workspace = {
  divergence: new Float32Array(width * height),
  pressure: new Float32Array(width * height),
  pressureResidual: new Float32Array(width * height),
  pressurePreconditioned: new Float32Array(width * height),
  pressureDirection: new Float32Array(width * height),
  pressureProduct: new Float32Array(width * height),
  preconditionerInverseDiagonal: new Float32Array(width * height),
  preconditionerForward: new Float32Array(width * height),
};
const result = projectIncompressibleVelocity2D(u, v, width, height, workspace, {
  minIterations: 4,
  maxIterations: 12,
  relativeTolerance: 0.05,
});
assert.ok(result.iterations >= 4 && result.iterations <= 12, 'pressure solve uses a bounded adaptive iteration count');
assert.ok(result.divergenceRmsAfter < result.divergenceRmsBefore * 0.10, `projection should remove at least 90% of divergence (${result.divergenceRmsBefore} -> ${result.divergenceRmsAfter})`);
assert.ok(result.poissonResidualRms < result.divergenceRmsBefore * 0.05, 'Poisson residual converges to a small fraction of the initial divergence');
assert.ok(Number.isFinite(result.poissonResidualRms) && Number.isFinite(result.divergenceRmsAfter), 'projection diagnostics remain finite');
assert.equal(result.converged, true, 'the pressure solve terminates within its configured residual threshold');
const zeroU = new Float32Array(width * height);
const zeroV = new Float32Array(width * height);
const zeroWorkspace = Object.fromEntries(Object.keys(workspace).map((key) => [key, new Float32Array(width * height)]));
const zeroResult = projectIncompressibleVelocity2D(zeroU, zeroV, width, height, zeroWorkspace, { minIterations: 1, maxIterations: 12, relativeTolerance: 0.05 });
assert.equal(zeroResult.divergenceRmsBefore, 0, 'zero field has zero initial divergence');
assert.equal(zeroResult.divergenceRmsAfter, 0, 'zero field remains unchanged');
assert.equal(zeroResult.poissonResidualRms, 0, 'zero field has zero Poisson residual');
assert.ok(zeroResult.iterations <= 12, 'zero field does not consume the iteration budget');
assert.equal(workspace.preconditionerReady, true, 'the IC(0) factor is prepared for this grid');
assert.equal(workspace.preconditionerWidth, width);
assert.equal(workspace.preconditionerHeight, height);
assert.throws(() => projectIncompressibleVelocity2D(u, v, 0, height, workspace), /buffers must match/i, 'invalid grid dimensions are rejected');

for (let seed = 1; seed <= 4; seed++) {
  const testU = new Float32Array(width * height);
  const testV = new Float32Array(width * height);
  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const i = y * width + x;
      testU[i] = Math.sin((x + seed * 0.17) * (0.11 + seed * 0.035)) * Math.cos(y * 0.23) * (0.5 + seed * 0.2);
      testV[i] = Math.cos(x * 0.19) * Math.sin((y + seed * 0.31) * (0.13 + seed * 0.027)) * (0.7 + seed * 0.16);
    }
  }
  const testWorkspace = Object.fromEntries(Object.keys(workspace).map((key) => [key, new Float32Array(width * height)]));
  const diagnostics = projectIncompressibleVelocity2D(testU, testV, width, height, testWorkspace, { minIterations: 4, maxIterations: 12, relativeTolerance: 0.05 });
  assert.ok(diagnostics.converged, `IC(0)-PCG converges for deterministic field ${seed}`);
  assert.ok(diagnostics.divergenceRmsAfter < diagnostics.divergenceRmsBefore * 0.1, `IC(0)-PCG removes at least 90% of divergence for field ${seed}`);
  assert.ok(diagnostics.iterations <= 12);
  assert.ok([...testU, ...testV].every(Number.isFinite), `velocity remains finite for field ${seed}`);
}

console.log(`PASS: IC(0)-PCG incompressible projection (${result.iterations} iterations; divergence ${result.divergenceRmsBefore.toFixed(5)} -> ${result.divergenceRmsAfter.toFixed(5)}; residual ${result.poissonResidualRms.toFixed(5)})`);
