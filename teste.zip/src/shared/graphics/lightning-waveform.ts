export interface HeidlerWaveformParameters {
  riseTimeSeconds: number;
  decayTimeSeconds: number;
  exponent: number;
  normalization: number;
}

export const DEFAULT_HEIDLER_PARAMETERS: Readonly<HeidlerWaveformParameters> = Object.freeze({
  riseTimeSeconds: 0.045,
  decayTimeSeconds: 0.20,
  exponent: 3,
  normalization: 0.5695701063405509,
});

/** Normalized Heidler current envelope for a visual return-stroke pulse; not a discharge-field solver. */
export function heidlerLightningEnvelope(
  phaseSeconds: number,
  parameters: HeidlerWaveformParameters = DEFAULT_HEIDLER_PARAMETERS,
): number {
  if (!Number.isFinite(phaseSeconds) || phaseSeconds <= 0) return 0;
  const rise = Math.max(1e-4, parameters.riseTimeSeconds);
  const decay = Math.max(rise, parameters.decayTimeSeconds);
  const exponent = Math.max(1, Math.min(8, parameters.exponent));
  const normalization = Math.max(1e-4, parameters.normalization);
  const ratioPower = Math.pow(phaseSeconds / rise, exponent);
  const value = (ratioPower / (1 + ratioPower)) * Math.exp(-phaseSeconds / decay) / normalization;
  return Math.max(0, Math.min(1, Number.isFinite(value) ? value : 0));
}
