import { useEffect, useState } from 'react';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';

export const TITAN_EASE = [0.22, 1, 0.36, 1] as const;

export const TITAN_DURATIONS = {
  press: 0.1,
  quick: 0.16,
  standard: 0.2,
  progress: 0.26,
  panel: 0.24,
} as const;

export function useTitanReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return;
    const query = window.matchMedia('(prefers-reduced-motion: reduce)');
    setReduced(query.matches);
    const onChange = (event: MediaQueryListEvent) => setReduced(event.matches);
    query.addEventListener('change', onChange);
    return () => query.removeEventListener('change', onChange);
  }, []);

  return reduced;
}

export { AnimatePresence, MotionConfig, motion };

export interface CoalescedPointerSample {
  x: number;
  y: number;
  t: number;
  predicted?: boolean;
}

/**
 * Extracts coalesced high-frequency pointer samples (120Hz+) plus browser-predicted
 * future coordinates when available, normalized to [0..1] inside `rect`.
 */
export function extractCoalescedSamples(
  nativeEvent: PointerEvent | undefined,
  fallbackClientX: number,
  fallbackClientY: number,
  rect: DOMRect,
): CoalescedPointerSample[] {
  const safeW = Math.max(1, rect.width);
  const safeH = Math.max(1, rect.height);
  const clampNorm = (val: number) => (val < 0 ? 0 : val > 1 ? 1 : val);
  const out: CoalescedPointerSample[] = [];

  if (nativeEvent && typeof nativeEvent.getCoalescedEvents === 'function') {
    const coalesced = nativeEvent.getCoalescedEvents();
    for (let i = 0; i < coalesced.length; i++) {
      const ev = coalesced[i];
      if (!ev) continue;
      out.push({
        x: clampNorm((ev.clientX - rect.left) / safeW),
        y: clampNorm((ev.clientY - rect.top) / safeH),
        t: ev.timeStamp > 0 ? ev.timeStamp : performance.now(),
      });
    }
  }

  if (out.length === 0) {
    out.push({
      x: clampNorm((fallbackClientX - rect.left) / safeW),
      y: clampNorm((fallbackClientY - rect.top) / safeH),
      t: nativeEvent && nativeEvent.timeStamp > 0 ? nativeEvent.timeStamp : performance.now(),
    });
  }

  if (nativeEvent && typeof nativeEvent.getPredictedEvents === 'function') {
    const predicted = nativeEvent.getPredictedEvents();
    const firstPred = predicted[0];
    if (firstPred) {
      out.push({
        x: clampNorm((firstPred.clientX - rect.left) / safeW),
        y: clampNorm((firstPred.clientY - rect.top) / safeH),
        t: firstPred.timeStamp > 0 ? firstPred.timeStamp : performance.now() + 8,
        predicted: true,
      });
    }
  }

  return out;
}

/**
 * 2nd-order kinematic Kalman filter ([pos, vel, acc] per axis) that fuses
 * sub-frame coalesced pointer samples and predicts 1 display frame ahead (~9 ms)
 * to eliminate perceived WebView glass-ripple & fluid-slosh touch latency.
 */
export class KalmanTouchPredictor {
  private x = 0.5;
  private vx = 0;
  private ax = 0;
  private y = 0.5;
  private vy = 0;
  private ay = 0;
  private lastT = 0;
  private initialized = false;

  reset(): void {
    this.initialized = false;
    this.vx = 0;
    this.vy = 0;
    this.ax = 0;
    this.ay = 0;
    this.lastT = 0;
  }

  update(
    normX: number,
    normY: number,
    timestampMs: number,
  ): { x: number; y: number; vx: number; vy: number; speed: number } {
    const t = timestampMs > 0 ? timestampMs : performance.now();
    if (!this.initialized || t <= this.lastT) {
      this.x = normX;
      this.y = normY;
      this.vx = 0;
      this.vy = 0;
      this.ax = 0;
      this.ay = 0;
      this.lastT = t;
      this.initialized = true;
      return { x: this.x, y: this.y, vx: 0, vy: 0, speed: 0 };
    }

    const dt = Math.min(0.05, Math.max(0.001, (t - this.lastT) / 1000));
    this.lastT = t;

    // Constant-acceleration prior prediction
    const px = this.x + this.vx * dt + 0.5 * this.ax * dt * dt;
    const py = this.y + this.vy * dt + 0.5 * this.ay * dt * dt;
    const pvx = this.vx + this.ax * dt;
    const pvy = this.vy + this.ay * dt;

    // Tuned alpha-beta-gamma Kalman steady gains for 60–120 Hz touch
    const alpha = 0.72;
    const beta = 0.34;
    const gamma = 0.08;

    const rx = normX - px;
    const ry = normY - py;

    this.x = px + alpha * rx;
    this.y = py + alpha * ry;
    this.vx = Math.max(-4.5, Math.min(4.5, pvx + (beta / dt) * rx));
    this.vy = Math.max(-4.5, Math.min(4.5, pvy + (beta / dt) * ry));
    this.ax = Math.max(-18, Math.min(18, this.ax + (gamma / (0.5 * dt * dt)) * rx));
    this.ay = Math.max(-18, Math.min(18, this.ay + (gamma / (0.5 * dt * dt)) * ry));

    // Sub-frame lookahead (~9 ms = ~1 frame ahead on 120 Hz panels)
    const lookahead = 0.009;
    const predX = Math.max(0, Math.min(1, this.x + this.vx * lookahead + 0.5 * this.ax * lookahead * lookahead));
    const predY = Math.max(0, Math.min(1, this.y + this.vy * lookahead + 0.5 * this.ay * lookahead * lookahead));
    const speed = Math.min(1.5, Math.hypot(this.vx, this.vy) * 0.45);

    return {
      x: predX,
      y: predY,
      vx: this.vx,
      vy: this.vy,
      speed,
    };
  }
}

/** 4th-order Runge-Kutta damped harmonic spring step (zero numerical energy drift). */
export function stepRK4Spring(
  state: { value: number; velocity: number },
  target: number,
  stiffness: number,
  damping: number,
  dt: number,
): void {
  const h = Math.min(0.033, Math.max(0.001, dt));
  const accel = (v: number, vel: number) => stiffness * (target - v) - damping * vel;

  const k1x = state.velocity;
  const k1v = accel(state.value, state.velocity);

  const k2x = state.velocity + 0.5 * h * k1v;
  const k2v = accel(state.value + 0.5 * h * k1x, state.velocity + 0.5 * h * k1v);

  const k3x = state.velocity + 0.5 * h * k2v;
  const k3v = accel(state.value + 0.5 * h * k2x, state.velocity + 0.5 * h * k2v);

  const k4x = state.velocity + h * k3v;
  const k4v = accel(state.value + h * k3x, state.velocity + h * k3v);

  state.value += (h / 6) * (k1x + 2 * k2x + 2 * k3x + k4x);
  state.velocity += (h / 6) * (k1v + 2 * k2v + 2 * k3v + k4v);
}

