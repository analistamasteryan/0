# TITAN V11.24 — Nutrition Engine & Proportional Meal Targets

## Implementado

- Adicionada operação determinística `scaleDayPlanProportionallyToMealTargets`: converte a meta diária de energia e a distribuição percentual de cada refeição em metas de kcal por slot; aplica um fator comum a todos os ingredientes quantificados e desbloqueados daquele slot.
- Itens `locked` permanecem com a quantidade atual. Ingredientes sem quantidade não são inventados nem escalados; alimentos sem composição não geram kcal fictícias. O resultado expõe cobertura, contagem de itens travados, dados incompletos, baixa confiança, fator e desvio da meta.
- O rendimento (`targetServings`) acompanha o fator comum, respeitando a faixa suportada de 0,25× a 4× e o teto de 2.000 g por ingrediente. O cálculo é reversível pelo snapshot de desfazer já existente.
- Integrada ação explícita no painel de balanço: **Aplicar metas de kcal mantendo as proporções dos alimentos**. A ação não substitui o otimizador QP/MILP; é um modo separado de ajuste de quantidade.
- O composer passou a agregar os 23 micronutrientes, preservando estados `quantified`, `trace`, `not_analyzed` e `missing`; o painel exibe todos os 23 sem converter ausência em zero.
- O solver marca a proposta como `approximate` se a composição/quantidade estiver incompleta ou houver alimento `unverified`/`label_partial`.
- Metas de proteína, carboidratos e gordura por refeição só são adicionadas ao QP quando cada distribuição soma 100%. Metas incompletas não geram restrições parciais que conflitam com a meta diária.
- RMR automático centralizado no cálculo de metas. Sem escolha manual persistida, o método é resolvido novamente com o perfil atual. A seleção automática usa Mifflin como padrão geral; nenhuma equação específica de atletas/FFM é escolhida automaticamente porque atividade e origem da FFM, isoladamente, não comprovam compatibilidade com a população de desenvolvimento. Katch, Cunningham, Ten Haaf e Pavlidou permanecem opções explícitas.
- O formulário deixa de gravar o método automático como se fosse uma escolha manual. Perfis legados que já possuem `rmrMethod` continuam preservados para não apagar uma escolha anterior sem evidência de que era automática.
- A estimativa adaptativa de TDEE é calculada independentemente da abertura do modal de metas. A ingestão diária confirmada exige cobertura quantificada de 99,99% ou mais.
- Corrigida a referência de sódio: o painel agora separa AI de 1.500 mg e CDRR de 2.300 mg; o CDRR não é registrado como UL, exceder a AI não é sinalizado como excesso de limite e ficar abaixo da AI não é descrito como deficiência.
- Novos testes de proporção por refeição, preservação de itens travados, dados ausentes, cobertura dos micronutrientes e fechamento de alocação.

## Regras explícitas do modo proporcional

1. A meta da refeição é `meta diária de kcal × percentual da refeição / 100`.
2. Para cada refeição, todos os ingredientes conhecidos e desbloqueados recebem o mesmo multiplicador; isso mantém as proporções relativas de massa, salvo arredondamento de 0,5 g.
3. Ingredientes travados permanecem fixos e entram como energia fixa ao resolver o fator dos demais.
4. Ingredientes com quantidade ausente/a gosto não recebem quantidades inventadas. Os itens quantificados desbloqueados passam ao modo `proportional` e estabelecem a composição atual como nova base para futuras mudanças de rendimento.
5. Ingredientes sem composição alimentar não são usados para calcular energia, mas a quantidade conhecida acompanha o fator para preservar a composição em massa; a proposta sinaliza dados incompletos.
6. O fator é limitado pelos rendimentos de receita (0,25×–4×) e pela massa máxima de 2.000 g por ingrediente. Se a meta não for atingível dentro desses limites, o desvio permanece explícito.
7. O modo proporcional não promete atingir simultaneamente metas individuais de proteína, carboidrato e gordura. Para alterar seletivamente os alimentos, use o QP/MILP, que continua sujeito aos gates de qualidade.
8. A aplicação é explícita e reversível; mudar uma meta não sobrescreve silenciosamente as quantidades atuais.

## Não implementado / não alegado

- Não há validação clínica externa nova para RMR/TDEE/Hall.
- Não há cálculo DIAAS/PDCAAS: faltam perfis de aminoácidos indispensáveis e digestibilidade ileal específica. Gordura trans e açúcar adicionado ainda não possuem campos completos no contrato/catálogo e não são inferidos a partir de carboidratos ou gordura total.
- O solver não otimiza todos os 23 micronutrientes como restrições duras; ele agrega e exibe os dados disponíveis, enquanto a otimização contínua permanece macroenergética.
- A ingestão remota Open Food Facts continua não operacional; não foi introduzido conector HTTP.
- O pacote continua com a base TBCA 7.2; não foi substituída pela 7.3 porque os termos CC BY-NC-ND e as condições de uso para cálculo/distribuição exigem autorização formal antes de transformar ou redistribuir o conteúdo.
- Build integral, lint integral, WASM HiGHS e teste visual em navegador não foram certificados neste ambiente sem `node_modules`.
