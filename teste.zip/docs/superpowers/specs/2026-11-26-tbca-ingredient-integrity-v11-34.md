# V11.34 — TBCA ingredient identity and recipe-ingredient eligibility

## Problem
The shared food index mixes TBCA rows classified as `ALIMENTO` and `PREPARACAO_COMPOSTA`. Recipe ingredient addition and composite replacement therefore can select a multi-ingredient dish as though it were one raw/simple ingredient. The composer only detects three hard-coded local IDs and does not read the TBCA classification.

The compact TBCA 7.2 catalog has 5,830 rows: 2,717 `ALIMENTO` and 3,113 `PREPARACAO_COMPOSTA`. These rows remain in the general food catalog because complete dishes are valid diary entries; the filtering rule applies only to recipe ingredient selection and replacement.

A separate provenance audit found six local legacy rows presented as TBCA. Three of their `source_record_id` values resolve to unrelated foods in the compact catalog: BRC0042A is a chocolate/cereal biscuit, BRC0114C is a mixed fruit juice, and BRC0018B is an onion. Three legacy meal snapshots have synthetic IDs not present in the catalog. Correct the three single-food aliases to canonical TBCA entries, and reclassify the three local composite snapshots as `TITAN_LEGACY` / unverified with local IDs.

## Required behavior
1. TBCA `ALIMENTO` records may be used as recipe ingredients.
2. TBCA `PREPARACAO_COMPOSTA` records may remain searchable/loggable as whole foods, but may not be inserted or substituted as recipe ingredients.
3. Unknown/missing TBCA `food_type` fails closed for recipe-ingredient operations.
4. Non-TBCA sources are not inferred to be simple/compound from their names; absent a trustworthy classifier, they remain eligible under the existing source policy.
5. Composite detection is data-driven from `food_type`, while preserving known local composite identity for legacy meals.
6. Store actions enforce the rule even if UI filtering is bypassed.
7. A recipe template is eligible for new selection/substitution only when every line resolves to an eligible ingredient; templates containing legacy/composite snapshots are hidden from new selection, but preserved for existing records.
7. General catalog search and diary logging retain composed food records.
8. TBCA legacy aliases map to verified canonical rows: egg BRC0065J, whole-wheat bread BRC0149A, and prata banana BRC0011C.
9. Existing local composite meal records stay available as whole diary entries but are explicitly marked TITAN_LEGACY, unverified, and composite, not TBCA-derived.

## Non-goals
- Removing composite dishes from TBCA or the diary.
- Inferring source category by keyword matching.
- Automatic fuzzy crosswalk from TBCA to USDA.
- Introducing a new search dependency; the current 5.8k record catalog does not justify it for this safety filter.
- Replacing sample meal formulations with invented ingredient weights.
- Deleting historical templates or changing already-persisted plans just because a referenced ingredient is now classified as composite.

## Acceptance
- Unit tests prove allowed/blocked/unknown cases and source boundaries.
- Integration tests prove recipe search and replacement results contain no TBCA composite rows.
- General search still returns composed TBCA foods.
- Store refuses a composite TBCA ID for new recipe ingredient additions/replacements.
- Recipe search, recipe substitutions, new slot creation, catalog template add/swap and discrete substitution reject any template containing a composed/noncanonical line; the eight-template catalog audit reports two selectable and six blocked.
- `isCompositeFoodId` detects every TBCA `PREPARACAO_COMPOSTA` and remains true for local legacy meals.
- The 5,830-row audit script asserts the category counts and reports no malformed type labels.
- Canonical legacy aliases resolve to the correct TBCA record IDs/names; legacy meal snapshots no longer claim TBCA provenance.
- Existing nutrition regression suite remains green.
