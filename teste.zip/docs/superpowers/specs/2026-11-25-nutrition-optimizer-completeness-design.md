# TITAN V11.26 — Nutrition Optimizer Completeness Design

## Intent

Extend the existing nutrition QP so DRI micronutrient targets participate in daily meal optimization when, and only when, the complete food composition needed for that nutrient is quantifiable. Keep the existing TypeScript/HiGHS architecture and preserve the meal-level proportional mode.

## Goals

- Derive daily micronutrient goals from the active, age/sex-specific DRI profile.
- Add RDA/AI minimums as soft optimization goals, a CDRR value as a soft preferred ceiling, and an actual UL as a hard upper constraint.
- Never map missing, trace, or not-analyzed values to zero.
- Never apply a nutrient constraint when any positive-quantity ingredient in the day cannot be quantified for that nutrient. Explain the reason.
- Keep daily nutrient constraints out of single-meal optimization unless an explicit meal share is provided.
- Expose before/after coverage and which constraints were applied or skipped.
- Use the same nutrient model in HiGHS and the TypeScript fallback; the fallback must mark any unverified hard limit as approximate.
- Preserve ingredient locks and the proportional-quantity mode.

## Non-goals

- Do not manufacture missing food data or use generic nutrient estimates.
- Do not reinterpret CDRR as a UL.
- Do not label RDA/AI shortfalls as clinical deficiency.
- Do not import code from AGPL/GPL/unknown-license projects.
- Do not claim DIAAS/PDCAAS until amino-acid and digestibility evidence is available.
- Do not apply generic raw/cooked yield or retention multipliers.

## Approaches considered

1. Add micronutrients only to the display. Rejected because optimizer output could still ignore deficiencies and upper limits.
2. Add every reference as a hard constraint. Rejected because RDA/AI targets can make the plan infeasible, especially with fixed ingredients or incomplete food data; an infeasible plan would not help the user.
3. Coverage-aware mixed constraints (selected). RDA/AI and CDRR are soft, one-sided optimization goals; UL is a hard upper bound. Constraints are admitted only when every positive ingredient contribution for that nutrient is quantified. If unsupported, the target is shown as unavailable instead of using zero.

## Data contract

- Quantified nutrient: value is finite, normalized, and has a positive basis quantity.
- Trace / missing / not analyzed: unknown for solver purposes; do not use zero.
- RDA/AI: soft lower target, not a clinical diagnosis.
- CDRR: soft preferred upper target, not an UL.
- UL: hard upper bound when the dataset coverage is complete.

## Optimizer contract

- The selected DRI profile is resolved from the same persisted `referenceProfileId` used by daily micronutrient reporting.
- Only day-scope optimization receives daily DRI constraints. Single-slot optimization does not silently apply a full-day RDA to one meal.
- Every constraint reports `applied`, `insufficient_data`, or `not_applicable_scope`.
- HiGHS expresses soft one-sided targets with non-negative slack variables and hard ULs as linear inequalities.
- The TypeScript fallback minimizes the same soft one-sided objective and projects against hard UL half-spaces. Any non-converged/infeasible projection downgrades the certificate and reports the violation.

## Safety / uncertainty

- Food database completeness is per nutrient, not global. The solver may support iron while not supporting vitamin D for the same plan.
- Source quality and data coverage remain visible; a mathematically optimal result based on incomplete food records is not certified as nutrition-complete.
- An UL is not a personalized medical maximum where a clinician has provided a different limit.
- Food preparation state remains source-record-specific. No universal cooking multiplier is introduced.

## Implementation decisions

- Use the active DRI profile in the composer; no persistence schema change is required for target definitions.
- Keep HiGHS WASM and the existing FISTA/coordinate solver. No new runtime dependencies.
- Extend proposal diagnostics with per-nutrient status, bounds, and before/after totals.
- Do not copy source code from Mealie (AGPL-3.0), wger (AGPL-3.0), OpenNutriTracker (GPL-3.0), or projects with no declared license. Keep existing HiGHS (MIT); use OR-Tools (Apache-2.0) and SciPy/CVXPY only as algorithmic references because they are not suitable drop-in browser dependencies.
