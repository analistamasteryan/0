# TITAN V11.27 — Nutrition completeness design

## Intent

Continue the V11.25 energy-budget and V11.26 micronutrient optimizer without replacing the existing architecture. Prevent incomplete dietary metrics from appearing as complete totals, provide evidence-gated calculation primitives for protein quality and food preparation, and reject inconsistent source-aware exercise bases.

## Goals

- Every dietary metric total (fiber, saturated fat, cholesterol) must carry quantified/source coverage and become unavailable when any contributing ingredient is not quantified.
- Publicly expose a DIAAS engine that only calculates when indispensable amino acids and amino-acid-specific ileal digestibility evidence match each food and preparation state.
- Apply FAO reference patterns correctly; do not truncate an individual food's DIAAS above 100, but cap a mixed-diet score at 100 and preserve the untruncated result for auditing.
- Provide a raw/prepared food transform that requires exact food identity/state, preparation method, mass yield, and separately sourced macro and micronutrient retention values.
- Do not fill absent factors, sources, or amino-acid values with estimates.
- Reject an exercise-excluding expenditure base below RMR before adding workout energy.
- Preserve daily energy logic: final intake equals total daily expenditure plus goal adjustment; NASEM EER/adaptive TDEE already include activity and exercise.

## Non-goals

- No invented amino-acid or ileal digestibility profiles for TBCA records.
- No generic raw-to-cooked multiplier and no automatic TBCA-to-USDA mapping without a validated food/cut/method crosswalk.
- No assumption that USDA micronutrient retention factors apply to kcal, protein, carbs, or fat.
- No new solver, backend, external runtime, or dependency.
- No claim of clinical validation, complete food-source coverage, or a complete total-exposure UL assessment.

## Approaches considered

1. Fill missing values with generic food factors or protein scores. Rejected because it manufactures data and would produce false confidence.
2. Keep all functions as documentation-only roadmap items. Rejected because pure domain engines can be implemented and tested independently.
3. Implement evidence-gated pure domain capabilities and expose them publicly while keeping catalogue coverage explicitly unavailable until sourced (selected). This adds reusable functionality without misrepresenting evidence.

## Constraints and boundaries

- Existing TypeScript domain, React UI, Zustand persistence, TypeScript fallback and HiGHS integration remain.
- Existing proportional meal scaling retains one common factor for unlocked/quantifiable ingredients; locked ingredients remain fixed.
- Unknown or incomplete dietary metrics do not become zero and do not form partial total claims.
- DIAAS must not use total protein as a proxy for amino-acid profile or generic digestibility.
- Food preparation needs independent evidence for macro and nutrient-specific retention factors.
- Current data sources remain TBCA 7.2 plus the curated local OFF subset. Licensing and redistribution must be reviewed before any replacement or expanded dataset is added.

## Remaining external gates

Actual food-level DIAAS needs an amino-acid and ileal digestibility dataset by preparation state. Raw/prepared auto-conversion needs a validated food/cut/method yield and retention crosswalk. Choline, iodine, chloride, molybdenum, chromium and fluoride remain unquantified in current food catalogs. Supplements, water and external exposures are not yet part of the micronutrient UL model. Hall/RMR/TDEE/adaptive models still need independent real-world validation. Browser/Vite and HiGHS WASM integration require an installed dependency/browser environment.


## V11.28 adversarial review additions

- Any optimization result that is known to exceed an applicable total-intake UL must be rejected by both domain/store apply paths and disabled in UI actions.
- DIAAS evidence must be traceable to exact food identity, food state, source/version/reference/URL for amino-acid composition and every amino-acid-specific digestibility datum. Rat digestibility is not accepted for this DIAAS implementation.
