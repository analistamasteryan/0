# TITAN Nutrition Engine — Data Integrity, Supplemental Exposure & Activity Bridge

## Intent
Advance the recovered V11.28 Nutrition Engine without rewriting its modular-domain architecture. Restore the documented solver guard from the V11.30 handoff, complete the supplement micronutrient exposure ledger described for V11.31, and close correctness gaps in UL scope and training-energy reconciliation.

## Goals
- Never accept incomplete or malformed primal vectors from HiGHS as a complete optimal result.
- Persist supplement micronutrient exposures with units, chemical-form metadata and immutable provenance.
- Never compare a source-specific UL with an incompatible food-only exposure aggregate.
- Bridge completed strength sessions to the existing activity estimator only when the user supplies body weight and a source/versioned MET entry; mark the result as estimated and preserve active-energy semantics.
- Add an offline, version-pinned USDA FoodData Central import boundary that preserves source IDs, datatype/version, permanent `nutrient.id`, legacy `nutrient.number`, nutrient name and original `unitName`; unknown or mismatched identity tuples are quarantined, not guessed.
- Keep food totals, supplement exposures and training expenditure separately attributable.

## Non-goals
- Do not claim a complete clinical nutrition engine or a complete USDA import without the archive and a verified source manifest.
- Do not infer strength-training kcal from sets, reps, loads or elapsed workout time alone.
- Do not convert IU, RAE, DFE, NE or chemical forms using a generic mass conversion.
- Do not add new dependencies solely to mirror popular repositories.
- Do not alter existing DRI reference values without source-by-source scientific validation.

## Constraints
- Build on the recovered V11.28 ZIP because V11.29–V11.31 binaries are not available in the current workspace; reconstruct only changes established by the prior handoff and explicitly disclose this.
- Preserve the existing React + TypeScript + Zustand + HiGHS architecture.
- Use strict input validation, runtime guards, deterministic tests, and source provenance.
- Existing activity reconciliation adds only active energy to a daily baseline; gross/total calories remain non-additive.
- Datasets are not invented. Import fixtures are synthetic parser tests only.

## Approaches considered
1. Replace the data and solver stack with a larger nutrition platform or OR-Tools: rejected because it would multiply dependencies and rewrite working domain logic.
2. Add a generic schema framework to every boundary: rejected because Zod already exists in the project and the changed domain contracts need narrow, explicit guards.
3. Incrementally harden the current boundaries and retain the existing engines: selected because it targets concrete correctness defects, keeps current data model and solver, and is testable offline.

## Selected design
Use small domain contracts: `highs-solution-validation.ts`, `supplement-intake.ts`, a strict USDA FDC data adapter, and a training-session-to-activity estimate adapter. Supplement records stay separately typed and persisted; display functions receive food-only aggregates unless a compatible total exposure aggregate can be proven. Training adapters require an explicit MET entry and body mass and output an `estimated` active-energy record; they never update daily TDEE automatically.

## Acceptance criteria
- Missing, non-finite, out-of-bounds, fractional or non-exclusive solver primal selections are rejected.
- Invalid QP output falls back to the deterministic TS optimizer; invalid MIP output yields no joint proposal and keeps single-slot alternatives.
- Supplement entries validate date/time/amount/unit/form/provenance and persist through migration and backup.
- Unit conversions are limited to g/mg/µg; nutrient-unit equivalency is not inferred.
- Food-only UL calculations suppress non-total scopes; preformed/synthetic-form limits require matching chemical-form evidence.
- Training session energy bridge rejects missing starts, invalid durations, absent MET source provenance and unreasonable values; does not estimate from set counts.
- USDA importer supports explicit FoodData Central datatype/version and exact `(nutrient.id, nutrient.number, name, unitName)` mapping only; unknown nutrient IDs, number mismatches and units are retained as unmapped audit entries. The source URL must use the official `fdc.nal.usda.gov` hostname.
- All tests run from the extracted release archive; no live WASM or real USDA dataset claim without the relevant environment/data.
