# TITAN V11.25 — Energy Budget and Target Intake Design

## Intent

Make the nutrition engine calculate and explain daily food intake targets from total daily energy expenditure (TDEE), then apply the goal-specific energy adjustment and distribute the resulting intake target across meals. Keep meal-level proportional scaling distinct from flexible nutrient optimization.

## Goals

- Use resting metabolic rate (RMR) as one component of energy expenditure, never as the complete daily requirement.
- Treat NASEM 2023 EER and observed adaptive TDEE as total-day estimates that already include physical activity and exercise; never add workout calories a second time.
- Permit explicit exercise calories to be reported as included in an already-total TDEE, and permit additive exercise only when a future base explicitly excludes exercise and supplies NET (not gross) exercise energy.
- Calculate the intake target as total daily expenditure plus the goal adjustment: negative for loss, zero for maintenance/recomposition baseline, positive for gain.
- Make the effective adjustment reconcile exactly with the final kcal target, including any macro-feasibility floor.
- Display the resting estimate, non-resting residual, TDEE source, goal adjustment, and final intake target.
- Preserve the V11.24 meal allocation and proportional ingredient scaling behavior.

## Non-goals

- Do not sum RMR + gross workout calories + NASEM EER. This is double counting.
- Do not claim that the residual TDEE component is measured NEAT, exercise, or TEF; it is an aggregate of non-resting expenditure and model error.
- Do not infer workout calories from sets/reps, steps, or training frequency.
- Do not claim clinical validation of the NASEM, Hall, or adaptive models from synthetic tests.
- Do not bundle third-party food/activity datasets whose license does not permit redistribution or modification.
- Do not use an LLM to calculate energy or nutrient quantities.

## Approaches considered

1. **Add RMR + workout + goal adjustment directly.** Rejected: omits NEAT and thermic effect, and double-counts when the TDEE source already includes activity.
2. **Use TDEE only and hide its components.** Rejected: the target is mathematically safer but does not explain resting metabolism, activity, exercise, or the goal adjustment.
3. **Source-aware energy budget (selected).** Keep the source's total-day estimate as the base; expose RMR and the non-resting residual; add logged exercise only when the declared base explicitly excludes it. This preserves correctness and provides an extensible path to future component-based estimation.

## Energy accounting contract

For current sources:

- `NASEM_2023_TABLE_S3`: population-level total daily energy estimate, selected using an activity category.
- `observed_adaptive`: inferred total daily expenditure from logged intake and body-weight trend; exercise and normal activity are already represented in the observed energy balance.
- `HALL_2011_DYNAMIC_CORE_V1`: dynamic body-weight response model used to solve the target intake; it is not a second expenditure source and must not be added to TDEE.

The accounting identity is:

`TDEE = RMR + nonRestingResidual`

The residual is `TDEE - RMR`; it includes physical activity, exercise, thermic effect and equation error. It must not be relabeled as one measured component.

`TargetIntake = TDEE + GoalAdjustment`

- Weight loss: negative adjustment, limited by the current rate and percentage safeguards.
- Weight gain: positive adjustment, limited by the current rate and percentage safeguards.
- Maintenance: zero adjustment.
- Recomposition: zero energy adjustment in this version; protein target is handled separately.

If the macro feasibility floor forces the target above the planned value, report both the requested/bounded adjustment and the effective adjustment (`final kcal - TDEE`). Never present the bounded deficit as achieved if the final intake target no longer reflects it.

Exercise accounting:

- With a total-day TDEE source, logged NET exercise kcal are informational and already included; add 0 kcal.
- With a future explicitly non-exercise baseline, add logged NET exercise kcal exactly once.
- Gross exercise kcal are not accepted as additive because they include resting energy.
- No activity data means no workout number is invented.

## Food-data quality contract

- Validate macro inputs before calculation, scaling or optimization: finite/nonnegative energy and macro fields, positive basis mass, protein+carbohydrate+fat no more than 105 g per 100 g, and saturated fat no more than total fat.
- A simple Atwater discrepancy is a warning only; source-specific Atwater factors, fiber definitions and methods can explain differences. Never overwrite a source value automatically.
- Invalid food composition is excluded from selection and numeric calculation, counted as unresolved/low confidence, and blocks an `optimal` solver certificate.
- The authoritative source must be checked before any correction. Do not infer a missing decimal or replace an outlier with a model estimate.

## Meal target contract

1. The final daily intake target is the source for the day's kcal target.
2. Meal energy shares must total 100% before applying the allocation.
3. Each meal receives its target kcal from its share.
4. Proportional mode applies one common factor to all unlocked, quantifiable ingredients in that meal; locked ingredients stay fixed.
5. After scaling, recompute kcal, macros, dietary metrics, and all available micronutrients from source quantities.
6. Proportional scaling does not guarantee macro/micronutrient adequacy. Flexible optimization is a separate operation and must report coverage and constraints.

## Safety and uncertainty

- Population equations are estimates; activity category is a proxy.
- Adaptive TDEE is usable only after the existing data-quality gate; its current interval is model-based and not externally calibrated.
- Exercise records require deduplication and a NET energy definition before they can enter a component-based budget.
- Adult equations are not automatically valid for pregnancy, lactation, minors, or clinical conditions.
- No target should be described as a medical prescription.

## Implementation calls

- Keep Vite/React/TypeScript/Zustand and HiGHS; no backend or new runtime dependency.
- Preserve legacy `bmr` output for compatibility while adding the explicit `restingMetabolicRateKcal` name.
- Add a pure energy-budget domain function with source-aware exercise treatment.
- Add an optional exercise context to the goal calculator for future activity integration; current UI does not fabricate or infer workout kcal.
- Update the live target preview to show the energy-accounting components and explain no double counting.
- Add a source-aware food macro validator and quarantine inconsistent food records without mutating their source values.
