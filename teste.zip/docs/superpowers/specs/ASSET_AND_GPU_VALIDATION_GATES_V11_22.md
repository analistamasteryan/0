# V11.22 — Gates de ativos, física e GPU

## Fechado nesta versão

- [x] Projeção Euleriana 2D: IC(0)-PCG com fator precondicionador fixo, cacheado por dimensão no workspace da instância e sem alocação por passo.
- [x] Pressão: grade 48×24, stencil simétrico 5 pontos, fronteira Dirichlet zero, correção de todas as faces que compõem a divergência.
- [x] Teste de pressão: campo principal + quatro campos determinísticos; redução RMS ≥90%, no máximo 12 iterações, resíduo verdadeiro calculado por `b-Ap`; campo nulo e grid inválido.
- [x] Plasma: node ID e coordenada local são somente espaciais; cada nó tem seed/cadência própria, ciclo temporal contínuo.
- [x] Pele: 3 escalas screen-space em 4 direções, pesos RGB e depth gate, hue gate e alpha preservado.
- [x] Regressão V11.21: mass ledger, 9-band conductor optics, Heidler, capillary meniscus e source-contract de shaders.
- [x] Iluminação: contrato de um único halo difuso atrás do corpo, sem piso, plinto, projetor ou luz de contato.

## Ainda pendente — física/ativos

### Água
- [ ] Escala SI para coordenadas/tempo da UI.
- [ ] Integrar Cox–Voinov com parâmetros medidos de ângulo de avanço/recuo, viscosidade, tensão superficial e material de parede.
- [ ] Resolver menisco não linear Young–Laplace em 2D/3D se a validação do formato exigir.
- [ ] Simulação 3D de superfície livre (PBF/DFSPH/SPH ou PIC/FLIP) somente se o efeito requerer interação de milhares de partículas e houver budget GPU.
- [ ] Validar altura/tank fill visual com a massa/volume do ledger; hoje massa física do solver e UI fill são contratos distintos.

### Vidro/metais
- [ ] Referências de espectro contínuo para vidro/ligas/revestimentos reais com origem/DOI/condição.
- [ ] Spectral quadrature/CIE XYZ→linear sRGB completo em GPU, caso dispersão contínua seja requisito visual.
- [ ] Múltiplas interfaces, filmes finos, rough transmission e estabilidade de highlight em dispositivo.
- [ ] Comparação fotográfica sob HDRI/exposição calibrada.

### Plasma/descarga
- [ ] Estimar erro de integração volumétrica por optical depth e medir passo adaptativo em GPU.
- [ ] Crescimento de líder por Laplace/DBM e retorno MTLE somente com código de licença permissiva ou implementação original.
- [ ] Calibrar parâmetros dielétricos e tempos físicos; não chamar VFX procedural de descarga física.
- [ ] Sequência de 10–20 s para avaliar repetição, branch popping, restrike e persistência.

### Anatomia
- [ ] Download/pinning de GLBs masculino/feminino de referência com checksums, atribuição e validação do catálogo.
- [ ] Adaptador opt-in separado da malha de morphs atual, com coordinate frame, escala, pose e mapeamento de estrutura.
- [ ] Novas meshes individualizadas só com origem/inserção e topologia real; sem separar músculos por rótulo.
- [ ] Geometria e deformações para músculos/tendões/fáscias atualmente compartilhados, preservando anatomia masculina e feminina.
- [ ] Medidas corporais e incerteza para deformação do corpo objetivo.

### Pele
- [ ] SSS separável no espaço de irradiância antes do tone mapping; filtro screen-space atual não é BSSRDF.
- [ ] Thickness maps regionais e material IDs.
- [ ] Albedo, normal e roughness escaneados com licença.
- [ ] Comparação multi-iluminação e multi-tonalidade com especialistas/refs.

### Iluminação
- [ ] HDRI/EXR de estúdio com direitos e propriedades de captura.
- [ ] Calibrar exposição, white balance, área/intensidade das softboxes e tone mapping.
- [ ] Teste de 360° em corpo masculino/feminino e hardware real.
- [ ] Garantir fallback compatível sem adicionar iluminação no chão nem um segundo halo.

## Validação de engenharia

V.MAX precisa de evidência de:

1. `npm test` em instalação limpa.
2. `npm run lint` e `npm run build` com exit 0.
3. Compilação WebGL2 em browser real/hardware GPU. Teste estático de texto GLSL não substitui compilador.
4. GPU time, VRAM/render-target, draw calls e custo por pixel ratio, low/medium/high.
5. Capturas antes/depois dos componentes, com 10–20 segundos de estabilidade temporal.
6. Desktop + mobile e fallback de software.
7. Licença, origem, checksum, sistema de coordenadas, escala e identidade de malha para cada ativo externo.

## Restrições preservadas

- Sem migração de engine ou backend.
- Sem adicionar dependência runtime.
- Nenhum ativo externo incorporado nesta versão.
- Sem iluminação no chão, plinto, projetor ou halo adicional.
- Sem declarações de MHD, SPH/FLIP 3D, BSSRDF ou anatomia individualizada que não correspondam ao código.
