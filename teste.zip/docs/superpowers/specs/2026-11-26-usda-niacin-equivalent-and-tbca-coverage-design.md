# V11.35 — Derivação rastreável de niacina equivalente e cobertura TBCA por tipo

## Intenção

Fechar uma lacuna semântica do motor nutricional: a meta canônica de vitamina B3 usa mg NE (niacina equivalente), mas um registro USDA de niacina pré-formada em mg não é, por si só, o total em mg NE. Quando a fonte fornece componentes suficientes e identificados, o adaptador deve calcular o equivalente e preservar a evidência. A auditoria de cobertura deve também diferenciar o universo TBCA de alimentos elegíveis para receitas (`ALIMENTO`) do universo de preparações compostas (`PREPARACAO_COMPOSTA`).

## Por que

A V11.34 protege receitas contra preparações compostas TBCA e corrigiu aliases/proveniência. O inventário da V11.34 registra 5.830 itens TBCA: 2.717 `ALIMENTO` e 3.113 `PREPARACAO_COMPOSTA`. A cobertura agregada atual pode confundir a quantidade de registros gerais com a quantidade de ingredientes aptos a compor uma receita. Em paralelo, B3 é acompanhado em mg NE, enquanto o nutriente FDC 406 é niacina pré-formada em mg.

NIH/FNB e FDA descrevem 1 mg NE como 1 mg de niacina ou 60 mg de triptofano. A fórmula é `mg NE = mg niacina + (mg triptofano / 60)`. O USDA FDC identifica, em seu dicionário, 406 (niacina), 407 (niacina de triptofano determinada), 409 (N406 + N407) e 501 (triptofano). O adaptador deve respeitar as identidades permanentes, números históricos, nomes, unidades e base de 100 g. Ausência de dado não pode ser convertida em zero nem suprida por percentual genérico de proteína nesta mudança.

## Objetivos

1. Calcular `vitamin_b3` em `mg NE/100 g` apenas por caminhos explicitamente definidos e com unidades/basis verificadas.
2. Preferir valor direto do FDC 409 se presente e validado.
3. Se 409 não existir, permitir `N406 + N407` somente quando ambos os registros forem exatos e válidos.
4. Se 407 não existir, permitir `N406 + N501/60` somente quando niacina pré-formada (mg/100 g) e triptofano (g/100 g) estiverem ambos exatos e válidos; converter `g` para `mg` antes de dividir por 60.
5. Preservar em `FoodNutrientRecord` a fórmula, URL de referência e valores/unidades/IDs originais que produziram B3 derivada.
6. Sem componentes suficientes, não produzir valor quantificado de B3; enviar os registros isolados para quarentena com razão semântica apropriada.
7. Impedir que IDs, números, nomes, unidades alterados ou duplicatas conflitantes participem de uma derivação; revalidar também a evidência do FDC 409 direto no limite de registro runtime.
8. Emitir cobertura TBCA por `ALIMENTO`, `PREPARACAO_COMPOSTA` e `UNKNOWN`, sem classificar outras fontes como itens TBCA desconhecidos.
9. Preservar todas as regras V11.34 de associação de alimentos simples e exclusão de pratos compostos nas receitas.
10. Não adicionar dependências de runtime nem importar/reempacotar dados TBCA 7.3 sem autorização de uso.

## Fora de escopo

- Imputar triptofano a partir de percentuais de proteína ou classe de alimento.
- Tratar niacina pré-formada sozinha como mg NE.
- Calcular NE para TBCA se a base não fornecer os componentes necessários.
- Ingerir a base TBCA 7.3 ou redistribuir seus dados; a versão pública e as permissões aplicáveis precisam ser obtidas junto à coordenação.
- Adicionar Fuzzy Search / embedding / LLM para decidir identidade nutricional.
- Mudar cálculos DRI ou otimização clínica sem fonte e cobertura completas.
- Importar automaticamente o corpus oficial USDA neste ambiente; a mudança trata do parser e dos valores sintéticos de validação.

## Abordagens consideradas

1. **Assumir niacina mg = mg NE.** Rejeitada: elimina a contribuição do triptofano e gera super/subestimação de B3.
2. **Derivação por componentes medidos e tipados (selecionada).** Primeiro FDC 409 validado; depois N406 + N407 validados; por fim N406 + N501 medidos, com conversão de unidade explícita. A evidência bruta acompanha o valor final. Fail-closed se faltar um componente.
3. **Imputar triptofano a partir de proteína (por exemplo 1,1%).** Rejeitada nesta versão: depende de classe/tipo de alimento e regra externa, pode introduzir erro sistemático e não é informação analítica observada. Manter como investigação futura, com metodologia, faixas, classe específica e marcação de estimativa.

## Contratos e invariantes

- Unidade canônica de `vitamin_b3`: `mg NE` por 100 g de alimento.
- FDC 406: ID permanente `1167`, número `406`, nome `Niacin`, unidade `mg`.
- FDC 407: ID permanente `1168`, número `407`, nome `Niacin from tryptophan, determined`, unidade `mg`.
- FDC 409: ID permanente `1169`, número `409`, nome `Niacin equivalent N406 +N407`, unidade `mg`.
- FDC 501: ID permanente `1210`, número `501`, nome `Tryptophan`, unidade `g`.
- Todos os valores devem representar a mesma base FDC (por 100 g) e ser numéricos, finitos e não negativos.
- Prioridade de derivação: 409 direto; 406 + 407; 406 + 501 convertido (`406 mg + (501 g × 1000 / 60)`).
- O parser nunca soma N407 com N501; ambos representam caminhos alternativos para a parcela derivada de triptofano.
- O valor final não é quantificado com apenas 406, 407 ou 501 isolado.
- O caminho direto 409 preserva ID 1169, número 409, nome exato, unidade mg e valor original; o registro runtime recusa evidência adulterada ou ausente.
- Qualquer B3 USDA normalizada para `mg NE` só pode usar conversão `direct` com evidência 409 ou `niacin_equivalent_from_components` com derivação validável; métodos genéricos não podem contornar o gate.
- A soma/conversão final também precisa ser finita; overflow de componentes finitos produz quarentena, nunca `Infinity` quantificado.
- Nenhum valor ausente vira zero. Nenhum ID/número/nome/unidade é inferido por texto aproximado.
- `PREPARACAO_COMPOSTA` permanece permitida para diário geral, nunca como ingrediente de receita.
- O relatório de cobertura total permanece disponível e ganha visões TBCA estratificadas, sem alterar o denominador global silenciosamente.

## Validação e aceite

- Testes TDD de cada caminho 409, 406+407 e 406+501.
- Testes de ausência de componente, ausência de niacina, unidade incorreta, ID/número incompatíveis, valores negativos/não finitos, overflow aritmético, métodos genéricos sem evidência e duplicata conflitante.
- Validação de registro reimportado/runtime para evidência de derivação e método, além de identidade original de 409 direto.
- Testes da estratificação TBCA demonstram reconciliação com o total e não incluem outras fontes em `UNKNOWN`.
- Suítes `test:review`, `test:nutrition-hardening`, `test:nutrition-data-quality`, typecheck dedicado e auditorias TBCA/receitas/cobertura.
- Build, lint e `npm test` serão reportados separadamente caso a falta de dependências continue impedindo execução.

## Decisões do implementador

- Preservar o estilo estrutural e nomes já usados pelo adaptador USDA.
- Não adicionar pacote fuzzy, banco de dados, vetor nem solver novo; a regra é determinística e limitada a quatro nutrientes FDC.
- Manter o catálogo TBCA e os modelos de receita da V11.34 imutáveis neste trabalho, salvo atualização de relatório derivada de `food_type`.
