# TITAN V11.19 — Realismo óptico, pele, anatomia e iluminação

## Intent
Fechar as lacunas de implementação da V11.18 que podem ser resolvidas sem trocar o renderer do TITAN: água/menisco, pele/SSS, coerência das luzes e validação automatizada dos shaders e dados anatômicos.

## Goals
- Dar à pele uma contribuição de espalhamento multi-Gaussian pré-filtrada em UV, distinta do albedo de poros, integrada aos materiais de corpo e músculos.
- Tornar o modelo de menisco um modelo capilar planar explicitamente parametrizado por contato angular e escala de comprimento capilar, sem apresentar a aproximação como solver CFD.
- Fazer a direção usada no shading anatômico customizado corresponder à luz key efetiva da cena.
- Reforçar testes para kernels UV, parâmetros capilares, mapeamento morfológico e coerência de iluminação.
- Aplicar os vértices do morph esparso de deltoides com pesos independentes nas três cabeças já identificadas pelos IDs canônicos 2/3/4, mantendo fallback `deltoids` em perfis persistidos antigos.
- Criar validações executáveis que diferenciem shader parsing, compilação GPU e testes estáticos.
- Documentar fontes GitHub e limitações/licenças de forma reproduzível.

## Non-goals
- Não substituir Three.js/WebGL2 por outra engine.
- Não adicionar SPH/FLIP, FFT ocean, path tracer, MHD/descarga elétrica, nem um framework de física de fluidos.
- Não importar o conjunto completo do Human Atlas (15 sistemas e dezenas de MB) para o runtime.
- Não declarar anatomia clínica, previsão fisiológica ou SSS path-traced.
- Não mudar os IDs de grupos musculares consumidos pelo domínio de treino.

## Anti-goals
- Não trocar qualidade por glow/neon, partículas permanentes ou luz no chão.
- Não adicionar dependências runtime por popularidade.
- Não modificar o halo único atrás do corpo nem reintroduzir plinto, chão, projector ou sombra de contato.
- Não sobrescrever a malha-base feminina com dataset de anatomia masculina.

## Current findings
- A água usa SDF/ray marching e solver Euleriano 2D compacto; o menisco atual é `h(d)=h0 exp(-d/lambda)` e é uma aproximação planar linearizada, não solução numérica 3D de Young–Laplace.
- Os metais usam Fresnel de condutor exato e RGB `n,k` tabulado para prata/cromo/ouro; amostras são discretas em λ, não espectro contínuo.
- O plasma e os arcos seguem modelos procedurais visuais, não simulação eletromagnética.
- A anatomia-base é MakeHuman hm08; há 12 canais de morph de domínio/14 IDs estáveis no render. A tabela esparsa `deltoids` contém vértices canônicos nos IDs 2/3/4, então os três pesos podem ser separados sem trocar o asset. Outras subdivisões continuam agrupadas.
- A pele usa mapas procedurais de 512/768 px e o compositor dual-body tem difusão screen-space curta de cinco taps.
- O shader de anatomia usa uma direção de key fixa que precisa ser conferida contra o rig real.
- O estágio já não tem chão/plinto/projector; o fundo usa um único halo suave.

## Approaches considered
1. **Substituir o motor de renderização / adicionar física pesada:** maior potencial teórico, custo de integração e dispositivos muito alto, incompatível com o tamanho dos componentes.
2. **Importar o Human Atlas completo como corpo:** adicionaria grande dataset masculino adulto CC BY 4.0, com incompatibilidade direta com a topologia e morfologia atuais; não é seguro como malha universal.
3. **Incremental físico baseado nos contratos existentes (recomendado):** manter Three.js, adicionar SSS UV multi-Gaussian leve a partir do albedo já gerado, explicitar o modelo capilar e alinhar as luzes; preservar morfologia/mesh atuais e melhorar testes e proveniência. Maior melhoria com menos risco.

## Tech stack
Three.js 0.187, TypeScript, WebGL2, GLSL ES 3.00 para os componentes; compositor Three.js ShaderMaterial no pipeline atual. Processamento UV gerado uma vez na inicialização, textura RGBA linear/sRGB declarada corretamente; testes Node/tsx sem dependência de GPU quando possível.

## Source and licensing policy
GitHub repositories are algorithm references, not code to copy blindly. Human Atlas source code is MIT, while BodyParts3D assets are CC BY 4.0 and represent adult male reference anatomy; data attribution and demographic limitations must accompany any asset use. Water repos without a declared license are not eligible for code reuse. FastNoiseLite MIT is a reference/library candidate, but no runtime dependency is needed for this increment.


## Additional implementation discovered during source review

The canonical mesh payload already stores the deltoid sparse morph across canonical muscle IDs 2, 3 and 4 (138, 52 and 102 affected vertices in the current payload). V11.19 now applies that existing sparse delta with `anteriorDeltoid`, `lateralDeltoid` and `posteriorDeltoid` weights. Existing profiles lacking those optional fields continue to use `regionalMorphs.deltoids`, preserving stored-state compatibility and baseline appearance. This is a genuine independent weight split on existing topology, not new scanned anatomical geometry.
