# V11.27 Nutrition Finalization Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans task-by-task. Each task uses TDD and is independently testable.

**Goal:** Close implementable V11.26 data-quality and domain-engine gaps without fabricating nutrient evidence.

**Architecture:** Keep calculations in pure nutrition/profile domain functions; aggregate complete coverage at recipe/meal/day boundaries; export the evidence-gated calculation primitives through the existing public nutrition module.

**Tech Stack:** Existing TypeScript/Node 22, React, Zustand, current HiGHS adapter. No new runtime dependencies.

**Spec:** `docs/superpowers/specs/2026-11-25-nutrition-finalization-v11-27.md`

## Global Constraints

- Unknown nutrient metrics never become zero.
- A partial sum is never displayed as a complete recipe, slot or day total.
- DIAAS requires amino-acid-specific ileal evidence and exact food-state matching.
- Only mixed-diet DIAAS is capped at 100; individual food score may exceed 100.
- Macro retention evidence is independent from micronutrient retention evidence.
- No universal raw-to-cooked multiplier.
- A non-exercise baseline must be at least RMR before exercise is added.
- Preserve V11.24 proportional meal scaling and V11.25 source-aware total energy.

## Review Focus

- A known food contributes a metric but a second food has that field `not_analyzed`.
- A meal is complete but a separate meal is missing a metric.
- DIAAS is >100 for an individual food versus a mixed diet.
- Digestibility species/method/state differ across protein sources.
- Raw-to-prepared yield is a percentage instead of a ratio.
- Numeric retention factor exists without matching source evidence.
- Workout energy is added to a base that is below RMR.

---

### Task 1: Full coverage for dietary metric totals

**Files:**
- Modify `src/domains/nutrition/domain/rules/cardapio-composer-engine.ts`
- Modify `src/domains/nutrition/components/cardapio-composer/composer/NutrientTargetBands.tsx`
- Modify `src/domains/nutrition/components/cardapio-composer/__tests__/composer-micronutrient-coverage.test.ts`

- [x] Add RED test for a quantified food combined with an unanalyzed food.
- [x] Verify RED: partial fiber sum was displayed instead of `null`.
- [x] Add `quantifiedCount`, `sourceCount` and `dataStatus` to dietary metric totals.
- [x] Propagate incompleteness through recipe, slot and day aggregation.
- [x] Use actual metric source count in the UI.
- [x] Verify focused composer test and full review suite.

### Task 2: Evidence-gated DIAAS and preparation engines

**Files:**
- Create `src/domains/nutrition/domain/rules/protein-quality.ts`
- Create `src/domains/nutrition/domain/rules/food-preparation-transform.ts`
- Create `src/domains/nutrition/domain/rules/__tests__/protein-quality-and-preparation.test.mjs`
- Modify `src/domains/nutrition/application/nutrition-public.ts`

- [x] Require amino-acid-specific ileal digestibility, source, state, method and species.
- [x] Apply FAO age-group scoring patterns and distinguish individual foods from mixtures.
- [x] Add RED test for a mixed diet with a raw score above 100; verify RED.
- [x] Cap only mixed-diet DIAAS at 100; preserve `untruncatedDiaas`.
- [x] Require exact food ID/state, yield factor and independently evidenced retention factors.
- [x] Keep unsupported or unmatched nutrient transformations `not_analyzed`.
- [x] Export both calculation engines and contracts publicly.
- [x] Verify direct tests and calculation typecheck.

### Task 3: Energy-base invariants

**Files:**
- Modify `src/domains/profile/domain/rules/energy-budget.ts`
- Modify `src/domains/profile/domain/rules/__tests__/energy-budget.test.mjs`

- [x] Add RED test where an exercise-excluding base below RMR is made to appear valid by a workout addition.
- [x] Verify RED.
- [x] Reject an exercise-excluding base below RMR before adding NET exercise energy.
- [x] Verify energy-budget and full review tests.

### Task 4: Reproducible nutrient-source coverage audit

**Files:**
- Create `src/domains/nutrition/domain/rules/nutrition-data-coverage.ts`
- Create `src/domains/nutrition/domain/rules/__tests__/nutrition-data-coverage.test.mjs`
- Create `scripts/audit-nutrition-data-coverage.mjs`
- Create `docs/research/NUTRIENT_COVERAGE_TBCA72_V11_27.json`
- Modify `src/domains/nutrition/application/nutrition-public.ts` and `package.json`

- [x] Add RED test for unit mismatch, negative value, trace, unanalyzed and missing source records.
- [x] Verify RED when module is absent.
- [x] Count only canonical-unit, finite, non-negative values with positive basis.
- [x] Preserve TBCA `not_analyzed` versus OFF `missing` semantics.
- [x] Export audit API and generate a reproducible full-catalog JSON snapshot.
- [x] Verify focused test and audit command.

### Task 5: Research, docs, final verification and packaging

**Files:**
- Update `README.md`, `package.json`, research ledger, changelog and SDD progress.
- Add V11.27 design and plan records.

- [x] Record GitHub repositories, stars snapshot, license metadata and decisions not to reuse incompatible/unlicensed code.
- [x] Record real data coverage blockers and external validation gates.
- [x] Run `npm run test:review`, targeted tests, strict calculation typecheck and `git diff --check`.
- [x] Attempt Vite build, full lint and `npm test`; record exact dependency failures. HiGHS WASM remains unavailable without dependencies/browser.
- [x] Package ZIP and verify archive integrity and SHA-256 (V11.28 archive; see package verification record in README/changelog).


### Task 6: UL application guard and DIAAS evidence provenance

**Files:**
- Modify `src/domains/nutrition/domain/rules/cardapio-composer-engine.ts`
- Modify `src/domains/nutrition/state/nutrition.store.ts`
- Modify `src/domains/nutrition/components/cardapio-composer/variants/OptimizationPreview.tsx`
- Modify `src/domains/nutrition/domain/rules/protein-quality.ts`
- Modify `src/domains/nutrition/domain/rules/__tests__/micronutrient-optimizer.test.mjs` and `protein-quality-and-preparation.test.mjs`

- [x] RED: hard-UL conflict had no domain apply guard; add assertion.
- [x] GREEN: block proposal application and saving across domain/store/UI when an applicable UL is exceeded.
- [x] RED: DIAAS accepted rat digestibility and ignored mismatched amino-acid food identity.
- [x] GREEN: restrict evidence species to human/pig; validate exact food/state/source/version/reference/URL and mg/g protein basis for amino-acid and digestibility evidence.
- [x] Verify focused tests and full review suite.
