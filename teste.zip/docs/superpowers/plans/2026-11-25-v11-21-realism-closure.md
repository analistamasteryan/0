# TITAN V11.21 Realism Closure Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Corrigir as lacunas numéricas e ópticas incrementais de V11.20 sem substituir o renderer ou adicionar dependências de runtime.

**Architecture:** Evolução isolada do solver 2D, helpers de física testáveis no CPU e injeção GLSL existente. Pesquisa de GitHub orienta algoritmo e licença; não há cópia de motores ou ativos de terceiros.

**Tech Stack:** React 19, TypeScript, Three.js r187, WebGL2, GLSL ES 3.00, Node.js 22 para testes nativos.

**Spec:** `docs/superpowers/specs/2026-11-25-v11-21-realism-closure-design.md`

## Global Constraints

- Manter React 19, TypeScript, Three.js r187, WebGL2 e GLSL ES 3.00.
- Não adicionar dependências de runtime.
- Preservar halo difuso único atrás do corpo e ausência de luz no chão/projetor.
- Não substituir o rig anatômico sem compatibilidade verificada.
- Não afirmar solver físico completo onde o código é aproximado.
- Dados externos incorporados devem ter licença e proveniência verificáveis.

## Review Focus

- Coalescência, reciclagem e eventos devem fechar conservação de massa no conjunto de gotas — `droplet-mass-balance.test.mjs`.
- Projeção sob campo determinístico, número de iterações e resíduo devem ter limites — `fluid-pressure-projection.test.mjs`.
- Fresnel em ângulo normal/rasante, anchors e interpolação devem ser consistentes — `metal-optics-spectrum.test.mjs`.
- Envelope Heidler deve alcançar unidade, permanecer limitado e decair — `lightning-waveform.test.mjs`.
- Avanço/recuo devem trocar o par dinâmico de ângulos e alterar pinning — `capillary-meniscus.test.mjs`.

---

### Task 1: Deep research e decisão de adoção

**Arquivos:**
- Create: `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_21.md`
- Create: `docs/superpowers/specs/2026-11-25-v11-21-realism-closure-design.md`

- [x] Selecionar até cinco repositórios por função pela compatibilidade técnica, não pelo número de estrelas isolado.
- [x] Inspecionar código de SPlisHSPlasH, PBRT, Three.js SSS, DBM, WebGPU-Ocean, Open Anatomy e refractiveindex.info.
- [x] Registrar licenças conhecidas, decisões de não adoção e limites de compatibilidade.

### Task 2: Ledger de massa das gotas

**Arquivos:**
- Create: `src/shared/graphics/droplet-mass-balance.ts`
- Modify: `src/shared/graphics/hydration-fluid-solver.ts`
- Test: `src/shared/graphics/__tests__/droplet-mass-balance.test.mjs`

- [x] Escrever teste de coalescência, fontes, sumidouros e transferência para reservatório.
- [x] Executar antes da implementação e observar falha por ausência da API.
- [x] Implementar ledger e roteamento central das mudanças de massa.
- [x] Transferir massa integralmente na coalescência e expor massa transferida ao reservatório.
- [x] Executar teste determinístico e confirmar resíduo próximo de zero.

### Task 3: Projeção de pressão 2D

**Arquivos:**
- Create: `src/shared/graphics/fluid-pressure-projection.ts`
- Modify: `src/shared/graphics/hydration-fluid-solver.ts`
- Test: `src/shared/graphics/__tests__/fluid-pressure-projection.test.mjs`

- [x] Escrever teste determinístico de redução de divergência.
- [x] Executar teste RED (módulo não existente).
- [x] Implementar divergência forward, gradiente backward e Laplaciano compatível.
- [x] Adicionar Jacobi adaptativo limitado a 8–28 iterações e diagnóstico de resíduo.
- [x] Corrigir documentação interna para não chamar o operador de MAC/centralizado.
- [x] Executar teste GREEN.

### Task 4: Histerese capilar

**Arquivos:**
- Modify: `src/shared/graphics/capillary-meniscus.ts`
- Modify: `src/shared/graphics/hydration-fluid-solver.ts`
- Test: `src/shared/graphics/__tests__/capillary-meniscus.test.mjs`

- [x] Testar ângulo leading/trailing em avanço e inversão.
- [x] Implementar relaxação limitada advancing/receding e fator fenomenológico de pinning.
- [x] Integrar atualização na gota sem alterar a equação linearizada do menisco.
- [x] Executar regressão do perfil capilar.

### Task 5: Dados de óptica de metais

**Arquivos:**
- Create: `src/shared/graphics/metal-optics-spectrum.ts`
- Modify: `src/shared/graphics/fluid-shader-engine.ts`
- Test: `src/shared/graphics/__tests__/metal-optics-spectrum.test.mjs`

- [x] Importar apenas dados medidos de domínio público CC0 para Au, Ag e Cr.
- [x] Implementar interpolação linear n/k e Fresnel complexo exato.
- [x] Integrar nove amostras no shader: três taps por banda RGB.
- [x] Testar anchors, interpolação e resposta Fresnel em incidência normal/rasante.

### Task 6: Envelope temporal Heidler

**Arquivos:**
- Create: `src/shared/graphics/lightning-waveform.ts`
- Modify: `src/shared/graphics/fluid-shader-engine.ts`
- Test: `src/shared/graphics/__tests__/lightning-waveform.test.mjs`

- [x] Escrever teste que exige pico normalizado em 1.0 e observar falha com a constante anterior.
- [x] Corrigir a normalização analítica para o conjunto de parâmetros visual usado.
- [x] Manter CPU e GLSL com a mesma constante.
- [x] Executar teste temporal e verificar cauda.

### Task 7: Integração, pesquisa, pacote e validação

**Arquivos:**
- Modify: `package.json`
- Create: `scripts/check-physics-v11-21.mjs`
- Create: `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_21.md`
- Create: `CHANGELOG_V11_21.md`
- Create: `.superpowers/sdd/2026-11-25-v11-21-realism-closure/progress.md`

- [x] Adicionar teste agrupado V11.21 aos scripts de realismo.
- [x] Executar teste agrupado e suites existentes de realismo/review (`physics`, `rendering-realism`, `review`, `adaptive-plasma`, `typecheck:calculations` passaram).
- [x] Executar suíte completa, lint, typecheck, build e GPU shader test; bloqueios reais registrados no ledger (`tsx`, `vite`, `vite/client` ausentes; Chromium WebGL excedeu timeout).
- [x] Revisar fontes e diff por regressões e preservar arquivo-base.
- [x] Gerar ZIP e sidecar SHA-256; validar CRC e checksum após extração limpa e repetir `test:physics-v11-21` na cópia extraída.
