# V11.25 Energy Budget and Goal Intake Implementation Plan

> **For agentic workers:** Use superpowers:executing-plans task-by-task. Each task uses TDD.

**Goal:** Correct and expose the energy accounting that produces the daily calorie intake target, preserving meal allocation and proportional ingredient scaling.

**Architecture:** A pure domain energy-budget resolver composes source-aware TDEE, RMR, optional NET exercise energy, goal adjustment and final intake. The existing goal calculator remains the orchestration point; the React preview only displays the resulting contract.

**Tech Stack:** Existing TypeScript, Node 22 tests, React, Zustand, Vite. No runtime dependency additions.

**Spec:** `docs/superpowers/specs/2026-11-25-energy-budget-and-target-intake-design.md`

## Global Constraints

- Never add exercise calories to NASEM EER or observed adaptive TDEE.
- Never use gross exercise energy as additive expenditure.
- Preserve existing public fields and persisted profile compatibility.
- Do not infer unknown energy/nutrient values.
- Keep Hall as a dynamic target-intake model, not an extra expenditure term.
- Keep meal allocation and proportional scaling explicit, reversible and separate from flexible optimization.
- Do not claim clinical validation or external calibration not performed.

## Review Focus

- TDEE below RMR or invalid/negative inputs.
- Logged workout energy added twice.
- Workout record is gross or has ambiguous energy basis.
- Macro feasibility floor changes the final energy target.
- Goal and target-weight direction disagree.
- UI wording implies that residual activity/TEF is directly measured.

---

### Task 1: Source-aware daily energy budget

**Files:**
- Create: `src/domains/profile/domain/rules/energy-budget.ts`
- Create: `src/domains/profile/domain/rules/__tests__/energy-budget.test.mjs`

**Interfaces:**
- `resolveDailyEnergyBudget(input)` accepts RMR, base TDEE, source basis, optional NET exercise kcal and signed goal adjustment.
- Returns total TDEE, non-resting residual, exercise treatment, and final target intake.

- [x] Write tests for total TDEE with exercise already included; no double-add.
- [x] Write tests for explicitly exercise-excluding base; add NET exercise once.
- [x] Write tests for invalid, negative, gross/ambiguous, and TDEE-below-RMR inputs.
- [x] Run test and verify expected RED.
- [x] Implement minimal pure function.
- [x] Run test and verify GREEN.

### Task 2: Integrate budget into goal calculator

**Files:**
- Modify: `src/domains/profile/domain/contracts/user-profile.ts`
- Modify: `src/domains/profile/domain/rules/goal-calculator.ts`
- Modify: `src/domains/profile/application/profile-public.ts`
- Modify: `src/domains/profile/__tests__/calculation-engine.test.mjs`

- [x] Add `restingMetabolicRateKcal` and `energyBudget` while preserving `bmr`.
- [x] Add optional exercise context; current NASEM/adaptive sources always mark exercise as already included.
- [x] Make `calorieAdjustmentKcal` equal final `kcal - tdee`; retain requested and bounded adjustments separately.
- [x] Test all four goals, adaptive and NASEM sources, macro floor and workout non-addition.
- [x] Verify RED → GREEN.

### Task 3: Validate food macro data before calculation

**Files:**
- Create: `src/domains/nutrition/domain/rules/food-data-quality.ts`
- Modify: `src/domains/nutrition/domain/rules/nutrition-calculator.ts`
- Modify: `src/domains/nutrition/domain/rules/cardapio-composer-engine.ts`
- Modify: `src/domains/nutrition/domain/rules/food-search.ts`
- Modify: `src/domains/nutrition/state/nutrition.store.ts`
- Create: `src/domains/nutrition/domain/rules/__tests__/food-macro-validation.test.mjs`

- [x] Validate finite/nonnegative macro fields, basis, mass balance and saturated-fat relation.
- [x] Treat simple Atwater mismatch as a warning, not an automatic correction.
- [x] Quarantine invalid foods from selection, logging, recipe aggregation, proportional scaling energy basis and QP variables.
- [x] Preserve common-factor scaling for an invalid/unquantified ingredient when another valid ingredient establishes the meal factor; do not scale an all-invalid meal without an energy basis.
- [x] Scan the bundled TBCA catalog and explicitly test every anomaly.
- [x] Verify RED → GREEN.

### Task 4: Explain the energy equation in the live preview

**Files:**
- Modify: `src/domains/cockpit/components/HomeHeader.tsx`

- [x] Show RMR, non-resting residual, TDEE, goal adjustment and final daily intake.
- [x] Explain that recorded exercise is included in total TDEE and is not added again.
- [x] Keep the label for the residual broad; do not call it measured NEAT or measured TEF.
- [x] Transpile/check component syntax.

### Task 5: Regression and final review

**Files:**
- Modify: `package.json`
- Modify: `README.md`
- Create: `CHANGELOG_V11_25.md`
- Modify: `.superpowers/sdd/2026-11-25-v11-25-energy-budget/progress.md`

- [x] Add energy budget tests to the existing calculation review chain.
- [x] Run `npm run test:review`, calculation typecheck, and any available build/lint commands (build/lint attempted and blocked by absent dependencies).
- [x] Review diff against the design and run the V11.24 regression suite.
- [x] Record blocked environment checks honestly.
- [x] Package and verify ZIP integrity and SHA-256.
