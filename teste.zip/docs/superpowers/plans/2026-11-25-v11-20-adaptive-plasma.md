# TITAN V11.20 Adaptive Plasma Integration Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the plasma volume shader's fixed 12-step integration with a bounded segment-length adaptive policy while preserving visual baseline and GLSL ES 3.00 compatibility.

**Architecture:** Keep the current WebGL2 shader and noise field. Mirror the step-count policy in TypeScript for unit tests, use a static GLSL loop bound of 16, and divide the traversed segment by the selected count.

**Tech Stack:** TypeScript, GLSL ES 3.00, Node.js native type stripping, existing static shader checks.

**Spec:** `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_20.md`

## Global Constraints
- Do not add runtime dependencies.
- Do not replace Three.js/WebGL2 or the current plasma field.
- Preserve the approximately 12-step baseline for typical cavity chords.
- Keep GLSL loop bound statically capped at 16.
- Do not claim GPU performance gains without GPU measurements.

## Review Focus
- Zero, negative, non-finite and very short segment lengths.
- Long segments remain capped at 16 samples.
- Typical segment length preserves the V11.19 12-sample baseline.
- GLSL integration covers the full segment with `ds = segmentLength / volumeSteps`.
- Static loop bound remains compatible with GLSL ES 3.00 drivers.

---

### Task 1: Adaptive plasma volume-step policy

**Files:**
- Modify: `src/shared/graphics/fluid-shader-engine.ts`
- Create: `src/shared/graphics/__tests__/adaptive-plasma-volume-steps.test.mjs`
- Create: `scripts/check-adaptive-plasma-march-v11-20.mjs`
- Modify: `package.json`
- Modify: `CHANGELOG_V11_20.md`

- [x] Write a failing behavior test for minimum, baseline and maximum tiers.
- [x] Run it and confirm the missing export causes the expected failure.
- [x] Implement a CPU mirror and bounded GLSL policy (8–16 samples).
- [x] Replace the fixed 12-step loop with static maximum 16 and early break at selected count.
- [x] Run adaptive policy test and full rendering-realism contract.
- [x] Record GPU compile/performance blockers explicitly.
