# TITAN V11.23 Rendering Scope and Runtime Pruning Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Improve the visible water/glass meniscus and prune API/server/anatomy scaffolding that has no product consumer, without changing the renderer or adding dependencies.

**Architecture:** Keep the Three.js/WebGL2 renderer. Mirror a nonlinear 2D Young–Laplace approximation in CPU reference code and GLSL; remove the unneeded Express server entirely and use Vite plus static `dist/`; remove unused infrastructure and hidden skeletal geometry while preserving muscle and provenance paths.

**Tech Stack:** TypeScript, Node.js 22.12+, Vite 8, React 19, Three.js r187, GLSL ES 3.00, Node assert scripts. No Express or new runtime dependency.

**Spec:** `docs/superpowers/specs/2026-11-25-v11-23-rendering-scope-and-runtime-pruning-design.md`

## Global Constraints

- Do not add runtime or development dependencies.
- Do not add network/API endpoints or external API clients.
- Do not generate bones, tendons or fascia meshes.
- Preserve muscle surfaces, dual-body morphs, selection/picking, deep soft-tissue plane, and body halo/no-floor-light rule.
- Preserve record-level exercise data provenance and Open Food Facts catalog behavior.
- Use TDD for every behavior change.

## Review Focus

- Contact angles near neutral and strongly wetting/non-wetting values must stay finite and converge to zero at distance.
- Old persisted `layerMode: 'skeleton'` must remain safe and display complete body mode.
- Removing Express must leave `dev`, local `start` preview, and static production `dist/` commands valid.
- Production must not depend on a custom Node server or ungenerated artifact.
- Provenance and active food-domain catalog data must remain intact after removing candidate-source UI.

---

### Task 1: Nonlinear Young–Laplace meniscus

**Files:**
- Modify: `src/shared/graphics/capillary-meniscus.ts`
- Modify: `src/shared/graphics/fluid-shader-engine.ts`
- Test: `src/shared/graphics/__tests__/capillary-meniscus.test.mjs`
- Test: `scripts/check-nonlinear-meniscus-v11-23.mjs`

**Interfaces:**
- Produce `capillaryMeniscusHeightNonlinear(wallDistance, capillaryLength, contactAngleRadians): number`.

- [x] Add RK4 reference test and fail against missing function.
- [x] Run test and confirm expected missing-export failure (RED observed).
- [ ] Implement bounded closed-form approximation using exact first-integral wall height, contact-line slope and exponential far-field transition.
- [x] Mirror formula in GLSL and switch the two existing wall-meniscus call sites.
- [x] Run numerical and shader source-contract tests; target <=8% relative error at specified points.

### Task 2: Remove unconsumed API/runtime scaffolding

**Files:**
- Delete: `server.ts`
- Modify: `package.json`
- Modify: `AGENTS.md`
- Delete: `server.js`
- Delete: `src/infrastructure/api/http-client.ts`
- Delete: `src/infrastructure/sync/sync-queue.ts`
- Delete: `src/infrastructure/analytics/event-tracker.ts`
- Test: `scripts/check-v11-23-scope-and-pruning.mjs`

**Interfaces:**
- Use Vite directly: `dev` runs `vite --host 0.0.0.0`, `start` runs `vite preview --host 0.0.0.0`, production publishes `dist/`.

- [x] Add source-contract checks and observe failure.
- [x] Remove API routes, Zod endpoint schemas and unused route-only domain imports.
- [x] Remove custom Express server, Express/compression dependencies and type packages; keep Vite as the sole dev/preview server.
- [x] Delete zero-consumer modules and the unused Gemini SDK/key plus unused Open Food Facts API URL helper.
- [x] Verify all retained data/domain source contracts.

### Task 3: Remove hidden skeletal construction

**Files:**
- Modify: `src/domains/anatomy/engine/scene/build-anatomy-body.ts`
- Modify: `src/domains/anatomy/engine/materials/anatomy-materials.ts`
- Modify: `src/domains/anatomy/engine/renderer/anatomy-renderer.ts`
- Modify: `scripts/check-anatomy-v9.mjs`
- Modify: `AGENTS.md`
- Test: `scripts/check-v11-23-scope-and-pruning.mjs`

**Interfaces:**
- `AnatomyBodyRig` retains `root`, `shellGroup`, `superficialGroup`, `deepGroup`, muscle entries, pickable/occlusion meshes and dispose; no skeleton group.

- [x] Add contracts requiring no generated skeleton group/material/tubes while preserving muscle/deep groups; observe RED.
- [x] Remove skeletal geometry generators and generated bone/skull/rib/pelvis/limb/toe batches.
- [x] Remove unused skeleton material and renderer visibility toggling.
- [x] Preserve legacy persisted skeleton layer alias to complete mode.
- [x] Run source contracts; full anatomy suite status is recorded in the ledger after fresh execution.

### Task 4: Remove candidate repository panel from runtime UI

**Files:**
- Modify: `src/domains/exercise-library/screens/ExerciseLibraryScreen.tsx`
- Keep: `src/domains/exercise-library/data/repositories/exercise-source-registry.ts`
- Keep: exercise source references in catalog records
- Test: `scripts/check-exercise-muscle-contract.mjs`

- [x] Add UI-source assertion for absence of candidate repository panel.
- [x] Remove panel/import only; retain static registry for provenance tests and record-level metadata.
- [x] Preserve their direct test commands in the verification plan; execution status recorded in ledger.

### Task 5: Release documentation and verification

**Files:**
- Create: `CHANGELOG_V11_23.md`
- Create: `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_23.md`
- Create: `.superpowers/sdd/2026-11-25-v11-23-scope-pruning/progress.md`
- Modify: `package.json` to add focused test script and include it in `test:rendering-realism` or `test:review`.

- [x] Update research with five relevant GitHub references per visual subsystem, adoption decisions, no new dependencies and user scope excluding bones/tendons.
- [x] Run focused rendering checks and review suite; calculation typecheck passed. Full `test:anatomy` remains blocked by missing `tsx`/`three`; run independent static anatomy contracts.
- [x] Attempt lint/build and document toolchain failures precisely: `vite/client` and `vite` absent because dependencies are not installed.
- [x] Perform final source audit, create ZIP and SHA-256, run archive CRC test (recorded after packaging).
