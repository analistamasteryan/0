# V11.34 — TBCA ingredient integrity implementation plan

> Superpowers-style TDD and isolated Git worktree. Each task starts with a failing test, then a minimal implementation and a verification pass.

## Architecture decisions
- Keep the source catalog complete; enforce selection policy at recipe-specific boundaries only.
- Add one pure domain policy for source-aware eligibility. Do not couple it to React or search UI.
- Add a purpose parameter to the current search function, keeping `general` as the backward-compatible default.
- Enforce eligibility in the Zustand store as the final guard.
- Use TBCA's explicit `food_type`; do not use title heuristics.
- Keep Fuse.js/Orama/Splink as researched reference options only. At 5,830 foods, no new dependency is justified; a source metadata gate is deterministic and cheaper than fuzzy retrieval.

## Tasks
1. [x] Add failing domain policy tests for TBCA ALIMENTO, PREPARACAO_COMPOSTA, missing type, local legacy, OFF and USDA.
2. [x] Implement the source-aware food ingredient policy.
3. [x] Add search purpose (`general` / `recipe-ingredient`) and test that the filter is applied before ranking/limit.
4. [x] Add dynamic composite detection from resolved source type, preserving legacy IDs.
5. [x] Guard store add and composite replacement methods; test rejection of compound rows.
6. [x] Update RecipeProportionMatrix and ProportionRail to use recipe-ingredient search.
7. [x] Preserve general results in IntegratedCatalogDrawer for diary logging but disable recipe addition for ineligible records with a visible reason.
8. [x] Repair legacy TBCA aliases to canonical IDs, move local composite snapshots to a truthful TITAN_LEGACY provenance namespace, and test all six.
9. [x] Add a reproducible TBCA type/provenance audit and regression tests against the full catalog.
10. [x] Update research, gaps, changelog, README and verification report; run focused tests, nutrition hardening, review suite, calculations typecheck, typecheck/lint/build where environment permits.
11. [x] Adversarial self-review, check diff/clean worktree, commit and package verified ZIP.
12. [x] Audit all recipe templates; hide legacy templates with composed/noncanonical lines and guard new assignment/substitution actions.

## Critical review questions
- Are existing composite foods still loggable as complete meals?
- Can a direct store call bypass the UI eligibility filter?
- Does an empty TBCA `food_type` pass unexpectedly?
- Does limit handling happen after filtering so a mixed index cannot starve valid ingredient results?
- Do aliases report real TBCA source_record_id values?
- Do local composite snapshots stop claiming TBCA laboratory provenance?
- Do other sources remain unchanged rather than being guessed from their names?
