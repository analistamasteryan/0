# Hydration liquid rendering — V.MAX

## Visual intent

The hydration meter is a small optical object, not a standard progress bar:
- one refractive water droplet at the left;
- one horizontal mineral-glass capsule;
- a clear, pale-cyan water volume that grows from left to right;
- a brief meniscus/ripple after a real hydration value change;
- a gentle resting capillary swell (~30fps) so the liquid stays organically alive without draining battery, boosting to 60fps during transitions, tilts, or droplet impacts.

The 3D-like visual is rendered in a shared WebGL2 context coordinated by `HydrationVisualScene` (`src/shared/graphics/hydration-visual-scene.ts`). Card gauges and `BottomSheet` gauges share identical wave springs, vorticity grids, solitons, tilt, and visual microdroplet mass swell. Rendering never writes registered ml to `hydration.store`.

## Research used

The implementation adapts techniques rather than importing a large water renderer:

1. [evanw/webgl-water](https://github.com/evanw/webgl-water) — reflection/refraction, Fresnel, height-field waves and differential-area caustics. Used as the baseline reference for optical behavior.
2. [Aureliengmz/clearwater](https://github.com/Aureliengmz/clearwater) — modern WebGL2 shallow-water shading, spectral refraction, Fresnel and adaptive rendering. Its full ocean/FFT pipeline is intentionally not imported for a 44px UI capsule.
3. [HowdyKeith/swek-webgl2-water](https://github.com/HowdyKeith/swek-webgl2-water) — compact WebGL2 heightfield, Schlick Fresnel and differential-area caustics. Used to review a lightweight ripple model.
4. [pmndrs/drei MeshTransmissionMaterial](https://github.com/pmndrs/drei/blob/master/src/core/MeshTransmissionMaterial.tsx) — transmission, thickness, IOR, attenuation, chromatic aberration and backside-refraction concepts. No dependency added.
5. [StarKnightt/liquid-glass](https://github.com/StarKnightt/liquid-glass) and [smirki/glasswork](https://github.com/smirki/glasswork) — SDF-based droplet/lens silhouettes, normals from distance gradients, bounded Snell refraction and refined rim response.

The existing engine already had most of the right optical primitives (IOR, Schlick Fresnel, Beer–Lambert attenuation, dispersion, caustics and SDF droplet). The main upgrades preserve glass clarity and add unified microdroplet absorption across the external action band and both liquid reservoirs.

## Implemented changes

### Visual hierarchy & unified coordinate space
- External top band above the Liquid Glass card hosts **Desfazer** and **Registrar água** (`>= 44px` touch targets).
- `CardDropletOverlay` (`pointer-events: none`, `z-[5]`) spans the entire `#cockpit-hydration` root so microdroplets slide over the external buttons, cascade onto the card (`cardBounds`), deflect off dry glass walls, and enter 6-stage capillary bridge absorption upon hitting the wet surfaces of the 3D droplet or 3D crystal tank.

### Droplet
- Optical canvas sized at 84×100 CSS pixels with tapered tip wall thickness (`0.020` to `0.0045`) so 85–100% fills render cleanly inside the narrow tip.
- True curved SDF silhouette, liquid fill plane, Young–Laplace curved meniscus, Beer–Lambert attenuation (`u_attenColor`, `u_attenDist`), and internal refraction.
- Percentage badge rendered directly below the droplet.

### Horizontal glass capsule
- Glass capsule height is 44px with optical end-cap highlights and crystal mineral bevel.
- Retains the horizontal fill model, fluid vorticity grid (`48×24`), left-to-right meniscus, and aeration turbulence (`fluidAeration`).
- Supports 6-stage microdroplet absorption (`contact` deformation → `liquid bridge` neck → `merge` fade → reservoir wave/meniscus swell).

### Motion and performance
- Fill interpolation is frame-rate independent.
- Spring simulation uses a fixed 60Hz-equivalent accumulator, capped to three catch-up steps.
- Incomplete Cholesky preconditioner caches `preconditionerRootDiagonal` per grid rebuild, eliminating per-iteration `Math.sqrt` overhead.
- Adaptive loop pacing: 60fps during fills, impulses, tilts, and active droplet absorption; ~30fps calm capillary swell at rest; paused immediately when off-screen, `document.hidden`, or `prefers-reduced-motion`.
- Reduced-motion mode disables particles/ambient waves and applies the new value immediately.

### Fallback
- Layered Canvas2D fallback for both droplet and 44px rounded glass capsule with meniscus, reflection strip, and beveled shell.
- Fallback values continue to use the same hydration summary and do not change business logic.

## Constraints

- This is a stylized optical UI object, not a full SPH fluid solver or a physically complete ray-traced glass simulation.
- Visual microdroplet absorption never alters registered milliliters in `hydration.store`.
- The existing quick add, custom amount, correction and history behaviors remain unchanged.


## Accuracy note

The studio environment is analytically generated in GLSL from a floor, horizon, sky and softbox lobes. It is **not** an imported HDR image/texture and the renderer is not path-traced or a complete 3D fluid solver. Its visual result is a deliberately bounded 2.5D/SDF optical approximation for a small dashboard control.
