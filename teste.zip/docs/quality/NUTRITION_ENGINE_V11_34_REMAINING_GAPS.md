# TITAN Nutrition Engine — gaps após V11.34

| Prioridade | Domínio | Estado após V11.34 | Próximo trabalho | Critério de aceite |
|---|---|---|---|---|
| P0 | Integridade TBCA no compositor | Fechado para o catálogo local 7.2: busca de ingredientes e ações de estado bloqueiam `PREPARACAO_COMPOSTA`; busca geral/diário preservam esses pratos; seis templates legados bloqueados em seleção nova/substituição, dois templates elegíveis | Manter gate em toda nova tela/API de inclusão de ingrediente; validar importações futuras antes de indexar; obter dados de receita e pesos documentados para reconstruir modelos bloqueados | Nenhuma preparação composta TBCA entra como ingrediente ou modelo novo por UI, chamada direta ou busca vazia |
| P0 | TBCA 7.3 e licença/proveniência | Catálogo embarcado continua TBCA 7.2; site oficial informa versão 7.3 (2025) | Avaliar obtenção/autorização para dados novos, comparar versão por versão, conservar origem/licença e não redistribuir nem alterar os valores TBCA sem permissão | Release 7.3 adquirido de fonte autorizada, hash, versionamento, diffs e revisão legal/científica |
| P0 | USDA FDC | Downloader pinado + ZIP parser/importer + agregação multi-tipo; catálogo gerado permanece vazio | Obter releases reais, importar Foundation/SR/FNDDS, medir memória/tempo e quarentena | Hash/release oficial, reimport idempotente, cobertura por nutriente/fonte, nenhuma falha silenciosa |
| P0 | Build/CI/runtime | Gates de domínio existentes; validação local anterior bloqueada por ausência de dependências instaladas | Executar CI completo, build/lint global e runtime real do HiGHS WASM em ambiente com lockfile instalado | Workflow verde em ambiente limpo; solver runtime passa fixtures QP/MIP e integração |
| P1 | Crosswalk TBCA↔FDC | Namespace por fonte; sem crosswalk automático | Blocking por taxonomia/grupo/parte/estado/preparação e score multissinal; revisão humana dos pares duvidosos | Correspondência rastreável e nenhum merge por fuzzy name sozinho |
| P1 | UL / micronutrientes | Escopo químico/source-aware para casos cobertos; ledger suplementar | Bebidas, fortificados, medicamentos, suplemento completo e formas moleculares por produto | UL só avaliado com fonte/formas suficientes; cobertura incompleta resulta `indeterminate` |
| P1 | Preparo e rendimento | Framework de transformação/retenção separado | Importar fatores oficiais de retenção e rendimentos por alimento/método; macros e micronutrientes separados | True retention e cooking yield com evidência por combinação; sem fatores genéricos |
| P1 | DIAAS | Contrato de aminoácidos/digestibilidade e guardas de evidência | Dataset com aminoácidos e digestibilidade ileal por aminoácido, fonte, espécie, alimento e preparo | Validar com exemplos FAO publicados; sem dados, DIAAS fica indisponível |
| P1 | Gasto energético de treino | Estimativa MET acionada pelo usuário; sem soma automática a TDEE | Ledger persistente por sessão, baseline/calibração; revisar modelo de treino resistido | Proveniência/confiança e nenhuma dupla contagem em TDEE/EER |
| P2 | Otimização multidiária | QP/MIP diário e troca de refeição | Frequência/variedade, lote, orçamento, estoque, disponibilidade e explicações de inviabilidade | Regressões de 7/14/28 dias, restrições e qualidade/desempenho medidos |
| P2 | Validação científica/produto | Testes de domínio e simulações sintéticas | Revisão independente de nutricionistas/cientistas e validação populacional | Relatório científico, população/escopo, segurança e resultados reproduzíveis |

## Guardrails que permanecem obrigatórios

- Não declarar o motor completo ou clinicamente validado.
- Não declarar cobertura USDA enquanto `USDA_FDC_GENERATED_CATALOG` estiver vazio.
- Não converter ausência, traço, não analisado, unidade divergente ou registro em quarentena em zero.
- Não permitir que preparações TBCA compostas sejam ingredientes ou linhas de novos templates; elas continuam válidas como alimentos/refeições lançados diretamente no diário.
- Modelos legados com ingredientes compostos permanecem preservados para históricos, mas não aparecem em novas buscas/substituições até serem reconstruídos com linhas e quantidades de ingredientes verificadas.
- Não deduzir composição a partir de nomes de alimentos. A elegibilidade TBCA depende do campo tipado `food_type`.
- Não fazer crosswalk automático entre fontes usando somente similaridade textual; preservar os registros originais e as decisões de revisão.
- Não aplicar fatores de retenção de micronutrientes a macros.
- Não somar estimativas de treino a TDEE quando a atividade já estiver incluída.
