# TITAN Nutrition Engine — lacunas após V11.32

Auditoria de 2026-11-26. A matriz separa motor já implementado, integração incompleta, ausência de dados e validação externa. Uma função implementada sem dados reais não deve ser tratada como capacidade científica populada.

| Prioridade | Domínio | O que existe | O que falta para fechar | Gate de aceite |
|---|---|---|---|---|
| P0 | Instalação e release | `bun.lock`, Node review suite, typecheck dedicado e scripts determinísticos | Instalar dependências em CI; build completo, lint global, `npm test`/Bun test real, navegador e WASM HiGHS | CI limpa a partir do lockfile, build e suites verdes; smoke browser real; QP/MIP WASM executado |
| P0 | USDA FDC | Parser offline estrito para Foundation, SR Legacy, FNDDS e Experimental; 26/29 nutrientes canônicos mapeados onde há correspondência semântica; IDs/número/nome/unidade exatos; auditoria content-addressed; busca/lookup de registros dinâmicos | Importar releases oficiais pinados; testar todo o corpus, tamanho/RSS, duração, hashes, distribuição de quarentena; avaliar mapeamento de cloreto e estratégia para vitamina K total/niacina NE; catálogo persistido/composto por fonte e política de promoção | Dataset oficial fixado por tipo/release/hash; relatório de cobertura por nutriente; reimport idempotente; restauração; regressão de IDs |
| P1 | Crosswalk TBCA↔FDC | IDs separados e proveniência por fonte | Crosswalk humano/revisado, identidade de alimento, parte comestível, estado, cultivar/corte, processamento e incerteza | Nenhuma junção fuzzy usada em cálculo; amostra rotulada e auditada; métricas precisão/recall e abstenção explícita |
| P1 | Ingestão de suplementos | Ledger manual persistido de micronutrientes, data/hora, forma química e origem; subtotal suplementar separado | Catálogo/barcode/rotulagem, porções e produto, medicações, fortificados, macros/energia; agregação alimentar+suplementar apenas em unidades e formas compatíveis | Auditoria de UL por nutriente e escopo; fonte de rótulo/versionamento; unknown nunca zero; alertas mostram base comparada |
| P1 | Gasto energético de treino | Adaptador de sessão concluída para energia ativa estimada com MET e proveniência explícita; reconciliação de sobreposição e prioridade de fonte | Catálogo de MET licenciado/versionado; picker de atividade; consentimento/edição; persistência de sessão estimada e integração com ledger diário sem double-counting | Comparação com medição indireta/calorimetria em amostra; reconciliação HealthKit/Health Connect; política de estimativa separada do TDEE adaptativo |
| P1 | DIAAS / qualidade proteica | Calculadora e contrato de evidências por aminoácido/preparo | Dataset confiável por alimento, aminoácido indispensável e digestibilidade ileal por aminoácido, com espécie/método/amostra e preparação | Dados de estudo publicados e rastreáveis; cálculo reproduzido contra exemplos de referência; sem score se faltar aminoácido/digestibilidade |
| P1 | Preparo / cru-cozido | Contrato de transformação e bloqueio de conversão sem evidência compatível | Tabelas de rendimento e verdadeira retenção específicas por alimento, corte, método e nutriente; mapeamento fonte→alimento | Yield e true-retention separados; balanço de massa; validação de preparo e incerteza por nutriente |
| P2 | Otimização de refeição/dia | QP/MIP single-day, restrições UL, proporção de refeições, solver output guards | Diagnóstico de inviabilidade, residuals originais, objetivo recalculado, robustez a incerteza e explicação de relaxamentos | Primal + residual + objective check no WASM; testes de perturbação; proposta nunca viola hard constraints |
| P2 | Otimização multidiária | Não há otimizador de horizonte multi-day completo | Frequência/variedade, repetição, orçamento, estoque, batch-cooking, disponibilidade, nutrientes semanais, lexicographic objectives e explicação de infeasibilidade | Benchmark contra plano de referência; constraints duras preservadas; resultado reproduzível e explicado |
| P2 | Qualidade científica e clínica | DRI profiles e fontes de referência versionadas; verificações computacionais/simuladas | Revisão externa por nutricionista/dietista, auditoria fonte-por-fonte, populações especiais, casos clínicos e comparação com dados independentes | Aprovação de especialista por escopo/população; rastreio das versões e limitações; protocolo de monitoramento |
| P2 | Cobertura do catálogo | TBCA + OFF existente; USDA gerado vazio até import real | Cobertura por nutriente×alimento×estado×fonte; densidade de dados e lacunas; validação regional brasileira | Matriz de cobertura, missingness por fonte e versão; nenhuma meta declarada coberta por soma parcial |

## Decisões de implementação deliberadas

- Não introduzir OR-Tools ou trocar HiGHS apenas por popularidade: primeiro demonstrar que a formulação atual não atende os requisitos medidos.
- Não adicionar `fast-check`, Vitest, ast-grep, Semgrep, SonarQube ou reviewdog nesta revisão. São opções fundamentadas na pesquisa GitHub; a próxima etapa é habilitá-las seletivamente em CI quando a instalação estiver reproduzível.
- Não estimar kcal de musculação por séries, repetições, carga ou duração isolada. MET explícito continua sendo estimativa populacional, não medição individual.
- Não gerar DIAAS ou retenção de nutrientes sem dados específicos com correspondência de alimento e preparo.
- Não atribuir 98% de cobertura ao catálogo sem cálculo por nutriente, território, estado/preparo e fonte.

## Próxima sequência recomendada

1. CI/instalação limpa e validação de HiGHS WASM.
2. Importação oficial USDA por release, com benchmark e relatório de cobertura, depois crosswalk auditado.
3. Fechamento do ledger diário de alimentos, bebidas, fortificados, suplementos e medicações com scopes UL por forma.
4. MET catalog licenciado e sessão estimada persistida/reconciliada.
5. Dataset de retenção e DIAAS com evidência rastreável.
6. Multi-day optimization e revisão científica independente.
