# TITAN Nutrition Engine — gaps depois da V11.33

| Prioridade | Domínio | Estado atual | O que falta para fechar | Critério de aceite |
|---|---|---|---|---|
| P0 | USDA FDC | Downloader pinado + ZIP parser/importer + agregação multi-tipo sem overwrite; auditoria por fonte; catálogo gerado permanece vazio | Baixar releases reais, importar Foundation/SR/FNDDS, medir memória/tempo e quarentena | Hash/release oficial, reimport idempotente, cobertura por nutriente/fonte, nenhuma falha silenciosa |
| P0 | Build/CI/runtime | Bun CI fixo em 1.4.5 com gates explícitos adicionados | Executar CI de ponta a ponta, build/lint global e HiGHS WASM real | Workflow verde em ambiente limpo; solver runtime passa QP/MIP fixtures e testes de integração |
| P1 | Crosswalk TBCA↔FDC | Namespace separado por fonte e cobertura integrada | Identidade alimentar por alimento, estado, parte comestível, cultivar, fortificação e preparação | Crosswalk revisado, rastreável e sem merge por fuzzy name sozinho |
| P1 | UL / micronutrientes | Escopo químico/source-aware para casos mapeados; ledger suplementar | Bebidas, fortificados, medicamentos, suplemento completo e formas moleculares por produto | UL só avaliado com fonte/formas suficientes; cobertura incompleta resulta indeterminate |
| P1 | Preparo e rendimento | Framework de transformação e retenção separado | Importar dados reais USDA Retention Release 6 e cruzar alimento/método; mapear yields e retenção de macros separadamente | True retention e cooking yield calculados com evidência por combinação; sem fatores genéricos |
| P1 | DIAAS | Contrato de aminoácidos/digestibilidade e guardas de evidência | Dataset com aminoácidos e digestibilidade ileal por aminoácido, fonte, espécie, alimento e preparo | Validar com exemplos FAO publicados; sem dados, DIAAS fica unavailable |
| P1 | Gasto energético de treino | Estimativa MET acionada pelo usuário; sem somar automaticamente ao TDEE | Ledger persistente por sessão, baseline e calibração contra medidas; revisar modelo de treino resistido | Proveniência/confiança e nenhuma contagem dupla em TDEE/EER |
| P2 | Otimização multidiária | QP/MIP diário e troca de refeição | Frequência/variedade, lote, orçamento, estoque, disponibilidade, preferências, período e explicações de inviabilidade | Casos de regressão de 7/14/28 dias, restrições e métricas de qualidade/desempenho |
| P2 | Validação científica/produto | Testes de domínio e simulações sintéticas | Revisão independente de nutricionistas e cientistas, validação de dados e uso em múltiplas populações | Relatório científico, população/escopo declarado, análise de segurança e resultados reproduzíveis |

## Restrições explícitas

- Não considerar o motor completo ou validado clinicamente.
- Não declarar cobertura USDA enquanto `USDA_FDC_GENERATED_CATALOG` estiver vazio.
- Não converter unidades químicas sem regra específica (IU, RAE, DFE, NE, equivalentes).
- Não tratar ausência, traço, não analisado, unidade divergente ou registro em quarentena como zero.
- Não somar estimativas de treino a TDEE quando atividade já estiver incluída na equação/estimativa adaptativa.
- Não aplicar fatores de retenção de micronutrientes a macros.
