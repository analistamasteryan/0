# TITAN Nutrition Engine — lacunas e roadmap técnico após V11.35

Escopo auditado: catálogo TBCA local 7.2 + Open Food Facts + USDA FDC (sem corpus real importado) + registros legados TITAN. Esta classificação separa falha de código, ausência de dados e atividade bloqueada por permissão/ambiente. Um recurso não é considerado concluído porque existe um parser ou um teste sintético.

## Gaps ordenados por risco e impacto

| Prioridade | Domínio | Estado comprovado em V11.35 | Stack/técnicas avançadas e próximo trabalho | Critério de aceite |
|---|---|---|---|---|
| P0 | Catálogo USDA real | Pipeline downloader/ZIP/parser/importer e adaptador testados com fixtures; **0 registros USDA reais** no catálogo | Obter os archives oficiais Foundation, SR Legacy e FNDDS; `immutable artifact`, SHA-256, manifest de release, idempotent import, `quarantine ledger`, source-type isolation, bounded memory profiling | Corpus oficial íntegro, versão/hash, contagens por `dataType`, reimport idempotente, quarentena revisada, cobertura por nutriente e tipo alimentar; nenhuma fixture contada como dado real |
| P0 | Elegibilidade das receitas | 5.830 itens TBCA: 2.717 `ALIMENTO`, 3.113 `PREPARACAO_COMPOSTA`; 2/8 modelos elegíveis, 6 bloqueados porque usavam preparações compostas | Completar fichas reais com `recipe composition graph`, ingrediente canônico simples, gramas, EP/refugo, unidade/porção, método e fonte da receita; preservar histórico e não inferir gramagens | Os oito modelos passam por revisão com receita reproduzível e pesos documentados, ou continuam inelegíveis. Zero composto/UNKNOWN em ingredient slots, search, swap e store/API |
| P0 | TBCA 7.3 | Catálogo embarcado segue em TBCA 7.2; portal público mostra 7.3, mas termos de reprodução/uso precisam ser confirmados para o destino | Solicitar autorização formal ao TBCA/FoRC; comparar datasets por `source diff`, códigos persistentes, `semantic delta`, novos nutrientes, unidade, food_type e hash por arquivo | Acesso/licença autorizada para o uso/distribuição pretendido, proveniência e versão, revisão de todos os deltas, sem reempacotamento não autorizado |
| P0 | Build / CI / solver real | `test:review`, hardening e typecheck dedicado executáveis passam; nesta sessão falta Bun e `node_modules`, então lint/build/npm test não iniciam; HiGHS WASM não foi verificado em browser/runtime limpo | Instalar com `bun.lock` em runner suportado; `reproducible build`, `strict TypeScript`, Zod strict schemas em boundary, browser smoke test, WASM solver integration, CI artifact attestation | Ambiente limpo instala pelo lockfile; lint, typecheck global, build, testes completos e HiGHS WASM em problema de cardápio passam; sem lockfile/npm improvisado |
| P1 | Cobertura de micronutrientes para ingredientes | Audit agora separa TBCA simples/compostos. Agregado: B3 `mg NE` 0%; B5 0,1%; B7 0%; K 0,1%; colina, iodo, cloreto, molibdênio, cromo e fluoreto 0%; selênio 82,7%. | Obter fonte compatível e autorizada; `analyte identity`, `chemical species`, `unit normalization`, `same-basis matching`, `reported vs derived vs imputed`; B3 somente com NE explícito ou componentes 406+407/406+501 validados | Cobertura por `ALIMENTO` sobe com observações rastreáveis; lacunas explícitas continuam não quantificadas. Nenhum traço/ausente/unidade incompatível transformado em zero |
| P1 | Crosswalk TBCA ↔ USDA ↔ OFF | IDs e namespaces separados; nenhum merge automático | `FoodOn` + `LanguaL facets`, taxonomia/espécie/parte/EP/estado/processamento; `blocking`, Fellegi–Sunter/Splink, term-frequency adjustment, active-learning review queue, threshold calibration, precision/recall por classe | Cada par tem fonte, atributos comparados, score calibrado, decisão, motivo, versão e revisor; match por nome sozinho nunca é aceito; composto nunca cruza para simples |
| P1 | Cozimento / rendimento / composição de receita | Existem regras de transformação/preparação, mas não corpus suficiente de fatores por alimento/método | Separar EP, `yield factor` e `true retention factor`; `mass balance`, nutrient transformation, process metadata (método, tempo, temperatura, peso antes/depois, água/gordura adicionada ou perdida), uncertainty propagation | Fórmula reproduzível, fator por combinação alimento/nutriente/processo/fonte e versão; valores calculados marcados como calculados, diferentes dos analíticos; sem usar cru como cozido sem ajuste |
| P1 | DIAAS / qualidade proteica | Há dados de aminoácidos/contratos de digestibilidade, mas não banco amplo específico por alimento/processamento | `true ileal amino-acid digestibility`, scoring pattern por fase da vida, `reactive lysine`, hierarquia de espécie e método; não reutilizar digestibilidade fora da matriz/processamento validado | Todos aminoácidos indispensáveis e coeficientes compatíveis; método, espécie, fase de vida, processo e fonte; sem score parcial apresentado como DIAAS completo |
| P1 | UL / fontes de micronutriente | Escopo source-aware implementado para casos modelados; formas e origens ainda não estão completas | `chemical-form normalization`, `total chronic intake`, intrínseco vs fortificado, bebida/água, suplemento e medicamento, exposição por fonte e fase da vida, bioavailability | UL aplicado somente ao conjunto de formas/fontes definido pela autoridade; `indeterminate` quando exposição ou forma relevante for desconhecida; histórico/autoridade/jurisdição/versionamento persistidos |
| P1 | Gasto energético de treino e calibração | Bridge MET e filtro adaptativo Kalman existem; simulação é sintética; ledger longitudinal real e calibração externa faltam | `state-space model`, robust Kalman residual, measurement error, N-of-1 calibration, posterior predictive interval, net-vs-gross exercise energy e double-count prevention | Dados longitudinais e protocolo; erro/bias/interval coverage medidos; gasto não somado duas vezes ao TDEE; incerteza explícita por tipo de treino |
| P2 | Planejamento 7/14/28 dias | Otimização atual diária e substituição de refeição | `CP-SAT`/OR-Tools ou `MILP`/HiGHS; variáveis binárias de refeições + quantidades contínuas, frequência semanal, variedade, orçamento, estoque, batch-cooking, lexicographic objectives, unsat core/IIS | Instâncias 7/14/28 dias, benchmark solver e timeout, hard constraints preservadas, objetivo reproduzível e justificativa dos casos inviáveis; zero relaxamento silencioso de alergia/restrição |
| P2 | Testes avançados / static analysis | TypeScript, testes nativos e hardening existentes; falta execução global no ambiente atual e geração sistemática de variantes | `fast-check` property-based tests, `ast-grep` rules estruturais, Semgrep variant analysis (rever LGPL-2.1), mutation testing, golden fixtures, differential tests | Invariantes críticos cobrem permutações, duplicatas, limites, estados e serialização; regras AST impedem bypass dos gates; mutation score e CI limpo publicados |
| P2 | Validação científica e UX clínica | Testes de domínio/simulação sintética; sem validação clínica independente | Revisão por nutricionistas, protocolo de validação populacional, comparador de referência, subgroup analysis, safety cases, usabilidade | Relatório independente com população, protocolo, métricas de erro, segurança, limitações, validade externa e processo de atualização científica |

## Medições atuais de cobertura (5.835 registros consolidados)

| Nutriente | Unidade normalizada | Cobertura agregada | Observação de interpretação |
|---|---|---:|---|
| Vitamina A | µg RAE | 94,9% | Alta cobertura agregada; revisar diferenças entre retinol/caroteno e equivalência |
| Vitamina C | mg | 98,6% | Alta cobertura agregada |
| Vitamina D | µg | 89,9% | Confirmar formas D2/D3 e bases da fonte |
| Vitamina E | mg | 93,1% | Confirmar alfa-tocoferol vs outros tocoferóis |
| Vitamina K | µg | 0,1% | TBCA atual não cobre adequadamente o alvo total; K1 não equivale automaticamente a K total |
| B3 | mg NE | 0% | 5.783 registros TBCA estão em unidade/semântica incompatível para mg NE; niacina pré-formada mg não é automaticamente NE |
| B5 | mg | 0,1% | Lacuna real no catálogo |
| B7 | µg | 0% | Lacuna real no catálogo |
| Colina | mg | 0% | Lacuna real no catálogo |
| Iodo | µg | 0% | Lacuna real no catálogo |
| Cloreto | mg | 0% | Lacuna real no catálogo |
| Molibdênio | µg | 0% | Lacuna real no catálogo |
| Cromo | µg | 0% | Lacuna real no catálogo |
| Fluoreto | mg | 0% | Lacuna real no catálogo/unidade compatível |
| Selênio | µg | 82,7% | Ainda há 1.007 registros sem análise, além de poucos ausentes |

**Leitura importante:** esses percentuais são agregados TBCA + OFF + USDA + legado. Como USDA real ainda está em zero e OFF tem apenas dois itens, os números refletem essencialmente a TBCA 7.2. O relatório JSON V11.35 traz a estratificação por `ALIMENTO`, `PREPARACAO_COMPOSTA` e `UNKNOWN`; use `ALIMENTO` para avaliar qualidade das opções de ingredientes.

### Cobertura específica dos 2.717 alimentos simples elegíveis

| Nutriente | Quantificado | Cobertura `ALIMENTO` |
|---|---:|---:|
| Vitamina A | 2.482/2.717 | 91,4% |
| Vitamina C | 2.647/2.717 | 97,4% |
| Vitamina D | 2.360/2.717 | 86,9% |
| Vitamina E | 2.379/2.717 | 87,6% |
| Vitamina K | 0/2.717 | 0% |
| B1 | 2.694/2.717 | 99,2% |
| B2 | 2.693/2.717 | 99,1% |
| B3 em NE | 0/2.717 | 0% |
| B5 | 0/2.717 | 0% |
| B6 | 2.668/2.717 | 98,2% |
| B7 | 0/2.717 | 0% |
| B9 em DFE | 2.473/2.717 | 91,0% |
| B12 | 2.598/2.717 | 95,6% |
| Cálcio | 2.710/2.717 | 99,7% |
| Cobre | 2.589/2.717 | 95,3% |
| Ferro | 2.710/2.717 | 99,7% |
| Magnésio | 2.705/2.717 | 99,6% |
| Manganês | 2.527/2.717 | 93,0% |
| Potássio | 2.709/2.717 | 99,7% |
| Selênio | 1.920/2.717 | 70,7% |
| Sódio | 2.700/2.717 | 99,4% |
| Zinco | 2.705/2.717 | 99,6% |
| Colina, iodo, cloreto, molibdênio, cromo e fluoreto | 0/2.717 cada | 0% |

Esse quadro deve orientar a prioridade das próximas fontes de dados e não deve ser confundido com cobertura de preparações. É um snapshot da TBCA 7.2 com apenas dois itens OFF e nenhum registro USDA real.

## Guardrails invariantes

- Não declarar o motor completo ou clinicamente validado.
- Não declarar cobertura USDA até `USDA_FDC_GENERATED_CATALOG` receber registros reais com release/hash verificados.
- B3: FDC 409 direto; ou 406+407; ou 406+501. Nunca somar 407 e 501; nunca presumir niacina ou triptofano ausentes como zero.
- Não estimar triptofano a partir de proteína sem metodologia/fator validado e declarado.
- Não converter ausência, traço, não analisado, unidade divergente ou quarentena em zero.
- Não permitir TBCA `PREPARACAO_COMPOSTA` ou `UNKNOWN` como ingrediente; diário geral pode continuar aceitando preparações.
- Não aceitar crosswalk por similaridade textual/embedding isolada; hard gates de classe e descritores vêm antes do ranking.
- Não usar dados crus como cozidos sem EP, rendimento e retenção compatíveis.
- DIAAS incompleto não deve ser apresentado como score completo.
- UL precisa preservar forma química, fonte, cronicidade, população e autoridade.
- Não importar TBCA 7.3/derivados sem autorização/licença compatível com uso e redistribuição pretendidos.
