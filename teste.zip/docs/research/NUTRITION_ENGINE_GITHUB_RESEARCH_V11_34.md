# Pesquisa de repositórios e técnicas — V11.34

Snapshot de estrelas consultado em 26 nov 2026 via GitHub API. Estrelas são uma métrica de descoberta, não prova de qualidade ou compatibilidade. As licenças são as expostas no metadata do repositório; rever termos de distribuição de cada release antes de adoção.

| Repositório | Estrelas | Licença | Caso de uso | Decisão para V11.34 |
|---|---:|---|---|---|
| [Microsoft TypeScript](https://github.com/microsoft/TypeScript) | 111.907 | Apache-2.0 | Checker, linguagem, tipos e compilador | Mantém TypeScript nativo; sem nova dependência |
| [Prettier](https://github.com/prettier/prettier) | 52.449 | MIT | Formatação consistente | Ferramenta existente/opção de revisão, sem alterar stack |
| [Biome](https://github.com/biomejs/biome) | 26.216 | Apache-2.0 | Linter/formatter integrado | Candidato a pipeline futuro; não trocar ferramentas neste patch |
| [Fuse.js](https://github.com/krisk/Fuse) | 20.537 | Apache-2.0 | Busca fuzzy/tokenizada e ranking local | Referência para UX de pesquisa futura, não para identidade de fonte ou elegibilidade |
| [Semgrep](https://github.com/semgrep/semgrep) | 17.956 | LGPL-2.1 | Análise estática e padrões de bug | Pesquisado, não integrado; licença requer avaliação própria |
| [Vitest](https://github.com/vitest-dev/vitest) | 17.459 | MIT | Testes unitários/integração | Já é referência do ecossistema; sem dependência nova |
| [ast-grep](https://github.com/ast-grep/ast-grep) | 16.706 | MIT | Busca/lint/rewrite estrutural via AST | Candidato a guardrails de arquitetura e revisão de padrões |
| [Orama](https://github.com/oramasearch/orama) | 10.620 | NOASSERTION | Full-text, vector, hybrid, BM25, filtros e facets | Não adotar até licença inequívoca; desnecessário para 5,8k linhas e esta regra |
| [fast-check](https://github.com/dubzzz/fast-check) | 5.322 | MIT | Property-based testing TypeScript | Candidato para gerar casos de invariantes; patch usa regressões determinísticas sem adicionar dependência |
| [RapidFuzz](https://github.com/rapidfuzz/RapidFuzz) | 4.220 | MIT | Métricas fuzzy de texto, Python | Referência para pesquisa offline; não usar fuzzy para merge automático |
| [Splink](https://github.com/moj-analytical-services/splink) | 2.604 | MIT | Record linkage probabilístico Fellegi–Sunter | Referência para crosswalk TBCA↔USDA futuro, não runtime TypeScript |

## Técnicas aplicadas

1. **Hard eligibility gate antes do ranking.** A política de domínio filtra `PREPARACAO_COMPOSTA` e tipo TBCA desconhecido antes do limite de resultados. Similaridade lexical não tem como recuperar um composto bloqueado.
2. **Defense in depth.** A UI oferece um motivo visível e desabilita o botão; o store repete a validação antes da mutação, reduzindo bypass por outro consumidor.
3. **Source-aware schema.** A regra usa a taxonomia TBCA explícita e não presume que outras fontes tenham o mesmo campo ou semântica.
4. **Entity resolution sem falso positivo.** Um crosswalk futuro deve bloquear candidatos por grupo/taxonomia/estado/preparação e comparar múltiplos campos independentes (nome, parte comestível, forma, perfil nutricional e proveniência); usar probabilidades e revisão humana para faixa ambígua. Similaridade de nome isolada não basta.
5. **Property-based/structural assurance.** Fast-check é adequado para invariantes gerais (p.ex. nenhum composto passa, qualquer campo desconhecido falha fechado); ast-grep e typescript-eslint servem para detectar padrões de código e violações estruturais no pipeline. Permanecem oportunidades futuras, não dependências trazidas no patch.

## Por que não instalamos Fuse.js ou Orama agora

O conjunto tem apenas 5.830 registros TBCA e já usa busca local determinística. O problema desta revisão era categórico e de integridade, não velocidade nem tolerância a erros. Fuzzy search pode ajudar a encontrar candidatos com erros de digitação, mas deve operar depois dos gates de fonte/eligibilidade e nunca atribuir identidade canônica automaticamente. Não houve adição de dependências de runtime.
