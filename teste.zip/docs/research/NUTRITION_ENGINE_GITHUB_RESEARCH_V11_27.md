# TITAN Nutrition Engine — GitHub research and scientific/data decisions V11.27

**Snapshot:** 2026-11-25. GitHub stars/licences are live metadata snapshots, approximate and not evidence of clinical validity. No repository code, assets, or third-party food datasets were copied into TITAN.

## Ranked GitHub references by capability

| Capability | Repository | Approx. stars | License metadata | What was inspected/learned | Decision |
|---|---|---:|---|---|---|
| Scientific numerical algorithms | `scipy/scipy` | 15,256 | BSD-3-Clause | Numerical optimization ecosystem | Reference only; Python runtime not a fit for existing browser domain. |
| LP/MIP/CP optimization | `google/or-tools` | 14,457 | Apache-2.0 | `StiglerDiet` LP sample, nutrient constraint matrix | Keep current HiGHS and TypeScript fallback; no second solver stack. |
| Recipe scaling / meal planner UX | `mealie-recipes/mealie` | 13,992 | AGPL-3.0 | `use-mealplan-scale.ts` debounced changes, preserve pending edits | Behavioral reference only; no AGPL code imported. |
| Recipe quantities / unit conversions | `grocy/grocy` | 9,708 | MIT | Recipe serving scaling and explicit unit conversion paths | Reference only; do not introduce PHP/runtime. |
| Recipe/meal management | `TandoorRecipes/recipes` | 8,749 | NOASSERTION | Scale recipe quantities by serving yield | No code reuse without license verification. |
| Nutrition validation | `wger-project/wger` | 7,325 | AGPL-3.0 | `sanity_checks()` for impossible mass relationships and imported nutrition values | Reimplemented domain-specific validation independently; no AGPL code copied. |
| Convex model language | `cvxpy/cvxpy` | 6,401 | Apache-2.0 | QP and convex problem formulation concepts | Reference only; existing TS/HiGHS integration retained. |
| Food diary/nutrient snapshots | `simonoppowa/OpenNutriTracker` | 3,033 | GPL-3.0 | Source-backed food snapshots and OFF micronutrient repair | Reference only; no GPL import. |
| Convex QP backend | `osqp/osqp` | 2,233 | Apache-2.0 | QP solver option | Not added; HiGHS is already present. |
| LP/QP backend | `ERGO-Code/HiGHS` | 1,952 | MIT | Existing LP/QP dependency | Retained. WASM runtime not available in this host. |
| Food database/API | `openfoodfacts/openfoodfacts-server` | 1,219 | AGPL-3.0 | Food product and nutrient source ecosystem | Provider reference only; API/server and dataset licences remain distinct. |
| QP adapters | `qpsolvers/qpsolvers` | 764 | LGPL-3.0 | Python solver adapter patterns | No Python dependency added. |
| Meal planning / quantities | `vangelov/calories-in` | 187 | MIT | Food→meal→plan nutrition aggregation | Limited reference; existing TITAN domain is more complete. |
| Recipe nutrition optimizer | `DerekGloudemans/Nutrition-Optimization-New` | 21 | NOASSERTION | Diet LP prototype | Small, old, license unclear; do not reuse. |
| Nutritionally complete diet generator | `josh-minch/spartan` | 11 | NOASSERTION | Diet optimization concept | Small, old, license unclear; do not reuse. |
| DIAAS explainer | `diaas-calculator/diaas-calculator-angular` | 3 | LGPL-2.1 | User-facing explanation of DIAAS and preparation specificity | Not a scientific data source; formula anchored to FAO instead. |
| Multi-period diet optimization | `ddarmon/llmn` | 2 | NOASSERTION | Per-meal decision variables, daily linking constraints, infeasibility diagnosis, adaptive TDEE | Algorithmic reference only. License is not asserted; Python code was not copied. |

A search for food preparation/yield/retention repositories did not reveal a high-star, clearly licensed implementation with a validated food×method retention dataset. In that case, the domain source—not GitHub popularity—is the appropriate anchor.

Additional food-data/meal-planner repository searches surfaced `eliashussary/nutrition-facts` (34 stars, no license metadata, last pushed 2017), `umangsh/famnom` (13 stars, no license metadata, last pushed 2022), and `Dwarfex/usda-food-composition` (1 star, MIT, last pushed 2018). These are not superior to the official USDA FoodData Central data source or the maintained Open Food Facts ecosystem; stale snapshots, weak provenance and missing license metadata rule them out for production integration.

## Inspected files and decisions

- OR-Tools `ortools/linear_solver/samples/stigler_diet.py`: nutrient matrix and linear constraints.
- Mealie `frontend/app/composables/use-mealplan-scale.ts`: scale editing and debounced save lifecycle.
- Grocy `services/RecipesService.php`: explicit quantity-unit conversion.
- wger `wger/nutrition/dataclasses.py`: nutrition mass sanity checks.
- OpenNutriTracker `lib/core/utils/off_micronutrient_repair.dart`: repair only when source values are available, then recompute totals.
- llmn `src/llmn/optimizer/multiperiod_solver.py`, `multiperiod_constraints.py`, `multiperiod_models.py`: meal-level variables and daily linking constraints.

No code was copied and no new runtime dependency was added.

## Implemented in V11.27

1. Complete-coverage aggregation for fibre, saturated fat and cholesterol. A partial numeric sum is now hidden when any source in the meal/day is missing or unanalyzed.
2. Public DIAAS primitive using FAO 2013 age-group reference patterns and amino-acid-specific ileal digestibility. It checks source identity, food state, reference, species and digestibility method. A single food can score >100; a mixed diet is capped at 100 and exposes the untruncated score separately.
3. Public raw/prepared-food transform primitive with exact food ID/state binding, explicit cooked/raw mass yield, and independently evidenced macro and micronutrient retention factors.
4. Data validation rejects non-finite/negative macros, impossible mass balance, saturated fat above total fat, and invalid nutrient entries rather than turning them into zero.

These are engines/contracts, not claims that the current data catalogue now contains all required evidence.

## Scientific and official data references

- FAO (2013), *Dietary protein quality evaluation in human nutrition*: https://www.fao.org/4/i3124e/i3124e.pdf — amino-acid-specific ileal digestibility, scoring patterns, and interpretation for mixtures.
- Health Canada, DIAAS guidance for mixed diets: https://www.canada.ca/en/health-canada/services/food-nutrition/legislation-guidelines/acts-regulations/notices-proposal-notices-modification/table-chemical-physical-nutritional-characteristics-food-pcpn-2607/determination-protein-rating-diaas.html — mixed-diet score should not be reported above 100.
- USDA Table of Nutrient Retention Factors, Release 6 (2007): https://www.ars.usda.gov/ARSUserFiles/80400525/Data/retn/retn06.pdf — food/method-specific vitamin and mineral retention; not an all-macro retention table and not a universal cooking factor.
- USDA Food Buying Guide: https://foodbuyingguide.fns.usda.gov/appendix/downloadfbg — explicit food-specific edible yield and preparation context.
- NASEM 2019 Sodium and Potassium DRI: https://www.nationalacademies.org/read/25353/chapter/13 — sodium adult AI 1,500 mg/day and CDRR 2,300 mg/day must remain different concepts.
- NIH ODS choline: https://ods.od.nih.gov/factsheets/choline-HealthProfessional/ — AI and UL context.
- NIH ODS iodine: https://ods.od.nih.gov/factsheets/iodine-HealthProfessional/ — RDA and UL context.
- NIH ODS chromium: https://ods.od.nih.gov/factsheets/Chromium-HealthProfessional/ — historical AI caveat and no established UL.
- NIH ODS fluoride: https://ods.od.nih.gov/factsheets/Fluoride-HealthProfessional/ — AI/UL and non-food exposure context.
- EFSA review of chloride DRIs: https://efsa.onlinelibrary.wiley.com/doi/full/10.2903/j.efsa.2019.5779.

## Audited nutrient coverage (catalog snapshot 2026-11-25)

`npm run audit:nutrition-coverage` checks all 29 nutrients across 5,838 food records (5,836 TBCA + 2 curated OFF records). Values count as quantified only if the source marks them quantified, the normalized value is finite/nonnegative, the basis quantity is finite/positive, and the normalized unit exactly matches the canonical DRI unit. An absent TBCA field is treated as `not_analyzed`; an absent OFF field is `missing`.

| Nutrient | Quantified coverage | Important caveat |
|---|---:|---|
| Vitamin C | 98.5% |  |
| Vitamin B1/B2 | 99.5% |  |
| Vitamin B3 (niacin equivalents) | 0.0% | 5,785 source values have incompatible units; preformed niacin is not silently promoted to mg NE |
| Vitamin B5 | 0.1% | Only 4 records quantified |
| Vitamin B7 (biotin) | <0.1% | Only 1 record quantified |
| Vitamin B9 (DFE) | 94.9% | 5 records unit-incompatible; DFE is not inferred from unqualified folate |
| Vitamin K | 0.1% | Only 4 records quantified |
| Selenium | 82.7% | Lowest of the broadly covered mineral fields |
| Choline, iodine, chloride, molybdenum, chromium, fluoride | 0.0% | TBCA fields are not analyzed; OFF records lack the fields |

Full counts by source and status are in `NUTRIENT_COVERAGE_TBCA72_V11_27.json`. These are catalog-level numbers. For a specific recipe/day the composer independently gates calculations on complete ingredient coverage, so catalogue percentages must not be interpreted as the percentage of any particular user's diet that is analyzable.

## Remaining gates — explicit and not claimed complete

- The current TBCA 7.2 adapter and local OFF adapter do not provide the complete amino-acid-specific digestibility dataset needed to calculate food-level DIAAS. The DIAAS engine therefore returns `insufficient_evidence` for food catalogue records until matched source records exist.
- No validated mapping links TBCA food IDs/states/cuts to USDA retention rows and food-specific yields. The transform primitive cannot be applied automatically until that crosswalk is sourced and validated.
- The six newer DRI fields (choline, iodine, chloride, molybdenum, chromium, fluoride) remain without quantified values for current TBCA food records. They are not represented as zero.
- UL optimisation sees only quantified ingredients in the food plan. Supplements, water, beverages outside the plan, and swallowed dental products are not included; the UI says so. It is not a full total-exposure assessment.
- Live Open Food Facts acquisition is not installed as a production data path; the existing adapter is local/curated. A remote client requires rate-limit/user-agent policy, source snapshots, freshness, license/ODbL review, and safe proxying; do not make a browser request and describe it as complete data ingestion.
- TBCA 7.3 and redistribution rights require legal review. Current data is not replaced or relicensed by this work.
- Hall/RMR/TDEE/adaptive models require external real-world validation and calibration. Synthetic simulations are code regression only.
- `npm run build` fails at environment boundary (`vite: not found`, exit 127); `npm run lint` fails because `vite/client` types are not installed (exit 2); `npm test` fails because `tsx` is unavailable (exit 127). Dependency installation timed out. Live HiGHS WASM and browser validation remain unverified.

## Verification snapshot

- `npm run test:review`: PASS (review gate do projeto, não o script integral `npm test`).
- Targeted micronutrient optimization, DIAAS/preparation and composer coverage tests: PASS.
- `tsc -p tsconfig.calc-review.json --pretty false`: PASS.
- `npm run audit:nutrition-coverage`: PASS; generated the source/status coverage snapshot.
- `git diff --check`: PASS.
- Vite build/lint/npm test and actual WASM solver run: NOT VERIFIED (no `node_modules`; install timed out).


## V11.28 safety review

- The UL safety boundary now covers proposal generation, the state-store application path and the UI. A result that exceeds a currently applicable hard UL cannot be applied or saved as a variant. Incomplete data remains an explicit limitation; it is not converted into a statement of safety.
- DIAAS evidence now requires exact food identity/state and independent source/version/reference provenance for amino-acid composition and each amino-acid-specific ileal digestibility value. Rat evidence is rejected; only human or pig species are accepted by this DIAAS function.
- No additional GitHub code or dataset was imported. Repository stars and licences remain the 2026-11-25 metadata snapshot above.
