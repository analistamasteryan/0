# Auditoria TBCA e aliases legados — V11.34

## Escopo

O repositório mantém um catálogo compacto atribuído a TBCA 7.2. A revisão verificou o campo de tipo alimentar nas 5.830 linhas e os seis aliases legados declarados no adaptador.

## Inventário de tipos no catálogo 7.2 local

| `food_type` | Registros | Uso no motor |
|---|---:|---|
| `ALIMENTO` | 2.717 | Permitido como ingrediente de receita |
| `PREPARACAO_COMPOSTA` | 3.113 | Bloqueado como ingrediente; permitido para pesquisa geral e lançamento direto no diário |
| Desconhecido/ausente | 0 | Política falha fechado se um futuro registro TBCA chegar sem tipo |
| **Total** | **5.830** | |

O campo oficial é a fonte de verdade. Palavras no nome não são usadas para inferir composição; um alimento simples cozido/assado/grelhado pode continuar em `ALIMENTO`, enquanto uma preparação feita de vários ingredientes está explicitamente em `PREPARACAO_COMPOSTA`.

## Correção de IDs históricos

| ID histórico do TITAN | Código que estava associado | Problema encontrado | Código canônico corrigido |
|---|---|---|---|
| `tbca-ovo-mexido` | BRC0042A | Código atual aponta para biscoito de chocolate/cereal | BRC0065J — Ovo, galinha, mexido, sem óleo e sem sal |
| `tbca-pao-integral` | BRC0114C | Código atual aponta para suco de frutas misto | BRC0149A — Pão, trigo, integral |
| `tbca-banana-prata` | BRC0018B | Código atual aponta para cebola | BRC0011C — Banana, prata, in natura |

Os IDs históricos permanecem como alias para não quebrar receitas persistidas; resolução, valor analítico, classificação e proveniência são oriundos da linha TBCA real. Os aliases não são enumerados como registros extras do catálogo.

## Refeições compostas legadas

| ID | Estado anterior | Estado V11.34 |
|---|---|---|
| `tbca-mamao-aveia` | Fonte TBCA e código divergente (BRC0219F) | `TITAN_LEGACY`, `TITAN-LEGACY-MAMAO-AVEIA`, `unverified`, `PREPARACAO_COMPOSTA` |
| `tbca-frango-arroz-legumes` | Fonte TBCA e código BRC0388P ausente do catálogo | `TITAN_LEGACY`, `TITAN-LEGACY-FRANGO-ARROZ-LEGUMES`, `unverified`, `PREPARACAO_COMPOSTA` |
| `tbca-salmao-batata-doce` | Fonte TBCA e código BRC0412S ausente do catálogo | `TITAN_LEGACY`, `TITAN-LEGACY-SALMAO-BATATA-DOCE`, `unverified`, `PREPARACAO_COMPOSTA` |

Os três registros continuam disponíveis para lançamento como refeição/diário; não representam dados laboratoriais TBCA, não são contados como TBCA e não podem entrar como ingredientes.

## Integridade de seleção

A regra `food-ingredient-policy.ts` permite somente TBCA `ALIMENTO`, rejeita TBCA `PREPARACAO_COMPOSTA` e rejeita tipo TBCA ausente/desconhecido. Registros `TITAN_LEGACY` também são rejeitados. Outras fontes mantêm a política atual, sem tentar adivinhar a estrutura de seus alimentos pelo nome.

O filtro de propósito (`recipe-ingredient`) é executado antes da ordenação e do limite. A busca padrão continua inclusiva para lançamento no diário. O estado da aplicação faz a mesma validação no momento da escrita, para que uma chamada direta não consiga contornar a UI.

O catálogo possui oito modelos, e seis incluíam ao menos uma refeição composta/local não canônica como linha de ingrediente. Esses seis foram excluídos das novas seleções e das substituições; apenas dois modelos, cujas linhas resolvem para ingredientes elegíveis, permanecem disponíveis. Os registros antigos e planos já persistidos são preservados. Não foram inventadas decomposições nem quantidades para os pratos legados.

## Limitação de versão e uso da fonte

Este patch **não atualiza** os valores do catálogo TBCA para a versão 7.3; o repositório permanece com a versão 7.2. O portal oficial apresenta TBCA 7.3 (São Paulo, 2025) e declara condições específicas de citação, reprodução e uso comercial. Antes de distribuir uma nova cópia do conjunto de dados ou migrar para 7.3, verificar as condições diretamente com os responsáveis e obter autorização quando aplicável. Nenhum valor analítico original do arquivo compacto foi modificado neste patch.
