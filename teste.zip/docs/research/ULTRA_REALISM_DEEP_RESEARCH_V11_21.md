# TITAN V.MAX — Deep Research de Realismo Visual V11.21

**Data:** 25/11/2026  
**Base:** `TITAN_V11_20_ADAPTIVE_PLASMA.zip`  
**Objetivo:** concluir melhorias incrementais justificadas em água, metais, plasma/arcos e deixar uma rota técnica verificável para anatomia, pele e iluminação.  
**Método:** pesquisa de repositórios e código diretamente no GitHub por meio do conector GitHub; **Firecrawl não foi usado**. Os cinco candidatos em cada área são shortlist de pertinência técnica para este problema, não ranking de estrelas nem endosso de qualidade. Nenhum código de terceiros foi copiado. Dados n/k de refractiveindex.info foram incorporados por CC0.

## 1. Decisão de engenharia

A stack permanece React 19 + TypeScript + Three.js r187 + WebGL2 + GLSL ES 3.00. O projeto já usa renderer próprio para os componentes de vidro e água, e Three.js para o corpo. Migrar para WebGPU/MLS-MPM, adicionar SPH a um pequeno conjunto de gotas, ou incorporar GLBs anatômicos sem compatibilidade com o rig criaria uma segunda arquitetura sem resolver a principal limitação do produto.

V11.21 implementa cinco correções/avanços: ledger conservativo de água, projeção de pressão com operadores discretos compatíveis, histerese advancing/receding, nove âncoras medidas n/k para metais e envelope visual Heidler normalizado. Plasma mantém raymarch adaptativo de V11.20; anatomia, SSS e lighting permanecem em rota de integração/validação, sem mudança visual estrutural não comprovada.

## 2. Shortlist GitHub por funcionalidade

### 2.1 Água, gotas, filme e cáusticas

| Repositório | O que consultar | Decisão para TITAN |
|---|---|---|
| [InteractiveComputerGraphics/SPlisHSPlasH](https://github.com/InteractiveComputerGraphics/SPlisHSPlasH) | SPH, Akinci 2013, tensão superficial, adesão de fronteira e solvers WCSPH/PCISPH/PBF/IISPH/DFSPH | Referência matemática, não runtime: o custo e a vizinhança de partículas são desproporcionais para poucas gotas de UI |
| [matsuoka-601/WebGPU-Ocean](https://github.com/matsuoka-601/WebGPU-Ocean) | MLS-MPM, SPH, P2G por atomics/fixed-point e screen-space fluid | Não adotar nesta fase: exige WebGPU e simulação massiva, fora do escopo do medidor |
| [Aureliengmz/clearwater](https://github.com/Aureliengmz/clearwater) | Água WebGL2, refração, reflexão e cáusticas | Referência de renderização e aparência; adaptar conceitos pontuais, não substituir o renderer |
| [jeantimex/threejs-water](https://github.com/jeantimex/threejs-water) | Superfície de água em Three.js e shaders | Referência de superfície e integração com cena, sem adicionar dependência |
| [HowdyKeith/swek-webgl2-water](https://github.com/HowdyKeith/swek-webgl2-water) | Solver 2D/grid e renderização de água WebGL2 | Referência de discretização e orçamento visual; validar licença antes de copiar qualquer trecho |

**Código efetivamente inspecionado:** [SPlisHSPlasH `SurfaceTension_Akinci2013.cpp`](https://github.com/InteractiveComputerGraphics/SPlisHSPlasH/blob/master/SPlisHSPlasH/SurfaceTension/SurfaceTension_Akinci2013.cpp). O método calcula normais de superfície e combina coesão/curvatura com adesão na fronteira. [WebGPU-Ocean README](https://github.com/matsuoka-601/WebGPU-Ocean) descreve MLS-MPM/P2G, atomics e fixed-point; é tecnicamente interessante, mas inapropriado para a pequena população de gotas. [2D-Weather-Sandbox README](https://github.com/niels747/2D-Weather-Sandbox) documenta grade escalonada (velocidade na face, pressão no centro) e projeção por pressão.

**Técnicas avançadas específicas:**
- **Euleriano grid:** divergência discreta + solução de Poisson; preferir MAC face-centered para remover modos espúrios quando for feita uma revisão de solver maior.
- **Solver:** Jacobi residual-bounded é barato, mas converge lentamente; próximo passo seria multigrid V-cycle ou PCG com precondicionador MIC/IC(0), não simplesmente aumentar iterações.
- **Advecção:** semi-Lagrangiana é estável, mas difusiva; MacCormack/BFECC com limiter reduz dissipação e impede overshoot.
- **Fluxo de volume:** finite-volume fluxes (MUSCL/limited reconstruction), CFL e orçamento de massa por domínio; contabilizar separadamente água transferida ao medidor.
- **Superfície:** curvature/CSF e Akinci para tensão superficial; level set + volume correction ou VOF para interface com conservação mais forte.
- **Contato:** ângulos advancing/receding, stick-slip, pinning heterogêneo e dependência da velocidade (Cox–Voinov/Cox law) são futuros degraus.
- **Menisco:** a solução atual é linearizada/planar. Para 3D real, resolver Young–Laplace não linear com condição de Young e gravidade, eixo/simetria apropriado e tensão superficial calibrada.

**Implementado nesta revisão:** toda alteração da massa dos corpos passa por ledger `initial + sources - sinks`; coalescência move a massa integralmente; o gauge emite `massTransferred`; a projeção usa divergência forward e gradiente backward cuja composição é o Laplaciano de cinco pontos, com Jacobi 8–28 iterações e diagnóstico de resíduo; ângulos leading/trailing atualizam e controlam pinning.

**Limite preservado:** não é solver de CFD 3D, não é grade MAC face-centered e não há transporte VOF/SPH. Teste determinístico nesta base: RMS de divergência 0.30164 → 0.17105 (redução de aproximadamente 43.3%) em 28 iterações. Isso é melhora mensurada, não incompressibilidade exata.

### 2.2 Vidro, metais e resposta espectral

| Repositório | O que consultar | Decisão para TITAN |
|---|---|---|
| [mmp/pbrt-v4](https://github.com/mmp/pbrt-v4) | Espectros amostrados, conversão XYZ, Fresnel complexo e BSSRDFs | Referência algorítmica; Apache-2.0. Não copiar módulo inteiro |
| [polyanskiy/refractiveindex.info-database](https://github.com/polyanskiy/refractiveindex.info-database) | n/k espectrais medidos por material e fonte experimental | Dados usados nesta versão sob CC0 1.0 |
| [google/filament](https://github.com/google/filament) | PBR, GGX, energia, IBL e modelos de material | Referência para coerência de BRDF; não substituir shaders existentes |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Fresnel, transmissão, PMREM e RectAreaLight/LTC | Stack já adotada na anatomia; referências de integração |
| [byzin/Nanairo](https://github.com/byzin/Nanairo) | Renderizador espectral e estrutura de amostragem por comprimento de onda | Pesquisa para uma futura integração espectral mais completa |

**Código inspecionado:** [PBRT `spectrum.cpp`](https://github.com/mmp/pbrt-v4/blob/master/src/pbrt/util/spectrum.cpp) faz interpolação linear piecewise de espectros e converte para XYZ com funções de correspondência CIE; [PBRT `scattering.h`](https://github.com/mmp/pbrt-v4/blob/master/src/pbrt/util/scattering.h) implementa Fresnel dielétrico e complexo; [refractiveindex.info README](https://github.com/polyanskiy/refractiveindex.info-database/blob/main/README.md) afirma que a base é domínio público/CC0 1.0 e recomenda citar a publicação de dados.

**Dados incorporados:** n/k de Au e Ag: Johnson & Christy, *Optical constants of the noble metals*, Phys. Rev. B 6, 4370–4379 (1972), DOI [10.1103/PhysRevB.6.4370](https://doi.org/10.1103/PhysRevB.6.4370). Cr: Johnson & Christy, *Optical constants of transition metals...*, Phys. Rev. B 9, 5056–5070 (1974), DOI [10.1103/PhysRevB.9.5056](https://doi.org/10.1103/PhysRevB.9.5056). Os arquivos usados são `database/data/main/Au/nk/Johnson.yml`, `Ag/nk/Johnson.yml` e `Cr/nk/Johnson.yml`.

**Técnicas avançadas específicas:** complex-IOR conductor Fresnel (n+ik), dados medidos em wavelength space, piecewise-linear interpolation, três quadraturas por banda RGB (9 âncoras), Beer–Lambert, Snell/TIR, Sellmeier para dielétricos, microfacet GGX/VNDF, multiple-scattering compensation, thin-film transfer matrix (TMM) quando existir camada física conhecida, e calibração de reflectância sob IBL. Uma próxima fase de espectro completo usaria sampled wavelengths + CIE XYZ, com custo controlado por amostragem.

**Implementado:** Ag/Au/Cr usam 9 âncoras de comprimento de onda na faixa visível (3 por saída RGB), interpolação linear CPU e Fresnel complexo exato na CPU/GLSL. Testes conferem anchors, interpolação, Fresnel analítico em incidência normal e limite rasante.

**Limite preservado:** média de três amostras por canal não equivale a render espectral CIE; as amostras são valores de n/k de metais puros, não uma medição universal da liga, acabamento, espessura ou substrato do objeto. Próximos passos: integrar dados n/k em mais materiais e faixas, TMM para revestimentos multilayer, rugosidade anisotrópica/micro-riscos, múltiplas reflexões internas e calibração de ambiente.

### 2.3 Plasma volumétrico

| Repositório | O que consultar | Decisão para TITAN |
|---|---|---|
| [Donitzo/three.js-volume-renderer](https://github.com/Donitzo/three.js-volume-renderer) | Raymarch de volume, densidade e extinção | Referência de integração/radiância |
| [Voltonik/VolumetricSmoke](https://github.com/Voltonik/VolumetricSmoke) | Volume procedimental e iluminação de fumaça | Referência de campo de densidade |
| [Auburn/FastNoiseLite](https://github.com/Auburn/FastNoiseLite) | Noise multifractal e variantes de baixo custo | Referência de ruído; não incorporado como dependência |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | Render WebGL/WebGPU, volumes e materiais | Compatibilidade com engine atual |
| [shader-park/shader-park-core](https://github.com/shader-park/shader-park-core) | Composição procedural de campos visuais | Referência de construção visual, não de plasma físico |

**Técnicas avançadas específicas:** raymarch adaptativo por comprimento do segmento e densidade local; Beer–Lambert/extinction e emission-absorption integration; majorant tracking/delta tracking quando usar fontes de ruído de alta frequência; blue-noise jitter e temporal accumulation para reduzir banding; curl noise em escalas múltiplas; iluminação volumétrica aproximada com gradiente de densidade; budget por pixels cobertos e LOD. Em investigação física, MHD, ionização/recombinação e transporte radiativo acoplado têm custo muito acima deste componente.

**Implementado na V11.20 e mantido:** 8–16 passos adaptativos, limite de loop compatível com GLSL ES 3.00, mais cobertura em segmentos longos. V11.21 adiciona um contrato estático geral de integração e regressões sem reescrever o raymarch.

**Limite:** plasma continua procedural e não simula condutividade, campo EM, ionização, MHD ou transporte radiativo.

### 2.4 Arcos e descargas

| Repositório | O que consultar | Decisão para TITAN |
|---|---|---|
| [the-worst-student/dielectric-breakdown-model](https://github.com/the-worst-student/dielectric-breakdown-model) | Modelo de breakdown por potencial Laplaciano, SOR e probabilidade de crescimento | Modelo de referência para geração offline/estudo, não runtime |
| [niels747/2D-Weather-Sandbox](https://github.com/niels747/2D-Weather-Sandbox) | Grades 2D, pressão/velocidade e estabilidade | Referência numérica adjacente, não simulador elétrico |
| [indyjo/Thunder-Lightning](https://github.com/indyjo/Thunder-Lightning) | Geração procedural de raios | Referência visual; licença precisa ser revista antes de copiar |
| [keijiro/SpektrLightning](https://github.com/keijiro/SpektrLightning) | VFX e construção de descargas | Referência visual; licença/integração a confirmar |
| [patch-gg/PixelFX](https://github.com/patch-gg/PixelFX) | Efeitos de raios e pós-processamento | Referência para VFX, não física |

**Código inspecionado:** o README do [DBM](https://github.com/the-worst-student/dielectric-breakdown-model) descreve solução iterativa de potencial Laplaciano via SOR em torno dos eletrodos/canal e seleção probabilística de célula conforme campo elétrico e limiar de ruptura. É uma rota superior a ramificações aleatórias quando houver uma etapa dedicada à topologia elétrica.

**Técnicas avançadas específicas:** DBM/Laplacian growth, stochastic dielectric streamer leader, campo potencial ∇²V=0, threshold field/ionization, channel branching probability, stepped leader, return stroke (Heidler/MTLE), corona/streamer, secondary leader e re-strike. O envelope Heidler não substitui o solver espacial. A integração futura exige validação de escalas e custo; para o VFX atual, a onda temporal é o objetivo proporcional.

**Implementado:** CPU + GLSL usam o mesmo envelope Heidler-type, com tau1 45 ms, tau2 200 ms e n=3, normalizado para pico unitário no tempo de animação. Um teste RED foi observado antes de corrigir a constante (pico anterior 0.971); o teste GREEN exige pico maior que 0.995.

**Limite:** esse envelope é escalado para animação em segundos, não um parâmetro físico de retorno de raio, e o sistema ainda não resolve DBM, campo de potencial, ionização, streamer ou MTLE completo.

### 2.5 Anatomia e deformação muscular

| Repositório | O que consultar | Decisão para TITAN |
|---|---|---|
| [MervinR07/open-anatomy-3d](https://github.com/MervinR07/open-anatomy-3d) | GLB masculino/feminino e meshes nomeados de estruturas | Candidato de referência/licença; não foi inserido no rig atual |
| [makehumancommunity/makehuman](https://github.com/makehumancommunity/makehuman) | Base corporal, rig e morph targets MakeHuman | Fonte do modelo atual e possível continuidade |
| [CalciferZh/SMPL](https://github.com/CalciferZh/SMPL) | Body model, shape/pose blend shapes e skinning | Pesos oficiais não estão incluídos; acesso/licença externa necessária |
| [vchoutas/smplx](https://github.com/vchoutas/smplx) | SMPL-X com shape/pose/expression, 54 juntas e corrective blend shapes | Código de referência; licença do modelo/software restringe a pesquisa científica não comercial, portanto não é candidato para uso comercial |
| [LluisV/Z-Anatomy](https://github.com/LluisV/Z-Anatomy) | Atlas 3D de estruturas anatômicas e exportação FBX/Blend | CC BY-SA 4.0; obrigação ShareAlike precisa ser avaliada antes de incorporar assets |

**Evidência e licença:** o [README do Open Anatomy](https://github.com/MervinR07/open-anatomy-3d/blob/main/README.md) informa dois corpos com estruturas nomeadas, ~147 estruturas e meshes GLB comprimidas. [LICENSE-MODELS.md](https://github.com/MervinR07/open-anatomy-3d/blob/main/packages/open-anatomy-3d/LICENSE-MODELS.md) declara CC BY 4.0 para modelos e catálogo; [ATTRIBUTION.md](https://github.com/MervinR07/open-anatomy-3d/blob/main/packages/open-anatomy-3d/ATTRIBUTION.md) documenta BodyParts3D, HRA e MakeHuman. O fetch do GLB via GitHub connector retornou corpo vazio (binário não disponibilizado pela interface de fetch), então não houve inspeção de pesos/ríg nem integração.

**Técnicas avançadas específicas:** rigging de músculos com origem/inserção, fascículos e tendões; anatomically constrained deformation; dual-quaternion skinning (DQS) para twist; corrective pose-space deformations; volumetric muscle bulging; FEM/XPBD para tecidos quando houver orçamento; morph-target quality gates; anatomia feminina e masculina com topologia coerente; meshopt/LOD e oclusão. O atual `hm08`/MakeHuman e seus morph IDs são preservados.

**Limite:** nomear cabeça muscular separada no catálogo não cria volume independente quando a malha não tem topologia. O GLB candidato é licença CC BY 4.0, mas não tem compatibilidade de rig/morph provada. SMPL requer o pacote/modelo oficial externo.

### 2.6 Pele, textura e subsurface scattering

| Repositório | O que consultar | Decisão para TITAN |
|---|---|---|
| [google/filament](https://github.com/google/filament) | Modelos de material, iluminação e aproximações SSS | Referência PBR |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | `SubsurfaceScatteringShader.js`, thickness map e integração com luz direta | Código inspecionado: é aproximação de translucidez por thickness, não BSSRDF difusivo |
| [DarkBlade909/DarkBladeSkinShader](https://github.com/DarkBlade909/DarkBladeSkinShader) | LUT pre-integrated SSS, mip-based diffusion, dual-lobe specular | Referência de técnica; requer Graphlit e licença/compatibilidade devem ser avaliadas antes de copiar |
| [mmp/pbrt-v4](https://github.com/mmp/pbrt-v4) | BSSRDF, diffusion profile e subsurface random walk | Referência científica/algorítmica; Apache-2.0, sem copiar módulo |
| [playcanvas/engine](https://github.com/playcanvas/engine) | Materiais e pipeline WebGL | Alternativa de padrões, sem substituir Three.js |

**Código inspecionado:** [Three.js `SubsurfaceScatteringShader.js`](https://github.com/mrdoob/three.js/blob/dev/examples/jsm/shaders/SubsurfaceScatteringShader.js) usa thickness map, distorção da meia-direção e um termo de scattering direto. Isso é útil para translucidez, mas não é convolução BSSRDF UV-space.

**Técnicas avançadas específicas:** perfil de difusão multi-Gaussian (Jimenez six-lobe), separable screen-space blur, bilateral depth/normal-aware blur, UV-space irradiance bake, chart-aware padding/dilation para evitar bleeding em seams, thickness maps regionais, espectros RGB de scattering, perfil de albedo/roughness por região e validação com múltiplas luzes. Um BSSRDF completo e medido é fora do orçamento desta revisão.

**Estado:** V11.19 já introduziu perfil UV 2-Gaussian aproximado e scattering screen-space; V11.21 não o reescreveu por não haver imagem/benchmark GPU verificável neste ambiente.

### 2.7 Iluminação do corpo e estúdio

| Repositório | O que consultar | Decisão para TITAN |
|---|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | RectAreaLight, LTC LUT e PMREM | Atual stack e referência direta |
| [google/filament](https://github.com/google/filament) | IBL, area lights e energia PBR | Referência de resposta física |
| [playcanvas/engine](https://github.com/playcanvas/engine) | PBR, envmaps, WebGL | Referência de fallback e plataforma |
| [LiamSwarbrick/LTCClustered-ManyAreaLights](https://github.com/LiamSwarbrick/LTCClustered-ManyAreaLights) | LTC polygonal area lights e clustered forward shading | Referência para escalar softboxes, não necessária com poucas luzes |
| [pmndrs/drei](https://github.com/pmndrs/drei) | Helpers de ambiente/estúdio no ecossistema R3F | Não adicionar R3F/Drei à cena atual |

**Técnicas avançadas específicas:** HDRI calibrado por exposição/white balance, PMREM/IBL, LTC rectangular/polygonal emitters, roughness-aware specular response, tone mapping/exposure consistency, multi-angle turntable test, cross-platform GPU fallback, frame-time budget e comparação com referência fotométrica.

**Estado a preservar:** corpo já usa `RoomEnvironment`/PMREM, RectAreaLight key/rim, hemispherical fill e fallback direcional; direção de key compartilhada com shader. Manter um único halo difuso atrás do corpo. Sem chão, plinto, projetor ou glow no piso.

## 3. Topologia das mudanças V11.21

| Mudança | Arquivo | Evidência/teste |
|---|---|---|
| Ledger de massa e fluxos | `src/shared/graphics/droplet-mass-balance.ts`; `hydration-fluid-solver.ts` | `droplet-mass-balance.test.mjs` |
| Projeção 2D compatível/adaptativa | `src/shared/graphics/fluid-pressure-projection.ts`; `hydration-fluid-solver.ts` | `fluid-pressure-projection.test.mjs` |
| Histerese capilar | `capillary-meniscus.ts`; `hydration-fluid-solver.ts` | `capillary-meniscus.test.mjs` |
| Dados n/k e Fresnel espectral de metal | `metal-optics-spectrum.ts`; `fluid-shader-engine.ts` | `metal-optics-spectrum.test.mjs` |
| Envelope temporal Heidler | `lightning-waveform.ts`; `fluid-shader-engine.ts` | `lightning-waveform.test.mjs` |
| Contratos de integração estáticos | `scripts/check-physics-v11-21.mjs` | script de teste V11.21 |

## 4. Licenças e proveniência

- Dados n/k de refractiveindex.info: CC0 1.0, com paper de origem associado por material; os anchors Au/Ag/Cr estão identificados no código.
- PBRT-v4: Apache-2.0; consultado como referência, sem cópia de código.
- Open Anatomy 3D: assets CC BY 4.0 e wrapper MIT + CC BY 4.0; candidato não foi importado. A atribuição exigida está no upstream.
- Z-Anatomy: CC BY-SA 4.0, com obrigação ShareAlike; não foi incorporado.
- SMPL-X: licença do modelo/software restrita a pesquisa científica não comercial; não usar em produto comercial sem licença separada explícita.
- Para outros projetos de shader/VFX da shortlist, a licença deve ser revalidada no commit/arquivo exato antes de qualquer cópia. Nenhum conteúdo desses repositórios foi incorporado.

## 5. Gaps reais após V11.21

1. **Água:** grade MAC 2D, multigrid/PCG, advecção BFECC/limiter, conservação de volume de superfície e menisco Young–Laplace 3D não linear; validar cáusticas refrativas em GPU.
2. **Óptica:** espectro contínuo/CIE ou sampled wavelengths, medir material e revestimento real, TMM para filmes finos e múltiplos ressaltos internos; calibrar ambiente/reflexões.
3. **Plasma:** validar custo e passo em GPU real, jitter blue-noise/temporal accumulation, density-adaptive marching e luz volumétrica calibrada; física MHD continua fora do escopo de UI.
4. **Arcos:** geometria de líderes/ramificações, SOR de potencial Laplaciano ou DBM, corona e re-strike, pulse/MTLE calibrado; Heidler atual é só envelope.
5. **Anatomia:** obter modelos male/female com licença compatível e rig/morphs demonstrados, músculos/heads realmente separados, tendões/fáscia/juntas independentes e deformação volumétrica. Não basta renomear grupos.
6. **Pele:** UV-space irradiance diffusion com perfil multi-Gaussian, chart/seam management e thickness regional; mapas escaneados com licença e validação de iluminação.
7. **Lighting:** HDRI/softbox calibrados, turntable multi-ângulo, testes em GPUs móveis e benchmarking de frame-time/memória/draw calls.
8. **Engenharia:** `npm test`, lint e build dependem de pacotes npm ainda não instalados/recuperáveis no ambiente; WebGL2 shader compile requer Chromium/EGL funcional. A auditoria deve ser repetida em CI/PC com GPU.

## 6. Links de código diretamente inspecionados

- [SPlisHSPlasH Akinci 2013 surface tension](https://github.com/InteractiveComputerGraphics/SPlisHSPlasH/blob/master/SPlisHSPlasH/SurfaceTension/SurfaceTension_Akinci2013.cpp)
- [PBRT-v4 spectrum interpolation](https://github.com/mmp/pbrt-v4/blob/master/src/pbrt/util/spectrum.cpp)
- [PBRT-v4 Fresnel complex / scattering](https://github.com/mmp/pbrt-v4/blob/master/src/pbrt/util/scattering.h)
- [Three.js subsurface approximation](https://github.com/mrdoob/three.js/blob/dev/examples/jsm/shaders/SubsurfaceScatteringShader.js)
- [Dielectric Breakdown Model](https://github.com/the-worst-student/dielectric-breakdown-model)
- [WebGPU Ocean / MLS-MPM](https://github.com/matsuoka-601/WebGPU-Ocean)
- [Open Anatomy 3D](https://github.com/MervinR07/open-anatomy-3d)
- [RefractiveIndex.info DB](https://github.com/polyanskiy/refractiveindex.info-database)
