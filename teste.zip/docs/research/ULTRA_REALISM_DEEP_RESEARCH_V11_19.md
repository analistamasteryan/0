# TITAN V.MAX V11.19 — Pesquisa profunda e engenharia de realismo

**Data da pesquisa:** 25 de novembro de 2026  
**Base:** ZIP completo V11.18 recebido e preservado; V11.19 acrescenta os ajustes detalhados na seção 7.  
**Stack de runtime mantida:** React + TypeScript + Three.js 0.187 + WebGL2 + GLSL ES 3.00; o compositor anatômico continua GLSL ES 1.00 no pipeline WebGL1/Three.js correspondente.  
**Regra de integração:** referências GitHub servem para comparar algoritmos e fundamentar escolhas. Nenhum projeto foi copiado como runtime ou adicionado como dependência apenas por popularidade.

> Estrelas são snapshots aproximados observados no levantamento anterior e em 25/11/2026. A seleção é por relevância técnica para cada especialidade, não por ranking global cego. Licença de código e licença de datasets/ativos são verificações separadas.

## 1. Síntese das decisões

1. Preservar o ray marcher e a geometria SDF já existentes para água, vidro, plasma e metal; os componentes são pequenos e não justificam ocean solver, path tracer ou uma segunda engine.
2. Usar Fresnel dielétrico exato (s/p) com Snell e reflexão interna total nas interfaces água/vidro relevantes. Usar Fresnel exato de condutor complexo com `n(λ)+i k(λ)` e GGX anisotrópico para os macros.
3. Os valores de metais não devem ser inferidos da cor de UI. A V11.18 usa amostras tabuladas R/G/B aproximadas de Johnson & Christy para prata, cromo e ouro; a cor visual do macro atua somente como acabamento/tint leve.
4. O plasma continua sendo volume emissivo procedural. A dispersão, filamentos e arcos devem ter coerência temporal; os caminhos dos arcos são persistentes durante a descarga e o ruído os deforma em vez de reconstruir a topologia em todo frame.
5. Para pele, combinar espessura óptica regional, pré-filtro UV periódico multi-Gaussian da refletância dérmica e difusão screen-space RGB de duas escalas, com rejeição por profundidade e proteção de cores holográficas. Isto melhora a aparência, mas não equivale à difusão UV da irradiância nem a path tracing.
6. Melhorar a independência muscular com os IDs anatômicos já incorporados no mesh CC0; evitar importar malhas de terceiros sem correspondência topológica/licença comprovadas.
7. Iluminação permanece sem luz projetada no chão: key, fill e rim discretos revelam o corpo; um único halo difuso, no plano de fundo atrás da silhueta, cria separação e profundidade.

## 2. Pesquisa por especialidade — Top 5

### 2.1 Água: gota e barra de hidratação

| Repositório | Estrelas aprox. | Licença/estado verificado | Aplicação no TITAN |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Base de renderer, shaders, precisão, refração e ambiente. |
| [evanw/webgl-water](https://github.com/evanw/webgl-water) | 1.3k | Sem licença identificada nos metadados consultados | Referência de height-field, refração, Fresnel e cáusticas; código não copiado. |
| [Aureliengmz/clearwater](https://github.com/Aureliengmz/clearwater) | 0.5k | MIT | Referência WebGL de Beer–Lambert, ondas e caústicas; escala de piscina não deve ser portada. |
| [jeantimex/threejs-water](https://github.com/jeantimex/threejs-water) | 0.24k | Metadados sem SPDX confirmado nesta coleta | GPU height-field e integrações Three.js; considerar compatibilidade de runtime antes de portar. |
| [ScottieFox/caustic-volume](https://github.com/ScottieFox/caustic-volume) | 0.19k | MIT | Caústicas, reflexão/refração e volume como referência de fenômeno. |

**Deep-search de implementação:** nos exemplos oficiais do Three.js, `WaterRefractionShader` usa distorção DuDv em uma textura projetada; é útil para água de cena, mas não substitui as interseções de dupla parede já usadas pelo medidor. `clearwater` e `caustic-volume` demonstram solver de superfície e cáusticas de escopo muito maior; portar esse solver para uma cápsula de hidratação teria custo desproporcional.

**Técnicas escolhidas:** Fresnel dielétrico exato s/p, Snell/TIR, Beer–Lambert em espaço linear, Sellmeier para água/vidro, menisco Young–Laplace, filtro analítico por footprint, caústicas por derivadas diferenciais e render sob demanda com dither estável por pixel.

**Limite:** a gota e a barra são aproximações SDF/2.5D otimizadas para UI. Não são fluidos SPH/FLIP nem path-traced; não se adicionou solver FFT, bolhas GPU ou partículas em massa.

### 2.2 Vidro de energia e de macros

| Repositório | Estrelas aprox. | Licença | Contribuição relevante |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | `MeshPhysicalMaterial`, iluminação e shaders-base. |
| [google/filament](https://github.com/google/filament) | 20.8k | Apache-2.0 | PBR, unidades físicas, transmissão, roughness e SSS. |
| [pmndrs/drei](https://github.com/pmndrs/drei) | 10.2k | MIT | `MeshTransmissionMaterial`, thickness/backside, IOR, aberração e custo de buffers. |
| [google/model-viewer](https://github.com/google/model-viewer) | 8.3k | Apache-2.0 | Validação de materiais glTF em cena de referência. |
| [KhronosGroup/glTF-Sample-Viewer](https://github.com/KhronosGroup/glTF-Sample-Viewer) | 1.5k | Apache-2.0 | Implementação de referência de extensões de transmissão/volume/IOR/dispersion. |

**Achado importante do deep-search:** o código do Drei e suas histórias documentam explicitamente o custo de resolução de transmissão, backside e thickness. A melhor decisão para este projeto é estudar o modelo e manter o ray marching local do TITAN, não adicionar um passe de transmissão da cena inteira.

**Técnicas escolhidas:** IOR e dupla interface, Fresnel exato, Snell/TIR, espessura de parede, absorção Beer–Lambert, dispersão Sellmeier do borossilicato e GGX para micro-highlights. A parede externa não deve receber dispersão RGB uniforme; o efeito é atenuado em regiões quase planas e cresce em bordas/ângulos rasantes.

#### Metais: dados ópticos

Fonte primária de dados: [polyanskiy/refractiveindex.info-database](https://github.com/polyanskiy/refractiveindex.info-database), que declara CC0 para a base. As amostras usadas são tabulações room-temperature de Johnson & Christy:

- Au: *Optical constants of the noble metals*, Physical Review B 6 (1972), 4370–4379.
- Ag: mesma publicação e tabela.
- Cr: *Optical constants of transition metals*, Physical Review B 9 (1974), 5056–5070.

A V11.18 amostra `n,k` em 659.5, 520.9 e 450.9 nm (R/G/B). Não é uma curva espectral contínua nem uma certificação de liga comercial; é uma aproximação RGB rastreável, muito melhor que derivar `n,k` da cor do widget. A equação usa Fresnel de condutor exato e termo correto `n²-k²-sin²θ`, com GGX anisotrópico. O teste numérico em incidência normal usa F0 aproximado: Ag 0.9906/0.9835/0.9803, Cr 0.5567/0.5581/0.5551, Au 0.9626/0.6434/0.4082 (R/G/B).

### 2.3 Plasma volumétrico

| Repositório | Estrelas aprox. | Licença | Contribuição e limite |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Contexto de runtime e WebGL. |
| [Auburn/FastNoiseLite](https://github.com/Auburn/FastNoiseLite) | 3.5k | MIT | Família de ruídos e GLSL; biblioteca de ruído, não plasma. |
| [pmndrs/postprocessing](https://github.com/pmndrs/postprocessing) | 3k | Zlib | Passes e bloom; não substitui a integração volumétrica. |
| [shader-park/shader-park-core](https://github.com/shader-park/shader-park-core) | 0.83k | MIT | Campos procedurais/SDF como referência de organização. |
| [Donitzo/three.js-volume-renderer](https://github.com/Donitzo/three.js-volume-renderer) | 22 | MIT | Raymarching de volume, clipping e extinção. |

**Técnicas:** ruído 3D multifrequência, curl noise, domain warp moderado, remapeamento de densidade, volume integration, Beer–Lambert, jitter estável, término antecipado, emissão HDR e bloom limitado ao núcleo. Não se deve aumentar o número de passos sem um benchmark de GPU; o shader atual tem um custo de ruído 3D significativo.

**Limite:** plasma de widget é uma representação emissiva estilizada. Henyey–Greenstein pode descrever scattering de volume, mas não transforma plasma emissivo em um meio atmosférico real. A luz interna/reflexo verde na parede deve continuar local e discreta.

### 2.4 Raios e microanimações

| Repositório | Estrelas aprox. | Licença/limite | Uso adequado |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Buffers, geometria e shader runtime. |
| [remotion-dev/remotion](https://github.com/remotion-dev/remotion) | 75k | Não assumir licença de reutilização pelo número de estrelas | Estudar efeito de lightning e envelopes temporais. |
| [patch-gg/pixelfx](https://github.com/patch-gg/pixelfx) | 9.2k | MIT | Catálogo e timing de arcos, corrente elétrica, sparks e bursts; linguagem visual VFX, não modelo 3D físico. |
| [keijiro/spektrlightning](https://github.com/keijiro/spektrlightning) | 210 | MIT; Unity/C# | Referência de ramificação procedural, não integração direta no Three.js. |
| [SummerEngine/summer](https://github.com/SummerEngine/summer) | 113 | MIT | Pipeline de efeitos/skills VFX; não um motor autônomo de plasma 3D. |

**Técnicas:** topologia de arcos persistente por seed, pontos de ramificação estáveis, jitter espacial limitado, envelope de ataque/decay contínuo, pulsos que percorrem canal, ramificações com vida independente, reacendimento parcial, núcleo e corona separados, distância/cobertura volumétrica e flicker não quantizado. As fontes consultadas são referências de arte e de VFX, não simulação de descarga elétrica de laboratório.

**Limite:** o componente do TITAN não calcula campo elétrico, breakdown dielétrico, streamer eletro-hidrodinâmico ou propagação de elétrons. Não se deve apresentar a animação como uma simulação física de descarga atmosférica.

### 2.5 Corpo, anatomia e deformação muscular

| Repositório | Estrelas aprox. | Licença | Aplicação/limite |
|---|---:|---|---|
| [ashemag/human-atlas](https://github.com/ashemag/human-atlas) | 4.6k | Código MIT; dado BodyParts3D CC BY 4.0 | Estruturas anatômicas e taxonomia; referência masculina adulta e dataset com atribuição. |
| [makehumancommunity/makehuman](https://github.com/makehumancommunity/makehuman) | 1.7k | Metadados devem ser verificados por componente/asset | Parametrização de corpo e base morfológica. |
| [facebookresearch/MHR](https://github.com/facebookresearch/MHR) | 0.9k | Apache-2.0 | Human model reconstruction e forma paramétrica. |
| [NVlabs/SOMA-X](https://github.com/NVlabs/SOMA-X) | 0.9k | Apache-2.0 | Parametrização de forma e morphs; backend científico, não renderer de app. |
| [naver/anny](https://github.com/naver/anny) | 0.66k | Licença/uso de dados precisa de avaliação específica | Representação e reconstrução humana. |

**Técnicas:** mapa semântico por vértice canônico, máscara muscular, morph targets esparsos, deformação por região e lado, volume preservation, smooth transitions, normal recomputation/tangent correctness e LOD real. A V11.18 separa os grupos já codificados nos dados da malha: bíceps (ID 5) e tríceps (ID 6), quadríceps (ID 12) e posteriores/isquiotibiais (ID 13). Os lofts complementares também recebem lóbulos anteriores e posteriores independentes.

**Limite importante:** isso aprimora a independência de deformação da malha existente. Não cria origem/inserção anatômica validada para todos os músculos, não aumenta automaticamente a resolução do asset-base, nem substitui um atlas anatômico completo. A malha MakeHuman hm08 continua como ativo-base CC0.

### 2.6 Pele e subsurface scattering

| Repositório | Estrelas aprox. | Licença | Contribuição |
|---|---:|---|---|
| [google/filament](https://github.com/google/filament) | 20.8k | Apache-2.0 | Modelo material subsurface e parâmetros, integração PBR. |
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Thickness e pipeline de materiais/iluminação. |
| [playcanvas/engine](https://github.com/playcanvas/engine) | 17.3k | MIT | Renderer e iluminação; referência de implementação de luz/arte. |
| [pmndrs/postprocessing](https://github.com/pmndrs/postprocessing) | 3k | Zlib | Pós-processamento e infraestrutura de filtros, não skin SSS pronto. |
| [pmndrs/drei](https://github.com/pmndrs/drei) | 10.2k | MIT | Materiais e integração R3F; referência de pipeline, não dependência necessária. |

**Fonte técnica adicional:** NVIDIA GPU Gems 3, capítulo “Advanced Techniques for Realistic Real-Time Skin Rendering” descreve difusão de luz por perfis multi-Gaussian em espaço de textura. O estudo ensina que a luz se espalha lateralmente em escalas diferentes e que um único blur é insuficiente.

**V11.18:** estimativa de espessura óptica por região (tronco, membros, cabeça), atenuação RGB e perfis próximo/largo no shader da pele; o compositor aplica 5 amostras screen-space, com rejeição por profundidade e filtro cromático para não borrar holograma/contorno. Isso é uma aproximação realtime, não substitui o método multi-Gaussian UV-space. A resolução e os RTs atuais devem ser medidos em GPU para decidir se o próximo salto justifica outro pass.

### 2.7 Iluminação do corpo

| Repositório | Estrelas aprox. | Licença | Contribuição |
|---|---:|---|---|
| [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119k | MIT | Renderer, PMREM, RectAreaLight. |
| [google/filament](https://github.com/google/filament) | 20.8k | Apache-2.0 | PBR e consistência de luz/material. |
| [playcanvas/engine](https://github.com/playcanvas/engine) | 17.3k | MIT | Área de luz e softboxes retangulares via LTC. |
| [pmndrs/react-three-fiber](https://github.com/pmndrs/react-three-fiber) | 33.9k | MIT | Integração Three.js/React, não melhora física por si só. |
| [pmndrs/drei](https://github.com/pmndrs/drei) | 10.2k | MIT | Environment/lighting utilities. |

**Decisão:** key de área para desenhar volume, fill fraco para abrir sombra, rim suave para separar contorno e um único halo difuso atrás do corpo. Sem floor mesh emissivo, ground projector, círculo nos pés ou feixe vertical. O halo é cenário, não uma fonte de luz local falsa no chão.

## 3. Implementação V11.18

### 3.1 Óptica dielétrica

- Adicionada equação exata de Fresnel não polarizado, média de polarizações s/p, com lei de Snell e TIR.
- Substituídos os Fresnel aproximados de interfaces dielétricas críticas água/vidro e microfacetas de água/borossilicato.
- Mantidos modelos de dispersão Sellmeier e Beer–Lambert já existentes.

### 3.2 Óptica metálica

- Corrigida e implementada Fresnel exata de condutor com `n,k` complexos.
- Adicionados três perfis de material: silver, chromium e gold, com amostras RGB tabuladas de `refractiveindex.info`/Johnson–Christy.
- O preset material vem do tipo do macro (carboidrato/prata, proteína/cromo, gordura/ouro); cor da UI apenas tinge o resultado levemente.
- Mantido GGX anisotrópico e anti-aliasing de highlight.

### 3.3 Plasma e microanimação de descarga

- O curl do campo escalar foi refeito com derivada analítica do ruído trilinear (`energyNoise3DGradient`): oito cantos do lattice são avaliados uma vez e o gradiente é obtido pela regra da cadeia, em vez de seis reamostragens por diferenças finitas.
- O caminho ridged do canal principal/secundário deixou de avaliar quatro extremidades por coordenada e interpolá-las a cada passo do raymarch; agora consulta diretamente duas coordenadas contínuas do campo, reduzindo o trabalho do caminho em cada amostra.
- O ruído ridged usa remapeamento com `smoothstep` para suavizar a inversão em torno do meio do sinal. A identidade da ramificação continua presa ao `nodeId`, com envelope temporal contínuo.
- Essa otimização reduz amostras de ruído, mas não é um benchmark de tempo de GPU. Os 12 passos fixos de volume e custo total continuam exigindo medição em hardware.

### 3.4 Anatomia e pele

- Verificada a separação de IDs canônicos para bíceps/tríceps e quadríceps/isquiotibiais no asset binário.
- Morfologia da malha usa os IDs distintos em cada morph esparso.
- Loft procedural recebe lóbulos anteriores/posteriores independentes e transições suavizadas.
- Material de pele recebe espessura óptica regional e perfis RGB multi-lobe aproximados.
- Compositor dual-body recebe difusão screen-space de cinco amostras com proteção por profundidade e tonalidade.

### 3.5 Iluminação

- Rig refinado para soft key retangular, fill baixo e rim suave; fallback de software possui intensidades próprias.
- Preservado apenas o halo difuso no fundo. Nenhum projetor/plinto de chão é criado.

### 3.6 Dependências

Nenhuma nova dependência runtime foi adicionada. Evita-se adicionar um segundo renderer, transmissão de cena inteira, solver oceanográfico ou pacote de partículas ao app.

## 4. Testes acrescentados (histórico V11.18)

- `scripts/check-rendering-realism-v11-18.mjs`: contratos de ótica exata, constantes `n,k`, presets de metal, morphs regionais, SSS e halo.
- `scripts/check-anatomy-independent-morphs-v11-19.mjs`: decodifica a geometria binária e valida que os morphs esparsos realmente alcançam IDs distintos das quatro regiões musculares.
- `scripts/check-energy-noise-gradient-v11-18.mjs`: compara a derivada analítica do ruído com diferenças centrais em seis pontos e três eixos (18 comparações).
- O contrato de realismo também confirma a derivada analítica do ruído de plasma e a retirada da interpolação segmentada redundante dos caminhos de arco.
- `scripts/check-gpu-shaders-v11-18.mjs`: cria contexto headless Chromium/WebGL2 e compila os sete fragment shaders de fluidos e o fragment shader do compositor, se o host oferecer Chromium com SwiftShader/WebGL.

## 5. Limitações remanescentes após V11.18 (atualizadas na seção 7)

- A simulação de água continua um shader SDF/2.5D; não é SPH/FLIP nem path tracing.
- O metal usa três amostras visíveis de `n,k` por material; não é uma curva espectral contínua nem identifica composição de uma liga real.
- O plasma e os arcos são representações visuais, não simulações de eletrodinâmica/plasma físico.
- A pele usa espessura estimada e difusão screen-space local; falta a implementação de SSS multi-Gaussian UV-space completa, que exigiria UVs/RTs/blur e benchmark específico.
- A anatomia foi refinada dentro da malha/IDs existentes. Para todas as origens, inserções, tendões e músculos profundos será necessário adquirir/validar ativo anatômico com licença e correspondência topológica, ou construir um novo asset.
- A calibração final de tom, roughness, bloom, exposição, subpixel aliasing e FPS precisa ser executada em browsers/GPU reais (desktop e mobile). Compilação headless confirma sintaxe/link do shader, não aprovação perceptual nem desempenho.

## 6. Arquivos de referência consultados (deep-search em código e documentação)

- [Three.js WaterRefractionShader](https://github.com/mrdoob/three.js/blob/dev/examples/jsm/shaders/WaterRefractionShader.js) e [exemplo de refração](https://github.com/mrdoob/three.js/blob/dev/examples/webgl_refraction.html): distorção screen-space DuDv; útil como referência complementar, não para substituir os limites internos SDF do medidor.
- [Drei MeshTransmissionMaterial source](https://github.com/pmndrs/drei/blob/master/src/core/MeshTransmissionMaterial.tsx) e [documentação do material](https://github.com/pmndrs/drei/blob/master/docs/shaders/mesh-transmission-material.mdx): contrato de `transmission`, `thickness`, backside, roughness e resolução. Reforça o custo de transmissão por buffer.
- [FastNoiseLite GLSL README](https://github.com/Auburn/FastNoiseLite/blob/master/GLSL/README.md): configurações e uso GLSL; avaliado como referência, sem substituir a função noise local por uma biblioteca extra.
- [Filament Materials guide](https://github.com/google/filament/blob/main/docs/Materials.md.html): material Subsurface, propriedades e integração PBR.
- [Three.js TSL thickness docs](https://github.com/mrdoob/three.js/blob/dev/tsl/content/Guide.md): thickness como espessura de volume para transmissão/SSS; referência para coerência de parâmetro.
- [PixelFX catalog — lightning effects](https://github.com/patch-gg/pixelfx/blob/main/docs/CATALOG.md): timing de charge-up/electrified/strike e camadas de descarga. É catálogo VFX e não modelo eletrofísico.
- [Human Atlas attribution and data scope](https://github.com/ashemag/human-atlas/blob/main/public/ATTRIBUTION.md): confirma licença CC BY 4.0 do conjunto BodyParts3D e a limitação de referência masculina adulta; por isso nenhum dado foi importado silenciosamente.
- [PlayCanvas area-light example](https://github.com/playcanvas/engine/blob/main/examples/src/examples/lights-and-shadows/area-lights/example.mjs): fonte retangular / softbox como referência de iluminação; o renderer do TITAN permanece Three.js.
- [RefractiveIndex database — Ag](https://github.com/polyanskiy/refractiveindex.info-database/blob/main/database/data/main/Ag/nk/Johnson.yml), [Au](https://github.com/polyanskiy/refractiveindex.info-database/blob/main/database/data/main/Au/nk/Johnson.yml) e [Cr](https://github.com/polyanskiy/refractiveindex.info-database/blob/main/database/data/main/Cr/nk/Johnson.yml): arquivos consultados para as três amostras RGB usadas no shader.
- [NVIDIA GPU Gems 3 — Advanced Techniques for Realistic Real-Time Skin Rendering](https://developer.nvidia.com/gpugems/gpugems3/part-iii-rendering/chapter-14-advanced-techniques-realistic-real-time-skin): referência de perfil de difusão multi-Gaussian e blur em espaço de textura; não foi portada como algoritmo completo nesta iteração.

---

## 7. V11.19 — aprofundamento, alterações adicionais e estado validado

**Data:** 25 de novembro de 2026. A V11.19 parte da V11.18 preservada e acrescenta difusão de pele RGB em duas escalas no compositor, pré-filtro multi-Gaussian em UV para refletância da pele, parâmetros explícitos de ângulo de contato para menisco capilar, coerência entre luz key física e direção no shader, e contratos de granularidade anatômica.

### 7.1 Pele: do mapa de poros ao espalhamento de baixa frequência

**Problema identificado:** um único albedo com poros e microcontraste não deve ser usado diretamente como resposta de espalhamento. Também era incorreto chamar a difusão screen-space de cinco taps da V11.18 de SSS UV-space.

**Referências aprofundadas em código:**

| Repositório | Contribuição estudada | Aplicação/limite |
|---|---|---|
| [google/filament — separableGaussianBlur.fs](https://github.com/google/filament/blob/main/filament/src/materials/separableGaussianBlur.fs) | Convolução separável, pesos normalizados e filtragem em passes | Base algorítmica para prefilter, não código copiado; shader não é o perfil de pele do TITAN. |
| [mrdoob/three.js — SubsurfaceScatteringShader.js](https://github.com/mrdoob/three.js/blob/dev/examples/jsm/shaders/SubsurfaceScatteringShader.js) | Termo direcional de translucência com thickness map | Referência de aproximação rápida; não é difusão espacial multi-Gaussian completa. |
| [google/filament — Materials guide](https://github.com/google/filament/blob/main/docs/Materials.md.html) | Modelo `subsurface`, parâmetros e resposta PBR | Referência para comportamento de material e integração. |
| [pmndrs/postprocessing](https://github.com/pmndrs/postprocessing) | Efeitos de screen-space, depth-aware sampling e passes | Avaliado como referência de arquitetura; nenhuma dependência adicionada. |
| [pmndrs/drei — MeshTransmissionMaterial](https://github.com/pmndrs/drei/blob/master/src/core/MeshTransmissionMaterial.tsx) | Espessura/transmissão/backside e custo dos passes | Utilizado como referência óptica do vidro, não como SSS da pele. |

**Implementação V11.19:**

- Albedo principal de poros continua nítido e separado.
- Uma cópia compacta 256×256 é criada em luz linear, com downsample periódico e mistura de duas Gaussianas por canal, antes de voltar a sRGB.
- O perfil permite maior raio para vermelho, intermediário para verde e menor para azul; a costura U/V é periódica.
- O mapa é compartilhado por corpo atual, corpo objetivo e materiais musculares; não duplica os pixels de origem.
- O compositor recebe duas coroas cardinais (1,35 e 4,5 texels), kernels RGB diferentes, pesos normalizados por canal e rejeição por descontinuidade de profundidade. O gate cromático conserva contornos holográficos e evita difundir camadas não dérmicas.

**Limite honesto:** a pré-filtragem UV altera a refletância difusa de baixa frequência; ela não é uma convolução UV da iluminação incidente. O compositor aplica difusão screen-space dependente de profundidade ao resultado iluminado. A combinação é uma aproximação de SSS em tempo real, não um modelo de transporte de luz, não separable UV-space diffusion de iluminação e não path tracing. Um SSS UV integral exigiria passe de bake de irradiância UV, identificação de chart/seams, convolução multi-Gaussian da iluminação por canal e composição sem vazamento entre ilhas.

### 7.2 Menisco e água

**Referências Top 5 mantidas:** Three.js, WebGL Water, Clearwater, Three.js Water e Caustic Volume (seção 2.1). A inspeção de `WaterRefractionShader` do Three.js confirmou que a distorção DuDv é um efeito screen-space de superfície, não uma solução de dupla interface para uma gota dentro de vidro.

**Decisão numérica:** o perfil linearizado planar de Young–Laplace é escrito como:

\[
 h(d)=\lambda_c\cot(\theta)\exp(-d/\lambda_c)
\]

com \(\theta\) como ângulo de contato medido no líquido e \(\lambda_c\) como comprimento capilar característico. A derivada segunda é \(h''=h/\lambda_c^2\). Ângulos quase 0 e quase π são limitados para impedir singularidades numéricas. A gota e a barra mantêm seus comprimentos calibrados; os ângulos foram escolhidos para preservar a altura junto à parede das calibrações anteriores.

**Limite:** é uma aproximação 1D linearizada de pequena inclinação em parede planar. Não resolve a equação não-linear de Young–Laplace para recipiente curvo 3D, ângulo de contato dinâmico com histerese ou gravidade em toda a geometria. O solver da hidratação continua 2D Euleriano compacto (grade 48×24), com projeção de incompressibilidade de poucas iterações, confinamento de vorticidade, advecção semi-Lagrangiana e aeration field; não é SPH/FLIP nem fluido conservativo 3D.

### 7.3 Luz de estúdio coerente

**Referências Top 5:** Three.js, Filament, PlayCanvas, React Three Fiber e Drei (seção 2.7). A leitura do exemplo LTC do PlayCanvas mostra como softboxes retangulares são orientadas a um alvo; o rig do TITAN utiliza uma única direção compartilhada entre a key no renderer e o shading customizado.

**Implementação:** `ANATOMY_KEY_LIGHT_DIRECTION`, `ANATOMY_KEY_LIGHT_TARGET` e `ANATOMY_KEY_LIGHT_DISTANCE` são a fonte única de verdade. A luz retangular no caminho hardware e a luz direcional fallback derivam da mesma direção; o uniform `uKeyLightDirection` usa a mesma direção no shader. O halo de fundo continua independente. Nenhum plinto, projetor, spot no chão, anel sob o pé ou sombra de contato foi adicionado.

**Limite:** `RectAreaLight` não é fonte de luz de área fisicamente exata em todos os paths de Three.js; seu suporte e custo dependem do renderer/versão. A correspondência angular foi validada estaticamente, mas a aparência ainda requer captura em hardware WebGL real.

### 7.4 Anatomia, dados e licenciamento

**Referências Top 5:** Human Atlas, MakeHuman, Facebook MHR, NVIDIA SOMA-X e Naver Anny (seção 2.5). Foram lidos no Human Atlas `app/anatomy.ts`, `app/model-download.ts`, `scripts/convert-anatomy.py`, `scripts/optimize-anatomy.mjs`, `public/ATTRIBUTION.md` e o manifesto de meshes.

O Human Atlas fornece 2.234 meshes organizadas em sistemas anatômicos e 3.432 conceitos, com chunks binários compactados e conversão de OBJ para buffers tipados. Porém, seus dados BodyParts3D são referência de adulto masculino e estão sob CC BY 4.0, enquanto o código é MIT; não são um corpo feminino universal nem substituto topológico da malha do TITAN. Importar os dezenas de MB de anatomia sem correspondência de coordenadas, lateralidade, origem/inserção e morphs seria um falso avanço. A V11.19 não incorpora esses ativos. O único refinamento de topologia/deformação adicional foi separar os pesos das três cabeças do deltoide a partir dos IDs canônicos que já existiam; os demais agrupamentos permanecem declarados como compartilhados.

**Melhoria adicional identificada por inspeção do payload:** o morph esparso `deltoids` do MakeHuman hm08 já cobre os IDs canônicos 2/3/4 (138/52/102 vértices modificados). A V11.19 passa a aplicar pesos independentes para deltoide anterior, lateral e posterior, com fallback para o antigo `regionalMorphs.deltoids` em perfis persistidos. Não foram criados novos vértices nem alegada validação de origem/inserção anatômica.

**Implementação:** o mapa de subestruturas informa explicitamente se a geometria/deformação é independente ou compartilhada por grupo de treino. Os deltoides anterior, lateral e posterior mantêm grupos distintos; rótulos compostos de peitoral, bíceps/tríceps, quadríceps, posteriores, panturrilha e antebraço declaram compartilhamento. Os 14 IDs de treino permanecem intactos.

**Limite:** não foram adicionadas malhas anatômicas completas de músculo, tendão, osso, fáscia, inserção ou origem. Uma etapa futura precisa selecionar datasets por sexo/escala, auditar licenças e metadados, alinhar landmarks ao mesh-base, preservar topologia de picking e medir deformações sem falsificar a correspondência anatômica.

### 7.5 Matriz atual de validação

| Área | Verificação automatizada disponível | Não substitui |
|---|---|---|
| Água/menisco | Testes CPU do perfil, ângulo de contato e checker GLSL estático | Render ótico em hardware e comparação fotográfica |
| Metais | F0 normal-incidente calculado contra nove referências `n,k`; shader estático | Espectro contínuo de refletância e curva de liga real |
| Pele | Testes da convolução UV linear-light, preservação alpha e seam; teste de kernels screen-space | SSS UV de iluminação e captura real sob múltiplas luzes |
| Iluminação | Teste de igualdade do vetor shader/rig e checagem de ausência de chão | Percepção visual em hardware e todas as rotações |
| Anatomia | Decodificação dos morphs da base e teste de status de 15 labels | Avaliação por anatomista, morfologia clínica ou asset anatômico completo |
| Plasma | 18 comparações do gradiente analítico vs. diferenças centrais e checks estáticos | GPU profiling e percepção de microanimação em 10–20 s |
| Build | Transpilation sintática independente pode ser executada com TypeScript global | Build Vite, TypeScript semântico integral e E2E com dependências |
| GPU | Chromium headless tenta compilar 7 fragmentos de fluido e compositor | Contexto GPU não está disponível em todos os ambientes; SKIPPED não é PASS |

### 7.6 Top 5 e licença — referência consultada em 25/11/2026

A seleção Top 5 por especialidade permanece na seção 2 deste documento. O ranking é relativo à pertinência técnica; estrelas são indicadoras de adoção, não qualidade física. As referências `evanw/webgl-water`, `jeantimex/threejs-water` e alguns assets do Khronos não têm licença de reuso automaticamente confirmada por repository SPDX. Human Atlas code MIT não licencia automaticamente as malhas BodyParts3D. Nenhum novo código ou asset externo foi copiado para a V11.19.


### 7.7 Resultado de validação desta revisão

**Executado e aprovado em 25/11/2026:** `npm run test:rendering-realism`; `npm run test:review`; verificações estáticas de anatomia, ciclo de vida, design system, materiais, limites de domínio, cockpit e seleção muscular; testes CPU de perfil UV, menisco, coerência de iluminação, granularidade anatômica e pesos independentes de deltoide; 18 comparações de derivada analítica do ruído; transpilação sintática TypeScript/TSX de 206 arquivos sem erros; `npm run typecheck:calculations`.

**Bloqueado pelo ambiente e não aprovado:** `npm test` encerra no primeiro comando porque `tsx` não está instalado; `npm run lint` não encontra `vite/client`; `npm run build` não encontra `vite`; tentativa de instalar dependências falhou por indisponibilidade de rede/registry (`EAI_AGAIN`). `npm run test:gpu-shaders` foi executado, mas SKIPPED: Chromium/ANGLE retorna `EGL_NOT_INITIALIZED`/falha de XCB e o host não cria contexto WebGL2 mesmo com Xvfb/Mesa. Nenhum shader é declarado compilado por GPU nesta revisão.

**Consequência:** testes de domínio e sintaxe foram executados; o build final, o typecheck TypeScript completo e a compilação/link GPU continuam abertos para CI/browser com as dependências e GPU/WebGL2 disponíveis.
