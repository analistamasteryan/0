# TITAN V.MAX V11.17 — Deep Research e Decisões de Realismo Visual

**Data de corte da pesquisa:** 25 de novembro de 2026  
**Base auditada:** ZIP enviado nesta conversa (`titan (3).zip`)  
**Objetivo:** melhorar fidelidade óptica, continuidade das microanimações, anatomia e iluminação, mantendo Three.js/WebGL2/GLSL e sem incluir dependências runtime sem benefício mensurável.

> As contagens de estrelas abaixo são snapshots aproximados observados na data de pesquisa. Estrelas indicam adoção/visibilidade, não qualidade, validade anatômica, fidelidade física, segurança de licença nem adequação ao TITAN. As posições foram escolhidas pela relevância dentro do conjunto de referências da especialidade; quando um repositório é apenas motor/fundação ou exemplo conceitual, isso é indicado explicitamente.

## 1. Decisão arquitetural geral

O TITAN já tem um renderizador customizado e relativamente avançado. Água, vidro, metal e plasma não devem ser substituídos por uma biblioteca genérica. As melhores referências foram usadas como base de revisão matemática e técnica; não como justificativa para instalar engines paralelas.

Decisões:

- Preservar o motor compartilhado WebGL2 e os shaders SDF/volumétricos existentes.
- Priorizar coerência temporal, iluminação, estabilidade subpixel e agendamento sob demanda.
- Separar as propriedades ópticas de água, vidro e metal; uma cor diferente não deve simular outro material.
- Não importar simulação de oceano FFT, SPH, partículas massivas ou transmissão de cena inteira para medidores de poucos pixels.
- Manter Three.js para anatomia e a geometria base existente até haver dados anatômicos com licença, proveniência, topologia e mapeamento muscular validados.
- Não incluir novas dependências runtime nesta revisão.

---

## 2. Água da hidratação — gota e barra

### 2.1 Estado real encontrado no projeto

O motor `src/shared/graphics/fluid-shader-engine.ts` já inclui:

- gota SDF 3D com superfície de água e menisco;
- cápsula horizontal de vidro, com superfície líquida e inclinação;
- IOR nominal de água 1,333 e vidro borossilicato próximo de 1,515;
- refração sucessiva nas interfaces ar/vidro/água/vidro/ar;
- Fresnel, lei de Snell e reflexão interna total;
- absorção Beer–Lambert em espaço linear;
- equações de Sellmeier por comprimento de onda para água e vidro;
- foco/cáusticas baseados em área diferencial e derivadas de tela;
- menisco capilar Young–Laplace;
- pequenas ondas, solver de mola e perturbação por interação;
- render estático quando a gota/barra repousa.

A solução é uma aproximação óptica SDF/2.5D controlada, não path tracing nem um solver SPH. Essa escolha continua correta para uma peça pequena de dashboard.

### 2.2 Top 5 de repositórios de água

| Repositório | Estrelas aprox. | Licença/relevância | O que deve ser estudado |
|---|---:|---|---|
| [Evan Wallace — webgl-water](https://github.com/evanw/webgl-water) | 1,3 mil | Licença não declarada no metadado consultado; referência algorítmica | Altura de onda, refração, Fresnel e cáusticas por área diferencial. Não copiar o código sem esclarecer licença. |
| [Aureliengmz — clearwater](https://github.com/Aureliengmz/clearwater) | 0,52 mil | MIT; WebGL2 standalone | FFT, solver shallow-water, IOR espectral, absorção, resolução adaptativa e pipeline de cáusticas. Muito mais amplo que o medidor; não portar o oceano inteiro. |
| [jeantimex — webgpu-water](https://github.com/jeantimex/webgpu-water) | 0,276 mil | Verificar licença antes de reutilizar; WebGPU | Height-field 256×256, raytraced reflection/refraction e caustics; importante referência algorítmica, mas não é drop-in no renderer WebGL2 atual. |
| [jeantimex — threejs-water](https://github.com/jeantimex/threejs-water) | 0,244 mil | MIT; Three.js/WebGL | SDF para interseção de recipientes curvos, GPU height-field, raios/reflexões e cuidados de precisão no iOS Safari. |
| [ScottieFox — caustic-volume](https://github.com/ScottieFox/caustic-volume) | 0,188 mil | MIT; projeto experimental de alto escopo | FFT, iWave, caustics, reflexão/refração, TIR, photon tracing e temporal AA. Usar como referência de fenômeno, não como dependência do componente. |

**Referências complementares:** [HowdyKeith/swek-webgl2-water](https://github.com/HowdyKeith/swek-webgl2-water) (MIT, pequeno estudo WebGL2 de heightfield/caústicas) e [Three.js](https://github.com/mrdoob/three.js) (MIT; cerca de 119 mil estrelas, motor do app). Nenhum desses projetos justifica importar outro renderer.

### 2.3 Melhorias implementadas nesta revisão

- Dither espacial da saída óptica passou a usar coordenadas estáveis por pixel. Antes, o deslocamento do hash pelo tempo fazia o grão “caminhar” sobre a refração enquanto o componente animava. Isso é especialmente perceptível em bordas translúcidas e highlights.
- Mantido o render estático sob demanda. A barra/gota não deve gerar quadros apenas porque está preenchida.
- O comentário do shader foi corrigido para não afirmar que a gota inclui bolhas decorativas, que não fazem parte da versão renderizada atual.

### 2.4 O que não foi feito e por quê

- Não foi adicionado solver FFT, SPH ou sistema de partículas de bolhas. Um domínio de 54 px não obtém benefício visual proporcional ao custo, buffers e incompatibilidade móvel.
- Não foi substituído o solver de mola existente. O componente já dispõe de perturbação e amortecimento com baixo custo.
- Não foi introduzido HDRI externo sem ativo/atribuição/licença verificados.

### 2.5 Próxima evolução que realmente agregaria valor

1. Capturar testes visuais a 0/10/25/50/75/100% e acima da meta em GPU física, desktop e iOS Safari.
2. Medir artefatos em 1x/2x/3x DPR, em especial serrilhado de cáusticas e highlights.
3. Revisar a escala aparente do menisco em track com 54 px e confirmar que a refração não fica exagerada em dispositivos de baixa densidade.
4. Caso benchmarks revelem custo elevado, testar cache de ruído 3D/textura de blue-noise genuína antes de aumentar ou reescrever o solver.

---

## 3. Vidro da energia e dos macros

### 3.1 Top 5 de referência para vidro/transmissão/PBR

| Repositório | Estrelas aprox. | Licença | Aplicação correta |
|---|---:|---|---|
| [Three.js](https://github.com/mrdoob/three.js) | 119 mil | MIT | Base do renderer e das funções PBR/WebGL já usadas pelo TITAN. |
| [Google Filament](https://github.com/google/filament) | 20,8 mil | Apache-2.0 | Referência de BRDF Cook–Torrance, unidades físicas, anisotropia, IBL, transmissão, SSS aproximado e anti-aliasing especular. Não substituir o renderer por Filament. |
| [pmndrs/drei](https://github.com/pmndrs/drei) | 10,2 mil | MIT | `MeshTransmissionMaterial`: espessura, roughness, aberração cromática, refração traseira e buffer. É React Three Fiber e adiciona passes/custo; usar como estudo, não colar no TITAN. |
| [Google Model Viewer](https://github.com/google/model-viewer) | 8,3 mil | Apache-2.0 | Comportamento de materiais glTF, validação visual em cena simples e configurações de exposição/ambiente. |
| [Khronos glTF Sample Viewer](https://github.com/KhronosGroup/glTF-Sample-Viewer) | 1,5 mil | Apache-2.0 | Implementação de referência WebGL2 de IOR, transmission, volume, dispersion, anisotropy e clearcoat. |

**Especialistas adicionais:** [liquid-glass](https://github.com/archisvaze/liquid-glass) (cerca de 849 estrelas, MIT) e [liquidgl](https://github.com/naughtyduk/liquidgl) (cerca de 1,1 mil, licença não declarada nos metadados vistos) são úteis para estética/ótica de UI, mas não substituem validação de transmissão em volume 3D.

### 3.2 Vidro de energia

O shader existente já calcula vidro borossilicato ametista com duas paredes, refração de saída em canais, Fresnel/TIR, absorção Beer–Lambert e contribuição luminosa do plasma na parede interna.

O `Sellmeier` usado corresponde à parametrização de borossilicato N-BK7. Isso é preferível a um RGB arbitrário. A melhoria nesta revisão preserva a camada óptica e corrige o dither espacial compartilhado para remover o crawl temporal.

Próximo refinamento: validar espessura, transmissão e intensidade do spill do plasma em screenshots; controlar a dispersão para ela ser perceptível nas bordas curvas, e não como um contorno RGB uniforme.

### 3.3 Vidro e metal dos macros

O código existente usa:

- parede dianteira/traseira do tubo de vidro;
- refração e Fresnel;
- menisco convexo do metal líquido;
- Fresnel de condutor com índice complexo `n + i*k`;
- GGX anisotrópico e um ambiente dark-field procedural com softboxes.

Limitação confirmada: a parametrização espectral do condutor ainda é uma aproximação derivada de cores (`u_metalColor`/`u_metalHighlight`), não uma tabela medida de `n(λ)` e `k(λ)` específica para prata, ouro, cromo ou alumínio. Portanto, a aparência é materialmente coerente, mas não deve ser apresentada como correspondência laboratorial de uma liga específica.

### 3.4 Melhoria implementada

O metal dos macros não mantém mais animação permanente só porque existe preenchimento. O valor é interpolado durante uma mudança real e a inclinação óptica responde ao ponteiro por um amortecimento exponencial curto. Ao terminar a transição, o renderer volta a dormir.

Também foi corrigida a continuidade da interação: o alvo do ponteiro e a inclinação renderizada são estados separados. O ponteiro não teletransporta o material nem deixa o componente sem quadros no agendador.

### 3.5 Próxima evolução

- Criar pequenos conjuntos de amostras `n,k` espectrais para metais nomeados e interpolar RGB com 3 comprimentos de onda; não usar apenas mistura por cor da UI.
- Medir anti-aliasing de micro-highlights em 100×65 px para evitar cintilação subpixel.
- Validar o gradiente de espessura no menisco e a separação entre reflexo da parede e reflexo do líquido.
- Não adotar `MeshTransmissionMaterial` por inteiro: o medidor já resolve seu volume com um shader SDF menor, sem passe de transmissão da cena inteira.

---

## 4. Plasma volumétrico

### 4.1 Top 5 de código-base e algoritmos relevantes

Não existe um conjunto de cinco pacotes populares e maduros que ofereça um motor pronto de plasma volumétrico 3D em Three.js/WebGL2. A lista abaixo reúne as bases e bibliotecas de maior adoção realmente úteis para esse shader, e deixa claro o papel de cada uma.

| Repositório | Estrelas aprox. | Licença | Papel/limitação |
|---|---:|---|---|
| [Three.js](https://github.com/mrdoob/three.js) | 119 mil | MIT | Runtime, GLSL/WebGL2, buffer e gerenciamento de shader. |
| [FastNoiseLite](https://github.com/Auburn/FastNoiseLite) | 3,5 mil | MIT | Ruído Perlin/OpenSimplex/Value e domain warp em várias linguagens, inclusive GLSL. Biblioteca de ruído, não plasma pronto. |
| [pmndrs/postprocessing](https://github.com/pmndrs/postprocessing) | 3 mil | Zlib | Composição, bloom e passes; não calcula densidade volumétrica. |
| [Shader Park Core](https://github.com/shader-park/shader-park-core) | 0,83 mil | MIT | Campos procedurais, SDF e geração de shader em 2D/3D. Excelente referência de desenho de campos. |
| [Donitzo/three.js-volume-renderer](https://github.com/Donitzo/three.js-volume-renderer) | 22 | MIT | Raymarching de volumes procedurais e dados 3D, clipping e extinção; referência pequena e específica, não engine de plasma pronta. |

**Referências complementares:** [gokayfem/shader-skills](https://github.com/gokayfem/shader-skills) (cerca de 571 estrelas; MIT) é material de estudo e não runtime; [FastNoiseLite](https://github.com/Auburn/FastNoiseLite) é especialmente útil por disponibilizar implementações GLSL e domain warp, mas deve ser comparado com o ruído já implementado antes de trocar o campo.

### 4.2 Técnicas que a implementação deve respeitar

- Densidade volumétrica em múltiplas escalas, sem domínio de ruído que deslize como textura plana.
- FBM 3D para densidade macro/micro.
- Curl noise para advecção aproximadamente incompressível das estruturas.
- Domain warping moderado, evitando que o volume perca sua estrutura.
- Remapeamento de densidade para separar núcleo, corpo e corona.
- Integração Beer–Lambert ao longo dos passos.
- Acumulação emissiva em espaço linear/HDR.
- `early ray termination` apenas quando a transmissão restante já não afetar a imagem.
- Jitter espacial estável para eliminar banding sem gerar cintilação temporal.

### 4.3 Estado do shader e alterações

O shader existente já tem ray marching com 12 passos, FBM 3D em três oitavas, curl-noise por diferenças finitas, densidade, filamentos, núcleo emissivo, corona e spill na parede de vidro. Ele já é uma arquitetura adequada para esse pequeno volume.

Nesta revisão:

- o jitter por pixel do ray marching ficou estável entre quadros;
- o envelope temporal de energia passou a ter ataque e release suaves e energia zero nas duas bordas do ciclo;
- o campo não foi aumentado de 12 para 32/64 passos sem benchmark; o shader já executa várias amostras de ruído por ponto do raio.

O FastNoiseLite foi usado como referência matemática, mas não foi incorporado porque o shader já possui sua própria implementação e uma troca de ruído sem A/B de imagem poderia mudar a aparência, aumentar o custo ou criar incompatibilidades.

### 4.4 O que ainda falta

- Perfil de qualidade medido em GPUs integradas e dispositivos móveis.
- Referência visual congelada em posições de câmera e preenchimento para validar densidade e núcleo.
- Testar se pré-computar ruído em uma pequena textura 3D reduz custo real; não assumir que textura 3D será suportada/mais rápida em todo aparelho.
- Validar a contribuição emissiva do plasma no vidro sem aumentar o brilho global.

---

## 5. Raios e microanimações internas

### 5.1 Referências mais relevantes no GitHub

A pesquisa encontrou poucos projetos especializados; por isso a seleção distingue bibliotecas com adoção alta e repositórios muito mais próximos do efeito 3D. Não se deve interpretar as cinco linhas como cinco engines prontas para integração.

| Repositório | Estrelas aprox. | Licença/stack | O que oferece e o que não oferece |
|---|---:|---|---|
| [Remotion](https://github.com/remotion-dev/remotion) | 75,7 mil | Licença do repositório precisa ser auditada antes de reutilizar código; TypeScript | Há um shader de lightning em `packages/effects`; referência de composição e brilho, não um motor de descarga 3D. |
| [PixelFX](https://github.com/patch-gg/pixelfx) | cerca de 7,1 mil | MIT; JS | Efeito `electrified`; boa referência para envelopes, faíscas e aparência, não física 3D. |
| [Spektr Lightning](https://github.com/keijiro/spektrlightning) | 0,21 mil | MIT; Unity/C# | Renderer de segmentos elétricos com necessidade de HDR/bloom; referência conceitual, não compatível diretamente com WebGL/Three.js. |
| [Lightning-VFX](https://github.com/SahilK-027/Lightning-VFX) | 46 | MIT; Three.js/GLSL | Exemplo direto no stack: raios procedurais, sparks e composição. Adoção baixa; revisar a implementação antes de reutilizar. |
| [energy-sphere](https://github.com/pawelnosko/energy-sphere) | 0 | Licença não identificada nos metadados consultados; Three.js/GLSL | Une plasma volumétrico, caminhos de raio ramificados e partículas; serve apenas como estudo exploratório, sem copiar código até esclarecer licença. |

### 5.2 Defeitos temporais identificados e corrigidos

O shader anterior tinha etapas quantizadas temporalmente para alguns caminhos/ramificações; isso alterava o caminho de forma abrupta. Também havia células de faísca que se deslocavam pela grade de hash, fazendo a identidade das partículas saltar.

Alterações V11.17:

- Os pulsos de descarga usam um envelope suave com ataque e decaimento; a energia fecha em zero nas bordas do ciclo, reduzindo popping no wrap do `fract`.
- A trajetória irregular do canal principal usa interpolação cúbica `smoothstep` entre segmentos espaciais, deixando a tangente contínua nas fronteiras dos segmentos.
- A identidade da ramificação deriva de seed espacial persistente; apenas um pequeno vento senoidal contínuo curva o ramo.
- A grade dos sparks fica fixa no espaço. Cada célula tem seed e ciclo de vida próprios, com drift suave e fade por envelope, em vez de deslizar pela grade do hash.
- O ruído de jitter do ray marching usa coordenada espacial estável.

### 5.3 O que ainda falta

- Referência visual e teste temporal em vídeo de 10–20 segundos, incluindo o fechamento completo dos ciclos.
- Conferir ramificações contra o interior do volume: nenhum raio deve atravessar vidro/limites ou sair do corpo do plasma.
- Ajustar as proporções entre core, halo e corona em DPR baixo; brilho excessivo esconde a estrutura fina.
- Não adicionar milhares de partículas. Os raios devem ser campos/curvas com número controlado de ramificações e sparks.

---

## 6. Anatomia e pele do corpo 3D

### 6.1 Top 5 de repositórios/modelos de anatomia

| Repositório | Estrelas aprox. | Licença/proveniência | Adequação |
|---|---:|---|---|
| [ashemag/human-atlas](https://github.com/ashemag/human-atlas) | 4,6 mil | Código MIT; geometria BodyParts3D 4.0 CC BY 4.0 | 2.234 malhas selecionáveis, 15 sistemas e 3.432 conceitos. É referência de catálogo/seleção/anatomia, mas é referência anatômica masculina adulta e não representa todos os corpos. |
| [MakeHuman](https://github.com/makehumancommunity/makehuman) | 1,7 mil | Verificar licença de cada asset/modelo; metadados do repositório não bastam | Base paramétrica para proporções humanas; não equivale a anatomia muscular individualizada. |
| [NVIDIA SOMA-X](https://github.com/NVlabs/SOMA-X) | 0,91 mil | Apache-2.0 para o código; modelos/backend opcionais devem ser auditados | Topologia canônica e rig comum para vários modelos, com LOD e aceleração Warp. Útil para pipeline offline, não como shader runtime. |
| [Meta MHR](https://github.com/facebookresearch/MHR) | 0,902 mil | Apache-2.0 para código; assets baixados têm condições próprias | 45 parâmetros de identidade, 204 de pose e 7 LODs; pipeline Python/PyTorch. Referência para modelagem e rig, não runtime browser do TITAN. |
| [Naver Anny](https://github.com/naver/anny) | 0,66 mil | Código Apache-2.0; dados MPFB2/FaceUnits CC0; topology SOMA Apache-2.0; SMPL-X opcional não comercial | Corpo para ampla faixa etária, topologia comum e modelos para mãos/face; útil para pipeline offline, não runtime web. |

**Referências específicas adicionais:** [JohanBellander/BodyExplorer](https://github.com/JohanBellander/BodyExplorer) (467 estruturas musculares, tendões e tecido conjuntivo, além de 201 ossos) e [organui/muscles-3d](https://github.com/organui/muscles-3d) (catálogo de músculos/tendões). São bons exemplos de cobertura, mas as fontes dos ativos anatômicos devem ser confirmadas; não significam validação clínica.

### 6.2 O que o TITAN já oferece

- Corpo procedural/base paramétrica MakeHuman.
- Geometria lofted e volumes auxiliares.
- Identificadores musculares e seleção por região.
- Duas instâncias alinhadas para comparação atual/objetivo.
- Materiais customizados e shader anatômico.
- Render on-demand, limite de pixels, recuperação de contexto e descarte de recursos.

### 6.3 Alterações implementadas

- A normal no shader de anatomia agora usa a matriz inversa-transposta do modelo, necessária para escala/transformação não uniforme.
- A luz traseira, a normal e o vetor de visão usados no termo de back-scattering agora estão todos no mesmo espaço de coordenadas mundial. Antes, havia mistura de vetor view-space com vetor/normal world-space, o que invalidava o produto escalar.
- O termo de back-scattering ganhou um perfil cromático de pele quente quando o corpo não está em holograma. No modo holográfico conserva a paleta mineral/turquesa.
- A contribuição é uma aproximação direcional leve, não um SSS de múltiplos passes/difusão no espaço de textura.

### 6.4 Limitações anatômicas que continuam abertas

1. **Não há atlas de músculos reais integrado**: as máscaras/volumes continuam agrupados por região e a resolução muscular não chega a um atlas com origens, inserções, ventres e tendões individualizados.
2. **Deformação ainda é paramétrica simplificada**: não há morfologia independente e validada para cada cabeça muscular.
3. **O corpo objetivo não é previsão fisiológica**: fórmulas e morphs visuais precisam ser distinguidos de medidas realmente observadas; não podem prometer uma transformação biológica individual.
4. **Pele sem difusão espacial completa**: não há os passes de difusão RGB e mapas de transmissão descritos pelo método clássico de NVIDIA GPU Gems.
5. **Textura procedural não é scan**: poros/noise procedurais não equivalem a microtextura de pele escaneada e calibrada.
6. **Proveniência**: qualquer ativo anatômico externo precisa de licença por dataset/asset, atribuição e compatibilidade de uso comercial examinadas antes de entrar no ZIP/app.

**Evolução recomendada:** pipeline offline que importa uma base BodyParts3D/Z-Anatomy (quando a atribuição/licença e os termos de distribuição estiverem confirmados), agrupa por estrutura, simplifica por peça com limite de erro, cria `GLB` por camada e mapeia os grupos do dataset aos IDs sem perder lado/origem/inserção. Depois, criar blendshapes regionais com medidas de controle e validação anatômica. Não colocar 2,3 milhões de triângulos no cockpit inteiro sem LOD, seleção de camadas e budget.

### 6.5 Pesquisa de pele / SSS

A referência de maior valor técnico é [GPU Gems 3 — Real-Time Skin Rendering](https://developer.nvidia.com/gpugems/gpugems3/part-iii-rendering/chapter-14-advanced-techniques-realistic-real-time-skin). O método usa difusão no espaço de textura, perfis RGB com múltiplas escalas e mapas de sombra translúcida para regiões finas. A alternativa em screen-space exige blur controlado e preservação de profundidade/normais.

O [Google Filament](https://github.com/google/filament) documenta materiais translúcidos/SSS aproximados. Ambos são referências algorítmicas; não existe justificativa para adicionar o engine inteiro ao TITAN.

---

## 7. Iluminação do corpo 3D e halo de profundidade

### 7.1 Top 5 de engines/repositórios de iluminação relevante

| Repositório | Estrelas aprox. | Licença | Utilidade |
|---|---:|---|---|
| [Three.js](https://github.com/mrdoob/three.js) | 119 mil | MIT | PMREM, luzes, materiais, renderer e shaders já integrados. |
| [React Three Fiber](https://github.com/pmndrs/react-three-fiber) | 33,7 mil | MIT | Arquitetura de scene lifecycle React; não é necessária para o controller imperativo atual. |
| [Google Filament](https://github.com/google/filament) | 20,8 mil | Apache-2.0 | Referência forte de PBR, exposição, unidades de luz, IBL, AO e SSS. |
| [PlayCanvas Engine](https://github.com/playcanvas/engine) | 17,4 mil | MIT | Pipeline WebGL2/WebGPU, clustered lighting, soft shadows e pós-processamento. |
| [Drei](https://github.com/pmndrs/drei) | 10,2 mil | MIT | Environment/softbox helpers e componentes de conveniência; a adoção de R3F seria uma camada extra sem necessidade atual. |

### 7.2 Estado e alteração na V11.17

O ZIP já não possui plinto, plano de chão, projetor inferior nem sombra de contato de chão. A cena tem um único plano de fundo com shader radial/difuso, colocado atrás do corpo. Esse halo permanece separado da luz que incide sobre a anatomia.

A revisão anterior continha luzes de cores/posições demais para o objetivo premium. V11.17 simplifica a iluminação de corpo para:

- hemisphere neutro muito baixo;
- key direcional quente-neutra;
- fill frio discreto;
- rim traseiro mineral controlado;
- softbox retangular para key e rim em hardware compatível;
- um único halo difuso atrás do corpo.

A direção principal do key no shader de anatomia foi mantida alinhada com a key direcional da cena.

### 7.3 Limites e próximas medições

- Não foi adicionado HDRI fotográfico: o projeto ainda gera o ambiente de estúdio procedural via `RoomEnvironment`/PMREM. Não confundir PMREM com HDRI comprado/baixado.
- `RectAreaLight` é removido em software GL; validar o fallback nessa classe de dispositivo.
- O halo precisa ser inspecionado em câmera frontal, perfis de rotação e em corpos atuais/objetivos sobrepostos. Um halo atrás não deve virar uma auréola visível nem contaminar as pernas.
- Depois de coletar screenshots, ajustar exposição/temperatura por material, não por filtros globais.

---

## 8. Matriz de mudanças nesta ZIP

| Área | Alteração entregue | Objetivo técnico |
|---|---|---|
| Água/gota/barra | Dither espacial estável e comentário óptico corrigido; preservar render estático existente | Eliminar grain crawl e manter repouso sem RAF contínuo |
| Vidro/metal dos macros | Render estático quando o valor não muda; interpolação do tilt com spring curto | Evitar 30 FPS sem movimento e preservar parallax do ponteiro |
| Plasma | Pulsos com envelope periódico suave e jitter de amostragem estável por interleaved-gradient noise (não uma textura blue-noise) | Reduzir popping e shimmer |
| Raios | Interpolação espacial suave, identidade de ramos persistente, grid de sparks fixo e fade/drift contínuos | Tornar as descargas mais orgânicas e temporalmente coerentes |
| Anatomia | Normal transformada com inverse-transpose; backscatter em coordenadas mundiais; cor biológica fora do holograma | Corrigir base geométrica da iluminação e dar uma resposta de pele mais coerente |
| Iluminação | Rig de estúdio suavizado, remove kicker extra; um único halo difuso traseiro; sem palco no chão | Separar corpo do fundo sem círculo/plataforma luminosa inferior |
| Qualidade | Novo gate `check-rendering-realism-v11-17.mjs` integrado ao `npm test` e comando isolado | Proteger os contratos técnicos em mudanças futuras |

## 9. Validação e limitações da entrega

Validações executadas nesta revisão:

- 12 gates de domínio/estrutura/renderização passaram: TBCA catalog, domain boundaries, design-system, fluid shaders, cockpit visual semantics, novo rendering realism V11.17, anatomy V9 lifecycle, materials V10, anatomy V.MAX, anatomy group contract, anatomy lifecycle e muscle picking occlusion.
- 9 testes de domínio sem dependências externas passaram: exercise hydration, evolution trend, profile calculation, RMR, Hall body weight, adaptive energy/Kalman, activity energy, activity reconciliation e training strength calculations.
- Todos os 200 arquivos `.ts`/`.tsx` em `src` passaram pelo parser TypeScript (0 erros de sintaxe).
- Os imports relativos e aliases `@/` dos 200 arquivos foram resolvidos (0 caminhos internos ausentes).
- 22 scripts `.mjs` passaram por `node --check` (0 erros de sintaxe).

Integridade do pacote: o ZIP atual tinha seis arquivos que não existiam na base V11.16.0 anterior e foram preservados sem alteração. Também estavam ausentes 133 arquivos de aplicação compartilhados que as telas atuais importavam; eles foram restaurados da base anterior, sem sobrescrever nenhum caminho presente no upload desta conversa.

Limitações do ambiente/arquivo:

- O repositório inclui `bun.lock` como lockfile canônico, mas o ambiente de trabalho não tem o executável Bun nem `node_modules`. `npm ci` não é aplicável porque não há `package-lock.json`; a tentativa de `npm install --package-lock=false` excedeu o limite de execução. Build e typecheck completos não foram executados nesta sessão.
- `scripts/check-dual-body-anatomy.mjs` foi iniciado com `--experimental-strip-types`, mas não avançou porque o ambiente não tem a dependência `three` instalada. Esse é um teste não concluído, não um teste aprovado.
- Não havia validador `glslangValidator` nem contexto GPU/WebGL2 funcional no ambiente para compilar/inspecionar os shaders em hardware real.
- Não foram medidos FPS/GPU time nem aprovadas capturas em celular ou desktop físico. O ganho de repouso é uma mudança estrutural no scheduler, não um benchmark numérico.

**Não declarar realismo 9,5/10 nem aprovação visual final antes de revisar screenshots reais e performance nas classes de dispositivo-alvo.**
