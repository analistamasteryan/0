# Pesquisa de repositórios e técnicas — V11.35

Snapshot de estrelas consultado em 26 nov 2026 via GitHub API. Estrelas são sinal de descoberta, não prova de rigor científico, segurança, compatibilidade ou adequação ao domínio. Licenças aqui são o identificador exibido pelo GitHub e devem ser verificadas para a versão efetivamente incorporada.

| Repositório | Estrelas | Licença | Uso técnico avaliado | Decisão para V11.35 |
|---|---:|---|---|---|
| [Microsoft TypeScript](https://github.com/microsoft/TypeScript) | 111.908 | Apache-2.0 | Checker, linguagem, tipos e compilador | Manter strict typing e typecheck dedicado; sem ferramenta concorrente |
| [Prettier](https://github.com/prettier/prettier) | 52.450 | MIT | Formatação consistente | Referência para formato; não reorganizar arquivos fora do escopo |
| [Zod](https://github.com/colinhacks/zod) | 44.423 | MIT | Schemas runtime e validação de fronteiras | Já é dependência do projeto; adotar schemas strict em fronteiras externas, sem levar Zod para todo o domínio |
| [Biome](https://github.com/biomejs/biome) | 26.216 | Apache-2.0 | Lint/formatter integrado | Candidato para análise global futura; migração não necessária neste patch |
| [Fuse.js](https://github.com/krisk/Fuse) | 20.537 | Apache-2.0 | Fuzzy/token search com pesos e workers | Pode ajudar UX de busca após hard gates; não atribui identidade nutricional |
| [Semgrep](https://github.com/semgrep/semgrep) | 17.956 | LGPL-2.1 | Análise estática e regras de variantes de bug | Pesquisado; avaliar licença separadamente antes de adoção |
| [Vitest](https://github.com/vitest-dev/vitest) | 17.459 | MIT | Testes unitários/integração | Bom fit para stack Vite; manter testes existentes sem nova dependência neste patch |
| [ast-grep](https://github.com/ast-grep/ast-grep) | 16.706 | MIT | Busca/lint/rewrite estrutural por AST | Candidato para guardrails contra caminhos que contornem elegibilidade |
| [Google OR-Tools](https://github.com/google/or-tools) | 14.459 | Apache-2.0 | CP-SAT, programação inteira e scheduling | Principal candidato para planejamento alimentar multidiário; ainda não adicionado |
| [Orama](https://github.com/oramasearch/orama) | 10.620 | NOASSERTION | Full-text, vector, hybrid, BM25, filtros e facets | Não adotar sem licença inequívoca; índice vetorial não é necessário nesta correção |
| [fast-check](https://github.com/dubzzz/fast-check) | 5.322 | MIT | Property-based testing TypeScript | Candidato para ampliar invariantes; não instalado nesta versão |
| [RapidFuzz](https://github.com/rapidfuzz/RapidFuzz) | 4.220 | MIT | Distâncias fuzzy de texto, Python | Referência para matching offline; similaridade nunca é decisão final de crosswalk |
| [Splink](https://github.com/moj-analytical-services/splink) | 2.604 | MIT | Record linkage probabilístico Fellegi–Sunter | Referência para TBCA↔USDA com múltiplos sinais, calibração e revisão humana; não é dependência runtime TS |
| [HiGHS](https://github.com/ERGO-Code/HiGHS) | 1.953 | MIT | LP/MIP/QP solver | Já existe integração HiGHS WASM; falta executar em ambiente limpo com problemas reais do motor |
| [FoodOn](https://github.com/FoodOntology/foodon) | 250 | CC-BY-4.0 | Ontologia global de alimentos naturais/processados; 40 mil+ classes | Referência semântica para crosswalk futuro; não importar ontologia inteira nem substituir `food_type` TBCA |

Estrelas e licenças consultadas diretamente pela API do GitHub em 26-11-2026; números são snapshots e podem mudar. A contagem do FoodOn é 250 e a licença exibida é CC BY 4.0. Estrelas não comprovam rigor científico, segurança ou adequação de domínio.

## Deep research aplicado a B3 / niacina equivalente

- NIH Office of Dietary Supplements/Food and Nutrition Board define 1 mg NE como 1 mg de niacina ou 60 mg de triptofano. Fonte: [Niacin — Health Professional Fact Sheet](https://ods.od.nih.gov/factsheets/Niacin-HealthProfessional/).
- FDA descreve a expressão: `mg NE = mg niacina + (mg triptofano ÷ 60)`. Fonte: [Guidance: Converting Units of Measure for Folate, Niacin, and Vitamins A, D, and E](https://www.fda.gov/media/129863/download?attachment=).
- FAO/INFOODS especifica conversão em mesma base comestível: `NIAEQ (mg/100 g EP) = NIA preformed (mg/100 g EP) + TRP (mg/100 g EP)/60`. Fonte: [FAO/INFOODS Guidelines for Converting Units](https://www.fao.org/4/i3089e/i3089e.pdf).
- O Canadian Nutrient File documenta dois caminhos quando os componentes estão na base: pré-formada + triptofano medido; ou imputation de triptofano como fração da proteína. A V11.35 deliberadamente implementa apenas o caminho medido e não adota a imputação, porque ela exige classe/fator e explicitamente seria uma estimativa, não análise do alimento. Fonte: [Canadian Nutrient File — Users Guide](https://www.canada.ca/en/health-canada/services/food-nutrition/healthy-eating/nutrient-data/canadian-nutrient-file-compilation-canadian-food-composition-data-users-guide.html).

### Crosswalk FDC usado

A validação do adaptador exige o par de identidade (ID permanente + número histórico) e rótulo (nome + unidade) para estes campos do dicionário FoodData Central:

| FDC nutrient no. | ID permanente | Nome | Unidade | Papel |
|---:|---:|---|---|---|
| 406 | 1167 | Niacin | mg | Niacina pré-formada |
| 407 | 1168 | Niacin from tryptophan, determined | mg | Equivalente já derivado do triptofano |
| 409 | 1169 | Niacin equivalent N406 +N407 | mg | Total mg NE direto |
| 501 | 1210 | Tryptophan | g | Triptofano medido, convertido para mg antes de dividir por 60 |

A referência de dicionário legível usada na revisão é a cópia do vocabulário FDC no [repositório USDA FDC MCP server](https://github.com/cyanheads/usda-mcp-server/blob/main/scripts/data/nutrient.csv); trata-se de auxílio para conferir os rótulos/IDs, não de fonte de dados nutricionais do motor nem de dependência. A fonte normativa da fórmula continua NIH/FDA/FAO citada acima.

### Regras determinísticas implantadas

1. Preferir FDC 409 validado (valor expresso diretamente em mg NE).
2. Sem 409, somar FDC 406 + 407 somente quando os dois registros tiverem ID/número/nome/unidade corretos, valores finitos e não negativos e a mesma base por 100 g.
3. Sem 407, usar FDC 406 + FDC 501: `mg NE = mg niacina + (g triptofano × 1000 / 60)`.
4. Nunca somar 407 com 501: representam duas representações da parcela derivada do triptofano, e não componentes acumuláveis.
5. Sem 406 ou sem fonte de fração de triptofano suficiente, B3 não é quantificada; os componentes disponíveis vão para quarentena sem virarem zero.
6. A evidência de derivação armazena fórmula, referência, base e os dois componentes originais. O caminho direto 409 preserva a identidade exata do nutriente; o registro runtime recalcula a derivação e recusa evidência adulterada ou origem direta não identificada.

## Deep research aplicado à elegibilidade de ingredientes TBCA

- A V11.34 já usa `food_type` da própria fonte antes do ranking de busca: `ALIMENTO` é elegível; `PREPARACAO_COMPOSTA` é excluída; ausente/desconhecido falha fechado.
- A V11.35 não muda esses dados nem relaxa o gate. Ela melhora a observabilidade: cobertura de cada micronutriente é apresentada separadamente para `ALIMENTO`, `PREPARACAO_COMPOSTA` e `UNKNOWN`.
- Similaridade fuzzy, BM25, embeddings ou LLM não podem promover uma preparação composta para ingrediente nem resolver automaticamente um alimento canônico.
- Um crosswalk TBCA↔USDA deve futuramente fazer blocking por grupo/taxonomia, parte comestível, estado/preparação e múltiplos atributos nutricionais; usar Fellegi–Sunter como triagem de pares, limiar de aceitação/conflito e revisão humana para pares ambíguos. Nome isolado não basta.

## Licença e limites das fontes

O catálogo local permanece TBCA 7.2. O portal oficial apresenta TBCA 7.3/USP-FoRC 2025 e termos de uso CC BY-NC-ND 4.0, com restrições à reprodução/alteração e indicação para contactar a coordenação em usos comerciais. Portanto, não se importou nem reempacotou a versão 7.3 neste ZIP sem autorização correspondente. Fonte: [TBCA — Portal oficial](https://www.tbca.net.br/).

Nenhum código foi copiado de repositórios pesquisados e nenhuma dependência nova foi adicionada. As escolhas priorizam contratos de fonte explícitos e invariantes de domínio sobre aumento de stack.


## Deep search: arquitetura técnica avançada por lacuna do motor

Esta seção traduz pesquisa metodológica e repositórios em decisões de engenharia. Os termos são pistas de implementação e critérios de aceite; não significam que os módulos abaixo já estejam implantados.

### 1. Correspondência de alimentos entre TBCA, USDA e outras fontes

**Problema real:** dois nomes parecidos podem designar itens diferentes; dois nomes diferentes podem designar o mesmo alimento com origem, parte, processamento, estado ou preparo distintos. Uma correspondência de alimento cru não pode preencher automaticamente um prato composto, e a classificação oficial de `PREPARACAO_COMPOSTA` nunca é anulada pela similaridade lexical.

**Stack/termos recomendados:**
- `food entity resolution`, `record linkage`, `Fellegi–Sunter`, `m/u probabilities`, `term-frequency adjustment`, `blocking` e `candidate generation`.
- `LanguaL faceted food description`: product type, food source, part of plant/animal, physical state/form, heat treatment, cooking method, treatment, preservation, packing medium, dietary use e geografia.
- `FoodOn` como referência semântica global de alimento natural e processado; mapear por URI/curie e guardar versão da ontologia. FoodOn tem licença CC BY 4.0 e 250 estrelas na consulta de 26-11-2026; não representa uma licença automática para TBCA nem deve substituir o campo oficial `food_type`.
- `source-aware canonicalization`, `immutable source identifiers`, `explainable matching`, `review queue`, `decision provenance`, `active learning` e `precision/recall operating points`.

**Pipeline proposto (offline primeiro):**
1. Normalizar acentos, caixa, pontuação e sinônimos sem apagar os tokens informativos; guardar sempre descrição original.
2. Aplicar hard gates antes de gerar candidatos: classe simples vs composta, origem vegetal/animal, espécie quando disponível, parte anatômica, porção comestível, cru/cozido, método de cocção, preservação e ingredientes adicionados.
3. Fazer `blocking` por classe + fonte/grupo taxonômico + parte + estado/preparo; não comparar todos os pares quadráticamente.
4. Rankear pares com atributos independentes (descrição normalizada, taxonomia, parte, estado, processamento, macros, nutrientes selecionados e unidade-base). Similaridade lexical isolada não pode aprovar par.
5. Usar Splink/Fellegi–Sunter como experimento offline quando houver colunas independentes e exemplos rotulados; medir precisão/recall por classe e definir faixa de aceitação automática alta, faixa de revisão e faixa de rejeição. O algoritmo de probabilidade nunca sobrepõe os gates semânticos.
6. Persistir decisão, fontes, campos comparados, pesos/versão do modelo, score, faixa, revisor e motivo de rejeição.

**Critério de produção:** precisão por grupo de alimento, auditoria de falsos positivos e cobertura de revisão humana. Não realizar `merge` de IDs de fontes; cada fonte conserva ID e proveniência.

Referências: [FAO/INFOODS Food Matching Guidelines v1.2](https://www.fao.org/fileadmin/templates/food_composition/documents/upload/INFOODSGuidelinesforFoodMatching_version_1_2.pdf), [LanguaL facets — FAO](https://www.fao.org/fileadmin/templates/food_composition/documents/Presentations/Food_Composition_-_Food_nomenclature_in_food_composition_database.pdf), [LanguaL Introduction](https://www.langual.org/download/Langual2008WS/LanguaL%202008%20reports/LanguaL%202008%20Introduction.pdf), [FoodOn — OBO Foundry](https://obofoundry.org/ontology/foodon), [Splink](https://github.com/moj-analytical-services/splink).

### 2. Proteção de ingredientes e receitas compostas

**Regra de domínio já implementada em V11.34/V11.35:** apenas TBCA `ALIMENTO` pode participar da montagem/substituição de ingrediente; `PREPARACAO_COMPOSTA` e `UNKNOWN` são inelegíveis. Busca geral e diário alimentar continuam podendo exibir preparações compostas.

**Termos/guardrails para manter:** `closed-world enum`, `fail-closed classification`, `semantic type constraint`, `defense in depth`, `application-level invariant`, `store command validation`, `recipe graph integrity`, `non-transitive eligibility`.

A classificação `food_type` da fonte é o sinal autoritativo. Não classificar por palavras-chave (`molho`, `salada`, `bolo`), pois um alimento unitário pode ter nome de prato e um composto pode ter nome curto. A elegibilidade não é inferida a partir de search score, embeddings ou LLM. Guardar uma projeção derivada `ingredient_eligibility` apenas se ela for determinística e rastreável à enumeração original.

**Critério de produção:** testes garantem bloqueio na pesquisa, seletor, API/application command, store e substituição. Tentativas por ID direto também devem falhar. Registros históricos permanecem acessíveis, mas não se tornam candidatos a novas receitas.

### 3. Receita calculada, rendimento e retenção verdadeira

**Evitar:** copiar o valor por 100 g de um alimento cru diretamente para uma preparação cozida, ou usar rendimento como se fosse retenção de micronutriente.

**Stack/termos:** `recipe composition graph`, `edible-portion (EP)`, `yield factor (YF)`, `true retention factor (TRF)`, `mass balance`, `process-aware nutrient transformation`, `method-of-preparation ontology`, `uncertainty propagation`, `analytical vs calculated quality grade`.

- YF representa quanto peso final resta após preparação/cocção; TRF representa quanto do nutriente foi retido. São dimensões distintas.
- A fórmula de retenção verdadeira de USDA usa peso e concentração antes/depois: `%TR = (nutriente/g cozido × g cozido)/(nutriente/g cru × g cru) × 100`.
- Uma forma típica de calcular densidade final por 100 g é `N_cozido = N_cru × RF / YF`, desde que RF e YF usem as convenções de porcentagem corretas e a mesma definição de peso. A implementação deve formalizar se os fatores estão em escala 0–1 ou 0–100, não inferir.
- Armazenar por ingrediente: quantidade bruta, parte comestível, perdas/refugo, água/gordura adicionada ou perdida, método, tempo, temperatura, lote/fonte do fator e base. O prato calculado é um nó diferente, nunca um alimento simples.
- Fatores de retenção/yield devem ser específicos ao nutriente, alimento, processo e método regional; fator ausente implica estimativa parcial ou `indeterminate`, não retenção presumida de 100%.
- Marcar origem `analytical`, `calculated_recipe`, `borrowed_food_match` ou `label`; manter nível de qualidade/confiança e incerteza.

**Critério de produção:** balanço de massa consistente, fatores versionados e validados por exemplos publicados; comparar resultados calculados com receitas analisadas em laboratório; nunca substituir a fonte analítica original.

Referências: [FAO Food Matching Guidelines](https://www.fao.org/fileadmin/templates/food_composition/documents/upload/INFOODSGuidelinesforFoodMatching_version_1_2.pdf), [USDA True Retention Method](https://www.ars.usda.gov/ARSUserFiles/80400535/Data/retn/retn06.pdf), [USDA SR11 cooked food formula](https://www.ars.usda.gov/ARSUserFiles/80400525/Data/SR11/sr11_doc.pdf), [FAO Food Composition Data — preparation metadata](https://www.fao.org/4/y4705e/y4705e10.htm), [USDA Food Buying Guide yield tables](https://foodbuyingguide.fns.usda.gov/appendix/downloadfbg).

### 4. Qualidade de proteína e DIAAS

**Stack/termos:** `digestible indispensable amino acid score`, `true ileal amino-acid digestibility`, `amino-acid-specific coefficients`, `scoring pattern by life stage`, `reactive lysine`, `hydrolysis/analytical method provenance`, `species hierarchy`, `limiting indispensable amino acid`.

- O cálculo requer perfil dos aminoácidos indispensáveis no alimento teste, digestibilidade ileal verdadeira por aminoácido e padrão de referência da fase de vida. Para cada aminoácido indispensável `i`, `DIAA_i (mg/g proteína) = AA_i (mg/g proteína) × digestibilidade ileal_i`; `DIAAS (%) = 100 × min_i[DIAA_i / padrão de referência_i]`. O mínimo identifica o aminoácido limitante; a versão do padrão por fase de vida precisa ser parte do resultado.
- Dados humanos são preferíveis; a metodologia regulatória canadense publicada em 22-10-2026 usa hierarquia de fallback a suínos em crescimento e depois ratos em crescimento, se humanos não forem viáveis. Se não houver digestibilidade específica por AA, proteína ileal verdadeira e, por último, proteína fecal verdadeira podem ser usadas como alternativas menos específicas, claramente sinalizadas como fallback e não como o mesmo nível de evidência.
- Alimentos processados suscetíveis a dano térmico precisam de lisina reativa, não automaticamente lisina total.
- A evidência de digestibilidade deve especificar alimento/matriz, método, espécie, estágio de vida, preparo/processamento, tamanho da amostra e referência. Não reutilizar coeficiente de matéria-prima em isolado, extrusado ou assado sem justificativa.
- Se faltar aminoácido indispensável ou digestibilidade compatível, retornar `insufficient_data`, não um score parcial apresentado como DIAAS.

**Critério de produção:** reproduzir exemplos oficiais, validar unidades (mg/g proteína), identificar aminoácido limitante, versionar os padrões por idade/fase de vida e mostrar o grau de evidência.

Referências: [Health Canada DIAAS methodology, 22-10-2026](https://www.canada.ca/en/health-canada/services/food-nutrition/legislation-guidelines/acts-regulations/notices-proposal-notices-modification/table-chemical-physical-nutritional-characteristics-food-pcpn-2607/determination-protein-rating-diaas.html), [FAO protein quality consultation](https://www.fao.org/3/i3124e/i3124e.pdf).

### 5. UL, RDA/DRI e exposição por fonte

**Stack/termos:** `chemical-species normalization`, `source-specific exposure scope`, `chronic usual intake`, `dose aggregation`, `bioavailability`, `fortificant vs intrinsic nutrient`, `medication/supplement reconciliation`, `life-stage stratification`, `uncertainty bounds`.

Um UL pode abranger o total crônico de fontes alimentares e suplementos, mas a definição pode restringir formas químicas ou fontes específicas. Modelar a regra por nutriente com escopo explícito de forma química, alimento natural, alimento fortificado, bebida/água, suplemento e medicamento. Não usar uma soma universal de todas as formas nem assumir que o UL de uma forma se aplica automaticamente a outra.

O estado da avaliação deve distinguir `below`, `near`, `above`, `indeterminate` e `not_assessed`; falta de informação não pode ser considerada segurança nem zero. O registro da recomendação guarda autoridade, jurisdição, população/fase de vida, idade, data/versão, unidade, período crônico e fontes contabilizadas.

**Critério de produção:** para cada nutriente, testes de inclusão/exclusão por fonte/forma, ingestão crônica e subpopulação; quando o histórico de suplemento, fortificação ou forma estiver desconhecido, exibir `indeterminate`.

Referências: [EFSA UL guidance 2024](https://doi.org/10.2903/j.efsa.2024.9052), [National Academies DRI overview](https://www.ncbi.nlm.nih.gov/books/NBK114332/).

### 6. Gasto energético de treino e adaptação de TDEE

**Stack/termos:** `state-space model`, `Kalman filter`, `robust residual`, `measurement error`, `Bayesian updating`, `posterior predictive interval`, `double-count prevention`, `net vs gross exercise energy`, `N-of-1 calibration`.

O motor já contém atualização adaptativa Kalman e simulações sintéticas; o que falta é histórico longitudinal real e validação externa. O estado persistido deve separar TDEE basal esperado, ingestão registrada, peso observado, retenção hídrica/ruído, gasto de sessão bruto/líquido e confiança da estimativa. A sessão não deve ser somada duas vezes se a equação de TDEE já inclui atividade média. Usar resíduos robustos/outlier handling e intervalos, não atualizar como verdade a partir de uma única pesagem.

Uma revisão de escopo de 166 estudos encontrou grande heterogeneidade; calorimetria indireta é predominante, mas não capta adequadamente a contribuição glicolítica isoladamente. Calorimetria junto com lactato pode melhorar a estimativa laboratorial; MET é uma opção de campo mais prática, com incerteza explicitada.

**Critério de produção:** estudos N-of-1 com protocolo, manutenção de unidade temporal e sinais de peso/ingestão, calibração por indivíduo, interval coverage e análise de viés; não declarar estimativa de kcal de musculação como medida direta.

Referência: [2024 scoping review — 166 studies](https://link.springer.com/article/10.1007/s40279-024-02047-8).

### 7. Planejamento alimentar 7/14/28 dias

**Stack/termos:** `CP-SAT`, `MILP/MIP`, `lexicographic multi-objective optimization`, `hard/soft constraints`, `meal-slot assignment`, `ingredient quantity variables`, `weekly frequency constraints`, `variety penalties`, `budget/inventory`, `meal-prep batching`, `infeasibility explanation`, `Pareto frontier`.

- Variáveis binárias para escolher receitas por dia/refeição e contínuas para porções/quantidades.
- Restrições duras: alergias/intolerâncias declaradas, alimentos indisponíveis, limites operacionais, compatibilidade de ingrediente, energia/macro dentro de tolerância configurada.
- Restrições suaves: custo, variedade, frequência de ingredientes, preferência, repetição e conveniência; resolver em objetivos lexicográficos em vez de um único score que permita violar segurança em troca de conveniência.
- CP-SAT/OR-Tools é o candidato principal se scheduling e decisões inteiras dominarem; HiGHS já presente no projeto atende LP/MIP, desde que variáveis/solver suportem a formulação. Benchmark dos dois com instâncias reais antes de migrar.
- Quando inviável, explicar conflitos mínimos (IIS/unsat core quando suportado) e quais limites precisariam mudar; nunca silenciosamente relaxar alergias ou máximos.

**Critério de produção:** benchmarks 7/14/28 dias com seed reproducible, teto de tempo, estabilidade e gap de otimalidade, solução viável, explicação de inviabilidade e regressões de segurança; teste WASM real e browser.

Referências: [OR-Tools](https://github.com/google/or-tools), [HiGHS](https://github.com/ERGO-Code/HiGHS).

### 8. Engenharia de qualidade e segurança de alterações

**Stack/termos:** `strict TypeScript`, `exhaustive discriminated unions`, `Zod strict schemas`, `property-based testing`, `model-based testing`, `AST-based lint rules`, `taint boundaries`, `mutation testing`, `golden fixtures`, `differential tests`, `reproducible builds`.

- Zod já existe no projeto: centralizar schema de entrada externa/importações e usar parse estrito com `safeParse`, sem acoplar domínio à biblioteca em todas as entidades.
- `fast-check` pode gerar valores extremos, combinações de nutrientes, duplicatas, unidades e mudanças de ordem para propriedades invariantes; adicionar só se custo e instalação forem aprovados.
- `ast-grep` pode bloquear padrões estruturais proibidos (p.ex., um caminho de receita que chama busca geral sem filtro de elegibilidade); começar com regras pontuais em CI, não uma plataforma paralela.
- `Semgrep` tem regras de variante de bug poderosas, mas a licença LGPL-2.1 requer revisão antes de adoção embutida; execução de CLI externa pode ser diferente de incorporar código.
- `Biome` é candidato a formatter/linter futuro, não substituir TypeScript compiler nem misturar migração de style com correção nutricional.
- Nenhuma alteração pode promover missing/trace/invalid a zero; `status`, `normalized_unit`, `basis_quantity`, `source_version` e proveniência precisam sobreviver a serialização/hidratação.

**Critério de produção:** typecheck, tests, lint, build, property-based invariants, mutation score nos gates críticos e CI em instalação limpa por lockfile. Repositórios pesquisados são referências; nenhum código foi copiado ou novo pacote adicionado nesta versão.

---

## Fontes metodológicas adicionais

- [FAO/INFOODS food matching quality levels A–D and recipe calculation guidance](https://www.fao.org/fileadmin/templates/food_composition/documents/upload/INFOODSGuidelinesforFoodMatching_version_1_2.pdf)
- [FAO description of single vs mixed foods and ingredient lists](https://www.fao.org/4/AD069E/AD069E00.htm)
- [FAO food descriptors and metadata](https://www.fao.org/4/y4705e/y4705e08.htm)
- [FAO sample preparation fields: cooking method, time, temperature, before/after cooking weight, added ingredients](https://www.fao.org/4/y4705e/y4705e10.htm)
- [EFSA 2024 UL assessment guidance](https://doi.org/10.2903/j.efsa.2024.9052)
- [National Academies examples of nutrient-specific UL scope](https://www.ncbi.nlm.nih.gov/books/NBK114332/)
- [NIH ODS Niacin fact sheet](https://ods.od.nih.gov/factsheets/Niacin-HealthProfessional/)
- [USDA 2026 Food Buying Guide yield table update dates](https://foodbuyingguide.fns.usda.gov/appendix/downloadfbg)
