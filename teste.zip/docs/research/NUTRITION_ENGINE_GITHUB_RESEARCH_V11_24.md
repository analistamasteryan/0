# Pesquisa GitHub — motor nutricional V11.24

**Snapshot consultado:** 25/11/2026. Estrelas são uma medida de adoção, não de validade científica. A pesquisa foi usada para padrões de produto, integridade de dados, cálculo de receitas e otimização; nenhum código de terceiros foi copiado para o TITAN.

| Repositório | Estrelas | Licença declarada | Evidência inspecionada | Decisão para TITAN |
|---|---:|---|---|---|
| [Google OR-Tools](https://github.com/google/or-tools) | 14.457 | Apache-2.0 | CP-SAT, LP, MIP, knapsack e MathOpt; MathOpt suporta variáveis inteiras/contínuas e objetivos/restrições quadráticos | Melhor referência de solver combinatório geral; não substituir HiGHS no app atual: core C++ e wrappers oficiais Python/C#/Java, sem integração TypeScript/browser direta simples. Considerar só se seleção discreta futura justificar um worker/backend dedicado |
| [Calories-In](https://github.com/vangelov/calories-in) | 187 | MIT | React/TypeScript; `getStatsTree` agrega ingredientes → refeições → plano; lista virtualizada e exportação em worker via Comlink | Referência de UI/estado derivado e agregação hierárquica; último push em 2023, não usar como base nem copiar código |
| [Mealie](https://github.com/mealie-recipes/mealie) | 13.989 | AGPL-3.0 | `MealPlanScaleControl.vue` delega o ajuste de porções ao controle de escala de receita; separa o scale state do payload da refeição | Referência de UX para escala/rendimento, não usar como motor de kcal nem copiar código |
| [Tandoor Recipes](https://github.com/TandoorRecipes/recipes) | 8.747 | `NOASSERTION` no endpoint de metadados consultado | Modelos de receita, ingredientes, servings, meal plan e unidades; modelagem relacional madura | Referência de domínio; não adotar código sem esclarecer licença |
| [wger](https://github.com/wger-project/wger) | 7.324 | AGPL-3.0 | `wger/nutrition/dataclasses.py` valida energia/macros, quantidades, gorduras saturadas, açúcares e coerência de rótulos | Referência de validação e sanidade de dados, não importar servidor/plataforma |
| [OpenNutriTracker](https://github.com/simonoppowa/OpenNutriTracker) | 3.029 | GPL-3.0 | `compute_recipe_nutrition_usecase.dart` acumula nutrientes em uma passagem e preserva `null` quando nenhum ingrediente tem dado; `docs/tdee-iom-2005-verification.md` documenta revisão de equação e teste de regressão | Padrão adotado conceitualmente: uma passagem e ausência não vira zero. A auditoria de equações reforça golden tests. Não copiar código |
| [HiGHS](https://github.com/ERGO-Code/HiGHS) | 1.952 | MIT | LP, QP convexa, MIP; engine já utilizada no TITAN | Manter o motor existente; melhorar diagnóstico e gates de qualidade, sem trocar solver |
| [Open Food Facts Server](https://github.com/openfoodfacts/openfoodfacts-server) | 1.219 | AGPL-3.0 | API, dados de produto, alergênicos, rótulos e qualidade comunitária | Usar documentação/API conforme termos; não incorporar servidor |
| [FoodYou](https://github.com/maksimowiczm/FoodYou) | 633 | GPL-3.0 | Fluxos de diário, bases OFF/USDA/Swiss, receitas e persistência local | Referência de integração local-first; sem dependência ou código copiado |

## Repositório de otimização nutricional com recursos interessantes, mas não adotado

[llmn / eastokes/diet-optimization](https://github.com/eastokes/diet-optimization) declara QP para metas de kcal/macros/micros, limites por alimento, custo, multi-período por refeição, diagnóstico de inviabilidade e TDEE adaptativo. No snapshot consultado, `eastokes/diet-optimization` tinha 0 estrelas e nenhum identificador de licença declarado; o README aponta para `ddarmon/llmn`, que tinha 2 estrelas e também sem licença declarada no endpoint. Foi inspecionado como lista de funcionalidades, mas não é dependência nem base de implementação. Antes de qualquer uso futuro, seria necessário verificar autoria, licença, testes, equações e qualidade dos dados. As funcionalidades que faltam no TITAN não devem ser copiadas de um repositório sem licença clara.

## Descobertas que mudaram o código

### 1. Escala de refeição e receita

Mealie confirma um padrão simples e útil: o usuário altera o rendimento/escala da receita por uma interface própria. O TITAN já tinha `applyYieldScaleToRecipe`, `ProportionRail` e `targetServings`, mas o target calórico por refeição não tinha uma operação dedicada que aplicasse um multiplicador comum a todos os ingredientes. A V11.24 preenche essa lacuna com `scaleDayPlanProportionallyToMealTargets`, mantendo o QP/MILP como modo distinto para alterações seletivas.

### 2. Sanidade de dados nutricionais

wger implementa verificações como:
- energia informada comparada à energia estimada por macros, fibra e fatores específicos;
- gordura saturada não superior à gordura total;
- açúcar não superior a carboidratos;
- valores de nutrientes não negativos e finitos;
- limites de plausibilidade para composição de 100 g.

O TITAN não copia um teste rígido de energia 4/4/9, pois fatores específicos, fibra, polióis, álcool, método de energia e bases diferentes podem gerar divergência legítima. A próxima etapa recomendada é um **relatório de anomalias** com tolerâncias por fonte, sem sobrescrever os valores originais nem rejeitar alimentos automaticamente.

### 3. Agregação de micronutrientes

OpenNutriTracker usa acumulação em uma passagem e mantém o valor nulo quando todos os ingredientes não têm aquele nutriente. A V11.24 expande o composer para todos os 23 micronutrientes, guarda status por nutriente e preserva traço, não analisado e ausente. Um valor parcial com uma ou mais fontes quantificadas não deve ser interpretado como cobertura completa; os contadores e a cobertura global permanecem disponíveis.

### 4. Otimização

HiGHS permanece apropriado para QP/MIP. O problema do TITAN não era falta de solver: era qualidade da entrada e metas por refeição parcialmente fechadas. A V11.24 bloqueia restrições de P/C/G por refeição se o conjunto não soma 100% e rebaixa a proposta a `approximate` quando há alimentos sem composição/quantidade completa ou com baixa confiança.

## Pesquisa científica versus popularidade

Nenhum desses repositórios substitui estudos com calorimetria indireta, DLW ou métodos de referência de composição corporal. O motor mantém NASEM 2023 como baseline populacional, Hall 2011 como modelo dinâmico, e o TDEE adaptativo como candidato de personalização após dados suficientes. O código de repositórios populares não foi tratado como evidência fisiológica.

Referências metodológicas:
- NASEM 2023 Energy DRI: https://doi.org/10.17226/26818
- NASEM 2019 Sodium/Potassium DRI: https://doi.org/10.17226/25353
- FAO DIAAS report (2013): https://www.fao.org/4/i3124e/i3124e.pdf

## Correção adicional de referência DRI — sódio

A referência adulta agora mantém a AI de 1.500 mg/d e o CDRR de 2.300 mg/d em campos distintos. O CDRR não é um UL; ingerir acima da AI mas abaixo do CDRR não é mostrado como exceder um limite, e ficar abaixo da AI não é rotulado como deficiência. Fonte: NASEM 2019 Sodium and Potassium DRI, DOI https://doi.org/10.17226/25353.
