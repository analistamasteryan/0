# Nutrition Engine — GitHub research V11.25

**Snapshot:** 25 Nov 2026 (GitHub API `stargazers_count` and `pushed_at`). Stars are a popularity signal, not evidence of scientific validity.

## Repositories by capability

| Capability | Repository | Stars | License detected | Relevant evidence | Decision |
|---|---|---:|---|---|---|
| General optimization | [google/or-tools](https://github.com/google/or-tools) | 14,457 | Apache-2.0 | Operations research toolkit; includes classic Stigler diet LP sample | Keep as reference for future CP-SAT/discrete scheduling; not a drop-in convex QP replacement for the current browser HiGHS model |
| Meal planning and recipe scaling | [mealie-recipes/mealie](https://github.com/mealie-recipes/mealie) | 13,992 | AGPL-3.0 | Recipe/meal-plan scaling, serving count, debounced scale persistence | Reuse UX patterns only; do not copy AGPL code into TITAN |
| Scientific/numeric optimization | [scipy/scipy](https://github.com/scipy/scipy) | 15,254 | BSD-3-Clause | Broad numerical algorithms and optimization primitives | Python stack; not a browser/TypeScript dependency candidate |
| Household recipes and meal planning | [grocy/grocy](https://github.com/grocy/grocy) | 9,708 | MIT | Recipe quantities, unit conversions, meal plans, stock-aware ingredient handling | Useful domain patterns; not a nutrition calculation engine |
| Recipe planning | [TandoorRecipes/recipes](https://github.com/TandoorRecipes/recipes) | 8,748 | NOASSERTION | Recipe management, meal planning, shopping lists | No license detected by GitHub; no code reuse until license is verified |
| Fitness and nutrition | [wger-project/wger](https://github.com/wger-project/wger) | 7,325 | AGPL-3.0 | Food/ingredient contracts, recipe portions and import sanity checks | Used as a validation-design reference only; no AGPL code copied |
| Convex optimization | [cvxpy/cvxpy](https://github.com/cvxpy/cvxpy) | 6,401 | Apache-2.0 | Declarative convex optimization | Python-centric; not a drop-in browser solver |
| Nutrition tracking | [simonoppowa/OpenNutriTracker](https://github.com/simonoppowa/OpenNutriTracker) | 3,033 | GPL-3.0 | Recipe nutrition aggregation, null-preserving nutrient coverage, source citations | Reference for single-pass aggregation and unknown-value semantics; no GPL code copied |
| QP optimization | [osqp/osqp](https://github.com/osqp/osqp) | 2,233 | Apache-2.0 | Convex QP solver | Strong future candidate for QP benchmarking; no MIP replacement and not adopted because HiGHS already serves browser QP/MIP |
| Current solver | [ERGO-Code/HiGHS](https://github.com/ERGO-Code/HiGHS) | 1,952 | MIT | LP, convex QP and MIP; current TITAN integration uses WASM | Keep; its capability and browser fit matter more than star count |
| Food data and API | [openfoodfacts/openfoodfacts-server](https://github.com/openfoodfacts/openfoodfacts-server) | 1,219 | AGPL-3.0 | Open product data and API server | Consume permitted API/data interfaces; do not embed AGPL server code. Data license must be checked separately from server license |
| Meal editor | [vangelov/calories-in](https://github.com/vangelov/calories-in) | 187 | MIT | Desktop meal-plan editor, ingredient stats tree and Web Worker export | Low popularity and last push in 2023; inspect patterns only, no dependency adoption |
| Multi-period diet optimization | [eastokes/diet-optimization](https://github.com/eastokes/diet-optimization) | 0 | NOASSERTION | Per-meal calorie/nutrient constraints, daily linking constraints, affinity rules and infeasibility diagnosis | Directly relevant design reference, but no license detected and no external validation; do not copy code or adopt as a dependency |

## Code-level findings

### Recipe scaling

- Mealie `frontend/app/composables/use-mealplan-scale.ts` treats a recipe scale as an editable draft, derives servings from the recipe, debounces persistence, flushes on scope disposal and avoids overwriting a pending edit with a stale server refresh.
- TITAN's explicit proportional action remains separate from this autosave pattern. TITAN preserves locked ingredients, applies a common factor to the quantifiable unlocked ingredients in a meal, respects bounds, and can undo. Do not add debounce or implicit autosave to the calculation itself.
- Grocy's recipe service shows why unit conversion and recipe yield are distinct from raw grams. TITAN still needs density-aware volume-to-mass conversion and cooking yield/retention factors; do not assume 1 ml = 1 g for every ingredient.

### Food-data validation

- wger's `wger/nutrition/dataclasses.py` checks finite/nonnegative energy and nutrient fields, rejects implausible macro mass above 105 g per 100 g, checks saturated fat against total fat, and treats energy-vs-macro mismatch with tolerance.
- TITAN V11.25 adopts the structural checks as a local validator. The simple Atwater comparison is warning-only because food-specific Atwater factors, fiber definitions and source methods differ. Unknown nutrient values remain unknown.
- This check found a real source anomaly in TBCA 7.2 record `BRC1144B` (Cogumelo refogado): 219 g carbohydrate per 100 g. TITAN does not guess whether the intended value was 21.9, 2.19 or something else. The record is quarantined from macro calculations and selectable food search until corrected against the authoritative TBCA record.

### Nutrient aggregation and optimization

- OpenNutriTracker's `compute_recipe_nutrition_usecase.dart` uses a single-pass accumulator and preserves `null` when no ingredient has a value for a nutrient. TITAN already tracks 23 nutrient IDs with `quantified`, `trace`, `not_analyzed` and `missing`; preserve this semantic contract.
- The `eastokes/diet-optimization` prototype builds a multi-period QP with per-meal constraints and daily linking constraints, and runs an infeasibility diagnosis when constraints cannot be satisfied. This is the most directly relevant architecture pattern found for the future nutrient-constrained meal solver, but the repository has 0 stars, no detected license, and no independent validation. Treat it as an idea, not as trusted code.
- OR-Tools' Stigler diet example is a linear programming example, not proof of suitability for TITAN's convex QP objective. HiGHS remains the current browser-compatible LP/QP/MIP solver.

## Adoption decisions

1. **No new runtime dependency.** Keep the current TypeScript/React/Zustand and HiGHS WASM architecture.
2. **No direct third-party code copied.** AGPL/GPL/NOASSERTION repositories are reference-only; MIT/Apache/BSD licenses also require attribution and review before any code reuse.
3. **Do not rank by stars alone.** OR-Tools and SciPy have more stars than HiGHS, but their interfaces and problem classes do not replace the current browser QP/MIP path.
4. **Next optimization milestone:** define nutrient constraints as typed per-nutrient min/max/target with explicit unit, reference kind, coverage and time horizon; add infeasibility diagnostics; never turn missing nutrient data into zero or claim optimality if a required constraint is unsupported.
5. **Next recipe milestone:** implement ingredient-specific unit density, raw/cooked state, yield and nutrient-retention metadata with source/version and uncertainty; avoid universal conversion factors.

## Primary source links

- [NASEM 2023 DRI for Energy](https://doi.org/10.17226/26818)
- [Hall et al. 2011 dynamic body-weight model](https://doi.org/10.1016/S0140-6736(11)60812-X)
- [FAO 2013 protein quality / DIAAS](https://www.fao.org/4/i3124e/i3124e.pdf)
- [USDA FoodData Central downloads](https://fdc.nal.usda.gov/download-datasets/)
- [TBCA official portal](https://www.tbca.net.br/index.html)
