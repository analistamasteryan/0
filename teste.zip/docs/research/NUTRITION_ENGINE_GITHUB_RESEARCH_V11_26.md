# TITAN Nutrition Engine — GitHub research and technical decisions (2026-11-25)

## Selection method

GitHub repository metadata and selected source files were inspected on 2026-11-25. Star counts are repository popularity signals only, not evidence of nutrition validity, data quality, or clinical safety. Projects were considered for optimizer mathematics, meal/recipe scaling, food data validation, and amino-acid/protein quality. No third-party source code or food dataset was copied into TITAN.

## Relevant repositories (snapshot)

| Repository | Stars (approx.) | License metadata | Useful capability | Decision for TITAN |
|---|---:|---|---|---|
| `scipy/scipy` | 15,256 | BSD-3-Clause | Mature scientific optimization/numerical methods | Reference only; Python runtime is not a browser TypeScript drop-in |
| `google/or-tools` | 14,457 | Apache-2.0 | Linear programming, integer and constraint optimization; includes Stigler diet example | Algorithmic reference; C++/Python/Java/C# bindings would add a different runtime and deployment burden |
| `mealie-recipes/mealie` | 13,992 | AGPL-3.0 | Recipe and meal-plan scale UX | Reference only; do not import AGPL code |
| `grocy/grocy` | 9,708 | MIT | Recipe quantities and explicit unit conversions | Reference only; unit conversion behavior is useful, but source PHP code is not needed |
| `TandoorRecipes/recipes` | 8,749 | NOASSERTION | Meal planning, recipe serving scale, grocery management | Reference only; no license assertion means no code reuse |
| `wger-project/wger` | 7,325 | AGPL-3.0 | Nutrition models and sanity checks for macro mass/composition | Reference only; no AGPL import |
| `cvxpy/cvxpy` | 6,401 | Apache-2.0 | Declarative convex optimization formulation | Mathematical reference; Python model layer is not a browser dependency |
| `simonoppowa/OpenNutriTracker` | 3,033 | GPL-3.0 | Nutrient aggregation, food snapshots, incomplete-record repair | Reference only; no GPL import |
| `osqp/osqp` | 2,233 | Apache-2.0 | Convex QP solver | Consider only if existing solver becomes inadequate; no replacement needed now |
| `ERGO-Code/HiGHS` | 1,952 | MIT | LP/QP optimization backend already used by TITAN | Retained; existing WASM architecture is the appropriate integration path |
| `openfoodfacts/openfoodfacts-server` | 1,219 | AGPL-3.0 | Food-product data/API ecosystem | Data/provider reference; separate data license and completeness requirements remain |
| `qpsolvers/qpsolvers` | 764 | LGPL-3.0 | Python QP solver adapter | Reference only; adds Python/LGPL concerns without replacing HiGHS |
| `vangelov/calories-in` | 187 | MIT | Food → meal → plan totals and meal-prep composition | Limited reference; existing TITAN domain model is richer |
| `DerekGloudemans/Nutrition-Optimization-New` | 21 | NOASSERTION | Basic linear diet optimizer | Too small/old/unlicensed to reuse |
| `josh-minch/spartan` | 11 | NOASSERTION | Nutritionally complete diet optimization | Too small/old/unlicensed to reuse |
| `diaas-calculator/diaas-calculator-angular` | 3 | LGPL-2.1 | DIAAS explanatory calculator | Useful concept reference, not enough to source amino-acid-specific ileal digestibility values |
| `ddarmon/llmn` | 2 | NOASSERTION | Multi-period meal optimization, nutrient constraint diagnosis, adaptive TDEE ideas | Useful design reference; no code copied because license metadata is absent and Python stack differs |

## Files inspected

- OR-Tools `ortools/linear_solver/samples/stigler_diet.py`: linear diet constraints and nutrient matrix formulation.
- Mealie `frontend/app/composables/use-mealplan-scale.ts`: debounced recipe-scale editing and safe persistence behavior.
- Grocy `services/RecipesService.php`: recipe unit resolution and quantity conversion patterns.
- wger `wger/nutrition/dataclasses.py`: sanity checks preventing implausible macro mass values.
- OpenNutriTracker `lib/core/utils/off_micronutrient_repair.dart`: source-backed micronutrient repair and recomputation when an underlying ingredient record is fixed.
- llmn `multiperiod_solver.py`, `multiperiod_constraints.py`, and `multiperiod_models.py`: daily linking constraints, meal-specific targets, bounds, and infeasibility diagnosis. It is algorithmically relevant but its project is not a browser-ready TypeScript package.

## Code and architecture decisions

1. Keep TITAN's TypeScript/React domain, HiGHS WASM, and TypeScript fallback. Do not add Python, OR-Tools, CVXPY, OSQP, or a second solver engine just for star count.
2. In V11.26, the composer prepares daily DRI nutrient constraints only for day-scope optimization and only where every positive ingredient is fully quantified in the exact DRI unit. RDA/AI and CDRR are soft goals; actual total-intake ULs are hard limits.
3. Unknown, trace, missing, or mismatched-unit values never become zero. The optimizer excludes that nutrient and returns the reason.
4. Six extra adult reference nutrients (choline, iodine, chloride, molybdenum, chromium, fluoride) were added to the DRI metadata. This is a reference-coverage expansion, not food-data coverage. The current TBCA adapter did not quantify those six fields in the sampled records, so they remain `not_analyzed` and cannot be optimized until compatible source data is available.
5. Recipe scaling remains proportional when requested. No automatic raw-to-cooked multiplier was introduced: a source record with the correct preparation state takes precedence. A later conversion feature must use food- and method-specific weight yield and nutrient-retention factors, not a universal percentage.
6. DIAAS/PDCAAS remains intentionally unimplemented. DIAAS requires the amount of each indispensable amino acid per gram of protein and the ileal digestibility of that same amino acid. Total protein grams or generic digestibility cannot substitute for these data.

## Scientific and data references to unblock remaining work

- NIH Office of Dietary Supplements, Choline: https://ods.od.nih.gov/factsheets/choline-HealthProfessional/ — adult AI 550 mg/day men and 425 mg/day women; UL applies to food and supplements. Current TITAN DRI profile stores these values but TBCA coverage remains missing.
- NIH ODS, Iodine: https://ods.od.nih.gov/factsheets/iodine-HealthProfessional/ — adult RDA 150 µg/day and adult UL 1,100 µg/day; pregnancy/lactation have different RDAs and are outside the current healthy-adult profile.
- NASEM 2019, Sodium and Potassium DRIs: https://www.nationalacademies.org/read/25353/chapter/13 — revised sodium AI is 1,500 mg/day for all adults 19+; the prior 2005 age-specific values (1,300/1,200 mg) were superseded. Keep the 2019 AI and the 2,300 mg CDRR separate.
- NIH ODS, Chromium: https://ods.od.nih.gov/factsheets/Chromium-HealthProfessional/ — FNB AI values have not been reassessed since 2001; EFSA reported no convincing evidence that chromium is essential. TITAN retains the historical AI only with caution; no UL exists and the AI is not a deficiency diagnosis.
- NIH ODS, Fluoride: https://ods.od.nih.gov/factsheets/Fluoride-HealthProfessional/ — adult AI is 4 mg/day men and 3 mg/day women; adult UL 10 mg/day. Most exposure can be from fluoridated water, beverages made with it, and swallowed dental products; a food-plan-only UL check is incomplete.
- EFSA chloride review summarizing IOM 2005: https://efsa.onlinelibrary.wiley.com/doi/full/10.2903/j.efsa.2019.5779 — chloride AI 2,300 mg/day age 19–50, 2,000 mg/day age 51–70, and 1,800 mg/day over 70.
- FAO expert consultation (2013), protein quality: https://www.fao.org/ag/humannutrition/35978-02317b979a686a57aa4593304ffc17f06.pdf — DIAAS uses ileal digestibility of individual indispensable amino acids.
- USDA Table of Nutrient Retention Factors, Release 6 (2007): https://www.ars.usda.gov/ARSUserFiles/80400525/Data/retn/retn06.pdf — food/method-specific factors for roughly 290 foods, not a universal cooking multiplier.
- USDA Food Buying Guide: https://foodbuyingguide.fns.usda.gov/appendix/downloadfbg — yield references are food-specific and should be represented with explicit preparation state and edible yield.

## Remaining gates (not claimed complete)

- Obtain and legally clear a nutrient dataset that covers choline, iodine, chloride, molybdenum, chromium, fluoride and amino acids for the foods TITAN supports. Do not assume TBCA 7.3 or third-party data may be redistributed; review its exact license and terms first.
- Implement DIAAS only after amino-acid profiles and matching ileal-digestibility values are sourced per food/preparation state; include limiting amino acid and reference pattern/version.
- Add raw/cooked conversions only when exact food identity, yield factor, cooking method, nutrient retention factor, and provenance can be joined. Preserve measured cooked records when they already exist.
- Validate RMR/TDEE/Hall/adaptive models against external datasets and reference implementations; synthetic tests are not clinical validation.
- Install dependencies in CI and run the full browser/HiGHS WASM build, browser tests, and device verification. Local environment currently lacks node_modules, so package tests/build/lint are blocked here.
- Add total-exposure inputs for supplements, water and non-meal sources before interpreting total-intake ULs as complete exposure, especially fluoride, iodine, and nutrients whose UL includes supplements.


## Superseded by V11.27

The V11.26 section above is the historical state at that release. V11.27 adds a source-evidence-gated DIAAS calculation primitive, an explicit raw/prepared-food transformation primitive, and complete-coverage semantics for fibre/saturated fat/cholesterol. These engines do not imply that food-level amino-acid/digestibility or preparation crosswalk datasets are present. See `docs/research/NUTRITION_ENGINE_GITHUB_RESEARCH_V11_27.md` and `CHANGELOG_V11_27.md` for the current state.
