# TITAN V11.18.0 — Ultra-realism completion pass

## Óptica de água e vidro
- Fresnel dielétrico exato (polarizações s/p) com Snell e reflexão interna total nas interfaces principais.
- GGX dielétrico usa Fresnel exato em água e borossilicato.
- Mantidos Sellmeier, refração de dupla parede, Beer–Lambert, menisco e caústicas.

## Metais dos macros
- Fresnel exato de condutor complexo (`n + i k`) corrigido para usar `n² - k² - sin²(theta)`.
- Perfis RGB medidos/atribuídos para prata, cromo e ouro; UI tint continua sendo apenas acabamento discreto.
- GGX anisotrópico e anti-aliasing de highlights mantidos.

## Plasma e raios
- Campo curl otimizado com gradiente analítico de ruído 3D em uma única amostragem de lattice, substituindo seis reamostragens por diferenças finitas.
- Caminho ridged dos arcos usa amostragem contínua direta por coordenada, removendo reavaliação redundante de quatro endpoints em cada passo de volume.
- Remapeamento suave das cristas para reduzir descontinuidade local; IDs de nós e envelopes de ramificação permanecem estáveis.

## Corpo e pele
- Deformação esparsa separa bíceps/tríceps e quadríceps/isquiotibiais por ID canônico da malha.
- Loft procedimental ganha lóbulos anteriores e posteriores independentes, com transição por seção.
- Shader de pele estima espessura por região e usa perfis RGB de espalhamento aproximados.
- Compositor de corpos adiciona difusão screen-space de cinco taps, depth-aware e protegida por cor.

## Iluminação
- Ajuste de key retangular, fill e rim suave para revelar o relevo sem dramatizar bordas.
- Preservado o halo difuso atrás do corpo; sem iluminação projetada no chão.

## Engenharia e validação
- Nenhuma nova dependência runtime.
- Adicionados checks de contratos de realismo, mapeamento anatômico e compilação GPU headless quando Chromium/WebGL estiver disponível.
- Limitações e origem dos dados ópticos documentadas em `docs/research/ULTRA_REALISM_DEEP_RESEARCH_V11_18.md`.
