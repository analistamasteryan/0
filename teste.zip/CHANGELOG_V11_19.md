# TITAN V11.19 — Realism completion increment

## Added
- Linear-light UV periodic multi-Gaussian prefilter for a dedicated 256×256 skin scattering albedo map, separate from the crisp pore albedo.
- Depth-aware RGB screen-space skin diffusion with narrow and wide lobes; the red channel has a longer spatial support than green/blue, and depth discontinuities/holographic hues are protected.
- Shared anatomy key-light direction contract across body shader, hardware RectAreaLight and software fallback.
- Explicit planar linearized Young–Laplace capillary meniscus with contact-angle and capillary-length parameters for droplet and hydration bar.
- Anatomical structure map reports independent vs shared geometry/deformation granularity; stable 14 training IDs remain unchanged.
- The existing sparse deltoid morph is now weighted independently for anterior, lateral and posterior heads (canonical IDs 2/3/4); legacy profiles fall back to the previous shared `deltoids` value.
- Focused tests for UV scattering, capillary meniscus, lighting coherence, anatomy granularity and screen-space RGB diffusion.
- V11.19 Deep Research document extends Top 5 GitHub research with source-code-level inspection and explicit license/asset limits.

## Preserved
- Three.js 0.187, WebGL2/GLSL fluid renderer and existing UI architecture.
- Existing current/goal body meshes, 14 stable training muscle IDs and workout semantics.
- Single diffuse background halo; no floor, plinth, projector, ground glow or contact light.
- No new runtime dependency and no third-party anatomy asset imported.

## Verification
- Passed: `npm run test:rendering-realism` and `npm run test:review`.
- Passed: anatomy lifecycle/group/design/material/domain/cockpit/picking/static contracts and shader-injection tests.
- Passed: 206 TypeScript/TSX files syntax-transpiled without diagnostics.
- Passed: `npm run typecheck:calculations`.
- Blocked: full `npm test` requires missing `tsx`; `npm run lint` lacks `vite/client`; Vite build lacks `vite`. Package install could not reach registry (`EAI_AGAIN`).
- GPU compile attempted and SKIPPED: Chromium/ANGLE could not initialize EGL/XCB or create WebGL2, even with Xvfb/Mesa. No actual shader compile is claimed.

## Limitations
- UV prefilter is low-frequency albedo/reflectance, not a full UV-space irradiance diffusion pass.
- Screen-space RGB blur is an approximation of subsurface scattering.
- Fluid remains a 2D Eulerian UI solver plus SDF/2.5D optical surfaces, not SPH/FLIP or full 3D CFD.
- Plasma and arcs remain procedural visual effects, not MHD/electromagnetic discharge simulation.
- Anatomy still uses the existing MakeHuman hm08 base; individual atlas meshes were not imported because the reviewed Human Atlas BodyParts3D asset is male-adult reference data under CC BY 4.0 and is not a direct topological replacement. The three deltoid heads now have separate weights within the existing sparse morph; pectoral subdivisions, biceps/triceps heads, quadriceps heads and other deep structures remain grouped where the base payload does not contain separable morph topology.
