# SDD ledger — plan: docs/superpowers/plans/2026-11-25-nutrition-finalization-v11-27.md

Base: V11.26 candidate in the same isolated TITAN worktree.

- Task 1 RED: mixed avocado + banana test failed because 4.03 g of fiber was returned instead of `null` when the banana record had no fiber data.
- Task 1 GREEN: dietary metric totals now require every source to be quantified; source counts and data statuses propagate across recipe, slot and day. Focused test passes.
- Task 2 RED: mixed-diet DIAAS test initially returned undefined for the cap field; the desired behavior was not implemented.
- Task 2 GREEN: single-food values remain untruncated; mixed-diet DIAAS is capped at 100 and raw score remains separately auditable. Preparation factors require separate evidence. Target tests pass.
- Task 3 RED: a 1,200 kcal non-exercise base plus 400 kcal NET exercise passed despite an RMR of 1,500 kcal.
- Task 3 GREEN: non-exercise base is checked against RMR before exercise is added. Energy-budget test passes.
- Verification: `npm run test:review` PASS; targeted metric/DIAAS/preparation/micronutrient tests PASS; `tsc -p tsconfig.calc-review.json --pretty false` PASS; `git diff --check` PASS.
- Build/runtime limitations: dependency installation timed out. No full Vite build, full lint, `npm test` or real HiGHS WASM execution is claimed.
- External gates are intentionally not mislabeled complete: no amino-acid/digestibility catalog; no TBCA→USDA validated preparation crosswalk; no six-new-micronutrient food coverage; no full supplement/water exposure; no external clinical validation.
- Additional RED/GREEN: a missing-quantity ingredient followed by a quantified ingredient initially downgraded `missing` to `not_analyzed`; state preservation was corrected and the composer coverage test passed.
- Additional RED/GREEN: mismatched preparation evidence for a different food/state/method was initially accepted; exact evidence identity matching now gates macro and micronutrient retention. DIAAS/preparation tests and calc typecheck passed.
- Additional RED/GREEN: non-exercise base below RMR could be raised by adding exercise; the energy budget now rejects this invalid base and the energy-budget test passed.

- Additional RED/GREEN: coverage audit test failed before `nutrition-data-coverage.ts` existed. Implemented source-aware coverage accounting, canonical-unit and numeric-basis validation, public export, CLI audit and checked-in 29-nutrient snapshot for 5,838 food records. Focused test and `npm run audit:nutrition-coverage` passed.
- Final verification refresh: `npm run test:review` PASS; `tsc -p tsconfig.calc-review.json --pretty false` PASS; TypeScript/TSX transpilation PASS (15 modules); `git diff --check` PASS. `npm run build` (vite missing), `npm run lint` (vite/client missing), and `npm test` (tsx missing) are blocked because dependency install timed out; no actual HiGHS WASM run.

- V11.28 RED/GREEN: a known hard-UL conflict had no application guard; added domain block reason, store-side enforcement, disabled UI apply/save, and regression tests. Focused optimizer test: PASS.
- V11.28 RED/GREEN: DIAAS accepted rat digestibility and did not bind amino-acid data to the food identity; added exact source/version/reference/URL/food/state/basis checks for amino-acid composition and each digestibility record, and restricted accepted species to human/pig. Focused DIAAS/preparation test: PASS.
- Package version advanced to 11.28.0; build/runtime environment blockers remain unchanged and documented.

- V11.28 final verification: `npm run test:review` PASS (exit 0); `tsc -p tsconfig.calc-review.json --pretty false` PASS; 18/18 changed TypeScript/TSX modules transpiled without syntax diagnostics; `npm run audit:nutrition-coverage` PASS; `git diff --check` PASS.
- Full environment checks re-run: `npm run build` exit 127 (`vite: not found`); `npm run lint` exit 2 (`vite/client` types absent); `npm test` exit 127 (`tsx: not found`). These are environment blockers, not passing checks. Runtime HiGHS WASM remains unverified.
- Final artifact `/mnt/data/TITAN_V11_28_NUTRITION_ENGINE.zip`: `unzip -t` PASS; clean extraction confirmed package version 11.28.0, all required new code/docs, no `.git` or `node_modules`; `npm run test:review` from extracted ZIP PASS (exit 0). SHA-256 is verified outside the archive to avoid a self-referential checksum.
