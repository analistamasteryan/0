# SDD ledger — plan: docs/superpowers/plans/2026-11-25-v11-19-realism.md

Workspace: `/mnt/data/titan_v119_work` (isolated copy extracted from V11.18 ZIP; no `.git` metadata/worktree support in input archive).
Base archive preserved: `/mnt/data/TITAN_V11_18_ULTRA_REALISM.zip`.

Ruling: use incremental shader/material work rather than swapping engines or loading the complete Human Atlas — current body topology and female base are not compatible with directly replacing it using a male-only atlas; asset payload and license need a separate import decision.

Pre-flight: SSS shader, skin material map, dual-body compositor and water meniscus are related but independent interfaces. UV SSS touches anatomy materials and shader; meniscus touches shared fluid GLSL; lighting direction touches renderer and shader uniforms. Anatomical mapping metadata remains contract-only, not a topology replacement.

Task 1: complete — TDD UV multi-Gaussian prefilter tests passed; map integrated into current/goal body and muscle roles; shader-injection test passed.
Task 2: complete — CPU Young–Laplace boundary/angle/decay/curvature tests and GLSL static fluid checks passed.
Task 3: complete — shared key direction contract test and anatomy shader injection checks passed for hardware/fallback paths.
Task 4: complete — 15 labels carry explicit independent/shared geometry and deformation metadata; the existing sparse deltoid morph is split by canonical IDs 2/3/4 into three independently weighted heads; old stored profiles retain fallback; stable training IDs preserved. This is not a full anatomical mesh replacement.
Task 5: complete with documented host blockers — `test:rendering-realism`, `test:review`, 206-file TS/TSX syntax transpilation and `typecheck:calculations` passed. Full `npm test` blocked by missing `tsx`; lint blocked by missing `vite/client`; Vite build blocked by missing `vite`; dependency install failed due registry network EAI_AGAIN; GPU compile skipped because Chromium/ANGLE cannot initialize EGL/XCB/WebGL2 in this host. Final ZIP `/mnt/data/TITAN_V11_19_ULTRA_REALISM.zip` passed `unzip -t` and Python CRC validation (368 file entries); source archive and V11.18 base ZIP preserved.
