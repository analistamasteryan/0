# Execution Ledger — V11.23 Rendering Scope and Runtime Pruning

Plan: `docs/superpowers/plans/2026-11-25-v11-23-rendering-scope-and-runtime-pruning.md`
Base: `TITAN_V11_22_ULTRA_REALISM.zip` (extracted isolated copy; no `.git` metadata was provided).

Ruling: Keep Three.js/WebGL2 and add no libraries — current renderer is the product runtime and external engines do not fit the small visual components.
Ruling: Do not build bones or tendons — user explicitly excluded them; hidden skeletal batches are currently generated and then forced invisible.
Ruling: Keep Open Food Facts data and per-exercise provenance — they are data-domain contracts, not unused HTTP infrastructure.
Ruling: Delete only server routes without a frontend consumer, the unused generic HTTP client, zero-consumer analytics/sync modules, and stale server bundle — remove false capability claims rather than connect unrequested services.

Baseline: `npm run test:rendering-v11-22` passed in Node 22.16.0 before changes.

Ruling: Remove the Express app entirely rather than retaining middleware/static hosting — no frontend routes consume its endpoints; Vite dev/preview plus static `dist/` is simpler and removes the unnecessary server API surface.

## Implemented
- Nonlinear 2D Young–Laplace meniscus approximation in TypeScript and GLSL, regression bounded to <=8% against RK4 on tested angles/distances.
- Removed hidden generated skeletal geometry/material/renderer toggle. No bones, tendons, or fascia geometry are created; body surface, muscle layers, 14 muscle IDs, morphs, picking and dual-body remain.
- Deleted Express app and dependencies; Vite direct dev/preview and static `dist/` deployment.
- Removed unconsumed Gemini SDK/key/metadata, generic HTTP client, in-memory sync/analytics queues, stale server bundle, unconsumed Open Food Facts URL builder, and candidate-repository panel. Preserved local food catalog records and per-exercise provenance.
- Added GitHub Top 5 research by technical relevance across seven rendering specialties; no new package or third-party asset/code imported.

## Fresh verification in this session
- PASS: `npm run test:rendering-v11-23`
- PASS: `npm run test:rendering-realism`
- PASS: `npm run test:review`
- PASS: `npm run typecheck:calculations`
- PASS: `node scripts/check-anatomy-group-contract.mjs`
- PASS: `node scripts/check-anatomy-lifecycle.mjs`
- PASS: `node scripts/check-anatomy-v9.mjs`
- PASS: `node scripts/check-anatomy-vmax-v11.mjs`
- PASS: `node scripts/check-domain-boundaries.mjs`
- PASS: `node scripts/check-v11-23-scope-and-pruning.mjs`
- PASS: `node scripts/check-react-hardening.mjs`
- BLOCKED before test execution: `npm test` and `npm run test:anatomy` (`tsx` not installed); one direct anatomy module also cannot import `three` because it is not installed.
- BLOCKED: `npm run lint` (`vite/client` type package unavailable).
- BLOCKED: `npm run build` (`vite` executable unavailable).
- SKIPPED by GPU gate: Chromium could not initialize WebGL/SwiftShader (`ETIMEDOUT`). No GPU shader compile claim.

Packaging and archive CRC verification are completed after the above fresh runs. The distributable archive and SHA-256 are stored in `/mnt/data`. No Git metadata/worktree or independent reviewer tool was provided; no commit or subagent review is claimed.
