import assert from 'node:assert/strict';
import { existsSync, readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const packageJson = JSON.parse(read('package.json'));
const metadata = JSON.parse(read('metadata.json'));
const envExample = read('.env.example');
const readme = read('README.md');
const viteConfig = read('vite.config.ts');
const bunLock = read('bun.lock');
const bodyBuilder = read('src/domains/anatomy/engine/scene/build-anatomy-body.ts');
const materials = read('src/domains/anatomy/engine/materials/anatomy-materials.ts');
const renderer = read('src/domains/anatomy/engine/renderer/anatomy-renderer.ts');
const exerciseScreen = read('src/domains/exercise-library/screens/ExerciseLibraryScreen.tsx');
const exerciseContract = read('src/domains/exercise-library/domain/entities/exercise-item.ts');
const foodSearch = read('src/domains/nutrition/data/sources/food-search-index.ts');
const foodSource = read('src/domains/nutrition/data/sources/open-food-facts-adapter.ts');

assert.equal(existsSync(new URL('../server.ts', import.meta.url)), false, 'custom Express server is removed; there is no backend API host');
assert.equal(packageJson.scripts.dev, 'vite --host 0.0.0.0', 'development uses Vite directly');
assert.equal(packageJson.scripts.start, 'vite preview --host 0.0.0.0', 'start is a local static preview, not a product API server');
assert.equal(packageJson.dependencies?.express, undefined, 'Express is not retained without a backend');
assert.equal(packageJson.dependencies?.compression, undefined, 'compression middleware is not retained without Express');
assert.equal(packageJson.devDependencies?.['@types/express'], undefined, 'unused Express types are removed');
assert.equal(packageJson.dependencies?.['@types/compression'], undefined, 'unused compression types are removed');
assert.match(viteConfig, /preview:\s*\{/);
assert.match(viteConfig, /host:\s*'0\.0\.0\.0'/);
assert.match(viteConfig, /port:\s*Number\(process\.env\.PORT \?\? 4173\)/);
assert.equal(packageJson.scripts.build, 'vite build', 'frontend is a static Vite build');
assert.equal(packageJson.scripts['build:server'], undefined, 'custom server bundle script is removed');
assert.equal(packageJson.devDependencies?.esbuild, undefined, 'esbuild is not a direct project dependency');
assert.equal(packageJson.dependencies?.['@google/genai'], undefined, 'unused Gemini SDK is not a runtime dependency');
assert.doesNotMatch(bunLock, /@google\/genai/, 'lockfile does not retain the unused Gemini SDK package');
assert.doesNotMatch(bunLock, /\"express\"|\"compression\"/, 'lockfile workspace does not retain removed server packages');
assert.doesNotMatch(envExample, /GEMINI_API_KEY|APP_URL/, 'environment template does not request an unused AI API key');
assert.doesNotMatch(readme, /GEMINI_API_KEY|Gemini API|funções de IA/, 'README does not advertise an unused Gemini API integration');
assert.deepEqual(metadata.majorCapabilities, [], 'metadata does not claim an unused server-side Gemini API');
assert.equal(existsSync(new URL('../server.js', import.meta.url)), false, 'stale generated server bundle is not shipped');

for (const path of [
  'src/infrastructure/api/http-client.ts',
  'src/infrastructure/sync/sync-queue.ts',
  'src/infrastructure/analytics/event-tracker.ts',
]) {
  assert.equal(existsSync(new URL(`../${path}`, import.meta.url)), false, `${path} is deleted because it has no consumers`);
}

assert.doesNotMatch(bodyBuilder, /skeletonGroup|skeletonGeos|addBoneTube|anatomy-skeleton-reference|SKELETAL REFERENCE/, 'body builder does not create hidden skeleton geometry');
assert.doesNotMatch(materials, /skeletonReference/, 'anatomy materials do not allocate an unused skeletal material');
assert.doesNotMatch(bodyBuilder, /tendon|fascia|skeleton/i, 'anatomy body does not construct excluded skeletal or tendon structures');
assert.doesNotMatch(renderer, /rig\.skeletonGroup/, 'renderer does not toggle a removed skeleton group');
assert.match(bodyBuilder, /superficialGroup/, 'superficial muscle geometry remains');
assert.match(bodyBuilder, /deepGroup/, 'deep soft-tissue layer remains');
assert.match(bodyBuilder, /muscleEntries/, 'canonical muscle registry and anatomy mapping remain');

assert.doesNotMatch(exerciseScreen, /EXERCISE_DATA_SOURCES|Fontes do catálogo e política de licenças/, 'repository candidate list is not shown as an app feature');
assert.match(exerciseContract, /ExerciseSourceReference/, 'item-level exercise provenance contract remains');
assert.match(foodSearch, /open-food-facts-adapter/, 'curated Open Food Facts records remain connected to catalog search');
assert.match(foodSource, /OPEN_FOOD_FACTS_PRODUCTS/, 'curated branded-food records and their provenance remain');
assert.doesNotMatch(foodSource, /buildOpenFoodFactsV3Url|world\.openfoodfacts\.org\/api\//, 'unused live API URL builder is removed; no remote OFF API integration is claimed');

console.log('PASS: V11.23 scope, runtime/API pruning, anatomy exclusion and provenance retention');
