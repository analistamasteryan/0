import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const fluid = read('src/shared/graphics/fluid-shader-engine.ts');
const macros = read('src/domains/cockpit/components/MacroOverview.tsx');
const anatomyShader = read('src/domains/anatomy/engine/shaders/anatomy-material-shader.ts');
const anatomyRenderer = read('src/domains/anatomy/engine/renderer/anatomy-renderer.ts');

// Water and glass: stable spatial dither avoids animated grain crawling through refractive surfaces.
assert.match(fluid, /float ig = fract\(magic\.z \* fract\(dot\(fragCoord, magic\.xy\)\)\);/);
assert.match(fluid, /float evalSellmeierWaterIOR\(float lambdaMicron\)/);
assert.match(fluid, /float evalSellmeierGlassIOR\(float lambdaMicron\)/);
assert.match(fluid, /float evalYoungLaplaceMeniscus\(float wallDist, float capHeight, float capLength\)/);
assert.match(fluid, /vec3 applyBeerLambert\(vec3 bgLinear, vec3 attenColor, float attenDist, float opticalDepth\)/);
assert.match(fluid, /float fresnelSchlick|vec3 fresnelSchlick/);
assert.match(fluid, /evalWaterCausticWeb/);
assert.match(fluid, /vec3 evalConductorFresnelLSK\(vec3 nIor, vec3 kExt, float cosTheta\)/);
assert.match(fluid, /float interleavedGradientHash\(vec2 fragCoord\)/);
assert.doesNotMatch(fluid, /finalizeHdrOrSrgb\([^\n]*timeSeed/);

// Macro gauges must render once when still; non-zero fill alone is not an animation.
assert.match(macros, /isAnimating:\s*isInterpolating/);
assert.doesNotMatch(macros, /isFlowActive/);
assert.doesNotMatch(macros, /idleFrameIntervalMs/);
assert.doesNotMatch(fluid, /idleFrameIntervalMs/);
assert.doesNotMatch(macros, /currentRatioRef\.current\s*>\s*0\.005\)\s*\{\s*engine\.wake\(\)/);
assert.match(macros, /const tiltTargetRef = useRef<\[number, number\]>\(\[0, 0\]\)/);
assert.match(macros, /const tiltAlpha = 1 - Math\.exp\(-elapsed \/ 0\.085\)/);
assert.match(macros, /isAnimating: isInterpolating \|\| isTiltSettling/);
assert.doesNotMatch(macros, /tiltSettlingUntilRef/);

// Plasma/lightning: periodic pulses close smoothly, branch identity stays anchored,
// spark cells do not scroll through hash discontinuities, and per-pixel ray jitter is stable.
assert.match(fluid, /float energyPulseEnvelope\(float phase\)/);
assert.match(fluid, /float pulseA = energyPulseEnvelope\(cycA\)/);
assert.match(fluid, /float nodeHeat = energyPulseEnvelope\(nodeCycle\)/);
assert.match(fluid, /segT = segT \* segT \* \(3\.0 - 2\.0 \* segT\)/);
assert.match(fluid, /sin\(t \* 0\.92 \+ nodeId \* 1\.71\) \* 0\.045/);
assert.doesNotMatch(fluid, /\* 6\.2831853 \+ t \* 0\.25/);
assert.match(fluid, /vec3 sparkGrid = vec3\(pos3D\.x \* 6\.5, pos3D\.y \* 8\.0, pos3D\.z \* 8\.0\)/);
assert.match(fluid, /float sparkLife = energyPulseEnvelope\(sparkPhase\)/);
assert.doesNotMatch(fluid, /pos3D\.x \* 6\.5 - t \* 3\.2/);
assert.match(fluid, /energyInterleavedGradientHash\(gl_FragCoord\.xy\) \+ 0\.5/);
assert.match(fluid, /float energyPulseEnvelope\(float phase\)/);
assert.match(fluid, /segT = segT \* segT \* \(3\.0 - 2\.0 \* segT\)/);

// Anatomy: normals and all backscatter vectors are in the same world coordinate space.
assert.match(anatomyShader, /mat3\(transpose\(inverse\(modelMatrix\)\)\) \* objectNormal/);
assert.equal((anatomyShader.match(/cameraPosition - vAnatomyWorldPos/g) ?? []).length, 2);
assert.equal((anatomyShader.match(/titanBackFacing = max\(dot\(-titanWorldNormal, titanBackLightDir\), 0\.0\)/g) ?? []).length, 2);
assert.match(anatomyShader, /vec3\(0\.62, 0\.15, 0\.085\)/);

// Lighting: keep exactly one diffuse background separation object; no ground stage or extra kicker.
assert.match(anatomyRenderer, /buildBackdropSeparation\(\)/);
assert.match(anatomyRenderer, /const backlightHalo = new THREE\.Mesh\(haloGeo, haloMat\)/);
assert.match(anatomyRenderer, /this\.scene\.add\(backlightHalo\)/);
assert.doesNotMatch(anatomyRenderer, /const kicker\s*=|floorStage|contactShadow|rearEmitterCircle|rearBelowLight/);
assert.match(anatomyRenderer, /DirectionalLight\('#FFF7EC', 2\.85\)/);
assert.match(anatomyRenderer, /DirectionalLight\('#66838D', 0\.28\)/);
assert.match(anatomyRenderer, /DirectionalLight\('#8CCFC7', 1\.32\)/);

console.log('V11.17 rendering realism checks passed (stable optics, idle scheduling, temporally coherent plasma, world-space anatomy SSS, single backdrop halo).');
