import fs from 'node:fs/promises';

const sourcePath = 'src/domains/nutrition/data/sources/tbca-catalog.compact.json';
const rows = JSON.parse(await fs.readFile(sourcePath, 'utf8'));
if (!Array.isArray(rows)) throw new TypeError('Catálogo TBCA compacto precisa ser uma lista.');

const counts = { ALIMENTO: 0, PREPARACAO_COMPOSTA: 0, UNKNOWN: 0 };
const ids = new Set();
const malformed = [];
for (const row of rows) {
  if (!Array.isArray(row) || row.length < 9) throw new Error('Registro TBCA compacto malformado.');
  const [code, name, group, type] = row;
  if (typeof code !== 'string' || !code || typeof name !== 'string' || !name.trim()) {
    throw new Error('Registro TBCA sem código/nome válido.');
  }
  if (ids.has(code)) throw new Error(`Código TBCA duplicado: ${code}`);
  ids.add(code);
  if (type === 'ALIMENTO' || type === 'PREPARACAO_COMPOSTA') counts[type] += 1;
  else {
    counts.UNKNOWN += 1;
    malformed.push({ code, name, group, type: type ?? null });
  }
}

const report = {
  source: 'TBCA 7.2 compact catalog packaged with TITAN V11.35',
  sourcePath,
  totalRecords: rows.length,
  typeCounts: counts,
  compoundPreparationSharePercent: Number((counts.PREPARACAO_COMPOSTA / rows.length * 100).toFixed(2)),
  recipeIngredientPolicy: 'Allow only TBCA food_type=ALIMENTO; exclude PREPARACAO_COMPOSTA and fail closed for unknown types. General diary search retains all records.',
  malformedTypeRecords: malformed,
};

if (rows.length !== 5830 || counts.ALIMENTO !== 2717 || counts.PREPARACAO_COMPOSTA !== 3113 || counts.UNKNOWN !== 0) {
  throw new Error(`TBCA category inventory drift: ${JSON.stringify(report)}`);
}
if (process.argv.includes('--write')) {
  const output = 'docs/research/TBCA_INGREDIENT_ELIGIBILITY_AUDIT_V11_35.json';
  await fs.writeFile(output, `${JSON.stringify(report, null, 2)}\n`);
  process.stdout.write(`Wrote ${output}\n`);
}
process.stdout.write(`TBCA ingredient audit: ${report.totalRecords} total; ${counts.ALIMENTO} ALIMENTO; ${counts.PREPARACAO_COMPOSTA} PREPARACAO_COMPOSTA (${report.compoundPreparationSharePercent}%); unknown ${counts.UNKNOWN}.\n`);
