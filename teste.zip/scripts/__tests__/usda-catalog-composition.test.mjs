import assert from 'node:assert/strict';
import { composeUsdaCatalogs } from '../../src/domains/nutrition/data/sources/usda-catalog-composition.ts';

const foundationFood = { food_id: 'usda-fdc:1', source_id: 'USDA_FDC' };
const legacyFood = { food_id: 'usda-fdc:2', source_id: 'USDA_FDC' };
const combined = composeUsdaCatalogs([
  { manifest: { dataType: 'Foundation' }, foods: [foundationFood] },
  { manifest: { dataType: 'SR Legacy' }, foods: [legacyFood] },
]);
assert.deepEqual(combined, [foundationFood, legacyFood]);
assert.throws(() => composeUsdaCatalogs([
  { manifest: { dataType: 'Foundation' }, foods: [foundationFood] },
  { manifest: { dataType: 'SR Legacy' }, foods: [foundationFood] },
]), /duplicado/);
assert.throws(() => composeUsdaCatalogs([{ manifest: {}, foods: [{ food_id: 'tbca:1', source_id: 'TBCA' }] }]), /inválido/);
console.log('USDA multi-release catalog composition tests passed.');
