import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const fluid = read('src/shared/graphics/fluid-shader-engine.ts');
const macros = read('src/domains/cockpit/components/MacroOverview.tsx');
const skinShader = read('src/domains/anatomy/engine/shaders/anatomy-material-shader.ts');
const compositor = read('src/domains/anatomy/engine/renderer/dual-body-compositor.ts');
const renderer = read('src/domains/anatomy/engine/renderer/anatomy-renderer.ts');
const geometry = read('src/domains/anatomy/engine/scene/build-anatomy-body.ts');
const decoder = read('src/domains/anatomy/engine/assets/human-mesh-decoder.ts');
const pkg = JSON.parse(read('package.json'));

// Exact dielectric optics: Snell, s/p polarization and total internal reflection.
assert.match(fluid, /float evalDielectricFresnelExact\(float cosThetaI, float etaI, float etaT\)/);
assert.match(fluid, /if \(sin2T >= 1\.0\) return 1\.0;/);
assert.match(fluid, /float rs = \(etaI \* c - etaT \* cosT\)/);
assert.match(fluid, /float rp = \(etaT \* c - etaI \* cosT\)/);
assert.ok((fluid.match(/evalDielectricFresnelExact\(/g) ?? []).length >= 12);
assert.match(fluid, /vec3 evaluateGGXDielectricSpecular\(/);
// Plasma noise gradient is analytic: one eight-corner lattice sample replaces six finite differences.
assert.match(fluid, /vec4 energyNoise3DGradient\(vec3 x\)/);
assert.match(fluid, /vec3 grad = energyNoise3DGradient\(p\)\.yzw;/);
assert.doesNotMatch(fluid, /energyNoise3D\(p \+ vec3\(0\.0, e, 0\.0\)\)/);
assert.match(fluid, /float ry = energyRidgedLeader\(xCoord, flowT, seed\)/);
assert.match(fluid, /float rz = energyRidgedLeader\(xCoord, flowT \+ 3\.7, seed \+ 19\.4\)/);
assert.doesNotMatch(fluid, /floor\(xCoord \* 5\.6/);
assert.match(fluid, /float nodeId = floor\(nodePhase\)/);
assert.match(fluid, /float branchGate = nodeHeat/);
assert.match(fluid, /evalDielectricFresnelExact\(vDotH, etaI, etaT\)/);
assert.match(fluid, /evalSellmeierWaterIOR\(0\.532\)/);
assert.match(fluid, /evalSellmeierGlassIOR\(0\.532\)/);

// Conductor Fresnel: correct exact n²-k² term and measured optical constants.
assert.match(fluid, /vec3 evalConductorFresnelExact\(vec3 nIor, vec3 kExt, float cosTheta\)/);
assert.match(fluid, /vec3 t0 = n2 - k2 - sin2;/);
assert.doesNotMatch(fluid, /vec3 t0 = n2 \+ k2 - sin2;/);
assert.match(fluid, /void measuredMetalOptics\(int preset, out vec3 nIor, out vec3 kExt\)/);
for (const literal of ['4.483, 3.324, 2.657', '3.34, 3.33, 3.14', '3.697, 2.081, 1.914']) assert.ok(fluid.includes(literal));
assert.match(fluid, /evaluateGGXAnisotropicConductorSpecular\([\s\S]*?nCond, kCond/);
// Independent normal-incidence reference values from F0=((n-1)^2+k^2)/((n+1)^2+k^2).
const f0 = (n, k) => ((n - 1) ** 2 + k ** 2) / ((n + 1) ** 2 + k ** 2);
const near = (a, b) => assert.ok(Math.abs(a - b) < 0.001, `${a} != ${b}`);
near(f0(0.05, 4.483), 0.9906); near(f0(0.05, 3.324), 0.9835); near(f0(0.04, 2.657), 0.9803);
near(f0(3.09, 3.34), 0.5567); near(f0(2.94, 3.33), 0.5581); near(f0(2.33, 3.14), 0.5551);
near(f0(0.14, 3.697), 0.9626); near(f0(0.62, 2.081), 0.6434); near(f0(1.38, 1.914), 0.4082);
assert.match(macros, /carbs:[\s\S]*?metalPreset:\s*'silver'/);
assert.match(macros, /protein:[\s\S]*?metalPreset:\s*'chromium'/);
assert.match(macros, /fat:\s*\{[\s\S]*?metalPreset:\s*'gold'/);
assert.match(fluid, /uniform int u_metalPreset;/);
assert.match(fluid, /const preset = job\.metalPreset === 'chromium' \? 1 : job\.metalPreset === 'gold' \? 2 : 0;/);
assert.match(fluid, /gl\.uniform1i\(cached\.uMetalPreset, preset\)/);

// Regional independent muscle deformation (base-mesh semantic IDs and procedural lobes).
assert.match(decoder, /canonicalMuscleIds/);
assert.match(decoder, /biceps_triceps/);
assert.match(decoder, /quadriceps_hamstrings/);
for (const id of ['5', '6', '12', '13']) assert.ok(decoder.includes(`[${id},`) || decoder.includes(`, ${id}]`));
assert.match(geometry, /anteriorBulge\?: number/);
assert.match(geometry, /posteriorBulge\?: number/);
assert.match(geometry, /const bicepsBulge/);
assert.match(geometry, /const tricepsBulge/);
assert.match(geometry, /const quadricepsBulge/);
assert.match(geometry, /const hamstringBulge/);
assert.match(geometry, /anteriorBulge: bicepsBulge/);
assert.match(geometry, /posteriorBulge: tricepsBulge/);
assert.match(geometry, /anteriorBulge: quadricepsBulge/);
assert.match(geometry, /posteriorBulge: hamstringBulge/);

// Skin: regional optical thickness, spectral attenuation and depth-aware screen-space diffusion.
assert.match(skinShader, /varying float vSkinThickness/);
assert.match(skinShader, /titanThicknessM = mix\(0\.0068, 0\.0180, titanTorsoThickness\)/);
assert.match(skinShader, /vec3\(18\.0, 31\.0, 47\.0\)/);
assert.match(skinShader, /titanDiffusionWide/);
assert.match(skinShader, /titanDiffusionNear/);
assert.match(compositor, /sampleSkinDiffusionTap\(/);
assert.match(compositor, /depthGate = 1\.0 - smoothstep\(0\.008, 0\.050, depthDelta\)/);
assert.match(compositor, /skinHueGate/);
assert.equal((compositor.match(/sampleSkinDiffusionTap\(colorTex, depthTex/g) ?? []).length, 4);
assert.match(compositor, /mix\(centerColor\.rgb, diffused, skinHueGate \* 0\.18\)/);

// Stage: only one diffuse backdrop halo; no floor/projector/contact-light path.
assert.match(renderer, /buildBackdropSeparation\(\)/);
assert.match(renderer, /const backlightHalo = new THREE\.Mesh\(haloGeo, haloMat\)/);
assert.match(renderer, /this\.scene\.add\(backlightHalo\)/);
assert.doesNotMatch(renderer, /buildProjectorPlinth|floorStage|contactShadow|rearEmitterCircle|rearBelowLight|titanGroundAO/);
assert.match(renderer, /RectAreaLight/);
assert.match(renderer, /backdropObjects/);

// V11.18 release identity.
assert.equal(pkg.version, '11.18.0');
console.log('V11.18 realism checks passed: exact dielectric/conductor Fresnel, measured metal n/k presets, separate muscle morph lobes, regional skin transmission + depth-aware diffusion, and single backdrop halo.');
