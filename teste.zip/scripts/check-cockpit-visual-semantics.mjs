import { readFileSync } from 'node:fs';

const root = new URL('../src/domains/cockpit/components/', import.meta.url);
const files = {
  energy: readFileSync(new URL('EnergySummary.tsx', root), 'utf8'),
  macros: readFileSync(new URL('MacroOverview.tsx', root), 'utf8'),
  hydration: readFileSync(new URL('HydrationSummary.tsx', root), 'utf8'),
  workout: readFileSync(new URL('TodayWorkout.tsx', root), 'utf8'),
  meal: readFileSync(new URL('NextMeal.tsx', root), 'utf8'),
  header: readFileSync(new URL('HomeHeader.tsx', root), 'utf8'),
};
const errors = [];
const anatomyRenderer = readFileSync(new URL('../src/domains/anatomy/engine/renderer/anatomy-renderer.ts', import.meta.url), 'utf8');
const anatomyShader = readFileSync(new URL('../src/domains/anatomy/engine/shaders/anatomy-material-shader.ts', import.meta.url), 'utf8');
const anatomyBuilder = readFileSync(new URL('../src/domains/anatomy/engine/scene/build-anatomy-body.ts', import.meta.url), 'utf8');

for (const name of ['energy', 'macros', 'hydration']) {
  const source = files[name];
  if (!source.includes("role={hasValidGoal ? 'progressbar' : 'group'}")) {
    errors.push(`${name}: missing valid-goal progress semantics`);
  }
  if (!source.includes('aria-valuenow={hasValidGoal ?')) {
    errors.push(`${name}: progress value must be omitted when no goal exists`);
  }
}

if (!files.energy.includes("{hasValidGoal ? `${rawPercent}%` : '—'}")) {
  errors.push('energy: undefined daily goal must not be presented as 0%');
}
if (!files.macros.includes('function formatMacroGrams(') || !files.macros.includes("return '<0,1 g'")) {
  errors.push('macros: small remaining/excess amounts must retain visible precision');
}
if (!files.macros.includes('Math.max(0, safeGoal - safeConsumed)') || !files.macros.includes('Math.max(0, safeConsumed - safeGoal)')) {
  errors.push('macros: remaining/excess states must use unrounded source values');
}
if (!files.hydration.includes("'Meta não definida'")) {
  errors.push('hydration: undefined goal must be labelled explicitly');
}
if (!files.workout.includes('const InlineRestTimer = memo(') || !files.workout.includes('aria-live="off"')) {
  errors.push('workout: rest timer ticks should be isolated from the exercise list and not spam live announcements');
}
if (files.workout.includes('onCommit(parsed)')) {
  errors.push('workout: numeric input must not update the store on every keystroke');
}
if (!files.workout.includes('onClick={onOpenTraining}')) {
  errors.push('workout: the existing start-training navigation callback must be wired to the start action');
}
if (!files.meal.includes('loading="lazy"') || !files.meal.includes('decoding="async"')) {
  errors.push('next meal: food images should use deferred loading/decoding');
}
if (!files.header.includes('if (goalsOpen) return;') || !files.header.includes('EMPTY_MARKED_DATE_KEYS')) {
  errors.push('header: profile drafts should sync only while the goal sheet is closed and closed-calendar markers should be reused');
}

if (!anatomyShader.includes('uActiveMusclesMask >> titanMuscleId') || !anatomyShader.includes('uniform int uActiveMusclesMask')) {
  errors.push('anatomy: active muscle mask must affect the PBR muscle surface');
}
if (!anatomyBuilder.includes('mergeStaticBatch(muscleGeos, geometries, true)') || !anatomyBuilder.includes('aMuscleSide')) {
  errors.push('anatomy: muscle geometry must be batched while preserving stable group and side attributes');
}
if (!anatomyBuilder.includes('longitudinalProfile') || !anatomyBuilder.includes('bulge')) {
  errors.push('anatomy: muscle surface needs rounded tapered geometry rather than flat patches');
}
if (!anatomyRenderer.includes('updateSelectionSweep') || !anatomyRenderer.includes('420')) {
  errors.push('anatomy: selected-muscle micro-interaction sweep is missing');
}
if (!anatomyRenderer.includes('buildBackdropSeparation') || anatomyRenderer.includes('contactShadow')) {
  errors.push('anatomy: studio backdrop separation must replace floor contact shadow plinth');
}
if (!anatomyRenderer.includes('lastPixelRatio') || !anatomyRenderer.includes('setPixelRatio(nextPixelRatio)')) {
  errors.push('anatomy: pixel ratio must be recalculated when display density changes');
}
if (!anatomyRenderer.includes('prefersReducedMotion')) {
  errors.push('anatomy: motion preferences must govern camera damping and selection sweep');
}

for (const [file, source] of [
  ['HydrationSummary.tsx', files.hydration],
  ['EnergySummary.tsx', files.energy],
  ['MacroOverview.tsx', files.macros],
]) {
  if (!source.includes('if (canvas.width !== pixelWidth) canvas.width = pixelWidth')) {
    errors.push(`${file}: backing store should only be resized when dimensions change`);
  }
}

if (errors.length) {
  console.error('Cockpit visual semantics checks failed:\n' + errors.join('\n'));
  process.exitCode = 1;
} else {
  console.log('Cockpit visual semantics checks passed (goal states, precision, ARIA and canvas allocation).');
}
