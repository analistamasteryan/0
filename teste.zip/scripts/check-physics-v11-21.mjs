import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const fluid = read('../src/shared/graphics/hydration-fluid-solver.ts');
const optics = read('../src/shared/graphics/metal-optics-spectrum.ts');
const shader = read('../src/shared/graphics/fluid-shader-engine.ts');
const waveform = read('../src/shared/graphics/lightning-waveform.ts');
const pressure = read('../src/shared/graphics/fluid-pressure-projection.ts');

assert.match(fluid, /projectIncompressibleVelocity2D\(/, 'fluid grid routes through the pressure projection');
assert.match(fluid, /updateContactAngleHysteresis\(/, 'droplet contact line uses advancing/receding angles');
assert.match(fluid, /massTransferred:\s*transferredMass/, 'droplet-pool impact exposes transferred mass');
assert.match(fluid, /mergeDropletMassConservatively\(/, 'coalescence preserves both represented masses');
assert.match(pressure, /relativeTolerance/, 'pressure solver exposes a bounded residual criterion');
assert.match(optics, /wavelengthNm: 659\.5/, 'measured spectrum reaches the long-wavelength red anchor');
for (const preset of ['silver', 'chromium', 'gold']) {
  const match = optics.match(new RegExp(`${preset}: Object\\.freeze\\(\\[([\\s\\S]*?)\\]\\)`));
  assert.ok(match, `${preset} table exists`);
  assert.equal((match[1].match(/wavelengthNm:/g) ?? []).length, 9, `${preset} has nine measured samples`);
}
assert.match(shader, /measuredMetalFresnelSpectral\(u_metalPreset, nDotV\)/, 'glass shader uses the measured multi-sample conductor response');
assert.match(shader, /0\.5695701063/, 'GLSL shares the normalized Heidler peak constant');
assert.match(waveform, /normalization: 0\.5695701063405509/, 'CPU waveform uses the same Heidler normalization');
console.log('PASS: V11.21 physics integration contracts');
