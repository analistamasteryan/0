#!/usr/bin/env node
import { mkdir, realpath } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { fetchUsdaFdcArchive, persistUsdaArchiveImmutable, USDA_FDC_DOWNLOADS } from './lib/usda-fdc-download.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUTPUT_DIRECTORY = path.join(ROOT, 'data', 'external', 'usda-fdc');

function parseArgs(argv) {
  const args = {};
  for (let index = 0; index < argv.length; index += 1) {
    const token = argv[index];
    if (token === '--') continue;
    if (token === '--help' || token === '-h') return { help: true };
    if (!token.startsWith('--')) throw new Error(`Argumento inesperado: ${token}`);
    const key = token.slice(2);
    if (key !== 'type') throw new Error(`Argumento desconhecido: --${key}`);
    if (args[key] !== undefined) throw new Error(`Argumento duplicado: --${key}`);
    const value = argv[index + 1];
    if (!value || value.startsWith('--')) throw new Error(`Valor ausente para --${key}`);
    args[key] = value;
    index += 1;
  }
  return args;
}

function usage() {
  return `Uso:\n  bun run download:usda-fdc -- --type <Foundation|SR Legacy|Survey (FNDDS)>\n\nSomente releases JSON fixadas e servidas diretamente por fdc.nal.usda.gov são aceitas.\n`;
}

export async function runDownloadUsdaCli(
  argv = process.argv.slice(2),
  { outputDirectory = OUTPUT_DIRECTORY, fetchImpl = globalThis.fetch, stdout = process.stdout, stderr = process.stderr } = {},
) {
  const args = parseArgs(argv);
  if (args.help) { stdout.write(usage()); return 0; }
  if (!args.type || !Object.hasOwn(USDA_FDC_DOWNLOADS, args.type)) {
    stderr.write(usage());
    return 2;
  }

  const archive = await fetchUsdaFdcArchive({ dataType: args.type, fetchImpl });
  await mkdir(outputDirectory, { recursive: true });
  const resolvedOutputDirectory = await realpath(outputDirectory);
  const allowedBase = outputDirectory === OUTPUT_DIRECTORY ? ROOT : path.dirname(resolvedOutputDirectory);
  if (resolvedOutputDirectory !== allowedBase && !resolvedOutputDirectory.startsWith(allowedBase + path.sep)) {
    throw new Error('Diretório de download USDA aponta para fora do projeto.');
  }
  const output = path.join(resolvedOutputDirectory, archive.fileName);
  const persisted = await persistUsdaArchiveImmutable({ destination: output, bytes: archive.bytes, sha256: archive.sha256 });
  stdout.write(`${persisted.created ? 'Arquivo USDA salvo' : 'Arquivo USDA já existe, hash idêntico'}: ${path.relative(ROOT, output)}\n`);
  stdout.write(`Tipo: ${archive.dataType}; release: ${archive.releaseVersion}\n`);
  stdout.write(`Bytes: ${archive.byteLength}; SHA-256 ZIP: ${archive.sha256}\n`);
  stdout.write(`Origem: ${archive.sourceUrl}\n`);
  stdout.write(`Próximo passo:\n  bun run import:usda-fdc -- --input "${path.relative(ROOT, output)}" --type "${archive.dataType}" --release "${archive.releaseVersion}" --source-url "${archive.sourceUrl}"\n`);
  return 0;
}

const isEntrypoint = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isEntrypoint) {
  runDownloadUsdaCli(process.argv.slice(2))
    .then((code) => {
      if (code !== 0) process.exitCode = code;
    })
    .catch((error) => {
      process.stderr.write(`${error instanceof Error ? error.message : String(error)}\n${usage()}`);
      process.exitCode = 1;
    });
}
