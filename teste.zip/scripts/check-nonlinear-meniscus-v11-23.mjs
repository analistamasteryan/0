import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(`../${path}`, import.meta.url), 'utf8');
const shader = read('src/shared/graphics/fluid-shader-engine.ts');
const cpu = read('src/shared/graphics/capillary-meniscus.ts');
const start = shader.indexOf('float evalYoungLaplaceMeniscus(');
const end = shader.indexOf('// Curvatura analítica normalizada', start);
assert.ok(start >= 0 && end > start, 'GLSL nonlinear meniscus function exists');
const glsl = shader.slice(start, end);

for (const expression of [
  /sqrt\(max\(0\.0, 2\.0 \* \(1\.0 - sinTheta\)\)\)/,
  /max\(wallDist, 0\.0\) \/ lambdaC/,
  /abs\(cosTheta\) \/ max\(sinTheta, 0\.04997917\)/,
  /contactSlope \/ wallHeightRatio/,
  /exp\(-4\.0 \* normalizedDistance\)/,
  /\* 0\.25/,
  /lambdaC \* wallSign \* wallHeightRatio \* exp\(exponent\)/,
]) {
  assert.match(glsl, expression, `GLSL profile preserves nonlinear parameterization ${expression}`);
}

assert.match(cpu, /const wallHeightRatio = Math\.sqrt\(Math\.max\(0, 2 \* \(1 - sinTheta\)\)\)/);
assert.match(cpu, /const transitionRate = contactSlope \/ wallHeightRatio/);
assert.match(cpu, /Math\.exp\(-4 \* normalizedDistance\)/);
assert.match(cpu, /return length \* sign \* wallHeightRatio \* Math\.exp\(exponent\)/);
assert.equal((shader.match(/evalYoungLaplaceMeniscus\(/g) ?? []).length, 3, 'exactly two existing shader call sites use the shared nonlinear function');
assert.match(shader, /evalYoungLaplaceMeniscus\(wallDist, 0\.030,/);
assert.match(shader, /evalYoungLaplaceMeniscus\(wallDist, 0\.052,/);

console.log('PASS: CPU and GLSL nonlinear Young–Laplace profiles share the same bounded formula and both glass/tank call sites use it');
