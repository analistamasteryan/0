# V11.16 — modelo dinâmico, reconciliação de atividade e conectores nativos

- Implementado o núcleo adulto de balanço energético de Hall (2011) em TypeScript: compartimentos de gordura/massa magra, partição de energia, termogênese alimentar, termogênese adaptativa, glicogênio/água associada e desvio de água extracelular. O solver encontra a ingestão diária aproximada para peso-alvo e prazo; limites conservadores de velocidade continuam aplicados depois da simulação.
- A estimativa adaptativa de TDEE passou a derivar densidade energética local da composição corporal e da partição de tecido do modelo de Hall quando perfil está disponível. Sem dados demográficos suficientes, mantém fallback legado explícito de 7.000 kcal/kg, acompanhado de aviso.
- A interface de perfil agora oferece método RMR, percentual de gordura, origem da composição corporal e RMR medido por calorimetria indireta. Campos são opcionais e perfis persistidos antigos continuam compatíveis.
- Adicionada reconciliação de eventos de energia ativa de origem manual, Health Connect, HealthKit, wearable e OpenMetabolics: deduplicação por ID, sessão-pai versus amostras-filhas, sobreposição entre fontes, rejeição de energia bruta/total como soma adicional e trilha de exclusão.
- Adicionada sincronização por contrato nativo injetado. Sem bridge nativa, o app retorna estado explícito de indisponibilidade; dados de atividade reconciliados não são adicionados automaticamente ao TDEE adaptativo.
- Adicionado importador MET versionado com proveniência consistente e allowlist de licenças redistribuíveis/deriváveis. Catálogos CC BY-NC-ND, comerciais sem autorização, customizados ou sem licença reconhecida são rejeitados.
- Criados scaffolds Android Health Connect e iOS HealthKit. A permissão de leitura em segundo plano é opcional e não é declarada no manifesto padrão. Ambos dependem de um host nativo, UX de permissões, revisão de privacidade e testes físicos; não estão ativos no app React/Vite preview.
- Reforçados testes para equilíbrio de manutenção, direção de ganho/perda, solver numérico, composição corporal adaptativa, reconciliação de duplicatas e conflitos parciais em quarentena, semântica de calorias, importação de catálogo, proveniência de composição e contrato de sync nativo. Idades fracionárias e prazos Hall acima de 10 anos deixam de passar silenciosamente.
- Nenhuma dependência runtime adicionada e nenhum código/dataset copiado dos repositórios analisados.

## Ainda não validado

- O núcleo Hall é uma implementação independente do core publicado de 2011, não o executável oficial NIDDK Body Weight Planner nem uma reprodução certificada de todo o seu pipeline. Carboidratos (45%), sódio estável e RMR são pressupostos quando não há dados individuais.
- O TDEE adaptativo e seus intervalos ainda precisam de backtesting com coortes reais, calorimetria indireta e, para gasto total diário, água duplamente marcada.
- Os scaffolds Kotlin/Swift não foram compilados com Android SDK/Xcode nem testados em aparelhos.
- O XGBoost/feature pipeline de OpenMetabolics não foi portado; faltam auditoria dos direitos de pesos/dados, paridade de features e validação por aparelho.
- O Compendium MET 2024 não foi embarcado; o produto aceita somente catálogo externo com licença permitida e proveniência verificável.
- Build/lint global permanecem dependentes de instalação de `node_modules`; nesta revisão foram executados os testes de revisão e typecheck estrito dos módulos de cálculo sem essas dependências.
