# TITAN — Visual & Interaction Contract V2.0 (V.MAX V7)

## 1. Product direction

**Quiet luxury · anatomical intelligence · measurable performance.**

The product is a body-performance system: anatomy gives spatial understanding, training guides execution, nutrition supports decisions, hydration supports daily behavior, and evolution reports observed measurements. The UI must feel calm, precise and deliberate — never like a sci-fi HUD, a hospital console, a generic admin dashboard, or a fitness-game interface.

The anatomy viewport is the visual protagonist of the cockpit. Energy and macros explain the day's state; workout and hydration give actionable next steps; meal photography and micronutrients provide supporting context. The viewport itself remains visually clean. Its controls and accessible muscle list stay outside the canvas.

## 2. Token hierarchy

1. **Primitive palette** in `src/index.css`: Obsidian, Graphite, Ceramic, Mist, Mineral Sage, Champagne, Mineral Blue, Copper and separate status colors.
2. **Semantic roles**: canvas/surfaces, text, brand accent, data-category colors, status colors, hydration material and focus.
3. **Component roles** in `src/shared/design-system/tokens.ts`: typography, spacing, radius, elevation, motion, touch and viewport dimensions.
4. **3D-only palette** in `src/domains/anatomy/engine/materials/anatomy-materials.ts`; shader/material colors must not be reused as general UI colors.

Do not introduce a raw color in a component if a semantic token exists. Hardcoded colors are permitted only for domain-specific physical fallback shaders, scientific molecular element palettes, or exact material behavior where CSS variables are not a good fit.

## 3. Color semantics

| Role | Purpose | Do not use it for |
|---|---|---|
| Obsidian | Deep canvas and inset areas | Text or active state |
| Graphite surfaces | Elevation and grouping | Status semantics |
| Ceramic | Primary text and dominant values | Large decorative fills |
| Mist | Secondary and supporting text | Disabled controls |
| Mineral Sage | Main identity and primary actions | Every positive status or all chart series |
| Champagne | Brand signature and high-value focus | Macro category, warnings by default, large metallic fills |
| Mineral Blue | Water and informational data | General selection state |
| Copper | Fat macro category / warm technical accent | Error or warning state |
| Success / Warning / Error | Explicit state feedback | Brand decoration |

Color associations are not universal emotional guarantees. Hue, lightness and saturation all matter, and color is subordinate to contrast, context and clear labels. The UI does not rely on color alone to convey progress, correctness or risk.

## 4. Layered surfaces

- `elevation=0`: inset/flat grouped readings and compact KPI tiles; no resting shadow.
- `elevation=1`: resting section or standard card.
- `elevation=2`: active focus area, current plan or the primary anatomy stage.
- `titan-surface--hero`: one main focal surface, not a treatment for every component.
- `titan-surface--inset`: controls, lower-level readings and grouped supporting values.
- Overlays/sheets use a single solid, clearly elevated surface; avoid decorative gradients on every card.

## 5. Typography

- Display: Plus Jakarta Sans, reserved for page headings and main numeric hierarchy.
- Body: DM Sans for readable labels, explanations and action text.
- Mono: JetBrains Mono only for precise numeric measurements, timers, units and aligned values.
- 12px is the normal minimum supporting-text size. 10px is reserved for short uppercase eyebrows/status metadata and should not carry essential instructions.
- Use tabular numerals without forcing all large metrics into a monospaced face.

## 6. Data-category and chart rules

- Protein: Mineral Sage.
- Carbohydrates: Mineral Blue.
- Fat: Copper.
- Energy: Ceramic.
- Hydration: Mineral Blue.
- Status colors express only status. An increase/decrease in a measurement is not automatically good/bad; interpretation requires a goal context.
- Evolution graphs plot stored observations only. No interpolation, smoothing, extrapolation or inferred body-composition conclusions.

## 7. Anatomy rendering rules

- Preserve the existing procedural lofted anatomy, muscle IDs, batching, raycasting layer and demand-render controller.
- The selected muscle is a controlled focal accent; the resting model uses low-saturation mineral materials.
- Avoid neon outlines, repeated scan bands, large light cones and ornamental HUD overlays.
- Keep the one-shot selection sweep short and bounded; respect `prefers-reduced-motion`.
- The contact shadow remains procedural; no shadow-map pass or bloom is introduced.
- Picking ignores invisible layer ancestors and must not trigger on a drag.
- A future licensed anatomical GLB is a separate, evidence-gated asset upgrade, not permission to discard batching or add a huge model by default.

## 8. Motion, interaction and accessibility

- Motion is functional: state change, feedback, transition or focus only.
- Hover/focus microinteractions should be short; ordinary UI transitions stay within 300ms, with reduced-motion alternatives.
- Touch targets target at least 44×44px. Inputs remain at least 16px to avoid mobile browser zoom.
- Keep visible keyboard focus, semantic progress roles, accessible text alternatives for charts and a non-canvas muscle selection path.
- Validate text contrast at 4.5:1 minimum where applicable; chart strokes and large UI graphics use at least 3:1 against adjacent colors where possible.

## 9. Performance guardrails

- No new runtime library is required for this visual pass.
- Keep the shared fluid context, existing demand rendering, reused shader/material resources, merged anatomy geometry and current mobile DPR policy.
- No post-processing stack, full-scene transmission material, continuous idle animation or unbounded canvas loop.
- GPU screenshots and full browser builds are release gates when the GPU/browser test environment is available.
