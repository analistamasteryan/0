export type MainDestination = 'cockpit' | 'cardapio' | 'treino' | 'evolucao';

export type SubViewDestination =
  | null
  | 'active-workout'
  | 'exercise-library'
  | 'profile'
  | 'settings';

export type MuscleGroupId =
  | 'pectoralis'
  | 'anterior_deltoid'
  | 'lateral_deltoid'
  | 'posterior_deltoid'
  | 'biceps'
  | 'triceps'
  | 'forearms'
  | 'abdominals'
  | 'latissimus'
  | 'trapezius'
  | 'glutes'
  | 'quadriceps'
  | 'hamstrings'
  | 'calves';

export type MuscleSide = 'left' | 'right' | 'center';

export interface SelectedMuscleTarget {
  id: MuscleGroupId;
  side: MuscleSide;
}

export interface MuscleHighlightPayload {
  primary: MuscleGroupId[];
  secondary: MuscleGroupId[];
}
