export function formatSecondsClock(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const mins = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function formatKcal(kcal: number): string {
  return new Intl.NumberFormat('pt-BR').format(Math.round(kcal));
}

export function formatMilliliters(ml: number): string {
  return `${new Intl.NumberFormat('pt-BR').format(Math.round(ml))} ml`;
}

export function formatNutrientAmount(value: number, unit: string): string {
  const decimals = value >= 100 ? 0 : value >= 10 ? 1 : 2;
  const formatted = new Intl.NumberFormat('pt-BR', {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  }).format(value);
  return `${formatted} ${unit}`;
}

export function parseLocaleNumber(raw: string | number): number {
  if (typeof raw === 'number') {
    return Number.isFinite(raw) ? raw : Number.NaN;
  }
  const normalized = raw.trim().replace(',', '.');
  if (normalized === '') {
    return Number.NaN;
  }
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : Number.NaN;
}
