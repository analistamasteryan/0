import assert from 'node:assert/strict';
import { createSpringArray, interpolateRatio, stepSpringNodes } from '../fluid-shader-engine';

const wave = createSpringArray(24);
assert.equal(wave.length, 24);
assert.ok(wave.every((node) => node.height === 0 && node.velocity === 0));
const center = wave[12];
assert.ok(center);
center.velocity = -3.4;

for (let i = 0; i < 240; i++) {
  stepSpringNodes(wave, 0.12, 0.2, 0.14);
}

assert.ok(wave.every((node) => Number.isFinite(node.height) && Number.isFinite(node.velocity)));
assert.ok(wave.every((node) => Math.abs(node.height) < 0.02));
assert.ok(wave.every((node) => Math.abs(node.velocity) < 0.02));

const symmetric = createSpringArray(25);
const impulse = symmetric[12];
assert.ok(impulse);
impulse.velocity = -2.5;
for (let i = 0; i < 180; i++) stepSpringNodes(symmetric, 0.12, 0.2, 0.14);
for (let i = 0; i < 12; i++) {
  assert.ok(Math.abs((symmetric[i]?.height ?? 0) - (symmetric[24 - i]?.height ?? 0)) < 1e-6);
}
console.log('Fluid spring assertions passed.');

const settleAt60Hz = Array.from({ length: 60 }, (_, index) => index).reduce<number>((value) => interpolateRatio(value, 1, 1 / 60), 0);
const settleAt30Hz = Array.from({ length: 30 }, (_, index) => index).reduce<number>((value) => interpolateRatio(value, 1, 1 / 30), 0);
assert.ok(Math.abs(settleAt60Hz - settleAt30Hz) < 1e-9, 'progress interpolation must be frame-rate independent');
assert.ok(interpolateRatio(0.4, 0.8, 0.05) > 0.4);
assert.ok(interpolateRatio(0.8, 0.4, 0.05) < 0.8);
assert.equal(interpolateRatio(0.9998, 1, 1 / 60), 1, 'tiny residuals should settle exactly');
const nearTarget = interpolateRatio(0.9993, 1, 0.05, 0.14);
assert.equal(nearTarget, 1, 'the frame that crosses the settle threshold must snap to the target');
console.log('Progress interpolation assertions passed.');
