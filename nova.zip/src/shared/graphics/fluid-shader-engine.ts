// Shared single-context WebGL2 liquid renderer.
// Research references adapted in this implementation:
// - mrdoob/three.js physical shader chunks: anisotropic GGX visibility/distribution for satin metal.
// - evanw/webgl-water and HowdyKeith/swek-webgl2-water: Fresnel, refraction,
//   height-field ripples and differential-area caustics.
// - Aureliengmz/clearwater: compact WebGL2 optics, absorption and clean highlights.
// - pmndrs/drei MeshTransmissionMaterial: IOR, thickness and Beer-Lambert attenuation.
// - StarKnightt/liquid-glass and smirki/glasswork: SDF silhouettes, refraction normals
//   and bounded edge/rim optics.
// This is a small UI liquid volume, not an ocean/SPH simulation. Static water is
// rendered once; the shared RAF wakes only for a fill transition or a single impulse.

export interface SpringNode {
  height: number;
  velocity: number;
}

export interface WaterOpticalConfig {
  ior: number;
  fresnelR0: number;
  attenuationColor: [number, number, number];
  attenuationDistance: number;
  esrIntensity: number;
  causticIntensity: number;
  footprintFilter: boolean;
}

export const DEFAULT_WATER_OPTICAL_CONFIG: WaterOpticalConfig = {
  ior: 1.333,
  fresnelR0: 0.020,
  attenuationColor: [0.82, 0.975, 1.0],
  attenuationDistance: 2.65,
  esrIntensity: 1.18,
  causticIntensity: 1.08,
  footprintFilter: true,
};


let reducedMotionQueryCache: MediaQueryList | null = null;

export function prefersReducedMotion(): boolean {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return false;
  reducedMotionQueryCache ??= window.matchMedia('(prefers-reduced-motion: reduce)');
  return reducedMotionQueryCache.matches;
}

export function createSpringArray(count: number): SpringNode[] {
  return Array.from({ length: count }, () => ({ height: 0, velocity: 0 }));
}

/** Exponential interpolation keeps progress transitions consistent at 30/60/120Hz. */
export function interpolateRatio(
  current: number,
  target: number,
  elapsedSeconds: number,
  timeConstantSeconds = 0.14,
): number {
  const delta = target - current;
  if (!Number.isFinite(delta) || Math.abs(delta) <= 0.0005) return target;
  const dt = Math.min(0.05, Math.max(0, Number.isFinite(elapsedSeconds) ? elapsedSeconds : 0));
  const timeConstant = Math.max(
    0.001,
    Number.isFinite(timeConstantSeconds) ? timeConstantSeconds : 0.14,
  );
  const next = current + delta * (1 - Math.exp(-dt / timeConstant));
  // Snap on the same frame that crosses the threshold so the final target is actually painted.
  return Math.abs(target - next) <= 0.0005 ? target : next;
}

const springScratch = new WeakMap<SpringNode[], { left: Float32Array; right: Float32Array }>();

export function stepSpringNodes(
  nodes: SpringNode[],
  tension: number,
  damping: number,
  spread: number,
): void {
  const n = nodes.length;
  for (let i = 0; i < n; i++) {
    const node = nodes[i];
    if (!node) continue;
    const force = -tension * node.height - node.velocity * damping;
    node.velocity += force;
    node.height += node.velocity;
  }

  let scratch = springScratch.get(nodes);
  if (!scratch || scratch.left.length !== n) {
    scratch = { left: new Float32Array(n), right: new Float32Array(n) };
    springScratch.set(nodes, scratch);
  }
  const { left: leftDeltas, right: rightDeltas } = scratch;

  for (let pass = 0; pass < 2; pass++) {
    for (let i = 0; i < n; i++) {
      const curr = nodes[i];
      if (!curr) continue;
      const prev = i > 0 ? nodes[i - 1] : undefined;
      const next = i < n - 1 ? nodes[i + 1] : undefined;

      if (prev) {
        const d = spread * (curr.height - prev.height);
        leftDeltas[i] = d;
        prev.velocity += d;
      }
      if (next) {
        const d = spread * (curr.height - next.height);
        rightDeltas[i] = d;
        next.velocity += d;
      }
    }

    for (let i = 0; i < n; i++) {
      const prev = i > 0 ? nodes[i - 1] : undefined;
      const next = i < n - 1 ? nodes[i + 1] : undefined;
      if (prev) prev.height += leftDeltas[i] ?? 0;
      if (next) next.height += rightDeltas[i] ?? 0;
    }
  }
}

export type FluidProgramKind = 'droplet' | 'tank' | 'energy' | 'metal';

const MIN_FLUID_FRAME_INTERVAL_MS = 1000 / 60;

export interface FluidDrawJob {
  kind: FluidProgramKind;
  targetCanvas: HTMLCanvasElement;
  width: number;
  height: number;
  fill: number;
  active?: boolean;
  isAnimating?: boolean;
  wave?: SpringNode[];
  opticalConfig?: Partial<WaterOpticalConfig>;
  metalColor?: [number, number, number];
  metalHighlight?: [number, number, number];
  isVisible: boolean;
}

const VERTEX_SHADER_300 = `#version 300 es
in vec2 a_position;
out vec2 v_uv;
void main() {
  v_uv = a_position * 0.5 + 0.5;
  gl_Position = vec4(a_position, 0.0, 1.0);
}
`;

// Utilitários ópticos em espaço linear HDR + ACES Filmic + derivadas hardware para projeção de cáusticas
const SHARED_OPTICS_GLSL = `
float invSmooth(float lo, float hi, float x) {
  return 1.0 - smoothstep(lo, hi, x);
}

vec3 acesFilmic(vec3 x) {
  float a = 2.51;
  float b = 0.03;
  float c = 2.43;
  float d = 0.59;
  float e = 0.14;
  return clamp((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0);
}

vec3 linearToSrgb(vec3 c) {
  vec3 linear = max(c, vec3(0.0));
  vec3 low = linear * 12.92;
  vec3 high = 1.055 * pow(linear, vec3(1.0 / 2.4)) - 0.055;
  return mix(high, low, lessThanEqual(linear, vec3(0.0031308)));
}

float distributionGGX(float nDotH, float roughness) {
  float a = max(roughness * roughness, 0.0025);
  float a2 = a * a;
  float n2 = nDotH * nDotH;
  float denom = n2 * (a2 - 1.0) + 1.0;
  return a2 / max(3.14159265 * denom * denom, 1e-5);
}

float geometrySchlickGGX(float nDotV, float roughness) {
  float r = roughness + 1.0;
  float k = (r * r) * 0.125;
  return nDotV / max(nDotV * (1.0 - k) + k, 1e-5);
}

vec3 fresnelSchlick(float cosTheta, vec3 f0) {
  float f = pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);
  return f0 + (1.0 - f0) * f;
}

vec3 evaluateGGXSpecular(vec3 normal, vec3 viewDir, vec3 lightDir, vec3 f0, float roughness) {
  vec3 n = normalize(normal);
  vec3 v = normalize(viewDir);
  vec3 l = normalize(lightDir);
  vec3 h = normalize(v + l);
  float nDotV = max(dot(n, v), 1e-4);
  float nDotL = max(dot(n, l), 0.0);
  float nDotH = max(dot(n, h), 0.0);
  float vDotH = max(dot(v, h), 0.0);
  float d = distributionGGX(nDotH, roughness);
  float g = geometrySchlickGGX(nDotV, roughness) * geometrySchlickGGX(nDotL, roughness);
  vec3 f = fresnelSchlick(vDotH, f0);
  return (d * g * f * nDotL) / max(4.0 * nDotV * nDotL, 1e-4);
}

float softboxRect(vec3 direction, vec3 centerDirection, vec2 halfSize, float softness) {
  vec3 center = normalize(centerDirection);
  vec3 referenceUp = abs(center.y) > 0.94 ? vec3(0.0, 0.0, 1.0) : vec3(0.0, 1.0, 0.0);
  vec3 axisU = normalize(cross(referenceUp, center));
  vec3 axisV = normalize(cross(center, axisU));
  float forward = max(dot(direction, center), 1e-3);
  vec2 panelUv = vec2(dot(direction, axisU), dot(direction, axisV)) / forward;
  float edge = max(abs(panelUv.x) / max(halfSize.x, 1e-3), abs(panelUv.y) / max(halfSize.y, 1e-3));
  return 1.0 - smoothstep(1.0 - softness, 1.0 + softness, edge);
}

// Anisotropic GGX keeps the macro reflections stretched along the liquid-metal flow.
// The tangent follows the arc; the bitangent closes a stable local shading frame.
float visibilityGGXSmithAnisotropic(
  float alphaT,
  float alphaB,
  float dotTV,
  float dotBV,
  float dotTL,
  float dotBL,
  float dotNV,
  float dotNL
) {
  float gv = dotNL * length(vec3(alphaT * dotTV, alphaB * dotBV, dotNV));
  float gl = dotNV * length(vec3(alphaT * dotTL, alphaB * dotBL, dotNL));
  return 0.5 / max(gv + gl, 1e-5);
}

float distributionGGXAnisotropic(
  float alphaT,
  float alphaB,
  float nDotH,
  float tDotH,
  float bDotH
) {
  float a2 = alphaT * alphaB;
  vec3 v = vec3(alphaB * tDotH, alphaT * bDotH, a2 * nDotH);
  float v2 = max(dot(v, v), 1e-6);
  float w2 = a2 / v2;
  return (a2 * w2 * w2) / 3.14159265;
}

vec3 evaluateGGXAnisotropicSpecular(
  vec3 normal,
  vec3 tangent,
  vec3 viewDir,
  vec3 lightDir,
  vec3 f0,
  float roughness,
  float anisotropy
) {
  vec3 n = normalize(normal);
  vec3 t = normalize(tangent - n * dot(n, tangent));
  vec3 b = normalize(cross(n, t));
  vec3 v = normalize(viewDir);
  vec3 l = normalize(lightDir);
  vec3 h = normalize(v + l);

  float nDotV = max(dot(n, v), 1e-4);
  float nDotL = max(dot(n, l), 0.0);
  float nDotH = max(dot(n, h), 0.0);
  float vDotH = max(dot(v, h), 0.0);
  float alpha = max(roughness * roughness, 0.0025);
  float alphaT = max(alpha * (1.0 - clamp(anisotropy, 0.0, 0.7)), 0.0025);
  float alphaB = max(alpha * (1.0 + clamp(anisotropy, 0.0, 0.7)), 0.0025);

  float visibility = visibilityGGXSmithAnisotropic(
    alphaT, alphaB,
    dot(t, v), dot(b, v),
    dot(t, l), dot(b, l),
    nDotV, nDotL
  );
  float distribution = distributionGGXAnisotropic(
    alphaT, alphaB, nDotH, dot(t, h), dot(b, h)
  );
  vec3 fresnel = fresnelSchlick(vDotH, f0);
  return fresnel * (visibility * distribution) * nDotL;
}

float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}


float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}

float fbm3(vec2 st) {
  float val = 0.0;
  float amp = 0.5;
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  for (int i = 0; i < 3; i++) {
    val += amp * valueNoise(st);
    st = rot * st * 2.02 + vec2(1.7, 3.1);
    amp *= 0.5;
  }
  return val;
}

// Cascata Gerstner com derivadas analíticas + micro-ondulação capilar
void evalGerstnerCascade(
  vec2 pos,
  float t,
  float footprintScale,
  out float heightOut,
  out vec2 gradOut,
  out float causticFocusOut
) {
  heightOut = 0.0;
  gradOut = vec2(0.0);
  float laplacian = 0.0;

  vec4 waves[4];
  waves[0] = vec4(1.25, 0.018, 0.89, 0.45);
  waves[1] = vec4(0.70, 0.011, -0.74, 0.67);
  waves[2] = vec4(0.36, 0.007, 0.48, -0.88);
  waves[3] = vec4(0.19, 0.0035, -0.92, -0.38);

  for (int i = 0; i < 4; i++) {
    float L = waves[i].x;
    float A = waves[i].y;
    vec2 dir = normalize(waves[i].zw);
    float fade = mix(1.0, smoothstep(0.04, 0.30, L), footprintScale);
    float k = 6.283185 / L;
    float c = sqrt(9.81 / k) * 0.48;
    float phase = k * dot(dir, pos) - c * t * 1.35;
    float amp = A * fade;
    float s = sin(phase);
    heightOut += amp * s;
    gradOut += dir * (amp * k * cos(phase));
    laplacian += amp * k * k * s;
  }

  causticFocusOut = clamp(0.5 + laplacian * 0.34, 0.0, 1.5);
}

// Ambiente analítico procedural de estúdio em espaço linear (não é uma textura HDRI).
vec3 sampleStudioEnvironment(vec3 dir, vec3 skyTint) {
  vec3 d = normalize(dir);
  float elev = d.y;
  float az = atan(d.x, d.z);

  // Chão escuro obsidiana + horizonte neutro frio + cúpula celeste clara
  vec3 floorCol = vec3(0.012, 0.022, 0.028);
  vec3 wallCol = vec3(0.045, 0.078, 0.095);
  vec3 horizonCol = mix(wallCol, skyTint * 0.24, 0.45);
  vec3 skyCol = mix(horizonCol, vec3(0.76, 0.90, 0.98), smoothstep(0.0, 0.88, elev));

  vec3 env = elev < 0.0
    ? mix(floorCol, horizonCol * 0.65, smoothstep(-0.65, 0.0, elev))
    : skyCol;

  // Painéis retangulares de estúdio: highlights alongados, não pontos circulares artificiais.
  float stripLeft = softboxRect(d, vec3(-0.56, 0.66, 0.50), vec2(0.13, 0.48), 0.10);
  float stripRight = softboxRect(d, vec3(0.62, 0.38, 0.68), vec2(0.11, 0.40), 0.12);
  float overhead = softboxRect(d, vec3(-0.15, 0.95, 0.27), vec2(0.34, 0.12), 0.12);
  float rimArc = exp(-pow((elev - 0.14) * 11.0, 2.0)) * (0.4 + 0.6 * cos(az * 2.0));

  env += vec3(2.40, 2.50, 2.60) * stripLeft;
  env += skyTint * 1.15 * stripRight;
  env += vec3(3.10, 3.20, 3.30) * overhead;
  env += vec3(0.90, 1.05, 1.15) * rimArc * 0.55;
  return env;
}

// Ambiente analítico iluminado para refração em água cristalina (luz de bancada/cáustica + cúpula celeste)
vec3 sampleWaterStudioEnvironment(vec3 dir, vec3 skyTint) {
  vec3 d = normalize(dir);
  float elev = d.y;
  float az = atan(d.x, d.z);

  vec3 floorBounce = vec3(0.04, 0.20, 0.28);
  vec3 wallCol = vec3(0.08, 0.30, 0.42);
  vec3 horizonCol = mix(wallCol, skyTint * 0.52, 0.62);
  vec3 skyCol = mix(horizonCol, vec3(0.94, 0.99, 1.0), smoothstep(-0.02, 0.78, elev));

  vec3 env = elev < 0.0
    ? mix(floorBounce, horizonCol * 0.86, smoothstep(-0.78, 0.0, elev))
    : skyCol;

  float stripLeft = softboxRect(d, vec3(-0.50, 0.72, 0.48), vec2(0.11, 0.54), 0.05);
  float stripRight = softboxRect(d, vec3(0.64, 0.38, 0.66), vec2(0.09, 0.48), 0.07);
  float overhead = softboxRect(d, vec3(-0.10, 0.96, 0.26), vec2(0.44, 0.12), 0.07);
  float tableBounce = softboxRect(d, vec3(0.05, -0.76, 0.64), vec2(0.50, 0.16), 0.14);
  float rimArc = exp(-pow((elev - 0.08) * 12.0, 2.0)) * (0.45 + 0.55 * cos(az * 2.0));

  env += vec3(3.75, 3.85, 3.95) * stripLeft;
  env += skyTint * 1.85 * stripRight;
  env += vec3(4.10, 4.20, 4.30) * overhead;
  env += vec3(0.52, 1.08, 1.30) * tableBounce * 0.72;
  env += vec3(1.15, 1.48, 1.62) * rimArc * 0.84;
  return env;
}

// Parede traseira óptica gravada vista por refração real através do volume de água
vec3 sampleOpticalCavityWall(vec2 refrPos, vec2 scaleGrid, float depthFade) {
  float majorY = invSmooth(0.0, 0.022, abs(fract(refrPos.y * scaleGrid.y) - 0.5));
  float minorX = invSmooth(0.0, 0.018, abs(fract(refrPos.x * scaleGrid.x) - 0.5));
  vec3 etched = vec3(0.026, 0.078, 0.105);
  etched += vec3(0.16, 0.36, 0.46) * majorY * 0.38;
  etched += vec3(0.10, 0.25, 0.34) * minorX * 0.20;
  return etched * mix(0.62, 1.24, clamp(depthFade, 0.0, 1.0));
}

// Cáustica por área diferencial projetada (evanw/webgl-water: dFdx / dFdy)
float computeDifferentialCaustic(vec2 basePos, vec2 refrPos) {
  float detBase = abs(dFdx(basePos.x) * dFdy(basePos.y) - dFdx(basePos.y) * dFdy(basePos.x));
  float detRefr = abs(dFdx(refrPos.x) * dFdy(refrPos.y) - dFdx(refrPos.y) * dFdy(refrPos.x));
  float ratio = detBase / max(detRefr, max(detBase * 0.11, 1e-6));
  return clamp(pow(ratio, 1.80) - 0.48, 0.0, 4.8);
}

// Bolha de oxigênio microscópica com borda Fresnel e reflexo especular pontual
float evalMicroBubble(vec2 p, vec2 center, float radius) {
  vec2 d = p - center;
  float r = length(d);
  float mask = invSmooth(radius * 0.85, radius * 1.15, r);
  float rim = exp(-pow((r - radius * 0.78) / max(radius * 0.24, 0.0005), 2.0));
  float glint = invSmooth(0.0, radius * 0.48, length(d - vec2(-radius * 0.30, radius * 0.32)));
  return mask * (rim * 0.65 + glint * 1.45);
}

// Atenuação volumétrica exponencial Beer-Lambert (linear)
vec3 applyBeerLambert(vec3 bgLinear, vec3 attenColor, float attenDist, float opticalDepth) {
  vec3 sigma = -log(max(attenColor, vec3(0.005))) / max(attenDist, 0.05);
  return bgLinear * exp(-sigma * max(opticalDepth, 0.0));
}
`;

// 1. Gota 3D de cristal com refração dupla, parede gravada ampliada pela lente de água, TIR real, cáusticas dFdx/dFdy e dispersão RGB
const DROPLET_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform float u_active;
uniform float u_ior;
uniform float u_fresnelR0;
uniform vec3 u_attenColor;
uniform float u_attenDist;
uniform float u_esrIntensity;
uniform float u_causticIntensity;
uniform float u_footprint;
uniform float u_wave[24];

${SHARED_OPTICS_GLSL}

float sdRoundedCone(vec2 p, vec2 a, vec2 b, float r1, float r2) {
  vec2 ba = b - a;
  float l2 = dot(ba, ba);
  float rr = r1 - r2;
  float a2 = l2 - rr * rr;
  float il2 = 1.0 / l2;

  vec2 pa = p - a;
  float y = dot(pa, ba);
  float z = y - l2;
  vec2 proj = pa * l2 - ba * y;
  float x2 = dot(proj, proj);
  float y2 = y * y * l2;
  float z2 = z * z * l2;

  float k = sign(rr) * rr * rr * x2;
  if (sign(z) * a2 * z2 > k) return sqrt(x2 + z2) * il2 - r2;
  if (sign(y) * a2 * y2 < k) return sqrt(x2 + y2) * il2 - r1;
  return (sqrt(x2 * a2 * il2) + y * rr) * il2 - r1;
}

float sdDroplet(vec2 p) {
  return sdRoundedCone(p, vec2(0.0, -0.155), vec2(0.0, 0.435), 0.305, 0.015);
}

float sampleWaveSpring(float u) {
  float idx = clamp(u, 0.0, 1.0) * 23.0;
  int i0 = clamp(int(floor(idx)), 0, 23);
  int i1 = min(23, i0 + 1);
  return mix(u_wave[i0], u_wave[i1], fract(idx));
}

// Refração dupla através do volume 3D + parede traseira curva com escala refratada, ambiente luminoso e cáusticas focadas
vec3 traceDropletRay(
  vec2 p,
  vec3 enterN,
  vec3 backN,
  vec3 viewDir,
  float etaIn,
  float etaOut,
  float travelDepth,
  float inWater,
  float causticTerm
) {
  vec3 ray1 = refract(-viewDir, enterN, etaIn);
  if (dot(ray1, ray1) < 0.001) {
    return sampleWaterStudioEnvironment(reflect(-viewDir, enterN), vec3(0.74, 0.95, 1.0));
  }

  vec3 ray2 = refract(ray1, -backN, etaOut);
  vec2 rearHit = p + ray1.xy * (0.09 + travelDepth * 0.24) + ray2.xy * 0.14;
  vec3 cavityDetail = sampleOpticalCavityWall(rearHit, vec2(6.0, 11.0), travelDepth);

  if (dot(ray2, ray2) < 0.001) {
    vec3 tirDir = reflect(ray1, -backN);
    vec3 tirEnv = sampleWaterStudioEnvironment(tirDir, vec3(0.72, 0.95, 1.0));
    return tirEnv * 0.88 + cavityDetail * 0.25 + vec3(0.80, 0.98, 1.0) * causticTerm * inWater * 0.86;
  }

  vec3 envCol = sampleWaterStudioEnvironment(ray2, vec3(0.58, 0.91, 1.0));
  vec3 reflectedBack = sampleWaterStudioEnvironment(reflect(ray1, -backN), vec3(0.80, 0.96, 1.0));
  float exitCos = clamp(abs(dot(ray1, -backN)), 0.0, 1.0);
  float exitR0 = pow((etaOut - 1.0) / max(etaOut + 1.0, 1e-3), 2.0);
  float exitFresnel = exitR0 + (1.0 - exitR0) * pow(1.0 - exitCos, 5.0);
  vec3 backInterface = mix(envCol, reflectedBack, clamp(exitFresnel * 0.85, 0.0, 0.82));
  vec3 refractedWall = mix(cavityDetail, backInterface, 0.78 + 0.16 * smoothstep(-0.45, 0.55, ray2.y));
  vec3 aquaDepth = mix(vec3(0.032, 0.20, 0.29), refractedWall * 1.02, smoothstep(-0.50, 0.55, ray2.y));
  vec3 backdrop = mix(refractedWall * 0.42, aquaDepth, inWater);
  backdrop += vec3(0.88, 0.99, 1.0) * causticTerm * inWater * clamp(0.54 + travelDepth * 1.65, 0.0, 1.85);
  return backdrop;
}

void main() {
  float aspect = u_resolution.x / max(u_resolution.y, 1.0);
  vec2 p = vec2((v_uv.x - 0.5) * aspect, v_uv.y - 0.5);

  float d = sdDroplet(p);
  float aa = 1.4 / max(min(u_resolution.x, u_resolution.y), 1.0);
  if (d > 0.04) {
    fragColor = vec4(0.0);
    return;
  }

  // Normal 3D C1-contínua verdadeira ao longo da superfície de revolução da gota
  vec2 eps = vec2(0.0035, 0.0);
  vec2 grad = vec2(sdDroplet(p + eps.xy) - sdDroplet(p - eps.xy),
                   sdDroplet(p + eps.yx) - sdDroplet(p - eps.yx)) / (2.0 * eps.x);
  float localR = mix(0.018, 0.305, (1.0 - smoothstep(-0.155, 0.435, p.y)));
  float zNorm = sqrt(max(0.0, (-d) * (2.0 * localR + d))) / max(localR, 0.02);
  vec3 glassN = normalize(vec3(grad * (1.0 - zNorm * 0.35), max(0.04, zNorm)));
  vec3 backN = normalize(vec3(grad * 0.85, -max(0.08, zNorm)));

  float fillY = mix(-0.43, 0.37, clamp(u_fill, 0.0, 1.0));
  float uX = clamp((p.x + 0.31) / 0.62, 0.0, 1.0);
  float springH = sampleWaveSpring(uX) * 0.022;
  float waveEnergy = clamp(abs(springH) * 58.0, 0.0, 1.0);
  float gerstH = 0.0;
  vec2 gerstGrad = vec2(0.0);
  float causticFocus = 0.0;
  if (u_fill > 0.004) {
    evalGerstnerCascade(vec2(p.x * 2.8, p.y * 2.0), u_time, u_footprint, gerstH, gerstGrad, causticFocus);
    float capPhase = p.x * 28.0 - u_time * 5.8;
    gerstH += sin(capPhase) * (0.0014 + 0.0028 * waveEnergy);
    gerstGrad.x += cos(capPhase) * (0.022 + 0.055 * waveEnergy);
  }

  // Menisco capilar aderido às paredes internas do cristal
  float wallProximity = smoothstep(-0.11, -0.002, d);
  float meniscusLift = wallProximity * 0.032 * step(0.02, u_fill) * step(u_fill, 0.98);
  float frontY = fillY + springH + gerstH * 0.72 + meniscusLift;

  // Plano elíptico 2.5D da superfície superior da água
  float ellipseH = 0.054 * step(0.03, u_fill) * step(u_fill, 0.97) * invSmooth(0.16, 0.32, abs(p.x));
  float backY = frontY + ellipseH;
  float inTopPlane = smoothstep(frontY - 0.0045, frontY + 0.0045, p.y) *
                     invSmooth(backY - 0.0045, backY + 0.0045, p.y) *
                     step(0.02, u_fill);

  float depthBelow = backY - p.y;
  float inWater = smoothstep(-0.005, 0.005, depthBelow) * step(0.004, u_fill);

  vec3 planeN = normalize(vec3(-gerstGrad.x * 2.1, 0.74 - gerstGrad.y * 1.25, 0.55));
  vec3 waveBodyN = normalize(vec3(glassN.x - gerstGrad.x * 0.28, glassN.y - gerstGrad.y * 0.18, glassN.z));
  vec3 waterN = normalize(mix(waveBodyN, planeN, inTopPlane * 0.92));
  vec3 activeN = mix(glassN, waterN, inWater);

  // Foco de cáustica física por área diferencial dFdx/dFdy + lente inferior da gota
  vec3 keyLight = normalize(vec3(-0.36, 0.86, 0.35));
  float causticTerm = 0.0;
  if (u_fill > 0.004) {
    vec3 refrLight = refract(-keyLight, waterN, 1.0 / max(u_ior, 1.01));
    float throwDist = clamp(depthBelow * 0.92 + zNorm * 0.28, 0.02, 0.74);
    vec2 floorHit = p + refrLight.xy * throwDist;
    float jacCaustic = computeDifferentialCaustic(p, floorHit);
    float waveFocus = clamp(0.80 + causticFocus * 0.34, 0.58, 1.28);
    float bottomLens = (1.0 - smoothstep(-0.44, -0.14, p.y)) * 0.82 + 0.42;
    causticTerm = jacCaustic * waveFocus * u_causticIntensity * bottomLens;
  }

  vec3 viewDir = normalize(vec3(0.0, -0.22, 0.975));

  // Dispersão cromática RGB real (IOR separado por canal R, G, B)
  float curIor = mix(1.50, u_ior, inWater);
  float disp = mix(0.0014, 0.0042, inWater);
  float etaInR = 1.0 / max(curIor - disp, 1.02);
  float etaInG = 1.0 / max(curIor, 1.02);
  float etaInB = 1.0 / max(curIor + disp, 1.02);

  vec3 tracedCol;
  if (u_fill > 0.004) {
    tracedCol = vec3(
      traceDropletRay(p, activeN, backN, viewDir, etaInR, curIor - disp, zNorm, inWater, causticTerm).r,
      traceDropletRay(p, activeN, backN, viewDir, etaInG, curIor, zNorm, inWater, causticTerm).g,
      traceDropletRay(p, activeN, backN, viewDir, etaInB, curIor + disp, zNorm, inWater, causticTerm).b
    );
  } else {
    tracedCol = traceDropletRay(p, activeN, backN, viewDir, 1.0 / 1.50, 1.50, zNorm, 0.0, 0.0);
  }

  // Atenuação Beer-Lambert cristalina: centro claro translúcido, bordas aqua luminosas
  float opticalPath = clamp(depthBelow * 0.48 + (1.0 - zNorm) * 0.34, 0.0, 1.0);
  vec3 beerCol = applyBeerLambert(tracedCol, u_attenColor, u_attenDist, opticalPath);
  vec3 waterBody = mix(tracedCol, beerCol, inWater);

  // Crescente cáustico interno no fundo curvo da gota (refração de lente convergente)
  float bottomLensArc = exp(-pow((length(p - vec2(0.018, -0.175)) - 0.215) * 15.0, 2.0)) * smoothstep(-0.34, -0.16, -p.y);
  waterBody += vec3(0.72, 0.98, 1.0) * bottomLensArc * inWater * 0.68;

  // Micro-bolhas de oxigênio submersas reais (borda Fresnel + brilho especular) subindo suavemente
  if (inWater > 0.08 && u_fill > 0.06) {
    float liftA = fract(u_time * 0.14);
    float liftB = fract(u_time * 0.11 + 0.48);
    float liftC = fract(u_time * 0.17 + 0.77);
    float spanH = max(0.06, frontY - (-0.42));
    float y1 = -0.40 + liftA * spanH * 0.85;
    float y2 = -0.38 + liftB * spanH * 0.82;
    float y3 = -0.36 + liftC * spanH * 0.78;
    float bubbles =
      evalMicroBubble(p, vec2(-0.085 + sin(u_time * 1.4) * 0.012, y1), 0.011) +
      evalMicroBubble(p, vec2(0.11 + cos(u_time * 1.7) * 0.010, y2), 0.009) +
      evalMicroBubble(p, vec2(0.018 + sin(u_time * 1.9 + 1.4) * 0.008, y3), 0.0075) +
      evalMicroBubble(p, vec2(-0.035, fillY - 0.075), 0.0065) * 0.8;
    waterBody += vec3(1.15, 1.52, 1.72) * bubbles * inWater * (1.0 - inTopPlane) * 0.42;
  }

  // Fresnel físico Schlick na interface frontal + reflexão do ambiente de estúdio
  float cosTheta = clamp(dot(activeN, viewDir), 0.0, 1.0);
  float r0 = mix(0.044, u_fresnelR0, inWater);
  float fresnel = r0 + (1.0 - r0) * pow(1.0 - cosTheta, 5.0);
  vec3 envRefl = sampleWaterStudioEnvironment(reflect(-viewDir, activeN), vec3(0.80, 0.96, 1.0));
  vec3 col = mix(waterBody, envRefl, clamp(fresnel * u_esrIntensity * mix(0.80, 1.0, u_active), 0.0, 0.96));

  // Brilho especular GGX ultra-nítido na superfície molhada + janela de Snell no topo elíptico
  if (inTopPlane > 0.04) {
    vec3 waterSpecular = evaluateGGXSpecular(planeN, viewDir, keyLight, vec3(u_fresnelR0), 0.0085);
    col += waterSpecular * vec3(4.5, 4.7, 4.85) * inTopPlane;
    col = mix(col, vec3(0.86, 0.99, 1.0), inTopPlane * (0.32 + 0.14 * waveEnergy));
  }

  // Menisco frontal luminoso + fina sombra de refração TIR logo abaixo da linha d'água
  float frontLip = invSmooth(0.0, 0.0075, abs(p.y - frontY)) * step(0.02, u_fill);
  float underMeniscusShadow = invSmooth(0.0, 0.015, abs(p.y - (frontY - 0.0095))) * step(0.02, u_fill);
  col *= 1.0 - underMeniscusShadow * 0.46;
  col += vec3(2.35, 2.52, 2.64) * frontLip * 1.05;

  // Gotículas micro-condensadas sutis na parte interna superior seca do cristal
  float dewCell = valueNoise(p * 34.0 + vec2(3.1, 7.4));
  float dewSpec = smoothstep(0.84, 0.96, dewCell) * (1.0 - inWater) * smoothstep(-0.3, 0.1, zNorm);
  col += vec3(1.30, 1.56, 1.70) * dewSpec * 0.30;

  // Dupla parede refrativa de vidro borossilicato + highlights de estúdio
  float innerWallRim = exp(-pow((d + 0.017) * 165.0, 2.0));
  col += vec3(0.82, 0.98, 1.08) * innerWallRim * mix(0.24, 0.48, inWater);

  float glassStreak = invSmooth(0.004, 0.062, length(p - vec2(-0.105, 0.108)));
  float longSoftbox = exp(-pow((p.x + 0.205) * 22.0, 2.0)) *
                      smoothstep(-0.26, -0.12, p.y) *
                      invSmooth(0.17, 0.39, p.y);
  float lowerSoftbox = exp(-pow((p.x - 0.205) * 24.0, 2.0)) *
                       smoothstep(-0.28, -0.12, p.y) *
                       invSmooth(0.10, 0.30, p.y);
  col += vec3(2.18, 2.32, 2.45) * glassStreak * 0.36;
  col += vec3(1.82, 2.02, 2.16) * longSoftbox * 0.34;
  col += vec3(0.95, 1.34, 1.52) * lowerSoftbox * 0.22;

  // Contorno refrativo natural (Fresnel no limite da gota)
  float rimGlow = invSmooth(0.001, 0.012, abs(d));
  vec3 rimTint = mix(vec3(0.48, 0.84, 0.96), vec3(1.80, 2.02, 2.14), clamp(0.55 - p.x + p.y * 0.4, 0.0, 1.0));
  col = mix(col, rimTint, rimGlow * mix(0.70, 0.96, u_active));

  col = linearToSrgb(acesFilmic(col));

  float shapeMask = invSmooth(-aa, aa, d);
  float glassAlpha = clamp(mix(0.36, 0.90, inWater) + fresnel * 0.58 + rimGlow * 0.48 + glassStreak * 0.20, 0.0, 1.0);
  float alpha = shapeMask * glassAlpha;
  fragColor = vec4(col * alpha, alpha);
}
`;

// 2. Tubo capilar de cristal 3D preenchido com água transparente contínua, escala refratada, menisco côncavo e lente cilíndrica
const TANK_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform float u_ior;
uniform float u_fresnelR0;
uniform vec3 u_attenColor;
uniform float u_attenDist;
uniform float u_esrIntensity;
uniform float u_causticIntensity;
uniform float u_footprint;
uniform float u_wave[24];

${SHARED_OPTICS_GLSL}

float sampleTankWave(float u) {
  float idx = clamp(u, 0.0, 1.0) * 23.0;
  int i0 = clamp(int(floor(idx)), 0, 23);
  int i1 = min(23, i0 + 1);
  return mix(u_wave[i0], u_wave[i1], fract(idx));
}

void main() {
  float aspect = u_resolution.x / max(u_resolution.y, 1.0);
  vec2 uv = v_uv;
  vec2 p = vec2(uv.x * aspect, uv.y);
  float t = u_time;

  float fill = clamp(u_fill, 0.0, 1.0);
  float cylY = clamp((uv.y - 0.5) * 1.92, -0.96, 0.96);
  float cylZ = sqrt(max(0.06, 1.0 - cylY * cylY));

  float meniscusSlosh = sampleTankWave(clamp(fill, 0.0, 1.0)) * 0.022;
  float waveEnergy = clamp(abs(meniscusSlosh) * 52.0, 0.0, 1.0);
  float gerstH = 0.0;
  vec2 gerstGrad = vec2(0.0);
  float causticFocus = 0.0;
  if (fill > 0.004) {
    evalGerstnerCascade(vec2(p.x * 1.45, p.y * 1.95), t, u_footprint, gerstH, gerstGrad, causticFocus);
    float capX = p.x * 18.0 - t * 5.2;
    gerstH += sin(capX) * (0.0014 + 0.003 * waveEnergy);
    gerstGrad.x += cos(capX) * (0.022 + 0.048 * waveEnergy);
  }

  // Menisco aderido à parede do tubo + ondulação física
  float wallWetCurve = 0.024 * pow(abs(cylY), 2.3);
  float waterEnd = fill + (wallWetCurve + meniscusSlosh + gerstH * 0.20) * step(0.015, fill) * step(fill, 0.985);

  float inWater = invSmooth(waterEnd - 0.0045, waterEnd + 0.0045, uv.x) * step(0.004, fill);

  // Normal do tubo de vidro + normal das ondas capilares na água
  vec3 cylN = normalize(vec3(0.0, cylY * 0.90, cylZ));
  vec3 meniscusLipN = normalize(vec3(-invSmooth(0.0, 0.032, abs(uv.x - waterEnd)) * 0.86 * step(fill, 0.985), cylY * 0.74, cylZ));
  vec3 waterWaveN = normalize(vec3(
    -gerstGrad.x * 0.58 - invSmooth(0.0, 0.030, abs(uv.x - waterEnd)) * 0.58 * step(fill, 0.985),
    cylY * 0.82 - gerstGrad.y * 0.46,
    cylZ
  ));
  vec3 activeN = mix(cylN, waterWaveN, inWater);
  activeN = normalize(mix(activeN, meniscusLipN, 0.46 * inWater));

  vec3 viewDir = normalize(vec3(0.0, -0.14, 0.99));
  vec3 keyLight = normalize(vec3(-0.32, 0.88, 0.35));

  // Foco de luz aproximado por área diferencial + lente cilíndrica no fundo do tubo
  float causticTerm = 0.0;
  float cylLensRibbon = exp(-pow((uv.y - 0.22) * 5.6, 2.0));
  if (fill > 0.004) {
    vec3 refrLight = refract(-keyLight, waterWaveN, 1.0 / max(u_ior, 1.01));
    vec2 floorHit = p + refrLight.xy * clamp((1.0 - uv.y) * 0.40 + cylZ * 0.20, 0.02, 0.54);
    float jacCaustic = computeDifferentialCaustic(p, floorHit);
    float waveFocus = clamp(0.82 + causticFocus * 0.38, 0.58, 1.32);
    causticTerm = jacCaustic * waveFocus * u_causticIntensity * (0.38 + 0.84 * cylLensRibbon);
  }

  // Refração RGB com dispersão cromática através da coluna cilíndrica de água
  float etaBase = mix(1.50, u_ior, inWater);
  float disp = mix(0.0014, 0.0044, inWater);

  vec3 refrR;
  vec3 refrG;
  vec3 refrB;
  if (fill > 0.004) {
    refrR = refract(-viewDir, activeN, 1.0 / max(etaBase - disp, 1.02));
    refrG = refract(-viewDir, activeN, 1.0 / max(etaBase, 1.02));
    refrB = refract(-viewDir, activeN, 1.0 / max(etaBase + disp, 1.02));
  } else {
    refrG = refract(-viewDir, activeN, 1.0 / max(etaBase, 1.02));
    refrR = refrG;
    refrB = refrG;
  }

  vec3 backN = normalize(vec3(0.0, cylY * 0.85, -cylZ));
  vec3 exitR;
  vec3 exitG;
  vec3 exitB;
  if (fill > 0.004) {
    exitR = refract(refrR, -backN, etaBase - disp);
    exitG = refract(refrG, -backN, etaBase);
    exitB = refract(refrB, -backN, etaBase + disp);
  } else {
    exitG = refract(refrG, -backN, etaBase);
    exitR = exitG;
    exitB = exitG;
  }

  vec3 glassEnv;
  if (fill > 0.004) {
    vec3 hdrBackR = dot(exitR, exitR) < 0.001
      ? sampleWaterStudioEnvironment(reflect(refrR, -backN), vec3(0.86, 0.98, 1.0))
      : sampleWaterStudioEnvironment(exitR, vec3(0.74, 0.96, 1.0));
    vec3 hdrBackG = dot(exitG, exitG) < 0.001
      ? sampleWaterStudioEnvironment(reflect(refrG, -backN), vec3(0.86, 0.98, 1.0))
      : sampleWaterStudioEnvironment(exitG, vec3(0.74, 0.96, 1.0));
    vec3 hdrBackB = dot(exitB, exitB) < 0.001
      ? sampleWaterStudioEnvironment(reflect(refrB, -backN), vec3(0.86, 0.98, 1.0))
      : sampleWaterStudioEnvironment(exitB, vec3(0.74, 0.96, 1.0));
    glassEnv = vec3(hdrBackR.r, hdrBackG.g, hdrBackB.b);
  } else {
    glassEnv = dot(exitG, exitG) < 0.001
      ? sampleWaterStudioEnvironment(reflect(refrG, -backN), vec3(0.86, 0.98, 1.0))
      : sampleWaterStudioEnvironment(exitG, vec3(0.74, 0.96, 1.0));
  }

  // Parede traseira do tubo vista refratada através do cilindro de água/ar
  vec2 rearTankHit = uv + refrG.xy * (0.07 + cylZ * 0.16) + exitG.xy * 0.09;
  vec3 etchedScale = sampleOpticalCavityWall(rearTankHit, vec2(12.0, 2.0), cylZ);
  float emptyTick = invSmooth(0.0, 0.028, abs(fract(uv.x * 12.0) - 0.5)) * smoothstep(0.60, 0.90, uv.y);

  vec3 emptyCavity = mix(vec3(0.012, 0.030, 0.042), glassEnv * 0.25 + etchedScale * 0.34, cylZ * 0.78);
  emptyCavity += vec3(0.14, 0.30, 0.38) * emptyTick * 0.18;

  if (fill > 0.004) {
    float exitCos = clamp(abs(dot(refrG, -backN)), 0.0, 1.0);
    float exitR0 = pow((etaBase - 1.0) / max(etaBase + 1.0, 1e-3), 2.0);
    float exitFresnel = exitR0 + (1.0 - exitR0) * pow(1.0 - exitCos, 5.0);
    vec3 reflectedBack = sampleWaterStudioEnvironment(reflect(refrG, -backN), vec3(0.84, 0.98, 1.0));
    glassEnv = mix(glassEnv, reflectedBack, clamp(exitFresnel * 0.85, 0.0, 0.80));
  }

  vec3 waterTint = vec3(0.42, 0.88, 0.99);
  vec3 wetCavity = mix(waterTint * 0.14 + etchedScale * 0.52, glassEnv * 1.02, 0.72 + 0.22 * cylLensRibbon);
  wetCavity = mix(wetCavity, waterTint * 0.62, 0.12);
  wetCavity += vec3(0.88, 1.00, 1.02) * causticTerm * 0.86;

  vec3 beerWater = applyBeerLambert(wetCavity, u_attenColor, u_attenDist, clamp(cylZ * 0.34, 0.03, 0.60));

  // Micro-bolhas de oxigênio com borda refrativa próximas ao menisco e na coluna
  if (inWater > 0.08 && fill > 0.08) {
    float bRise1 = 0.18 + fract(t * 0.16) * 0.66;
    float bRise2 = 0.16 + fract(t * 0.13 + 0.52) * 0.68;
    float b1 = evalMicroBubble(p, vec2(max(0.06, waterEnd - 0.055) * aspect, bRise1), 0.022);
    float b2 = evalMicroBubble(p, vec2(max(0.05, waterEnd - 0.125) * aspect, bRise2), 0.018);
    float b3 = evalMicroBubble(p, vec2(max(0.04, waterEnd * 0.45) * aspect, 0.38 + sin(t * 1.6) * 0.08), 0.015);
    beerWater += vec3(1.18, 1.58, 1.78) * (b1 + b2 + b3 * 0.75) * inWater * 0.42;
  }

  vec3 col = mix(emptyCavity, beerWater, inWater);

  // Fresnel cilíndrico + reflexo ESR da cúpula de estúdio
  float cosTheta = clamp(dot(activeN, viewDir), 0.0, 1.0);
  float r0 = mix(0.042, u_fresnelR0, inWater);
  float fresnel = r0 + (1.0 - r0) * pow(1.0 - cosTheta, 5.0);
  vec3 esrCol = sampleWaterStudioEnvironment(reflect(-viewDir, activeN), vec3(0.78, 0.96, 1.0));
  col = mix(col, esrCol, clamp(fresnel * u_esrIntensity * mix(0.42, 0.94, inWater), 0.0, 0.95));

  // Brilho especular contínuo de tubo cilíndrico molhado (roughness 0.009 no líquido)
  vec3 glassSpecular = evaluateGGXSpecular(activeN, viewDir, keyLight, vec3(0.042), mix(0.048, 0.009, inWater));
  float topGlassGlare = invSmooth(0.0, 0.052, abs(uv.y - 0.85)) *
                        smoothstep(0.02, 0.12, uv.x) * invSmooth(0.88, 0.98, uv.x);
  float innerGlassLine = invSmooth(0.0, 0.024, abs(uv.y - 0.10)) + invSmooth(0.0, 0.022, abs(uv.y - 0.90));
  float botLensSheen = invSmooth(0.0, 0.058, abs(uv.y - 0.13)) * inWater;
  col += glassSpecular * vec3(3.55, 3.75, 3.90) + vec3(2.05, 2.22, 2.34) * topGlassGlare * 0.38;
  col += vec3(0.72, 0.98, 1.10) * innerGlassLine * 0.24;
  col += vec3(0.88, 1.02, 1.04) * botLensSheen * 0.56;

  // Gotículas micro-condensadas na cavidade vazia direita
  float dewTank = valueNoise(vec2(p.x * 16.0, p.y * 22.0) + vec2(4.2, 1.9));
  float dewGlint = smoothstep(0.84, 0.96, dewTank) * (1.0 - inWater) * smoothstep(0.15, 0.85, uv.y);
  col += vec3(0.95, 1.25, 1.40) * dewGlint * 0.22;

  // End-caps refrativos: bordas de vidro borossilicato espesso
  float leftCap = exp(-pow((uv.x - 0.014) * 78.0, 2.0)) *
                  smoothstep(0.08, 0.32, uv.y) * invSmooth(0.68, 0.92, uv.y);
  float rightCap = exp(-pow((uv.x - 0.986) * 78.0, 2.0)) *
                   smoothstep(0.08, 0.32, uv.y) * invSmooth(0.68, 0.92, uv.y);
  float sideRim = leftCap + rightCap;
  col += vec3(1.48, 1.78, 1.92) * sideRim * 0.46;

  // Borda côncava brilhante do menisco no encontro ar/água (x ≈ waterEnd)
  float meniscusRim = invSmooth(0.0, 0.0075, abs(uv.x - waterEnd)) * step(0.015, fill) * step(fill, 0.985);
  float meniscusDark = invSmooth(0.0, 0.018, abs(uv.x - (waterEnd + 0.007))) * step(0.015, fill) * step(fill, 0.985);
  col *= 1.0 - meniscusDark * 0.56;
  col += vec3(2.38, 2.55, 2.68) * meniscusRim * (1.04 + 0.18 * waveEnergy);

  col = linearToSrgb(acesFilmic(col));

  float glassAlpha = clamp(mix(0.30, 0.86, inWater) + topGlassGlare * 0.22 + fresnel * 0.38 + meniscusRim * 0.26, 0.0, 0.97);
  fragColor = vec4(col * glassAlpha, glassAlpha);
}
`;

// Helpers mínimos da barra de energia: não carrega as rotinas ópticas da água/metal.
const ENERGY_NOISE_GLSL = `
float invSmooth(float lo, float hi, float x) {
  return 1.0 - smoothstep(lo, hi, x);
}
float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}
float valueNoise(vec2 st) {
  vec2 i = floor(st);
  vec2 f = fract(st);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
}
float fbm3(vec2 st) {
  float val = 0.0;
  float amp = 0.5;
  mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
  for (int i = 0; i < 3; i++) {
    val += amp * valueNoise(st);
    st = rot * st * 2.02 + vec2(1.7, 3.1);
    amp *= 0.5;
  }
  return val;
}
`;

// 3. Energia nutricional: cápsula cilíndrica de vidro borossilicato com refração dupla + fluido bioenergético volumétrico e filamentos luminosos
const ENERGY_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;

${ENERGY_NOISE_GLSL}

float energyCapsuleSdf(vec2 p, vec2 a, vec2 b, float r) {
  vec2 pa = p - a;
  vec2 ba = b - a;
  float h = clamp(dot(pa, ba) / max(dot(ba, ba), 1e-5), 0.0, 1.0);
  return length(pa - ba * h) - r;
}

vec3 energyToneAces(vec3 x) {
  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

vec3 energyToSrgb(vec3 c) {
  vec3 clamped = max(c, vec3(0.0));
  vec3 lo = clamped * 12.92;
  vec3 hi = 1.055 * pow(clamped, vec3(1.0 / 2.4)) - 0.055;
  return mix(lo, hi, step(vec3(0.0031308), clamped));
}

vec3 energyStudioEnv(vec3 dir, vec3 tint) {
  vec3 d = normalize(dir);
  float horizon = smoothstep(-0.42, 0.72, d.y);
  vec3 darkFloor = vec3(0.008, 0.015, 0.013);
  vec3 deepStudio = vec3(0.045, 0.088, 0.072) * tint;
  vec3 env = mix(darkFloor, deepStudio, horizon);

  float topStrip = exp(-pow((d.y - 0.58) * 5.6, 2.0)) * smoothstep(-0.72, 0.78, -abs(d.x) + 0.80);
  float sideKey = exp(-pow((d.x + 0.55) * 4.2, 2.0)) * exp(-pow((d.y - 0.25) * 3.8, 2.0));
  float lowerBounce = exp(-pow((d.y + 0.52) * 4.8, 2.0));

  env += vec3(1.36, 1.50, 1.42) * topStrip * 0.78;
  env += vec3(0.72, 0.64, 0.50) * sideKey * 0.28;
  env += vec3(0.18, 0.42, 0.32) * tint * lowerBounce * 0.48;
  return env;
}

float energyGGX(vec3 N, vec3 V, vec3 L, float rough) {
  vec3 H = normalize(V + L);
  float NdotH = max(dot(N, H), 0.0);
  float NdotV = max(dot(N, V), 0.001);
  float NdotL = max(dot(N, L), 0.001);
  float a = max(rough * rough, 0.0004);
  float a2 = a * a;
  float denom = NdotH * NdotH * (a2 - 1.0) + 1.0;
  float D = a2 / (3.14159265 * denom * denom);
  float k = (rough + 1.0) * (rough + 1.0) / 8.0;
  float G = (NdotV / (NdotV * (1.0 - k) + k)) * (NdotL / (NdotL * (1.0 - k) + k));
  return (D * G) / (4.0 * NdotV * NdotL + 0.001);
}

void main() {
  vec2 uv = v_uv;
  float aspect = max(1.0, u_resolution.x / max(1.0, u_resolution.y));
  vec2 p = vec2(uv.x * aspect, uv.y);

  float capR = 0.485;
  float capD = energyCapsuleSdf(p, vec2(capR, 0.5), vec2(aspect - capR, 0.5), capR);
  float aa = 1.6 / max(u_resolution.y, 2.0);
  if (capD > aa * 2.0) {
    fragColor = vec4(0.0);
    return;
  }

  float fill = clamp(u_fill, 0.0, 1.0);
  float t = u_time;

  // Normal 3D contínua da cápsula de borossilicato (corpo cilíndrico + cúpulas esféricas nas pontas)
  vec2 gradEps = vec2(0.004, 0.0);
  vec2 capGrad = vec2(
    energyCapsuleSdf(p + gradEps.xy, vec2(capR, 0.5), vec2(aspect - capR, 0.5), capR) -
      energyCapsuleSdf(p - gradEps.xy, vec2(capR, 0.5), vec2(aspect - capR, 0.5), capR),
    energyCapsuleSdf(p + gradEps.yx, vec2(capR, 0.5), vec2(aspect - capR, 0.5), capR) -
      energyCapsuleSdf(p - gradEps.yx, vec2(capR, 0.5), vec2(aspect - capR, 0.5), capR)
  ) / (2.0 * gradEps.x);
  float cylY = clamp((uv.y - 0.5) * 1.96, -0.98, 0.98);
  float depthNorm = clamp(-capD / capR, 0.0, 1.0);
  float cylZ = sqrt(max(0.04, 1.0 - pow(1.0 - depthNorm, 2.0)));
  vec3 glassN = normalize(vec3(capGrad.x * (1.0 - cylZ * 0.45), capGrad.y * (1.0 - cylZ * 0.15), max(0.08, cylZ)));

  // Menisco côncavo aderido às paredes internas do vidro + ondulação viva na ponta do líquido
  float wallWetCurve = 0.014 * pow(abs(cylY), 2.3);
  float capWave = sin(uv.y * 10.5 - t * 3.1) * 0.0026 + cos(uv.y * 17.0 + t * 2.1) * 0.0012;
  float activeMask = step(0.010, fill) * step(fill, 0.992);
  float meniscusX = fill + (wallWetCurve + capWave) * activeMask;
  float inFluid = invSmooth(meniscusX - 0.0045, meniscusX + 0.0045, uv.x) * step(0.004, fill);

  // Ondulação laminar interna do fluido energético + normal do menisco
  float flowSeed = fbm3(vec2(uv.x * 3.6 - t * 0.55, uv.y * 2.3 + t * 0.18));
  float waveGradX = cos(uv.x * 18.0 - t * 2.4 + flowSeed * 3.4) * 0.062;
  float waveGradY = sin(uv.y * 11.0 + flowSeed * 2.6 - t * 1.3) * 0.052;
  float lipFocus = invSmooth(0.0, 0.022, abs(uv.x - meniscusX)) * activeMask;
  vec3 fluidN = normalize(vec3(
    glassN.x - waveGradX * 0.46 - lipFocus * 0.72,
    glassN.y - waveGradY * 0.38,
    glassN.z
  ));
  vec3 activeN = mix(glassN, fluidN, inFluid);

  vec3 viewDir = normalize(vec3(0.0, -0.09, 0.996));
  vec3 keyLight = normalize(vec3(-0.28, 0.88, 0.38));

  // Refração dupla através da parede frontal e traseira do tubo borossilicato + dispersão RGB sutil
  float ior = mix(1.50, 1.36, inFluid);
  vec3 refrR = refract(-viewDir, activeN, 1.0 / (ior - 0.004));
  vec3 refrG = refract(-viewDir, activeN, 1.0 / ior);
  vec3 refrB = refract(-viewDir, activeN, 1.0 / (ior + 0.004));
  vec3 backN = normalize(vec3(activeN.xy * 0.86, -max(0.10, cylZ)));
  vec3 refrOut = refract(refrG, -backN, ior);
  vec3 refrEnvDir = dot(refrOut, refrOut) < 0.001 ? reflect(refrG, -backN) : refrOut;

  vec2 refractedUv = uv + refrG.xy * (0.045 + cylZ * 0.090);
  float etchedTicks = invSmooth(0.0, 0.024, abs(fract(refractedUv.x * 12.0) - 0.5)) * smoothstep(0.56, 0.90, refractedUv.y);
  float rearSubGrid = invSmooth(0.0, 0.032, abs(fract(refractedUv.x * 24.0) - 0.5)) * smoothstep(0.14, 0.42, refractedUv.y) * invSmooth(0.44, 0.62, refractedUv.y);

  // Cavidade óptica escura (lado vazio) com reflexo interno + escala a laser refratada
  vec3 emptyEnvR = energyStudioEnv(dot(refrR, refrR) > 0.0 ? refrR : refrEnvDir, vec3(0.56, 0.76, 0.68));
  vec3 emptyEnvG = energyStudioEnv(refrEnvDir, vec3(0.56, 0.78, 0.68));
  vec3 emptyEnvB = energyStudioEnv(dot(refrB, refrB) > 0.0 ? refrB : refrEnvDir, vec3(0.58, 0.80, 0.72));
  vec3 emptyEnv = vec3(emptyEnvR.r, emptyEnvG.g, emptyEnvB.b);

  vec3 emptyCavity = mix(vec3(0.008, 0.015, 0.013), emptyEnv * 0.28, cylZ * 0.78);
  emptyCavity += vec3(0.14, 0.28, 0.22) * (etchedTicks * 0.16 + rearSubGrid * 0.08);
  float wallShadow = smoothstep(0.52, 0.96, abs(cylY));
  emptyCavity *= 1.0 - wallShadow * 0.48;

  vec3 col = emptyCavity;

  if (inFluid > 0.005) {
    // 1. Correntes fluidas duplas contra-advectadas (fbm3 com domain-warping)
    vec2 flowUvA = vec2(uv.x * 3.1 - t * 0.52, uv.y * 2.1 + t * 0.14);
    vec2 flowUvB = vec2(uv.x * 4.6 - t * 0.84, uv.y * 2.8 - t * 0.18);
    float nA = fbm3(flowUvA + vec2(0.0, sin(uv.x * 6.0 - t * 1.4) * 0.06));
    float nB = fbm3(flowUvB + vec2(nA * 0.7, -nA * 0.4));
    float fluidTurbulence = clamp(nA * 0.58 + nB * 0.46, 0.0, 1.0);

    // 2. Filamentos bioenergéticos / micro-arcos coerentes correndo ao longo do núcleo fluido
    float warp1 = (fbm3(vec2(p.x * 2.2 - t * 1.65, 1.7 + t * 0.35)) - 0.5) * 0.42;
    float warp2 = (fbm3(vec2(p.x * 2.8 - t * 2.15, 7.3 - t * 0.42)) - 0.5) * 0.38;
    float wavePath1 = 0.50 + warp1 + sin(p.x * 2.6 - t * 2.8) * 0.09;
    float wavePath2 = 0.50 + warp2 + cos(p.x * 3.4 - t * 3.5) * 0.08;
    float distBolt1 = abs(uv.y - wavePath1);
    float distBolt2 = abs(uv.y - wavePath2);
    float filament1 = pow(0.020 / (distBolt1 + 0.018), 1.45);
    float filament2 = pow(0.016 / (distBolt2 + 0.022), 1.45);
    float coreContain = smoothstep(0.04, 0.38, cylZ);
    float filamentEnergy = (filament1 * 0.72 + filament2 * 0.52) * coreContain;

    // 3. Corona de sobrecarga na ponta ativa do líquido (meniscusX)
    float tipProximity = invSmooth(0.0, 0.14, abs(uv.x - meniscusX)) * activeMask;
    float tipCorona = tipProximity * (0.45 + 0.55 * nB) * coreContain;

    // 4. Cáustica de lente cilíndrica na parte inferior e faixa central
    float causticBand = exp(-pow((uv.y - (0.46 + (fluidTurbulence - 0.5) * 0.24)) * 3.2, 2.0));
    float bottomLensCaustic = exp(-pow((uv.y - 0.18) * 5.8, 2.0)) * (0.62 + 0.38 * sin(uv.x * 20.0 - t * 2.2));

    vec3 deepEmerald = vec3(0.016, 0.082, 0.056);
    vec3 jadeMineral = vec3(0.115, 0.395, 0.265);
    vec3 sageLumen = vec3(0.42, 0.84, 0.62);
    vec3 filamentGlowCol = vec3(0.76, 1.18, 0.92);
    vec3 coreCaustic = vec3(0.74, 0.96, 0.84);

    vec3 fluidScatter = mix(deepEmerald, jadeMineral, smoothstep(0.14, 0.86, fluidTurbulence * 0.74 + cylZ * 0.30));
    fluidScatter = mix(fluidScatter, sageLumen, causticBand * 0.44);
    fluidScatter += filamentGlowCol * filamentEnergy * 0.52;
    fluidScatter += vec3(0.84, 1.24, 0.96) * tipCorona * 0.42;
    fluidScatter += coreCaustic * bottomLensCaustic * 0.30;
    fluidScatter += energyStudioEnv(refrEnvDir, vec3(0.56, 0.96, 0.76)) * 0.22 * cylZ;

    // Atenuação Beer-Lambert através da espessura cilíndrica do fluido
    float opticalDepth = clamp(cylZ * 0.55, 0.04, 0.62);
    vec3 atten = exp(-vec3(1.48, 0.48, 0.92) * opticalDepth);
    vec3 beerFluid = fluidScatter * mix(vec3(1.0), atten, 0.54);

    // Micro-partículas energéticas em suspensão arrastadas pela correnteza
    float mx1 = fract(0.22 + t * 0.075) * max(fill - 0.05, 0.05);
    float mx2 = fract(0.58 + t * 0.052) * max(fill - 0.05, 0.05);
    float mx3 = fract(0.84 + t * 0.092) * max(fill - 0.05, 0.05);
    float mote1 = invSmooth(0.0020, 0.0085, length(p - vec2(mx1 * aspect, 0.42 + sin(t * 2.1 + 1.0) * 0.08)));
    float mote2 = invSmooth(0.0018, 0.0075, length(p - vec2(mx2 * aspect, 0.58 + cos(t * 1.8 + 2.5) * 0.07)));
    float mote3 = invSmooth(0.0016, 0.0068, length(p - vec2(mx3 * aspect, 0.48 + sin(t * 2.6 + 4.1) * 0.09)));
    beerFluid += vec3(0.96, 1.32, 1.08) * (mote1 + mote2 * 0.85 + mote3 * 0.75) * 0.34 * step(0.10, fill);

    beerFluid += vec3(0.12, 0.26, 0.19) * etchedTicks * 0.16;
    col = mix(emptyCavity, beerFluid, inFluid);
  }

  // Fresnel cilíndrico + reflexo externo de estúdio na parede externa do borossilicato
  float cosTheta = clamp(dot(activeN, viewDir), 0.0, 1.0);
  float r0 = mix(0.046, 0.030, inFluid);
  float fresnel = r0 + (1.0 - r0) * pow(1.0 - cosTheta, 5.0);
  vec3 reflEnv = energyStudioEnv(reflect(-viewDir, activeN), vec3(0.74, 0.96, 0.86));
  col = mix(col, reflEnv, clamp(fresnel * mix(0.62, 0.88, inFluid), 0.0, 0.90));

  // Brilho especular GGX de vidro molhado + faixa softbox superior + contorno óptico duplo de parede grossa
  float glassSpec = energyGGX(activeN, viewDir, keyLight, mix(0.044, 0.014, inFluid));
  float topSoftbox = invSmooth(0.0, 0.082, abs(uv.y - 0.84)) * smoothstep(0.02, 0.14, uv.x) * invSmooth(0.86, 0.98, uv.x);
  float upperGlassHairline = invSmooth(0.0, 0.026, abs(uv.y - 0.93));
  float lowerGlassRim = invSmooth(0.0, 0.038, abs(uv.y - 0.08));
  float outerBevel = exp(-pow((capD + 0.018) * 145.0, 2.0));

  col += vec3(1.26, 1.40, 1.32) * glassSpec * 0.48;
  col += vec3(1.05, 1.18, 1.08) * topSoftbox * 0.28;
  col += vec3(0.82, 0.98, 0.90) * upperGlassHairline * 0.22;
  col += vec3(0.36, 0.68, 0.52) * lowerGlassRim * mix(0.10, 0.30, inFluid);
  col += vec3(0.88, 1.08, 0.98) * outerBevel * mix(0.24, 0.42, inFluid);

  // End-caps refrativos em vidro espesso com dispersão prismática sutil nas pontas
  float leftCap = exp(-pow((uv.x - 0.010) * 85.0, 2.0)) * smoothstep(0.08, 0.35, uv.y) * invSmooth(0.65, 0.92, uv.y);
  float rightCap = exp(-pow((uv.x - 0.990) * 85.0, 2.0)) * smoothstep(0.08, 0.35, uv.y) * invSmooth(0.65, 0.92, uv.y);
  float capPrism = exp(-pow((abs(capD) - 0.008) * 210.0, 2.0));
  col += vec3(0.92, 1.12, 1.02) * (leftCap + rightCap) * 0.38;
  col += vec3(0.24, 0.56, 0.68) * capPrism * 0.16;

  // Menisco côncavo luminoso + sombra TIR logo após o limite ar/fluido
  float meniscusRim = invSmooth(0.0, 0.0070, abs(uv.x - meniscusX)) * activeMask;
  float meniscusTirDark = invSmooth(0.0, 0.016, abs(uv.x - (meniscusX + 0.006))) * activeMask;
  col *= 1.0 - meniscusTirDark * 0.58;
  col += vec3(1.62, 1.98, 1.72) * meniscusRim * 0.66;

  col = energyToSrgb(energyToneAces(col));
  float shapeAlpha = invSmooth(-aa, aa, capD);
  fragColor = vec4(col * shapeAlpha, shapeAlpha);
}
`;

// 4. Semicírculo em cápsula de vidro borossilicato preenchida com metal líquido anisotrópico e reflexo GGX de estúdio
const METAL_FRAGMENT_300 = `#version 300 es
precision highp float;

in vec2 v_uv;
out vec4 fragColor;

uniform vec2 u_resolution;
uniform float u_time;
uniform float u_fill;
uniform vec3 u_metalColor;
uniform vec3 u_metalHighlight;

${SHARED_OPTICS_GLSL}

void main() {
  vec2 p = vec2(v_uv.x * 96.0, (1.0 - v_uv.y) * 56.0);
  vec2 center = vec2(48.0, 48.0);
  vec2 rel = p - center;
  float dist = length(rel);
  float radius = 38.0;
  float halfThick = 5.1;

  float theta = atan(-rel.y, -rel.x);
  float trackDist;
  if (rel.y <= 0.0) {
    trackDist = abs(dist - radius) - halfThick;
  } else {
    float dLeft = length(p - vec2(48.0 - radius, 48.0)) - halfThick;
    float dRight = length(p - vec2(48.0 + radius, 48.0)) - halfThick;
    trackDist = min(dLeft, dRight);
  }

  float aa = 0.75;
  if (trackDist > aa * 2.5) {
    fragColor = vec4(0.0);
    return;
  }

  vec2 radialDir = normalize(rel + vec2(0.0001));
  float crossU = clamp((dist - radius) / halfThick, -0.96, 0.96);
  vec3 tubeN = normalize(vec3(radialDir * crossU, sqrt(max(0.06, 1.0 - crossU * crossU))));
  vec3 viewDir = vec3(0.0, 0.0, 1.0);

  // Cavidade cilíndrica em vidro borossilicato fumê com refração interna e marcações ópticas no arco
  float trackFresnel = 0.045 + 0.955 * pow(1.0 - max(dot(tubeN, viewDir), 0.0), 4.2);
  vec3 glassTrackEnv = sampleStudioEnvironment(reflect(-viewDir, tubeN), u_metalColor);
  float arcTicks = invSmooth(0.0, 0.075, abs(fract((theta / 3.14159265) * 10.0) - 0.5)) * invSmooth(0.45, 0.85, abs(crossU));
  float wallRimGlass = exp(-pow((abs(crossU) - 0.86) * 6.5, 2.0));
  vec3 grooveColor = mix(vec3(0.018, 0.028, 0.032), glassTrackEnv * 0.34, clamp(trackFresnel * 0.92, 0.0, 0.82));
  grooveColor += u_metalHighlight * wallRimGlass * 0.14;
  grooveColor += u_metalColor * arcTicks * 0.12;

  float fill = clamp(u_fill, 0.0, 1.0);
  float maxAngle = fill * 3.14159265;
  float inCapStart = length(p - vec2(48.0 - radius, 48.0)) - halfThick;
  vec2 tipPos = vec2(48.0 - radius * cos(maxAngle), 48.0 - radius * sin(maxAngle));
  float inCapTip = length(p - tipPos) - halfThick;

  float bodyAngleOk = step(0.0, theta) * step(theta, maxAngle) * step(0.0, -rel.y + 0.2);
  float bodyDist = bodyAngleOk > 0.5 ? abs(dist - radius) - halfThick : 99.0;
  float liquidDist = fill > 0.002 ? min(inCapStart, min(inCapTip, bodyDist)) : 99.0;

  vec3 col = grooveColor;
  if (liquidDist < aa) {
    float t = u_time * 0.30;
    vec2 mUv = p * 0.095;

    // Uma FBM de três oitavas dá irregularidade microscópica sem o custo
    // do antigo domínio warp com três FBMs completos por fragmento.
    float satinNoise = fbm3(mUv * 0.82 + vec2(t * 0.055, -t * 0.035));

    // Ondulações direcionais analíticas que fluem ao longo do arco (theta): gradiente estável,
    // sem derivadas GLSL dentro da máscara variável do líquido (onde dFdx/dFdy seriam indefinidas).
    float phaseA = theta * 3.8 - t * 2.4 + sin(crossU * 2.4 + t * 1.1) * 0.48;
    float phaseB = crossU * 4.4 - theta * 1.6 - t * 1.3;
    float phaseC = theta * 7.2 - t * 3.6 + (satinNoise - 0.5) * 1.6;
    float waveA = sin(phaseA);
    float waveB = sin(phaseB);
    float waveC = cos(phaseC);
    vec2 arcDir = radialDir;
    vec2 flowTangent = vec2(-radialDir.y, radialDir.x);
    vec2 heightGradient =
      flowTangent * (cos(phaseA) * 0.24 - sin(phaseC) * 0.14) +
      arcDir * (cos(phaseB) * 0.19) +
      vec2(waveA, waveB) * (satinNoise - 0.5) * 0.045;

    vec3 rippleN = normalize(vec3(-heightGradient * 0.95, 1.0));
    vec3 normal = normalize(mix(tubeN, rippleN, 0.36));
    vec3 tangent = normalize(vec3(-radialDir.y, radialDir.x, 0.0));

    // Reflexão de condutor colorido verdadeiro (Nadrin/PBR & 0xBaseline liquid metal):
    // o metal reflete o estúdio multiplicado pelo matiz intrínseco da sua liga.
    vec3 refl = reflect(-viewDir, normal);
    vec3 studioEnv = sampleStudioEnvironment(refl, u_metalColor);
    vec3 conductorTint = clamp(u_metalColor * 1.72, 0.0, 1.45);
    vec3 esr = studioEnv * mix(conductorTint, u_metalHighlight * 1.20, 0.24);
    float horizonDip = invSmooth(0.0, 0.22, abs(refl.y - 0.02));
    float moltenCurrent = 0.5 + 0.5 * (waveA * 0.56 + waveC * 0.44);

    vec3 deepAlloy = u_metalColor * 0.32;
    vec3 midAlloy = mix(u_metalColor * 0.92, u_metalHighlight * 1.02, 0.28);
    vec3 chromeCol = mix(deepAlloy, midAlloy, smoothstep(0.08, 0.90, moltenCurrent * 0.48 + 0.52 * (1.0 - abs(crossU)))) + esr * 0.60;
    chromeCol = mix(chromeCol, u_metalColor * 0.26, horizonDip * 0.42);
    chromeCol *= mix(0.91, 1.10, satinNoise);

    float fresnel = pow(1.0 - max(dot(normal, viewDir), 0.0), 3.0);
    chromeCol += mix(u_metalColor * 1.02, u_metalHighlight, 0.56) * fresnel * 0.28;

    vec3 light1 = normalize(vec3(-0.55, 0.72, 0.72));
    vec3 light2 = normalize(vec3(0.65, 0.45, 0.60));
    float roughness = mix(0.24, 0.32, satinNoise);
    vec3 conductorF0 = clamp(mix(u_metalColor * 1.42, u_metalHighlight, 0.34), 0.0, 1.22);
    vec3 specular = evaluateGGXAnisotropicSpecular(
      normal, tangent, viewDir, light1, conductorF0, roughness, 0.28
    ) * 3.35;
    specular += evaluateGGXAnisotropicSpecular(
      normal, tangent, viewDir, light2, conductorF0, roughness + 0.045, 0.21
    ) * 1.38;
    chromeCol += specular;

    // Menisco líquido arredondado luminoso na ponta do preenchimento
    float tipDist = length(p - (tipPos + vec2(-0.5, -0.6)));
    float tipSpot = invSmooth(0.32, 3.8, tipDist);
    float tipDomeSpec = invSmooth(0.2, 1.85, tipDist);
    chromeCol += mix(u_metalColor * 1.48, u_metalHighlight * 1.30, 0.58) * tipSpot * 0.56;
    chromeCol += u_metalHighlight * tipDomeSpec * 0.34;

    float liqMask = invSmooth(-aa, aa, liquidDist);
    col = mix(grooveColor, chromeCol, liqMask);
  }

  // Capa externa de vidro óptico curvo envolvendo todo o semicírculo (reflexo de lente, borda Fresnel e leve dispersão prismática RGB)
  vec3 outerGlassKey = normalize(vec3(-0.34, 0.84, 0.42));
  vec3 outerGlassSpec = evaluateGGXSpecular(tubeN, viewDir, outerGlassKey, vec3(0.048), 0.016);
  float glassSheenBand = exp(-pow((crossU + 0.38) * 3.4, 2.0)) * smoothstep(-0.2, 0.85, -rel.y / max(radius, 1.0));
  float prismOuter = exp(-pow((crossU - 0.88) * 9.5, 2.0));
  float prismInner = exp(-pow((crossU + 0.88) * 9.5, 2.0));
  col += outerGlassSpec * vec3(1.36, 1.44, 1.48) * 0.44;
  col += mix(vec3(0.92, 0.97, 1.0), u_metalHighlight, 0.34) * glassSheenBand * 0.19;
  col += u_metalHighlight * wallRimGlass * 0.14;
  col += vec3(0.22, 0.58, 0.88) * prismOuter * 0.11 + vec3(0.86, 0.68, 0.36) * prismInner * 0.08;

  col = linearToSrgb(acesFilmic(col));
  float trackAlpha = invSmooth(-aa, aa, trackDist);
  fragColor = vec4(col * trackAlpha, trackAlpha);
}
`;

interface CachedProgram {
  program: WebGLProgram;
  uResolution: WebGLUniformLocation | null;
  uTime: WebGLUniformLocation | null;
  uFill: WebGLUniformLocation | null;
  uActive: WebGLUniformLocation | null;
  uIor: WebGLUniformLocation | null;
  uFresnelR0: WebGLUniformLocation | null;
  uAttenColor: WebGLUniformLocation | null;
  uAttenDist: WebGLUniformLocation | null;
  uEsrIntensity: WebGLUniformLocation | null;
  uCausticIntensity: WebGLUniformLocation | null;
  uFootprint: WebGLUniformLocation | null;
  uWave: WebGLUniformLocation | null;
  uMetalColor: WebGLUniformLocation | null;
  uMetalHighlight: WebGLUniformLocation | null;
}

type TargetBlitHandle = { ctx: CanvasRenderingContext2D };

class SharedFluidShaderEngine {
  private offscreenCanvas: OffscreenCanvas | null = null;
  private fallbackCanvas: HTMLCanvasElement | null = null;
  private gl: WebGL2RenderingContext | null = null;
  private programs = new Map<FluidProgramKind, CachedProgram>();
  private targetCtxCache = new WeakMap<HTMLCanvasElement, TargetBlitHandle>();
  private lastJobRenderAt = new WeakMap<HTMLCanvasElement, number>();
  private quadVao: WebGLVertexArrayObject | null = null;
  private quadBuffer: WebGLBuffer | null = null;
  private activeJobScratch: FluidDrawJob[] = [];
  private webglFailed = false;
  private subscribers = new Set<() => FluidDrawJob | null>();
  private rafId = 0;
  private lastTime = 0;
  private elapsed = 1.35;
  private springAccumulator = 0;
  private waveUploadBuf = new Float32Array(24);
  private maxDpr = 1.5;
  private visibilityListenerAttached = false;
  private readonly handleVisibilityChange = () => {
    if (typeof document === 'undefined') return;
    if (document.hidden) {
      if (this.rafId) cancelAnimationFrame(this.rafId);
      this.rafId = 0;
      return;
    }
    for (const provider of this.subscribers) {
      this.renderSinglePass(provider);
    }
    this.startLoopIfNeeded();
  };

  private ensureContext(): WebGL2RenderingContext | null {
    if (this.webglFailed || typeof document === 'undefined') return null;
    if (this.gl) return this.gl;

    if (typeof window !== 'undefined' && typeof window.matchMedia === 'function') {
      const isCoarse = window.matchMedia('(pointer: coarse)').matches;
      this.maxDpr = isCoarse ? 1.5 : 2;
    }

    const attrs: WebGLContextAttributes = {
      alpha: true,
      antialias: false,
      depth: false,
      stencil: false,
      premultipliedAlpha: true,
      powerPreference: 'high-performance',
    };

    let gl: WebGL2RenderingContext | null = null;
    if (typeof OffscreenCanvas !== 'undefined') {
      const oc = new OffscreenCanvas(64, 64);
      gl = oc.getContext('webgl2', attrs);
      if (gl) {
        this.offscreenCanvas = oc;
        oc.addEventListener('webglcontextlost', (e) => {
          e.preventDefault();
          if (this.rafId) cancelAnimationFrame(this.rafId);
          this.rafId = 0;
          this.teardownContext();
          this.webglFailed = true;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-fallback'));
        });
        oc.addEventListener('webglcontextrestored', () => {
          this.teardownContext();
          this.webglFailed = false;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-restored'));
          this.wake();
        });
      }
    }

    if (!gl) {
      const hc = document.createElement('canvas');
      gl = hc.getContext('webgl2', attrs);
      if (gl) {
        this.fallbackCanvas = hc;
        hc.addEventListener('webglcontextlost', (e) => {
          e.preventDefault();
          if (this.rafId) cancelAnimationFrame(this.rafId);
          this.rafId = 0;
          this.teardownContext();
          this.webglFailed = true;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-fallback'));
        });
        hc.addEventListener('webglcontextrestored', () => {
          this.teardownContext();
          this.webglFailed = false;
          if (typeof window !== 'undefined') window.dispatchEvent(new Event('fluid-engine-restored'));
          this.wake();
        });
      }
    }

    if (!gl) {
      this.webglFailed = true;
      return null;
    }

    const vao = gl.createVertexArray();
    const buf = gl.createBuffer();
    if (!vao || !buf) {
      if (vao) gl.deleteVertexArray(vao);
      if (buf) gl.deleteBuffer(buf);
      this.webglFailed = true;
      return null;
    }

    gl.bindVertexArray(vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(
      gl.ARRAY_BUFFER,
      new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]),
      gl.STATIC_DRAW,
    );
    gl.enableVertexAttribArray(0);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
    gl.bindVertexArray(null);

    this.gl = gl;
    this.quadVao = vao;
    this.quadBuffer = buf;
    return gl;
  }

  private getProgram(gl: WebGL2RenderingContext, kind: FluidProgramKind): CachedProgram | null {
    const existing = this.programs.get(kind);
    if (existing) return existing;

    const fsSource =
      kind === 'droplet'
        ? DROPLET_FRAGMENT_300
        : kind === 'tank'
        ? TANK_FRAGMENT_300
        : kind === 'energy'
        ? ENERGY_FRAGMENT_300
        : METAL_FRAGMENT_300;

    const vs = this.compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER_300, `${kind}:vertex`);
    const fs = this.compileShader(gl, gl.FRAGMENT_SHADER, fsSource, `${kind}:fragment`);
    if (!vs || !fs) {
      if (vs) gl.deleteShader(vs);
      if (fs) gl.deleteShader(fs);
      return null;
    }

    const prog = gl.createProgram();
    if (!prog) {
      gl.deleteShader(vs);
      gl.deleteShader(fs);
      return null;
    }
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.bindAttribLocation(prog, 0, 'a_position');
    gl.linkProgram(prog);

    gl.deleteShader(vs);
    gl.deleteShader(fs);

    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      const info = gl.getProgramInfoLog(prog);
      console.error(`[FluidEngine] ${kind} program link failed`, info);
      gl.deleteProgram(prog);
      return null;
    }

    const cached: CachedProgram = {
      program: prog,
      uResolution: gl.getUniformLocation(prog, 'u_resolution'),
      uTime: gl.getUniformLocation(prog, 'u_time'),
      uFill: gl.getUniformLocation(prog, 'u_fill'),
      uActive: gl.getUniformLocation(prog, 'u_active'),
      uIor: gl.getUniformLocation(prog, 'u_ior'),
      uFresnelR0: gl.getUniformLocation(prog, 'u_fresnelR0'),
      uAttenColor: gl.getUniformLocation(prog, 'u_attenColor'),
      uAttenDist: gl.getUniformLocation(prog, 'u_attenDist'),
      uEsrIntensity: gl.getUniformLocation(prog, 'u_esrIntensity'),
      uCausticIntensity: gl.getUniformLocation(prog, 'u_causticIntensity'),
      uFootprint: gl.getUniformLocation(prog, 'u_footprint'),
      uWave: gl.getUniformLocation(prog, 'u_wave[0]'),
      uMetalColor: gl.getUniformLocation(prog, 'u_metalColor'),
      uMetalHighlight: gl.getUniformLocation(prog, 'u_metalHighlight'),
    };
    this.programs.set(kind, cached);
    return cached;
  }

  private compileShader(
    gl: WebGL2RenderingContext,
    type: number,
    src: string,
    label: string,
  ): WebGLShader | null {
    const shader = gl.createShader(type);
    if (!shader) return null;
    gl.shaderSource(shader, src);
    gl.compileShader(shader);
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const info = gl.getShaderInfoLog(shader);
      console.error(`[FluidEngine] ${label} shader compilation failed`, info);
      gl.deleteShader(shader);
      return null;
    }
    return shader;
  }

  private getTargetBlitHandle(canvas: HTMLCanvasElement): TargetBlitHandle | null {
    const existing = this.targetCtxCache.get(canvas);
    if (existing) return existing;

    const ctx2d = canvas.getContext('2d');
    if (!ctx2d) return null;
    const handle: TargetBlitHandle = { ctx: ctx2d };
    this.targetCtxCache.set(canvas, handle);
    return handle;
  }

  private renderJobToTarget(job: FluidDrawJob, timeSec: number): boolean {
    const gl = this.ensureContext();
    const offscreen = this.offscreenCanvas;
    const fallback = this.fallbackCanvas;
    if (!gl || !this.quadVao || (!offscreen && !fallback)) return false;

    const dpr = Math.min(window.devicePixelRatio || 1, this.maxDpr);
    const pxW = Math.max(2, Math.round(job.width * dpr));
    const pxH = Math.max(2, Math.round(job.height * dpr));

    if (job.targetCanvas.width !== pxW || job.targetCanvas.height !== pxH) {
      job.targetCanvas.width = pxW;
      job.targetCanvas.height = pxH;
    }

    const cached = this.getProgram(gl, job.kind);
    if (!cached) return false;

    const blit = this.getTargetBlitHandle(job.targetCanvas);
    if (!blit) return false;

    if (fallback) {
      if (fallback.width < pxW || fallback.height < pxH) {
        fallback.width = Math.max(fallback.width, pxW);
        fallback.height = Math.max(fallback.height, pxH);
      }
    } else if (offscreen) {
      if (offscreen.width < pxW || offscreen.height < pxH) {
        offscreen.width = Math.max(offscreen.width, pxW);
        offscreen.height = Math.max(offscreen.height, pxH);
      }
    }

    gl.enable(gl.SCISSOR_TEST);
    gl.scissor(0, 0, pxW, pxH);
    gl.viewport(0, 0, pxW, pxH);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(cached.program);
    gl.bindVertexArray(this.quadVao);

    if (cached.uResolution) gl.uniform2f(cached.uResolution, pxW, pxH);
    if (cached.uTime) gl.uniform1f(cached.uTime, timeSec);
    if (cached.uFill) gl.uniform1f(cached.uFill, job.fill);

    if (job.kind === 'droplet' && cached.uActive) {
      gl.uniform1f(cached.uActive, job.active ? 1 : 0);
    }

    if (job.kind === 'droplet' || job.kind === 'tank') {
      const cfg = job.opticalConfig;
      const ior = cfg?.ior ?? DEFAULT_WATER_OPTICAL_CONFIG.ior;
      const r0 = cfg?.fresnelR0 ?? DEFAULT_WATER_OPTICAL_CONFIG.fresnelR0;
      const ac = cfg?.attenuationColor ?? DEFAULT_WATER_OPTICAL_CONFIG.attenuationColor;
      const ad = cfg?.attenuationDistance ?? DEFAULT_WATER_OPTICAL_CONFIG.attenuationDistance;
      const esr = cfg?.esrIntensity ?? DEFAULT_WATER_OPTICAL_CONFIG.esrIntensity;
      const caust = cfg?.causticIntensity ?? DEFAULT_WATER_OPTICAL_CONFIG.causticIntensity;
      const fp = cfg?.footprintFilter ?? DEFAULT_WATER_OPTICAL_CONFIG.footprintFilter;

      if (cached.uIor) gl.uniform1f(cached.uIor, ior);
      if (cached.uFresnelR0) gl.uniform1f(cached.uFresnelR0, r0);
      if (cached.uAttenColor) gl.uniform3f(cached.uAttenColor, ac[0], ac[1], ac[2]);
      if (cached.uAttenDist) gl.uniform1f(cached.uAttenDist, ad);
      if (cached.uEsrIntensity) gl.uniform1f(cached.uEsrIntensity, esr);
      if (cached.uCausticIntensity) gl.uniform1f(cached.uCausticIntensity, caust);
      if (cached.uFootprint) gl.uniform1f(cached.uFootprint, fp ? 1 : 0);

      if (job.wave && cached.uWave) {
        const srcLen = job.wave.length;
        for (let i = 0; i < 24; i++) {
          const mapped = Math.min(srcLen - 1, Math.round((i / 23) * (srcLen - 1)));
          this.waveUploadBuf[i] = job.wave[mapped]?.height ?? 0;
        }
        gl.uniform1fv(cached.uWave, this.waveUploadBuf);
      }
    }

    if (job.kind === 'metal') {
      const mc = job.metalColor ?? [0.56, 0.69, 0.75];
      const mh = job.metalHighlight ?? [0.92, 0.98, 1.0];
      if (cached.uMetalColor) gl.uniform3f(cached.uMetalColor, mc[0], mc[1], mc[2]);
      if (cached.uMetalHighlight) gl.uniform3f(cached.uMetalHighlight, mh[0], mh[1], mh[2]);
    }

    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.disable(gl.SCISSOR_TEST);

    const src = fallback ?? offscreen;
    if (!src) return false;
    blit.ctx.clearRect(0, 0, pxW, pxH);
    // OffscreenCanvas is itself a CanvasImageSource. Drawing it directly avoids
    // allocating/transferring/closing a new ImageBitmap for every gauge frame.
    blit.ctx.drawImage(src, 0, src.height - pxH, pxW, pxH, 0, 0, pxW, pxH);
    return true;
  }

  subscribe(
    provider: () => FluidDrawJob | null,
    initialRenderAlreadyDone = false,
  ): () => void {
    this.subscribers.add(provider);
    if (!this.visibilityListenerAttached && typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', this.handleVisibilityChange);
      this.visibilityListenerAttached = true;
    }

    if (!initialRenderAlreadyDone) this.renderSinglePass(provider);
    const initialJob = provider();
    if (
      !this.webglFailed &&
      initialJob &&
      (initialJob.isAnimating || (initialJob.wave && this.hasActiveWave(initialJob.wave)))
    ) {
      this.startLoopIfNeeded();
    }

    return () => {
      this.subscribers.delete(provider);
      if (this.subscribers.size === 0) {
        if (this.rafId) cancelAnimationFrame(this.rafId);
        this.rafId = 0;
        if (this.visibilityListenerAttached && typeof document !== 'undefined') {
          document.removeEventListener('visibilitychange', this.handleVisibilityChange);
          this.visibilityListenerAttached = false;
        }
      }
    };
  }

  /**
   * Starts the shared renderer only after a value transition or a user impulse.
   * Static liquid is rendered once and then remains completely still.
   */
  wake(): void {
    if (this.webglFailed) return;
    if (
      typeof window === 'undefined' ||
      prefersReducedMotion() ||
      (typeof document !== 'undefined' && document.hidden)
    ) {
      return;
    }
    this.startLoopIfNeeded();
  }

  renderSinglePass(provider: () => FluidDrawJob | null): boolean {
    const job = provider();
    if (!job || !job.isVisible) return false;
    const ok = this.renderJobToTarget(job, this.elapsed);
    if (ok) {
      this.lastJobRenderAt.set(job.targetCanvas, performance.now());
    }
    return ok;
  }

  private hasActiveWave(nodes: SpringNode[]): boolean {
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      if (node && (Math.abs(node.height) > 0.012 || Math.abs(node.velocity) > 0.012)) {
        return true;
      }
    }
    return false;
  }

  private startLoopIfNeeded(): void {
    if (this.rafId || this.subscribers.size === 0) return;
    if (
      typeof window === 'undefined' ||
      prefersReducedMotion() ||
      (typeof document !== 'undefined' && document.hidden)
    ) {
      return;
    }

    this.lastTime = performance.now();

    const tick = (now: number) => {
      if (typeof document !== 'undefined' && document.hidden) {
        this.rafId = 0;
        return;
      }
      if (typeof window !== 'undefined' && prefersReducedMotion()) {
        for (const provider of this.subscribers) {
          const job = provider();
          if (job?.isVisible) this.renderJobToTarget(job, this.elapsed);
        }
        this.rafId = 0;
        return;
      }

      const dt = Math.min(0.05, Math.max(0, (now - this.lastTime) / 1000));
      this.lastTime = now;
      this.elapsed += dt;

      this.springAccumulator += dt;
      const springSubsteps = Math.min(3, Math.floor(this.springAccumulator * 60));
      if (springSubsteps > 0) this.springAccumulator -= springSubsteps / 60;
      this.activeJobScratch.length = 0;
      for (const provider of this.subscribers) {
        const job = provider();
        if (!job || !job.isVisible) continue;

        const waveActive = job.wave ? this.hasActiveWave(job.wave) : false;
        // Do not redraw static water at 30 fps. Only a fill transition or a
        // physical spring impulse is allowed to keep the GPU loop alive.
        if (!job.isAnimating && !waveActive) continue;

        if (waveActive && job.wave && springSubsteps > 0) {
          for (let step = 0; step < springSubsteps; step++) {
            stepSpringNodes(job.wave, 0.12, 0.20, 0.14);
          }
        }
        this.activeJobScratch.push(job);
      }

      if (this.activeJobScratch.length === 0) {
        this.rafId = 0;
        return;
      }

      for (let i = 0; i < this.activeJobScratch.length; i++) {
        const job = this.activeJobScratch[i];
        if (!job) continue;

        const prevAt = this.lastJobRenderAt.get(job.targetCanvas) ?? 0;
        if (now - prevAt >= MIN_FLUID_FRAME_INTERVAL_MS) {
          this.lastJobRenderAt.set(job.targetCanvas, now);
          this.renderJobToTarget(job, this.elapsed);
        }
      }

      this.rafId = requestAnimationFrame(tick);
    };

    this.rafId = requestAnimationFrame(tick);
  }

  private teardownContext(): void {
    const gl = this.gl;
    if (gl) {
      for (const cached of this.programs.values()) {
        gl.deleteProgram(cached.program);
      }
      this.programs.clear();
      if (this.quadBuffer) gl.deleteBuffer(this.quadBuffer);
      if (this.quadVao) gl.deleteVertexArray(this.quadVao);
    }
    this.quadBuffer = null;
    this.quadVao = null;
    this.gl = null;
    this.offscreenCanvas = null;
    this.fallbackCanvas = null;
  }
}

let sharedEngineSingleton: SharedFluidShaderEngine | null = null;

export function getSharedFluidEngine(): SharedFluidShaderEngine {
  if (!sharedEngineSingleton) {
    sharedEngineSingleton = new SharedFluidShaderEngine();
  }
  return sharedEngineSingleton;
}
