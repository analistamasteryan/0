import { useEffect, useState } from 'react';

interface BufferedNumberInputProps {
  value: number;
  min: number;
  max: number;
  step?: string | number;
  inputMode?: 'decimal' | 'numeric';
  integer?: boolean;
  ariaLabel?: string;
  className?: string;
  onCommit: (nextValue: number) => void;
}

export function BufferedNumberInput({
  value,
  min,
  max,
  step,
  inputMode = 'decimal',
  integer = false,
  ariaLabel,
  className,
  onCommit,
}: BufferedNumberInputProps) {
  const [draft, setDraft] = useState(String(value));

  useEffect(() => {
    setDraft(String(value));
  }, [value]);

  const parsed = draft.trim() === '' ? Number.NaN : Number(draft.replace(',', '.'));
  const isInvalid =
    draft.trim() !== '' && (!Number.isFinite(parsed) || parsed < min || parsed > max);

  const commit = () => {
    if (draft.trim() === '' || !Number.isFinite(parsed) || parsed < min || parsed > max) {
      setDraft(String(value));
      return;
    }
    const normalized = integer ? Math.round(parsed) : parsed;
    if (normalized < min || normalized > max) {
      setDraft(String(value));
      return;
    }
    setDraft(String(normalized));
    if (normalized !== value) {
      onCommit(normalized);
    }
  };

  return (
    <input
      type="number"
      inputMode={inputMode}
      min={min}
      max={max}
      step={step}
      value={draft}
      aria-label={ariaLabel}
      aria-invalid={isInvalid}
      onChange={(event) => setDraft(event.target.value)}
      onBlur={commit}
      onKeyDown={(event) => {
        if (event.key === 'Enter') {
          event.currentTarget.blur();
        } else if (event.key === 'Escape') {
          setDraft(String(value));
          event.currentTarget.blur();
        }
      }}
      className={className}
    />
  );
}
