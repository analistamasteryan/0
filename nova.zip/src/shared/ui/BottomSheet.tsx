import { useEffect, useId, useRef, useState, type ReactNode } from 'react';
import { Drawer } from 'vaul';
import { X } from 'lucide-react';
import { useEscapeKey } from '../hooks/use-escape-key';

interface BottomSheetProps {
  open: boolean;
  onClose: () => void;
  title: string;
  eyebrow?: string;
  subtitle?: string;
  animateOpen?: boolean;
  footer?: ReactNode;
  children: ReactNode;
}

const FOCUSABLE_SELECTOR = [
  'a[href]',
  'area[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(',');

let activeModalCount = 0;
let previousBodyOverflow = '';

function lockBodyScroll(): () => void {
  if (activeModalCount === 0) {
    previousBodyOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
  }
  activeModalCount += 1;
  return () => {
    activeModalCount = Math.max(0, activeModalCount - 1);
    if (activeModalCount === 0) {
      document.body.style.overflow = previousBodyOverflow;
      previousBodyOverflow = '';
    }
  };
}

export function BottomSheet({
  open,
  onClose,
  title,
  eyebrow,
  subtitle,
  animateOpen = true,
  footer,
  children,
}: BottomSheetProps) {
  const titleId = useId();
  const subtitleId = useId();
  const panelRef = useRef<HTMLDivElement | null>(null);
  const [panelEl, setPanelEl] = useState<HTMLDivElement | null>(null);
  useEscapeKey(open, onClose);

  useEffect(() => {
    if (!open) return;
    const panel = panelEl ?? panelRef.current;
    if (!panel) return;

    const previouslyFocused = document.activeElement instanceof HTMLElement
      ? document.activeElement
      : null;
    const releaseScrollLock = lockBodyScroll();
    const focusableElements = () => Array.from(
      panel.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR),
    ).filter((element) => element.getAttribute('aria-hidden') !== 'true' && element.getClientRects().length > 0);

    const firstFocusable = focusableElements()[0];
    (firstFocusable ?? panel).focus();

    const containFocus = (event: KeyboardEvent) => {
      if (event.key !== 'Tab') return;
      const focusable = focusableElements();
      if (focusable.length === 0) {
        event.preventDefault();
        panel.focus();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      const active = document.activeElement;
      if (event.shiftKey && (active === first || !panel.contains(active))) {
        event.preventDefault();
        last?.focus();
      } else if (!event.shiftKey && (active === last || !panel.contains(active))) {
        event.preventDefault();
        first?.focus();
      }
    };

    document.addEventListener('keydown', containFocus, true);
    return () => {
      document.removeEventListener('keydown', containFocus, true);
      releaseScrollLock();
      if (previouslyFocused?.isConnected) previouslyFocused.focus();
    };
  }, [open, panelEl]);

  return (
    <Drawer.Root
      open={open}
      onOpenChange={(nextOpen) => {
        if (!nextOpen) onClose();
      }}
      modal={false}
      shouldScaleBackground={false}
      repositionInputs={false}
    >
      <Drawer.Portal>
        <div
          className={`fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#060908]/82 backdrop-blur-[6px] ${
            animateOpen ? 'animate-sheet-backdrop' : ''
          }`}
          onClick={onClose}
        >
          <Drawer.Content
            ref={(node) => {
              panelRef.current = node;
              setPanelEl(node);
            }}
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            aria-describedby={subtitle ? subtitleId : undefined}
            tabIndex={-1}
            onClick={(event) => event.stopPropagation()}
            className={`titan-luxury-sheet w-full sm:max-w-lg border-t sm:border border-[rgba(200,173,122,0.18)] rounded-t-[28px] sm:rounded-[24px] max-h-[90dvh] flex flex-col overflow-hidden focus:outline-none ${
              animateOpen ? 'animate-sheet-panel' : ''
            }`}
          >
            <div className="sm:hidden pt-3 pb-1 flex justify-center shrink-0" aria-hidden="true">
              <div className="w-11 h-1 rounded-full bg-[var(--titan-champagne)]/35" />
            </div>

            <div className="flex items-start justify-between gap-4 px-5 pt-3.5 sm:pt-5 pb-4 border-b border-[rgba(193,204,196,0.10)] shrink-0">
              <div className="min-w-0">
                {eyebrow && (
                  <p className="titan-eyebrow mb-1">{eyebrow}</p>
                )}
                <Drawer.Title asChild>
                  <h2 id={titleId} className="text-lg font-semibold tracking-tight text-[var(--titan-text-primary)] truncate">
                    {title}
                  </h2>
                </Drawer.Title>
                {subtitle && (
                  <Drawer.Description asChild>
                    <p id={subtitleId} className="text-xs text-[var(--titan-text-secondary)] mt-0.5 leading-relaxed">
                      {subtitle}
                    </p>
                  </Drawer.Description>
                )}
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="Fechar painel"
                className="min-h-[44px] min-w-[44px] -mr-2 -mt-1 flex items-center justify-center rounded-2xl border border-transparent hover:border-[var(--titan-border)]/70 hover:bg-[var(--titan-surface-raised)]/60 text-[var(--titan-text-secondary)] hover:text-[var(--titan-text-primary)] shrink-0 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div
              data-vaul-no-drag=""
              className={`px-5 pt-4 overflow-y-auto flex-1 overscroll-contain ${footer ? 'pb-5' : 'pb-6 pb-safe'}`}
            >
              {children}
            </div>

            {footer && (
              <div className="shrink-0 px-5 pt-3 pb-4 pb-safe border-t border-[rgba(193,204,196,0.10)] bg-[#0E1412]/95">
                {footer}
              </div>
            )}
          </Drawer.Content>
        </div>
      </Drawer.Portal>
    </Drawer.Root>
  );
}
