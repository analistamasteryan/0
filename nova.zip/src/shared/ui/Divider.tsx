export function Divider({ className = '' }: { className?: string }) {
  return <div role="separator" className={`h-px w-full bg-[var(--titan-border)]/60 ${className}`} />;
}
