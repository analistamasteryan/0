export interface ExerciseHydrationInput {
  preExerciseWeightKg: number;
  postExerciseWeightKg: number;
  fluidIntakeMl: number;
  urineOutputMl: number;
  durationMinutes: number;
}

export interface ExerciseHydrationEstimate {
  estimatedSweatLossMl: number;
  sweatRateMlPerHour: number;
  netBodyMassLossPercent: number;
  netFluidDeficitMl: number;
  preExerciseFluidRangeMl: { lower: number; upper: number };
  postExerciseReplacementRangeMl: { lower: number; upper: number };
  interpretation: 'usable_measurement' | 'body_mass_gain_review' | 'invalid_fluid_balance';
  warnings: string[];
}

function assertNonNegativeFinite(value: number, label: string): void {
  if (!Number.isFinite(value) || value < 0) throw new RangeError(`${label} deve ser finito e não negativo.`);
}

/**
 * Estimates whole-session sweat loss from measured body-mass change corrected
 * for fluids consumed and urine produced. Weigh under comparable conditions
 * (same scale, minimal/dry clothing, emptied bladder where practical).
 *
 * This is a field estimate, not a laboratory sweat-sodium test. The 2026
 * athlete consensus describes 5–10 mL/kg 2–4 h before exercise, limiting
 * exercise body-mass loss to <2% while avoiding overdrinking, and replacing
 * 100–150% of net mass loss in the first 0–4 h after exercise.
 */
export function calculateExerciseHydration(
  input: ExerciseHydrationInput,
): ExerciseHydrationEstimate {
  if (!Number.isFinite(input.preExerciseWeightKg) || input.preExerciseWeightKg <= 0 ||
      !Number.isFinite(input.postExerciseWeightKg) || input.postExerciseWeightKg <= 0) {
    throw new RangeError('Os pesos antes e depois do exercício devem ser positivos e finitos.');
  }
  assertNonNegativeFinite(input.fluidIntakeMl, 'Líquido ingerido');
  assertNonNegativeFinite(input.urineOutputMl, 'Urina eliminada');
  if (!Number.isFinite(input.durationMinutes) || input.durationMinutes < 10 || input.durationMinutes > 1_440) {
    throw new RangeError('A duração precisa ficar entre 10 minutos e 24 horas.');
  }

  const massDeltaMl = (input.preExerciseWeightKg - input.postExerciseWeightKg) * 1_000;
  const rawSweatLossMl = massDeltaMl + input.fluidIntakeMl - input.urineOutputMl;
  const netBodyMassLossPercent = (massDeltaMl / input.preExerciseWeightKg / 1_000) * 100;
  const netFluidDeficitMl = Math.max(0, massDeltaMl);
  const preExerciseFluidRangeMl = {
    lower: Math.round(input.preExerciseWeightKg * 5 * 10) / 10,
    upper: Math.round(input.preExerciseWeightKg * 10 * 10) / 10,
  };
  const warnings: string[] = [
    'Repita a medição em condições semelhantes: horário, roupa, balança, clima, modalidade e intensidade alteram a taxa de suor.',
    'A taxa de suor não informa a concentração de sódio. Não prescreva sal/sódio a partir deste cálculo; isso requer avaliação específica.',
    'A faixa pré-exercício é uma referência para atletas, não uma obrigação de ingestão nem uma meta para pessoas com restrição hídrica.',
  ];

  if (rawSweatLossMl < 0) {
    warnings.push('O balanço resultou em perda de suor negativa; confira pesos, líquidos, urina, unidades e condições da pesagem. Não use esta taxa.');
    return {
      estimatedSweatLossMl: 0,
      sweatRateMlPerHour: 0,
      netBodyMassLossPercent: Number(netBodyMassLossPercent.toFixed(2)),
      netFluidDeficitMl,
      preExerciseFluidRangeMl,
      postExerciseReplacementRangeMl: { lower: Math.round(netFluidDeficitMl), upper: Math.round(netFluidDeficitMl * 1.5) },
      interpretation: 'invalid_fluid_balance',
      warnings,
    };
  }

  if (netBodyMassLossPercent < -0.1) {
    warnings.push('Houve ganho líquido de massa corporal durante a sessão. Isso pode indicar ingestão acima das perdas; não aumente a ingestão sem avaliar o risco de hiper-hidratação e hiponatremia.');
  } else if (netBodyMassLossPercent >= 2) {
    warnings.push('A perda líquida alcançou 2% ou mais da massa corporal; revise o plano de hidratação e as condições da sessão.');
  }
  if (input.durationMinutes < 60) {
    warnings.push('Sessões curtas podem produzir uma estimativa mais sensível a erro de balança, roupa molhada e pequenas diferenças de volume.');
  }

  return {
    estimatedSweatLossMl: Math.round(rawSweatLossMl),
    sweatRateMlPerHour: Math.round(rawSweatLossMl / (input.durationMinutes / 60)),
    netBodyMassLossPercent: Number(netBodyMassLossPercent.toFixed(2)),
    netFluidDeficitMl,
    preExerciseFluidRangeMl,
    postExerciseReplacementRangeMl: {
      lower: Math.round(netFluidDeficitMl),
      upper: Math.round(netFluidDeficitMl * 1.5),
    },
    interpretation: netBodyMassLossPercent < -0.1 ? 'body_mass_gain_review' : 'usable_measurement',
    warnings,
  };
}
