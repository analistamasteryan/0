import { getLocalDateKey } from '@/src/shared/utils/local-date';
import type {
  HydrationLogEntry,
  HydrationSummarySnapshot,
} from '../entities/hydration-entry';

export function getHydrationSummary(
  entries: HydrationLogEntry[],
  dailyGoalMl: number,
  dateKey: string = getLocalDateKey(),
): HydrationSummarySnapshot {
  const dayEntries = entries.filter((e) => e.dateKey === dateKey);
  const currentMl = dayEntries.reduce((sum, e) => sum + e.amountMl, 0);
  const rawPercent = dailyGoalMl > 0 ? Math.round((currentMl / dailyGoalMl) * 100) : 0;
  const barPercent = Math.min(100, Math.max(0, rawPercent));

  return {
    currentMl,
    goalMl: dailyGoalMl,
    percent: rawPercent,
    barPercent,
    hasRecords: dayEntries.length > 0,
    dayEntries,
  };
}
