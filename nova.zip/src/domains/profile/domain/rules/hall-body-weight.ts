/**
 * Transparent adult energy-balance model based on Hall et al. (2011),
 * Lancet, appendix equations. This is an independent TypeScript implementation
 * of the published model core, not the NIH Body Weight Planner application.
 *
 * Units: energy kJ/day; tissue energy densities kJ/kg; time days; sodium mg;
 * extracellular fluid L. Baseline carbohydrate fraction and activity are
 * explicit assumptions when individual measurements are unavailable.
 */
import type { BiologicalSex } from '../contracts/user-profile';

const KCAL_TO_KJ = 4.184;
const RHO_FAT_KJ_PER_KG = 39_500;
const RHO_LEAN_KJ_PER_KG = 7_600;
const RHO_GLYCOGEN_KJ_PER_KG = 17_600;
const GLYCOGEN_WATER_KG_PER_KG = 2.7;
const INITIAL_GLYCOGEN_KG = 0.5;
const TEF_FRACTION = 0.1;
const ADAPTIVE_THERMOGENESIS_FRACTION = 0.14;
const ADAPTIVE_THERMOGENESIS_TAU_DAYS = 14;
const NA_CONCENTRATION_MG_PER_L = 3_220;
const NA_RESTORATION_MG_PER_L_DAY = 3_000;
const CARB_FLUID_COUPLING_MG_PER_DAY = 4_000;
const GAMMA_FAT_KJ_PER_KG_DAY = 13;
const GAMMA_LEAN_KJ_PER_KG_DAY = 92;
const ETA_FAT_KJ_PER_KG = 750;
const ETA_LEAN_KJ_PER_KG = 960;
const MIN_DAILY_INTAKE_KCAL = 700;
const MAX_DAILY_INTAKE_KCAL = 8_000;

export interface HallBodyWeightInput {
  sex: BiologicalSex;
  age: number;
  heightCm: number;
  initialWeightKg: number;
  baselineTdeeKcal: number;
  targetWeightKg: number;
  days: number;
  /** DXA/BodPod/validated BIA input, not a waist-formula estimate. */
  bodyFatPercent?: number;
  /** Daily fraction of energy from carbohydrate. Defaults to 45%, surfaced as an assumption. */
  carbohydrateEnergyFraction?: number;
  /** Measured baseline RMR, otherwise Mifflin-St Jeor is used. */
  baselineRmrKcal?: number;
  /** Daily sodium intake change from baseline, milligrams/day. Defaults to 0. */
  sodiumChangeMgPerDay?: number;
}

export interface HallBodyWeightSimulation {
  predictedWeightKg: number;
  predictedFatMassKg: number;
  predictedLeanMassKg: number;
  predictedExtracellularFluidChangeKg: number;
  predictedGlycogenKg: number;
  finalEnergyExpenditureKcal: number;
  dailyIntakeKcal: number;
  days: number;
  model: 'hall_2011_adult_energy_balance_core_v1';
  bodyFatInitialization: 'user_supplied' | 'jackson_equation_estimate';
  carbohydrateEnergyFraction: number;
  warnings: string[];
}

export interface HallDailyIntakeSolution extends HallBodyWeightSimulation {
  converged: boolean;
  targetWeightKg: number;
  absoluteTargetErrorKg: number;
  iterations: number;
  searchRangeKcal: { min: number; max: number };
}

export function estimateHallBodyFatPercent(input: Pick<HallBodyWeightInput, 'sex' | 'age' | 'heightCm' | 'initialWeightKg'>): number {
  if ((input.sex !== 'male' && input.sex !== 'female') || !Number.isFinite(input.age) || input.age < 19 || input.age > 105 ||
      !Number.isFinite(input.heightCm) || input.heightCm < 110 || input.heightCm > 245 ||
      !Number.isFinite(input.initialWeightKg) || input.initialWeightKg < 30 || input.initialWeightKg > 300) {
    throw new RangeError('Dados antropométricos fora da faixa plausível para a estimativa de gordura corporal.');
  }
  const bmi = input.initialWeightKg / ((input.heightCm / 100) ** 2);
  const logBmi = Math.log(bmi);
  const estimate = input.sex === 'male'
    ? 0.14 * input.age + 37.31 * logBmi - 103.94
    : 0.14 * input.age + 39.96 * logBmi - 102.01;
  if (!Number.isFinite(estimate) || estimate < 2 || estimate > 70) {
    throw new RangeError('A estimativa antropométrica de gordura corporal saiu da faixa plausível; informe uma medição de composição corporal ou use a estimativa com outra fonte validada.');
  }
  return estimate;
}

/**
 * Effective energy per kilogram implied by Hall's fat/lean partition model.
 * p is the fraction of energy imbalance allocated to lean tissue.
 */
export function estimateHallEffectiveEnergyDensityKcalPerKg(input: {
  sex: BiologicalSex; age: number; heightCm: number; weightKg: number; bodyFatPercent?: number;
}): number {
  const bodyFatPercent = input.bodyFatPercent ?? estimateHallBodyFatPercent({
    sex: input.sex, age: input.age, heightCm: input.heightCm, initialWeightKg: input.weightKg,
  });
  if (!Number.isFinite(bodyFatPercent) || bodyFatPercent < 2 || bodyFatPercent > 70) {
    throw new RangeError('Percentual de gordura corporal deve estar entre 2% e 70%.');
  }
  const fatMassKg = input.weightKg * bodyFatPercent / 100;
  const partitionConstantKg = 10.4 * RHO_LEAN_KJ_PER_KG / RHO_FAT_KJ_PER_KG;
  const leanPartition = partitionConstantKg / (partitionConstantKg + fatMassKg);
  const kgPerKj = (1 - leanPartition) / RHO_FAT_KJ_PER_KG + leanPartition / RHO_LEAN_KJ_PER_KG;
  return 1 / kgPerKj / KCAL_TO_KJ;
}

function validateInput(input: HallBodyWeightInput): void {
  if (input.sex !== 'male' && input.sex !== 'female') throw new RangeError('Sexo biológico inválido para o modelo dinâmico.');
  if (![input.age, input.heightCm, input.initialWeightKg, input.baselineTdeeKcal, input.targetWeightKg, input.days].every(Number.isFinite)) {
    throw new RangeError('O modelo dinâmico recebeu valores não finitos.');
  }
  if (input.age < 19 || input.age > 105 || input.heightCm < 110 || input.heightCm > 245 ||
      input.initialWeightKg < 30 || input.initialWeightKg > 300 || input.targetWeightKg < 30 || input.targetWeightKg > 300 ||
      input.baselineTdeeKcal < 500 || input.baselineTdeeKcal > 8_000 || !Number.isInteger(input.days) || input.days < 1 || input.days > 3_650) {
    throw new RangeError('Perfil fora das faixas adultas suportadas pelo modelo dinâmico (prazo máximo de 10 anos).');
  }
  if (input.bodyFatPercent !== undefined && (!Number.isFinite(input.bodyFatPercent) || input.bodyFatPercent < 2 || input.bodyFatPercent > 70)) {
    throw new RangeError('Percentual de gordura corporal deve estar entre 2% e 70%.');
  }
  if (input.carbohydrateEnergyFraction !== undefined &&
      (!Number.isFinite(input.carbohydrateEnergyFraction) || input.carbohydrateEnergyFraction < 0.2 || input.carbohydrateEnergyFraction > 0.7)) {
    throw new RangeError('A fração energética de carboidratos deve ficar entre 20% e 70%.');
  }
  if (input.baselineRmrKcal !== undefined && (!Number.isFinite(input.baselineRmrKcal) || input.baselineRmrKcal < 300 || input.baselineRmrKcal > 5_000)) {
    throw new RangeError('RMR basal fornecida ao modelo dinâmico está fora da faixa plausível.');
  }
  if (input.sodiumChangeMgPerDay !== undefined && (!Number.isFinite(input.sodiumChangeMgPerDay) || Math.abs(input.sodiumChangeMgPerDay) > 10_000)) {
    throw new RangeError('Mudança de sódio diária fora da faixa suportada.');
  }
}

function mifflinRmr(input: HallBodyWeightInput): number {
  return 10 * input.initialWeightKg + 6.25 * input.heightCm - 5 * input.age + (input.sex === 'male' ? 5 : -161);
}

/** Simulate constant daily energy intake for a bounded adult horizon. */
export function simulateHallBodyWeight(input: HallBodyWeightInput, dailyIntakeKcal: number): HallBodyWeightSimulation {
  validateInput(input);
  if (!Number.isFinite(dailyIntakeKcal) || dailyIntakeKcal < MIN_DAILY_INTAKE_KCAL || dailyIntakeKcal > MAX_DAILY_INTAKE_KCAL) {
    throw new RangeError(`Ingestão diária deve ficar entre ${MIN_DAILY_INTAKE_KCAL} e ${MAX_DAILY_INTAKE_KCAL} kcal.`);
  }

  const bodyFatPercent = input.bodyFatPercent ?? estimateHallBodyFatPercent(input);
  const fatMassInitialKg = input.initialWeightKg * bodyFatPercent / 100;
  const glycogenInitialKg = INITIAL_GLYCOGEN_KG;
  const extracellularFluidDeviationInitialL = 0;
  const leanMassInitialKg = input.initialWeightKg - fatMassInitialKg - glycogenInitialKg * (1 + GLYCOGEN_WATER_KG_PER_KG);
  if (!Number.isFinite(leanMassInitialKg) || leanMassInitialKg <= 0) throw new RangeError('Composição corporal inicial incompatível com o peso informado.');

  let fatMassKg = fatMassInitialKg;
  let leanMassKg = leanMassInitialKg;
  let glycogenKg = glycogenInitialKg;
  let extracellularFluidDeviationL = extracellularFluidDeviationInitialL;
  let adaptiveThermogenesisKjPerDay = 0;

  const baselineEnergyKjPerDay = input.baselineTdeeKcal * KCAL_TO_KJ;
  const carbohydrateFraction = input.carbohydrateEnergyFraction ?? 0.45;
  const baselineCarbohydrateKjPerDay = baselineEnergyKjPerDay * carbohydrateFraction;
  const carbohydrateKjPerDay = dailyIntakeKcal * KCAL_TO_KJ * carbohydrateFraction;
  const glycogenTurnover = baselineCarbohydrateKjPerDay / (glycogenInitialKg ** 2);
  const rmrKjPerDay = (input.baselineRmrKcal ?? mifflinRmr(input)) * KCAL_TO_KJ;
  const pal = Math.max(1.2, Math.min(2.5, input.baselineTdeeKcal / (input.baselineRmrKcal ?? mifflinRmr(input))));
  const deltaKjPerKgDay = Math.max(0, ((1 - TEF_FRACTION) * pal - 1) * rmrKjPerDay / input.initialWeightKg);
  const partitionConstantKg = 10.4 * RHO_LEAN_KJ_PER_KG / RHO_FAT_KJ_PER_KG;
  const baselineKjPerDay = input.baselineTdeeKcal * KCAL_TO_KJ;
  // The integration constant is calibrated so the initial state is in energy balance.
  const metabolicConstantKjPerDay = baselineKjPerDay - GAMMA_FAT_KJ_PER_KG_DAY * fatMassKg -
    GAMMA_LEAN_KJ_PER_KG_DAY * leanMassKg - deltaKjPerKgDay * input.initialWeightKg;

  let finalEnergyExpenditureKjPerDay = baselineKjPerDay;
  const warnings: string[] = [];
  if (input.bodyFatPercent === undefined) warnings.push('Composição corporal inicial estimada pela equação antropométrica publicada por Hall; não é uma medição individual.');
  if (input.carbohydrateEnergyFraction === undefined) warnings.push('O modelo assume 45% da energia como carboidrato para inicializar o glicogênio; substitua por média dietética observada quando disponível.');
  if (input.sodiumChangeMgPerDay === undefined) warnings.push('Variação de sódio foi mantida em zero; mudanças relevantes de sódio podem alterar temporariamente a água extracelular e o peso.');
  if (input.baselineRmrKcal === undefined) warnings.push('RMR usada para calibrar atividade física foi estimada por Mifflin–St Jeor.');

  for (let day = 0; day < input.days; day += 1) {
    const bodyWeightBeforeKg = fatMassKg + leanMassKg + extracellularFluidDeviationL + glycogenKg * (1 + GLYCOGEN_WATER_KG_PER_KG);
    const leanPartition = partitionConstantKg / (partitionConstantKg + fatMassKg);
    const dynamicEnergyDensity = leanPartition * ETA_LEAN_KJ_PER_KG / RHO_LEAN_KJ_PER_KG +
      (1 - leanPartition) * ETA_FAT_KJ_PER_KG / RHO_FAT_KJ_PER_KG;
    const glycogenDerivativeKgPerDay = (carbohydrateKjPerDay - glycogenTurnover * glycogenKg ** 2) / RHO_GLYCOGEN_KJ_PER_KG;
    const extracellularFluidDerivativeLPerDay = (
      (input.sodiumChangeMgPerDay ?? 0) - NA_RESTORATION_MG_PER_L_DAY * extracellularFluidDeviationL -
      CARB_FLUID_COUPLING_MG_PER_DAY * (1 - carbohydrateKjPerDay / baselineCarbohydrateKjPerDay)
    ) / NA_CONCENTRATION_MG_PER_L;
    const tefChangeKjPerDay = TEF_FRACTION * (dailyIntakeKcal * KCAL_TO_KJ - baselineEnergyKjPerDay);
    const energyIntakeKjPerDay = dailyIntakeKcal * KCAL_TO_KJ;
    const energyExpenditureKjPerDay = (
      metabolicConstantKjPerDay + GAMMA_FAT_KJ_PER_KG_DAY * fatMassKg + GAMMA_LEAN_KJ_PER_KG_DAY * leanMassKg +
      deltaKjPerKgDay * bodyWeightBeforeKg + tefChangeKjPerDay + adaptiveThermogenesisKjPerDay +
      (energyIntakeKjPerDay - RHO_GLYCOGEN_KJ_PER_KG * glycogenDerivativeKgPerDay) * dynamicEnergyDensity
    ) / (1 + dynamicEnergyDensity);
    const tissueEnergySurplusKjPerDay = energyIntakeKjPerDay - energyExpenditureKjPerDay -
      RHO_GLYCOGEN_KJ_PER_KG * glycogenDerivativeKgPerDay;
    const fatDerivativeKgPerDay = (1 - leanPartition) * tissueEnergySurplusKjPerDay / RHO_FAT_KJ_PER_KG;
    const leanDerivativeKgPerDay = leanPartition * tissueEnergySurplusKjPerDay / RHO_LEAN_KJ_PER_KG;
    const adaptiveThermogenesisDerivative = (
      ADAPTIVE_THERMOGENESIS_FRACTION * (energyIntakeKjPerDay - baselineEnergyKjPerDay) - adaptiveThermogenesisKjPerDay
    ) / ADAPTIVE_THERMOGENESIS_TAU_DAYS;

    fatMassKg += fatDerivativeKgPerDay;
    leanMassKg += leanDerivativeKgPerDay;
    glycogenKg += glycogenDerivativeKgPerDay;
    extracellularFluidDeviationL += extracellularFluidDerivativeLPerDay;
    adaptiveThermogenesisKjPerDay += adaptiveThermogenesisDerivative;
    finalEnergyExpenditureKjPerDay = energyExpenditureKjPerDay;

    if (![fatMassKg, leanMassKg, glycogenKg, extracellularFluidDeviationL, adaptiveThermogenesisKjPerDay].every(Number.isFinite) ||
        fatMassKg <= 0 || leanMassKg <= 0 || glycogenKg < 0.05 || glycogenKg > 2 || Math.abs(extracellularFluidDeviationL) > 20) {
      throw new RangeError('Simulação dinâmica instável para esta combinação de ingestão e perfil; revise os dados e a faixa de entrada.');
    }
  }

  const predictedWeightKg = fatMassKg + leanMassKg + extracellularFluidDeviationL + glycogenKg * (1 + GLYCOGEN_WATER_KG_PER_KG);
  if (!Number.isFinite(predictedWeightKg) || predictedWeightKg < 25 || predictedWeightKg > 350) {
    throw new RangeError('O modelo dinâmico produziu peso final fora da faixa fisiológica suportada.');
  }
  return {
    predictedWeightKg: Number(predictedWeightKg.toFixed(3)),
    predictedFatMassKg: Number(fatMassKg.toFixed(3)),
    predictedLeanMassKg: Number(leanMassKg.toFixed(3)),
    predictedExtracellularFluidChangeKg: Number(extracellularFluidDeviationL.toFixed(3)),
    predictedGlycogenKg: Number(glycogenKg.toFixed(3)),
    finalEnergyExpenditureKcal: Math.round(finalEnergyExpenditureKjPerDay / KCAL_TO_KJ),
    dailyIntakeKcal: Math.round(dailyIntakeKcal),
    days: input.days,
    model: 'hall_2011_adult_energy_balance_core_v1',
    bodyFatInitialization: input.bodyFatPercent === undefined ? 'jackson_equation_estimate' : 'user_supplied',
    carbohydrateEnergyFraction: carbohydrateFraction,
    warnings,
  };
}

/** Find a constant daily intake that approaches the target weight at the supplied horizon. */
export function solveHallDailyIntakeForTarget(input: HallBodyWeightInput, options?: {
  minDailyIntakeKcal?: number; maxDailyIntakeKcal?: number; toleranceKg?: number; maxIterations?: number;
}): HallDailyIntakeSolution {
  validateInput(input);
  const minKcal = options?.minDailyIntakeKcal ?? MIN_DAILY_INTAKE_KCAL;
  const maxKcal = options?.maxDailyIntakeKcal ?? MAX_DAILY_INTAKE_KCAL;
  const toleranceKg = options?.toleranceKg ?? 0.05;
  const maxIterations = options?.maxIterations ?? 60;
  if (!Number.isFinite(minKcal) || !Number.isFinite(maxKcal) || minKcal < MIN_DAILY_INTAKE_KCAL || maxKcal > MAX_DAILY_INTAKE_KCAL || minKcal >= maxKcal) {
    throw new RangeError('Faixa de busca calórica inválida para o modelo dinâmico.');
  }
  if (!Number.isFinite(toleranceKg) || toleranceKg <= 0 || toleranceKg > 1 || !Number.isInteger(maxIterations) || maxIterations < 1 || maxIterations > 100) {
    throw new RangeError('Parâmetros de convergência inválidos.');
  }
  const simulate = (kcal: number) => simulateHallBodyWeight(input, kcal);
  const safeSimulate = (kcal: number): HallBodyWeightSimulation | null => {
    try { return simulate(kcal); } catch { return null; }
  };
  const baselineKcal = Math.max(minKcal, Math.min(maxKcal, input.baselineTdeeKcal));
  const baselineRun = safeSimulate(baselineKcal);
  if (!baselineRun) throw new RangeError('O estado basal do modelo dinâmico não pôde ser simulado com os dados informados.');
  let low = minKcal;
  let high = maxKcal;
  const lowRun = safeSimulate(low);
  const highRun = safeSimulate(high);
  const lowWeight = lowRun?.predictedWeightKg ?? Number.NEGATIVE_INFINITY;
  const highWeight = highRun?.predictedWeightKg ?? Number.POSITIVE_INFINITY;
  const candidates = [baselineRun, ...(lowRun ? [lowRun] : []), ...(highRun ? [highRun] : [])];
  let best = candidates.reduce((winner, candidate) =>
    Math.abs(candidate.predictedWeightKg - input.targetWeightKg) < Math.abs(winner.predictedWeightKg - input.targetWeightKg) ? candidate : winner,
  );
  let bestCalories = best.dailyIntakeKcal;
  let iterations = 0;
  let converged = Math.abs(best.predictedWeightKg - input.targetWeightKg) <= toleranceKg;
  const targetIsBracketed = input.targetWeightKg >= lowWeight && input.targetWeightKg <= highWeight;
  if (targetIsBracketed) {
    while (!converged && iterations < maxIterations) {
      const mid = (low + high) / 2;
      const run = safeSimulate(mid);
      iterations += 1;
      if (!run) {
        // Numerical/physiological limits are only used as a bracket boundary;
        // no invalid simulated weight is returned or treated as a valid result.
        if (input.targetWeightKg >= input.initialWeightKg) high = mid;
        else low = mid;
        continue;
      }
      if (Math.abs(run.predictedWeightKg - input.targetWeightKg) < Math.abs(best.predictedWeightKg - input.targetWeightKg)) {
        best = run;
        bestCalories = mid;
      }
      if (Math.abs(run.predictedWeightKg - input.targetWeightKg) <= toleranceKg) {
        best = run;
        bestCalories = mid;
        converged = true;
        break;
      }
      if (run.predictedWeightKg < input.targetWeightKg) low = mid;
      else high = mid;
    }
  }

  return {
    ...best,
    dailyIntakeKcal: Math.round(bestCalories),
    targetWeightKg: input.targetWeightKg,
    absoluteTargetErrorKg: Number(Math.abs(best.predictedWeightKg - input.targetWeightKg).toFixed(3)),
    converged,
    iterations,
    searchRangeKcal: { min: minKcal, max: maxKcal },
    warnings: [...best.warnings, ...(lowRun === null || highRun === null ? ['Um dos extremos da faixa calórica excedeu os limites numéricos/fisiológicos do modelo e foi tratado apenas como limite de busca.'] : []), ...(!targetIsBracketed ? ['O peso-alvo ficou fora da faixa simulável de ingestão; foi selecionado o estado válido mais próximo.'] : []), ...(!converged ? ['A meta não foi alcançada dentro da faixa calórica de busca; a estimativa representa o ponto válido mais próximo, não uma garantia de resultado.'] : [])],
  };
}
