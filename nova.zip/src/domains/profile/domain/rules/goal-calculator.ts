import { estimateRestingMetabolicRate } from './resting-metabolic-rate.ts';
import { estimateHallEffectiveEnergyDensityKcalPerKg, solveHallDailyIntakeForTarget } from './hall-body-weight.ts';
import type { AdaptiveTdeeEstimate } from './adaptive-energy';
import type {
  BiologicalSex,
  ComputedGoalTargets,
  DailyActivityLevel,
  FitnessGoalType,
  UserPhysiologicalProfile,
} from '../contracts/user-profile';

export type NASEMActivityCategory = 'inactive' | 'low_active' | 'active' | 'very_active';

export interface ActivityLevelOption {
  id: DailyActivityLevel;
  label: string;
  nasemCategory: NASEMActivityCategory;
  nasemLabel: string;
  description: string;
}

/**
 * The profile keeps its five established choices for persisted-data compatibility.
 * NASEM 2023 has four PAL categories, so adjacent app choices intentionally map
 * into the same published category rather than inventing a fifth equation.
 */
export const ACTIVITY_LEVEL_OPTIONS: readonly ActivityLevelOption[] = [
  { id: 'sedentary', label: 'Sedentário', nasemCategory: 'inactive', nasemLabel: 'Inativo', description: 'Trabalho sentado e pouco deslocamento diário (< 4 mil passos). Categoria inicial de atividade.' },
  { id: 'light', label: 'Leve', nasemCategory: 'low_active', nasemLabel: 'Pouco ativo', description: 'Caminhadas leves ou treino 1 a 3x por semana (4–6 mil passos). Categoria aproximada; passos não medem PAL diretamente.' },
  { id: 'moderate', label: 'Moderado', nasemCategory: 'active', nasemLabel: 'Ativo', description: 'Rotina ativa com treino regular 3 a 5x por semana (6–9 mil passos). Categoria aproximada.' },
  { id: 'high', label: 'Alto', nasemCategory: 'active', nasemLabel: 'Ativo', description: 'Treinos intensos 6x/semana ou trabalho físico (9–12 mil passos). Categoria aproximada.' },
  { id: 'very_high', label: 'Muito Alto', nasemCategory: 'very_active', nasemLabel: 'Muito ativo', description: 'Atleta ou volume diário duplo / alta demanda física (> 12 mil passos). Categoria aproximada; individualize pelo histórico.' },
] as const;

export interface GoalOption {
  id: FitnessGoalType;
  label: string;
  shortHint: string;
}

export const GOAL_OPTIONS: readonly GoalOption[] = [
  { id: 'gain_muscle', label: 'Ganhar Massa', shortHint: 'Superávit controlado com alta densidade proteica' },
  { id: 'lose_weight', label: 'Perder Peso', shortHint: 'Déficit sustentável preservando massa magra' },
  { id: 'recomposition', label: 'Recomposição Corporal', shortHint: 'Manutenção calórica estratégica com proteína elevada' },
  { id: 'maintain', label: 'Manter Peso', shortHint: 'Equilíbrio energético alinhado ao gasto diário' },
] as const;

const MAX_GAIN_RATE_PER_WEEK = 0.0025;
const MAX_LOSS_RATE_PER_WEEK = 0.0075;

function localDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function isValidDateKey(dateKey: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return false;
  const [year, month, day] = dateKey.split('-').map(Number);
  const parsed = new Date(Date.UTC(year!, month! - 1, day!));
  return parsed.getUTCFullYear() === year && parsed.getUTCMonth() === month! - 1 && parsed.getUTCDate() === day;
}

export function daysBetweenDateKeys(fromKey: string, toKey: string): number | null {
  if (!isValidDateKey(fromKey) || !isValidDateKey(toKey)) return null;
  const [fy, fm, fd] = fromKey.split('-').map(Number);
  const [ty, tm, td] = toKey.split('-').map(Number);
  const from = Date.UTC(fy!, fm! - 1, fd!);
  const to = Date.UTC(ty!, tm! - 1, td!);
  return Math.round((to - from) / 86_400_000);
}

/**
 * NASEM 2023 Table S-3 adult Estimated Energy Requirement (EER).
 * Units: age in years, height in centimetres, weight in kilograms, kcal/day.
 * This is a population prediction, not a measured metabolic rate.
 */
export function estimateNASEM2023Eer(input: {
  sex: BiologicalSex;
  age: number;
  heightCm: number;
  weightKg: number;
  activityCategory: NASEMActivityCategory;
}): number {
  const values = [input.age, input.heightCm, input.weightKg];
  if (input.sex !== 'male' && input.sex !== 'female') {
    throw new RangeError('Sexo de referência inválido para a equação NASEM 2023.');
  }
  if (!['inactive', 'low_active', 'active', 'very_active'].includes(input.activityCategory)) {
    throw new RangeError('Categoria de atividade inválida para a equação NASEM 2023.');
  }
  if (!values.every(Number.isFinite) || input.age < 19 || input.heightCm <= 0 || input.weightKg <= 0) {
    throw new RangeError('Os dados para a equação NASEM 2023 precisam ser finitos, positivos e destinados a adultos de 19 anos ou mais.');
  }

  const { age, heightCm, weightKg, sex, activityCategory } = input;
  let estimate: number;
  if (sex === 'male') {
    switch (activityCategory) {
      case 'inactive': estimate = 753.07 - 10.83 * age + 6.50 * heightCm + 14.10 * weightKg; break;
      case 'low_active': estimate = 581.47 - 10.83 * age + 8.30 * heightCm + 14.94 * weightKg; break;
      case 'active': estimate = 1004.82 - 10.83 * age + 6.52 * heightCm + 15.91 * weightKg; break;
      case 'very_active': estimate = -517.88 - 10.83 * age + 15.61 * heightCm + 19.11 * weightKg; break;
    }
  } else {
    switch (activityCategory) {
      case 'inactive': estimate = 584.90 - 7.01 * age + 5.72 * heightCm + 11.71 * weightKg; break;
      case 'low_active': estimate = 575.77 - 7.01 * age + 6.60 * heightCm + 12.14 * weightKg; break;
      case 'active': estimate = 710.25 - 7.01 * age + 6.54 * heightCm + 12.34 * weightKg; break;
      case 'very_active': estimate = 511.83 - 7.01 * age + 9.07 * heightCm + 12.56 * weightKg; break;
    }
  }
  if (!Number.isFinite(estimate) || estimate <= 0) throw new RangeError('A equação NASEM 2023 produziu uma estimativa inválida para este perfil.');
  return Math.round(estimate);
}

export function resolveDriProfileId(
  sex: BiologicalSex,
  age: number,
): ComputedGoalTargets['driProfileId'] {
  if (age >= 71) return sex === 'female' ? 'adult_female_71_plus' : 'adult_male_71_plus';
  if (age >= 51) return sex === 'female' ? 'adult_female_51_70' : 'adult_male_51_70';
  if (age < 31) return sex === 'female' ? 'adult_female_19_30' : 'adult_male_19_30';
  return sex === 'female' ? 'adult_female_19_50' : 'adult_male_19_50';
}

function assertValidProfile(profile: UserPhysiologicalProfile): void {
  if (profile.sex !== 'male' && profile.sex !== 'female') throw new RangeError('Sexo biológico de referência inválido.');
  if (!['gain_muscle', 'lose_weight', 'recomposition', 'maintain'].includes(profile.goal)) throw new RangeError('Objetivo físico inválido.');
  if (!ACTIVITY_LEVEL_OPTIONS.some((option) => option.id === profile.activityLevel)) throw new RangeError('Nível de atividade física inválido.');
  const numericValues = [profile.currentWeightKg, profile.targetWeightKg, profile.heightCm, profile.age];
  if (!numericValues.every(Number.isFinite)) throw new RangeError('O perfil contém valores numéricos inválidos.');
  if (profile.currentWeightKg < 30 || profile.currentWeightKg > 300 ||
      profile.targetWeightKg < 30 || profile.targetWeightKg > 300 ||
      profile.heightCm < 110 || profile.heightCm > 245 ||
      profile.age < 19 || profile.age > 105 || !Number.isInteger(profile.age)) {
    throw new RangeError('O perfil precisa respeitar as faixas aceitas: pesos de 30 a 300 kg, altura de 110 a 245 cm e idade inteira de 19 a 105 anos.');
  }
  if (profile.bodyFatPercent !== undefined && !profile.fatFreeMassSource) {
    throw new RangeError('Percentual de gordura corporal exige origem declarada para manter a proveniência da composição.');
  }
}

/**
 * TDEE inicial pela equação adulta NASEM 2023 + ajuste calórico limitado por
 * velocidade semanal e proporção do TDEE. Mifflin–St Jeor permanece como
 * estimativa auxiliar de TMB; o ajuste usa densidade energética de planejamento,
 * não um modelo dinâmico de peso corporal.
 */
export function calculatePhysiologicalGoalTargets(
  profile: UserPhysiologicalProfile,
  anchorDateKey = localDateKey(new Date()),
  adaptiveTdee?: AdaptiveTdeeEstimate | null,
): ComputedGoalTargets {
  assertValidProfile(profile);

  const warnings: string[] = [];
  const rmrEstimate = estimateRestingMetabolicRate({
    sex: profile.sex, age: profile.age, heightCm: profile.heightCm, weightKg: profile.currentWeightKg,
    ...(profile.bodyFatPercent !== undefined ? { bodyFatPercent: profile.bodyFatPercent } : {}),
    ...(profile.fatFreeMassSource ? { fatFreeMassSource: profile.fatFreeMassSource } : {}),
    ...(profile.measuredRmrKcal !== undefined ? { measuredRmrKcal: profile.measuredRmrKcal } : {}),
  }, profile.rmrMethod ?? 'mifflin_st_jeor');
  const bmr = rmrEstimate.kcalPerDay;
  const activitySpec = ACTIVITY_LEVEL_OPTIONS.find((item) => item.id === profile.activityLevel);
  if (!activitySpec) throw new RangeError('Nível de atividade física inválido.');
  const adaptiveTdeeIsUsable = Boolean(
    adaptiveTdee &&
    adaptiveTdee.confidence !== 'low' &&
    Number.isFinite(adaptiveTdee.estimateKcal) && adaptiveTdee.estimateKcal >= 500 && adaptiveTdee.estimateKcal <= 8_000 &&
    Number.isFinite(adaptiveTdee.lowerBoundKcal) && Number.isFinite(adaptiveTdee.upperBoundKcal) &&
    adaptiveTdee.lowerBoundKcal >= 500 && adaptiveTdee.upperBoundKcal <= 8_000 &&
    adaptiveTdee.lowerBoundKcal <= adaptiveTdee.estimateKcal && adaptiveTdee.estimateKcal <= adaptiveTdee.upperBoundKcal
  );
  const useAdaptiveTdee = adaptiveTdeeIsUsable;
  const equationTdee = estimateNASEM2023Eer({
    sex: profile.sex,
    age: profile.age,
    heightCm: profile.heightCm,
    weightKg: profile.currentWeightKg,
    activityCategory: activitySpec.nasemCategory,
  });
  const tdee = Math.round(useAdaptiveTdee ? adaptiveTdee!.estimateKcal : equationTdee);
  if (useAdaptiveTdee) {
    warnings.push('TDEE calibrado com ingestão registrada e tendência de peso por filtro de Kalman; a faixa é a incerteza interna do modelo e ainda não foi calibrada externamente.');
  } else if (adaptiveTdee) {
    warnings.push(adaptiveTdee.confidence === 'low'
      ? 'A estimativa adaptativa ainda tem confiança baixa; foi mantida a estimativa inicial pela equação NASEM 2023 e categoria de atividade.'
      : 'A estimativa adaptativa continha valores ou limites inválidos; foi descartada e mantida a estimativa inicial pela equação NASEM 2023.');
  }
  if (!useAdaptiveTdee) {
    warnings.push(`TDEE inicial estimado pela equação NASEM 2023 (Tabela S-3), categoria ${activitySpec.nasemLabel.toLowerCase()}. A categoria de atividade é um proxy; passos e frequência de treino não medem PAL diretamente.`);
  }
  const weightDeltaKg = profile.targetWeightKg - profile.currentWeightKg;
  const daysToDeadline = daysBetweenDateKeys(anchorDateKey, profile.deadlineDateKey);

  let requestedCalorieAdjustmentKcal = 0;
  let calorieAdjustmentKcal = 0;
  let bodyWeightModel: ComputedGoalTargets['bodyWeightModel'];
  let effectiveEnergyDensityKcalPerKg: number;
  try {
    effectiveEnergyDensityKcalPerKg = estimateHallEffectiveEnergyDensityKcalPerKg({
      sex: profile.sex, age: profile.age, heightCm: profile.heightCm, weightKg: profile.currentWeightKg,
      ...(profile.bodyFatPercent !== undefined ? { bodyFatPercent: profile.bodyFatPercent } : {}),
    });
  } catch {
    effectiveEnergyDensityKcalPerKg = 6_000;
    warnings.push('Não foi possível estimar densidade energética por composição; foi usado um valor conservador de fallback apenas para o limite de velocidade.');
  }
  warnings.push(...rmrEstimate.warnings);
  if (profile.bodyFatPercent !== undefined && profile.fatFreeMassSource === 'other') {
    warnings.push('A composição corporal foi informada com origem não especificada como método validado; a densidade energética derivada pode ter erro relevante.');
  }

  if (profile.goal === 'gain_muscle' || profile.goal === 'lose_weight') {
    const directionMatchesGoal = profile.goal === 'gain_muscle' ? weightDeltaKg > 0 : weightDeltaKg < 0;
    if (!directionMatchesGoal && Math.abs(weightDeltaKg) > 0.05) {
      warnings.push(profile.goal === 'gain_muscle'
        ? 'O peso-alvo está abaixo do peso atual; o objetivo de ganho de massa não foi convertido em superávit.'
        : 'O peso-alvo está acima do peso atual; o objetivo de perda de peso não foi convertido em déficit.');
    } else if (Math.abs(weightDeltaKg) > 0.05) {
      if (daysToDeadline === null || daysToDeadline <= 0) {
        warnings.push('Prazo inválido ou vencido na data de referência; foi mantida a estimativa de manutenção.');
      } else {
        const isGain = profile.goal === 'gain_muscle';
        if (daysToDeadline > 3_650) {
          const fallbackAdjustment = (weightDeltaKg * effectiveEnergyDensityKcalPerKg) / daysToDeadline;
          requestedCalorieAdjustmentKcal = Math.round(fallbackAdjustment);
          warnings.push('O prazo ultrapassa os 10 anos suportados pelo core dinâmico Hall; o modelo não foi extrapolado. Foi usado apenas um ajuste aproximado e limitado por segurança.');
        } else {
          try {
            const solution = solveHallDailyIntakeForTarget({
              sex: profile.sex, age: profile.age, heightCm: profile.heightCm,
              initialWeightKg: profile.currentWeightKg, baselineTdeeKcal: tdee,
              targetWeightKg: profile.targetWeightKg, days: daysToDeadline,
              ...(profile.bodyFatPercent !== undefined ? { bodyFatPercent: profile.bodyFatPercent } : {}),
              baselineRmrKcal: bmr,
            });
            bodyWeightModel = {
              version: solution.model,
              predictedWeightKg: solution.predictedWeightKg,
              targetWeightKg: solution.targetWeightKg,
              absoluteTargetErrorKg: solution.absoluteTargetErrorKg,
              dailyModelIntakeKcal: solution.dailyIntakeKcal,
              bodyFatInitialization: solution.bodyFatInitialization,
              converged: solution.converged,
            };
            warnings.push(...solution.warnings);
            requestedCalorieAdjustmentKcal = Math.round(solution.dailyIntakeKcal - tdee);
          } catch (error) {
            const fallbackAdjustment = (weightDeltaKg * effectiveEnergyDensityKcalPerKg) / daysToDeadline;
            requestedCalorieAdjustmentKcal = Math.round(fallbackAdjustment);
            warnings.push(`O modelo dinâmico não pôde resolver este prazo (${error instanceof Error ? error.message : 'entrada inválida'}); ajuste aproximado por densidade de composição foi usado apenas como fallback.`);
          }
        }
        const weeklyRateLimit = profile.currentWeightKg * (isGain ? MAX_GAIN_RATE_PER_WEEK : MAX_LOSS_RATE_PER_WEEK);
        const rateBasedDailyLimit = (weeklyRateLimit * effectiveEnergyDensityKcalPerKg) / 7;
        const tdeeBasedLimit = tdee * (isGain ? 0.1 : 0.2);
        const absoluteLimit = Math.min(rateBasedDailyLimit, tdeeBasedLimit, isGain ? 300 : 500);
        const requestedMagnitude = Math.abs(requestedCalorieAdjustmentKcal);
        const acceptedMagnitude = Math.min(requestedMagnitude, absoluteLimit);
        calorieAdjustmentKcal = Math.round(isGain ? acceptedMagnitude : -acceptedMagnitude);

        if (requestedMagnitude > absoluteLimit + 1) {
          warnings.push('O prazo exige uma variação mais rápida que o limite conservador; a meta diária foi limitada e o peso-alvo pode não ser atingido no prazo.');
        }
      }
    }
  }

  warnings.push('Sem calorimetria indireta, RMR/TDEE continuam estimativas. O ajuste por prazo usa o núcleo dinâmico de balanço energético de Hall et al. (2011), com composição corporal inicial medida ou estimada; não é uma previsão individual garantida.');
  warnings.push('O modelo dinâmico assume 45% da energia em carboidratos e sódio estável quando esses dados não são fornecidos; mudanças de macros, água, sódio, ciclo menstrual e doença podem gerar variações de peso que não representam gordura ou músculo.');
  warnings.push('Calibre metas com registros completos de ingestão e tendência de peso por pelo menos 3–4 semanas; não ajuste por pesagem isolada.');

  if (profile.age > 78) {
    warnings.push('A RMR auxiliar de Mifflin–St Jeor pode ter menor acurácia em idades avançadas; calorimetria indireta é preferível quando a precisão individual é necessária.');
  }
  if (profile.age > 50) {
    warnings.push('As referências de micronutrientes usam faixas adultas por sexo (51–70 e 71+); menopausa, gestação, lactação e condições clínicas não são inferidas.');
  }

  const plannedKcal = Math.max(1, Math.round(tdee + calorieAdjustmentKcal));
  const proteinFactor = profile.goal === 'lose_weight' || profile.goal === 'recomposition'
    ? 2.0
    : profile.goal === 'gain_muscle' ? 1.8 : 1.6;
  const proteinRangePerKg = profile.goal === 'maintain'
    ? { min: 1.2, max: 1.6 }
    : { min: 1.6, max: 2.2 };
  const proteinMinG = Math.round(profile.currentWeightKg * proteinRangePerKg.min);
  const proteinMaxG = Math.round(profile.currentWeightKg * proteinRangePerKg.max);
  const proteinG = Math.round(profile.currentWeightKg * proteinFactor);
  const fatMinG = Math.round(profile.currentWeightKg * 0.6);
  const minimumMacroEnergyKcal = proteinG * 4 + fatMinG * 9;
  const kcal = Math.max(plannedKcal, minimumMacroEnergyKcal);
  if (kcal > plannedKcal) {
    warnings.push('A meta calórica planejada não comportava simultaneamente a proteína e a gordura mínimas configuradas; o valor energético foi elevado para evitar macros incompatíveis com a própria meta. Reavalie o prazo e a estratégia.');
  }
  const fatG = Math.max(fatMinG, Math.round((kcal * 0.25) / 9));
  const carbsG = Math.max(0, Math.round((kcal - proteinG * 4 - fatG * 9) / 4));

  if (carbsG === 0) {
    warnings.push('A combinação de energia, proteína e gordura deixou pouca energia residual para carboidratos; revise as metas com um nutricionista.');
  }

  // Keep the established 32 mL/kg baseline, but do not add arbitrary fixed
  // activity bonuses. Exercise fluid needs are calculated from measured sweat
  // rate in the dedicated exercise-hydration calculator.
  const waterMl = Math.round((profile.currentWeightKg * 32) / 50) * 50;
  warnings.push('Hidratação diária de 32 mL/kg é apenas uma referência inicial, não uma prescrição universal nem a ingestão total de água da DRI. Ajuste exercício pelo suor medido, clima e tolerância; evite beber além das perdas.');
  const bmi = profile.currentWeightKg / Math.pow(profile.heightCm / 100, 2);
  if (bmi >= 30) {
    warnings.push('IMC ≥ 30: a meta proteica calculada pelo peso corporal atual pode superestimar a necessidade; considere peso de referência ou massa livre de gordura com avaliação profissional.');
  }

  return {
    bmr,
    tdee,
    kcal,
    proteinG,
    carbsG,
    fatG,
    waterMl: Math.min(6000, Math.max(1500, waterMl)),
    driProfileId: resolveDriProfileId(profile.sex, profile.age),
    calorieAdjustmentKcal,
    requestedCalorieAdjustmentKcal,
    proteinMinG,
    proteinMaxG,
    tdeeSource: useAdaptiveTdee ? 'observed_adaptive' : 'equation_nasem_2023',
    energyEquationVersion: bodyWeightModel ? 'HALL_2011_DYNAMIC_CORE_V1' : useAdaptiveTdee ? 'observed_adaptive_v1' : 'NASEM_2023_TABLE_S3',
    bodyWeightModel,
    tdeeActivityCategory: activitySpec.nasemCategory,
    tdeeRangeKcal: useAdaptiveTdee ? { lower: adaptiveTdee!.lowerBoundKcal, upper: adaptiveTdee!.upperBoundKcal } : undefined,
    energyDensityAssumptions: { low: Math.round(effectiveEnergyDensityKcalPerKg * 0.8), central: Math.round(effectiveEnergyDensityKcalPerKg), high: Math.round(effectiveEnergyDensityKcalPerKg * 1.2) },
    warnings,
  };
}
