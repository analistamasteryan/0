import assert from 'node:assert/strict';
import { mergeProfilePersistedState } from '../profile-persistence.ts';

const current = {
  profile: {
    sex: 'male', goal: 'gain_muscle', currentWeightKg: 79.1, targetWeightKg: 82,
    activityLevel: 'moderate', deadlineDateKey: '2027-02-20', heightCm: 179, age: 29,
  },
  profileConfigured: false,
};

const valid = { ...current.profile, currentWeightKg: 80.4, deadlineDateKey: '2027-03-01' };
assert.deepEqual(mergeProfilePersistedState({ profile: valid }, current), { profile: valid, profileConfigured: true });
assert.deepEqual(mergeProfilePersistedState({ profile: current.profile }, current), current, 'legacy hard-coded defaults remain unconfigured');
assert.deepEqual(mergeProfilePersistedState({ profile: valid, profileConfigured: false }, current), { profile: valid, profileConfigured: false });
assert.deepEqual(
  mergeProfilePersistedState({ profile: { ...valid, deadlineDateKey: '2027-02-30' } }, current),
  current,
  'invalid calendar dates must not enter persisted profile state',
);
assert.deepEqual(
  mergeProfilePersistedState({ profile: { ...valid, activityLevel: 'extreme' } }, current),
  current,
  'unknown enum values must fall back to the last valid profile',
);
assert.deepEqual(mergeProfilePersistedState({ profile: null }, current), current);
assert.deepEqual(mergeProfilePersistedState({ profile: { ...valid, age: 29.5 } }, current), current, 'fractional ages must not enter the persisted profile');
assert.deepEqual(mergeProfilePersistedState({ profile: { ...valid, rmrMethod: 'cunningham_1980' } }, current), current, 'FFM-based RMR methods require a provenance-backed body-fat value or measured RMR');
assert.deepEqual(mergeProfilePersistedState({ profile: { ...valid, bodyFatPercent: 18 } }, current), current, 'body-fat values require source provenance');
console.log('Profile persistence tests passed.');
