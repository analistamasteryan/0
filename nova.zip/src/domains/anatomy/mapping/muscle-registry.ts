import type { MuscleGroupId } from '@/src/shared/types/common';

export type AnatomicalView = 'frontal' | 'posterior' | 'lateral';
export type AnatomicalRegionZone = 'upper' | 'core' | 'lower';

export interface MuscleDefinition {
  id: MuscleGroupId;
  label: string;
  latinName: string;
  preferredView: AnatomicalView;
  zone: AnatomicalRegionZone;
  functionSummary: string;
  /** Search aliases; these never create new selectable muscle IDs. */
  aliases: readonly string[];
}

export const MUSCLE_REGISTRY: Record<MuscleGroupId, MuscleDefinition> = {
  pectoralis: {
    id: 'pectoralis',
    label: 'Peitoral Maior',
    latinName: 'Pectoralis major',
    preferredView: 'frontal',
    zone: 'upper',
    functionSummary: 'Adução horizontal e flexão do ombro em empurradas.',
    aliases: ['peito', 'peitoral', 'peitoral maior', 'chest'],
  },
  anterior_deltoid: {
    id: 'anterior_deltoid',
    label: 'Deltoide Anterior',
    latinName: 'Deltoideus pars clavicularis',
    preferredView: 'frontal',
    zone: 'upper',
    functionSummary: 'Elevação frontal e assistência em supinos.',
    aliases: ['ombro frontal', 'deltoide frontal', 'anterior do ombro'],
  },
  lateral_deltoid: {
    id: 'lateral_deltoid',
    label: 'Deltoide Lateral',
    latinName: 'Deltoideus pars acromialis',
    preferredView: 'lateral',
    zone: 'upper',
    functionSummary: 'Abdução do braço e amplitude lateral de ombros.',
    aliases: ['ombro lateral', 'deltoide médio', 'lateral do ombro'],
  },
  posterior_deltoid: {
    id: 'posterior_deltoid',
    label: 'Deltoide Posterior',
    latinName: 'Deltoideus pars spinalis',
    preferredView: 'posterior',
    zone: 'upper',
    functionSummary: 'Abdução horizontal e estabilidade escapular em puxadas.',
    aliases: ['ombro posterior', 'deltoide traseiro', 'posterior do ombro'],
  },
  biceps: {
    id: 'biceps',
    label: 'Bíceps Braquial',
    latinName: 'Biceps brachii',
    preferredView: 'frontal',
    zone: 'upper',
    functionSummary: 'Flexão do cotovelo e supinação do antebraço.',
    aliases: ['bíceps', 'biceps braquial', 'braço anterior'],
  },
  triceps: {
    id: 'triceps',
    label: 'Tríceps Braquial',
    latinName: 'Triceps brachii',
    preferredView: 'posterior',
    zone: 'upper',
    functionSummary: 'Extensão do cotovelo e bloqueio em movimentos de empurrar.',
    aliases: ['tríceps', 'triceps braquial', 'braço posterior'],
  },
  forearms: {
    id: 'forearms',
    label: 'Antebraços',
    latinName: 'Flexores e extensores do carpo',
    preferredView: 'frontal',
    zone: 'upper',
    functionSummary: 'Preensão, estabilidade de punho e suporte de carga.',
    aliases: ['antebraco', 'antebraço', 'punho', 'grip'],
  },
  abdominals: {
    id: 'abdominals',
    label: 'Abdômen',
    latinName: 'Rectus abdominis',
    preferredView: 'frontal',
    zone: 'core',
    functionSummary: 'Estabilização do tronco e transferência de força.',
    aliases: ['abdomen', 'abdômen', 'core', 'six pack'],
  },
  latissimus: {
    id: 'latissimus',
    label: 'Dorsais',
    latinName: 'Latissimus dorsi',
    preferredView: 'posterior',
    zone: 'upper',
    functionSummary: 'Extensão e adução do úmero em remadas e barras.',
    aliases: ['dorsal', 'costas', 'grande dorsal', 'lat'],
  },
  trapezius: {
    id: 'trapezius',
    label: 'Trapézio',
    latinName: 'Trapezius',
    preferredView: 'posterior',
    zone: 'upper',
    functionSummary: 'Elevação, retração e controle da escápula.',
    aliases: ['trapezio', 'trapézio', 'upper back'],
  },
  glutes: {
    id: 'glutes',
    label: 'Glúteos',
    latinName: 'Gluteus maximus & medius',
    preferredView: 'posterior',
    zone: 'lower',
    functionSummary: 'Extensão de quadril e estabilização pélvica.',
    aliases: ['gluteo', 'glúteo', 'bumbum'],
  },
  quadriceps: {
    id: 'quadriceps',
    label: 'Quadríceps',
    latinName: 'Quadriceps femoris',
    preferredView: 'frontal',
    zone: 'lower',
    functionSummary: 'Extensão do joelho em agachamentos e avanços.',
    aliases: ['quadriceps', 'coxa anterior', 'coxas'],
  },
  hamstrings: {
    id: 'hamstrings',
    label: 'Posteriores de Coxa',
    latinName: 'Isquiotibiais',
    preferredView: 'posterior',
    zone: 'lower',
    functionSummary: 'Flexão do joelho e extensão de quadril em terra.',
    aliases: ['posterior de coxa', 'isquiotibiais', 'hamstrings'],
  },
  calves: {
    id: 'calves',
    label: 'Panturrilhas',
    latinName: 'Gastrocnemius & soleus',
    preferredView: 'posterior',
    zone: 'lower',
    functionSummary: 'Flexão plantar e propulsão em apoio.',
    aliases: ['panturrilha', 'gemeos', 'gêmeos', 'calf'],
  },
};

export const MUSCLE_LIST: MuscleDefinition[] = Object.values(MUSCLE_REGISTRY);
