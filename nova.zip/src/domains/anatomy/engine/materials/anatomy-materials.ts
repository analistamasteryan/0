import * as THREE from 'three';
import { createMuscleFiberNormalPixels } from './muscle-fiber-normal';
import {
  createAnatomyStateDataTexture,
  createSkinAlbedoTexture,
  createSkinMicroNormalTexture,
  createSkinRoughnessTexture,
} from './skin-pbr-textures';
import {
  applyAnatomyMaterialEnhancements,
  type AnatomyShaderUniforms,
} from '../shaders/anatomy-material-shader';

export type { AnatomyShaderUniforms } from '../shaders/anatomy-material-shader';

export interface AnatomyMaterialSet {
  // Primary / Current body materials (retained names for contract compatibility)
  bodySurface: THREE.MeshStandardMaterial;
  muscleSurface: THREE.MeshStandardMaterial;
  // Independent Goal body materials
  goalBodySurface: THREE.MeshStandardMaterial;
  goalMuscleSurface: THREE.MeshStandardMaterial;
  deepPlane: THREE.MeshStandardMaterial;
  skeletonReference: THREE.MeshStandardMaterial;
  stateDataTexture: THREE.DataTexture;
  uniforms: AnatomyShaderUniforms;
  goalUniforms: AnatomyShaderUniforms;
  dispose: () => void;
}

export function attachMuscleIdAttribute(
  geometry: THREE.BufferGeometry,
  muscleNumericId: number,
  muscleSide: -1 | 0 | 1 = 0,
): void {
  const posAttr = geometry.attributes.position;
  if (!posAttr) return;
  const vertexCount = posAttr.count;
  // These are categorical attributes, not continuous measurements. Compact integer
  // buffers are exact for the 14 stable muscle IDs and the -1/0/+1 side values.
  const ids = new Uint8Array(vertexCount);
  const sides = new Int8Array(vertexCount);
  ids.fill(muscleNumericId);
  sides.fill(muscleSide);
  geometry.setAttribute('aMuscleId', new THREE.BufferAttribute(ids, 1));
  geometry.setAttribute('aMuscleSide', new THREE.BufferAttribute(sides, 1));
}

function createMuscleFiberNormalMap(): THREE.DataTexture {
  const size = 512;
  const data = createMuscleFiberNormalPixels(size);
  const texture = new THREE.DataTexture(data, size, size, THREE.RGBAFormat, THREE.UnsignedByteType);
  texture.name = 'titan-procedural-muscle-fiber-normal';
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.magFilter = THREE.LinearFilter;
  texture.minFilter = THREE.LinearMipmapLinearFilter;
  texture.generateMipmaps = true;
  texture.colorSpace = THREE.NoColorSpace;
  texture.needsUpdate = true;
  return texture;
}

function createUniformSet(
  role: 'current' | 'goal',
  sharedBacklightOrigin: THREE.Vector3,
): AnatomyShaderUniforms {
  const isGoal = role === 'goal';
  return {
    uActiveMusclesMask: { value: 0 },
    uPrimaryMusclesMask: { value: 0 },
    uSecondaryMusclesMask: { value: 0 },
    uSelectedMuscleIndex: { value: 0 },
    uSelectedMuscleSide: { value: 0 },
    uSelectedSideAny: { value: 1 },
    uHasSelection: { value: 0 },
    uMuscleRestingColor: { value: new THREE.Color(isGoal ? '#5E38A6' : '#24727D') },
    uMuscleDimmedColor: { value: new THREE.Color(isGoal ? '#3B2069' : '#174852') },
    // Workout colors: Coral-Orange for Primary, Warm Amber for Secondary, Champagne-White for Selection
    uMusclePrimaryColor: { value: new THREE.Color('#FF7547') },
    uMuscleSecondaryColor: { value: new THREE.Color('#FFC63D') },
    uMuscleSelectedColor: { value: new THREE.Color('#FFF8E3') },
    uSweepY: { value: 2.05 },
    uHologramMode: { value: 1 },
    uHologramTint: { value: new THREE.Color(isGoal ? '#C47BFF' : '#32F7EF') },
    uHologramAccent: { value: new THREE.Color(isGoal ? '#FFE8FF' : '#F2FFFF') },
    uScanPhase: { value: isGoal ? 1.57 : 0 },
    uTime: { value: 0 },
    uBodyRole: { value: isGoal ? 1 : 0 },
    uBacklightOrigin: { value: sharedBacklightOrigin },
  };
}

export function createAnatomyMaterials(maxAnisotropy = 4): AnatomyMaterialSet {
  const sharedBacklightOrigin = new THREE.Vector3(0, 0.14, -0.65);
  const uniforms = createUniformSet('current', sharedBacklightOrigin);
  const goalUniforms = createUniformSet('goal', sharedBacklightOrigin);

  const skinAlbedoMap = createSkinAlbedoTexture(512);
  const skinRoughnessMap = createSkinRoughnessTexture(512);
  const skinMicroNormalMap = createSkinMicroNormalTexture(512);
  const muscleFiberNormalMap = createMuscleFiberNormalMap();
  const stateDataTexture = createAnatomyStateDataTexture();

  for (const tex of [skinAlbedoMap, skinRoughnessMap, skinMicroNormalMap, muscleFiberNormalMap]) {
    tex.anisotropy = Math.max(1, maxAnisotropy);
  }

  // Current body surface: PBR dermal maps + cyan/teal holographic identity.
  const bodySurface = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#DECBB9'),
    map: skinAlbedoMap,
    roughness: 0.74,
    roughnessMap: skinRoughnessMap,
    normalMap: skinMicroNormalMap,
    normalScale: new THREE.Vector2(0.70, 0.70),
    envMapIntensity: 1.42,
    metalness: 0.04,
    side: THREE.FrontSide,
  });
  applyAnatomyMaterialEnhancements(bodySurface, uniforms, 'body');

  const muscleSurface = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#E8D3C2'),
    map: skinAlbedoMap,
    roughness: 0.68,
    roughnessMap: skinRoughnessMap,
    normalMap: muscleFiberNormalMap,
    normalScale: new THREE.Vector2(0.96, 0.44),
    envMapIntensity: 1.78,
    metalness: 0.06,
    side: THREE.FrontSide,
  });
  applyAnatomyMaterialEnhancements(muscleSurface, uniforms, 'muscle');

  // Goal body surface: independent PBR material with violet holographic identity.
  const goalBodySurface = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#DECBB9'),
    map: skinAlbedoMap,
    roughness: 0.74,
    roughnessMap: skinRoughnessMap,
    normalMap: skinMicroNormalMap,
    normalScale: new THREE.Vector2(0.70, 0.70),
    envMapIntensity: 1.42,
    metalness: 0.04,
    side: THREE.FrontSide,
  });
  applyAnatomyMaterialEnhancements(goalBodySurface, goalUniforms, 'body');

  const goalMuscleSurface = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#E8D3C2'),
    map: skinAlbedoMap,
    roughness: 0.68,
    roughnessMap: skinRoughnessMap,
    normalMap: muscleFiberNormalMap,
    normalScale: new THREE.Vector2(1.02, 0.46),
    envMapIntensity: 1.84,
    metalness: 0.06,
    side: THREE.FrontSide,
  });
  applyAnatomyMaterialEnhancements(goalMuscleSurface, goalUniforms, 'muscle');

  const deepPlane = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#9D766A'),
    roughness: 0.88,
    metalness: 0,
    transparent: true,
    opacity: 0.72,
    depthWrite: false,
    side: THREE.FrontSide,
    polygonOffset: true,
    polygonOffsetFactor: -1,
  });

  const skeletonReference = new THREE.MeshStandardMaterial({
    color: new THREE.Color('#DED2BE'),
    roughness: 0.86,
    metalness: 0,
    side: THREE.FrontSide,
  });

  return {
    bodySurface,
    muscleSurface,
    goalBodySurface,
    goalMuscleSurface,
    deepPlane,
    skeletonReference,
    stateDataTexture,
    uniforms,
    goalUniforms,
    dispose: () => {
      bodySurface.dispose();
      muscleSurface.dispose();
      goalBodySurface.dispose();
      goalMuscleSurface.dispose();
      skinAlbedoMap.dispose();
      skinRoughnessMap.dispose();
      skinMicroNormalMap.dispose();
      muscleFiberNormalMap.dispose();
      stateDataTexture.dispose();
      deepPlane.dispose();
      skeletonReference.dispose();
    },
  };
}
