import { create } from 'zustand';
import type {
  MuscleGroupId,
  MuscleHighlightPayload,
  MuscleSide,
} from '@/src/shared/types/common';
import {
  createDefaultDualBodyInput,
  type BodyComparisonMode,
  type DualBodyInput,
  type RegionalMuscleMorphs,
} from '../domain/body-identity';
import type { AnatomicalView } from '../mapping/muscle-registry';

export type FocusRegion = 'full' | 'upper' | 'core' | 'lower';
export type AnatomyLayerMode = 'complete' | 'deep' | 'skeleton';
export type WebglStatus = 'initializing' | 'ready' | 'fallback';

interface AnatomyState {
  selectedMuscleId: MuscleGroupId | null;
  selectedMuscleSide: MuscleSide | null;
  hoveredMuscleId: MuscleGroupId | null;
  hoveredMuscleSide: MuscleSide | null;
  cameraView: AnatomicalView;
  focusRegion: FocusRegion;
  layerMode: AnatomyLayerMode;
  zoomScale: number;
  workoutHighlights: MuscleHighlightPayload;
  hologramMode: boolean;
  dualBody: DualBodyInput;
  comparisonMode: BodyComparisonMode;
  webglStatus: WebglStatus;
  showAccessibleList: boolean;
  setSelectedMuscle: (id: MuscleGroupId | null, side?: MuscleSide | null) => void;
  setHoveredMuscle: (id: MuscleGroupId | null, side?: MuscleSide | null) => void;
  setCameraView: (view: AnatomicalView) => void;
  setFocusRegion: (region: FocusRegion) => void;
  setLayerMode: (mode: AnatomyLayerMode) => void;
  setHologramMode: (enabled: boolean) => void;
  setDualBody: (dualBody: DualBodyInput) => void;
  setComparisonMode: (mode: BodyComparisonMode) => void;
  updateGoalRegionalMorph: (region: keyof RegionalMuscleMorphs, value: number) => void;
  adjustZoom: (delta: number) => void;
  setZoomScale: (scale: number) => void;
  setWorkoutHighlights: (payload: MuscleHighlightPayload) => void;
  setWebglStatus: (status: WebglStatus) => void;
  toggleAccessibleList: () => void;
  resetExploration: () => void;
}

export const useAnatomyStore = create<AnatomyState>((set) => ({
  selectedMuscleId: null,
  selectedMuscleSide: null,
  hoveredMuscleId: null,
  hoveredMuscleSide: null,
  cameraView: 'frontal',
  focusRegion: 'full',
  layerMode: 'complete',
  zoomScale: 1,
  workoutHighlights: {
    primary: ['pectoralis', 'anterior_deltoid', 'lateral_deltoid', 'triceps'],
    secondary: ['trapezius', 'forearms'],
  },
  hologramMode: true,
  dualBody: createDefaultDualBodyInput(),
  comparisonMode: 'dual',
  webglStatus: 'initializing',
  showAccessibleList: false,
  setSelectedMuscle: (id, side = null) =>
    set({
      selectedMuscleId: id,
      selectedMuscleSide: id ? side ?? 'center' : null,
    }),
  setHoveredMuscle: (id, side = null) =>
    set({
      hoveredMuscleId: id,
      hoveredMuscleSide: id ? side ?? 'center' : null,
    }),
  setCameraView: (view) => set({ cameraView: view }),
  setFocusRegion: (region) => set({ focusRegion: region }),
  setLayerMode: (mode) => set({ layerMode: mode }),
  setHologramMode: (enabled) => set({ hologramMode: enabled }),
  setDualBody: (dualBody) => set({ dualBody }),
  setComparisonMode: (comparisonMode) => set({ comparisonMode }),
  updateGoalRegionalMorph: (region, value) =>
    set((state) => {
      const clamped = Math.max(0, Math.min(1, Number(value)));
      return {
        dualBody: {
          ...state.dualBody,
          goal: {
            ...state.dualBody.goal,
            regionalMorphs: {
              ...state.dualBody.goal.regionalMorphs,
              [region]: clamped,
            },
          },
        },
      };
    }),
  adjustZoom: (delta) =>
    set((state) => ({
      zoomScale: Number(
        Math.min(1.65, Math.max(0.75, state.zoomScale + delta)).toFixed(2),
      ),
    })),
  setZoomScale: (scale) =>
    set({
      zoomScale: Number(Math.min(1.65, Math.max(0.75, scale)).toFixed(2)),
    }),
  setWorkoutHighlights: (payload) => set({ workoutHighlights: payload }),
  setWebglStatus: (status) => set({ webglStatus: status }),
  toggleAccessibleList: () =>
    set((state) => ({ showAccessibleList: !state.showAccessibleList })),
  resetExploration: () =>
    set({
      selectedMuscleId: null,
      selectedMuscleSide: null,
      hoveredMuscleId: null,
      hoveredMuscleSide: null,
      cameraView: 'frontal',
      focusRegion: 'full',
      layerMode: 'complete',
      comparisonMode: 'dual',
      zoomScale: 1,
    }),
}));
