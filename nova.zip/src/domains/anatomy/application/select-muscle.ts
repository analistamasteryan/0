import type { MuscleGroupId, MuscleSide } from '@/src/shared/types/common';
import { useAnatomyStore } from '../state/anatomy.store';

export function selectMuscleExploratory(
  muscleId: MuscleGroupId | null,
  side: MuscleSide | null = null,
): void {
  const store = useAnatomyStore.getState();
  if (!muscleId) {
    store.setSelectedMuscle(null, null);
    return;
  }

  // Keep camera stable on 3D tap selection (Section 3.4.B.5: camera remains stable)
  const sameSelection =
    store.selectedMuscleId === muscleId &&
    (side === null || store.selectedMuscleSide === side);

  if (sameSelection) {
    store.setSelectedMuscle(null, null);
    return;
  }

  store.setSelectedMuscle(muscleId, side ?? 'center');
}
