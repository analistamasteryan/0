import type { MuscleGroupId } from '@/src/shared/types/common';
import { AnatomyViewport, type AnatomyStageIndicators } from '../components/AnatomyViewport';
import {
  deriveDualBodyInput,
  type BodyComparisonMode,
  type BodyIdentityProfile,
  type DualBodyInput,
  type ProfileBodyDerivationInput,
  type RegionalMuscleMorphs,
} from '../domain/body-identity';
import { getAnatomicalSubstructuresForGroup } from '../mapping/anatomical-structure-map';
import { MUSCLE_REGISTRY } from './muscle-catalog-public.ts';
import { setWorkoutMuscleHighlights } from './set-muscle-highlights';

export function getMuscleLabel(muscleId: MuscleGroupId): string {
  return MUSCLE_REGISTRY[muscleId].label;
}

export function getMuscleLabels(muscleIds: readonly MuscleGroupId[]): string[] {
  return muscleIds.map((id) => MUSCLE_REGISTRY[id].label);
}

export type {
  AnatomyStageIndicators,
  BodyComparisonMode,
  BodyIdentityProfile,
  DualBodyInput,
  ProfileBodyDerivationInput,
  RegionalMuscleMorphs,
};

export {
  AnatomyViewport,
  deriveDualBodyInput,
  getAnatomicalSubstructuresForGroup,
  setWorkoutMuscleHighlights,
  MUSCLE_REGISTRY,
};
