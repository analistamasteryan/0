import assert from 'node:assert/strict';
import { normalizeHealthConnectActivityRecords, normalizeHealthKitActivityRecords, reconcileActivityEnergyRecords } from '../activity-reconciliation.ts';
import { syncNativeActivityEnergy } from '../../../application/sync-native-activity-energy.ts';
import { validateVersionedActivityMetCatalog } from '../activity-met-catalog.ts';

const baseRecord = (overrides = {}) => ({
  id: 'r-1', source: 'health_connect', sourceRecordId: 'hc-1', kind: 'active_calories_interval',
  energyKind: 'active', startTime: '2026-11-23T08:00:00Z', endTime: '2026-11-23T09:00:00Z',
  energyKcal: 300, quality: 'measured', ...overrides,
});

const healthKit = normalizeHealthKitActivityRecords([{
  recordType: 'ActiveCaloriesBurnedRecord', id: 'hk-a', startTime: '2026-11-23T08:00:00Z', endTime: '2026-11-23T09:00:00Z', energyKcal: 225,
}, { recordType: 'ExerciseSessionRecord', id: 'hk-workout', startTime: '2026-11-23T08:00:00Z', endTime: '2026-11-23T09:00:00Z' }]);
assert.equal(healthKit.length, 1);
assert.equal(healthKit[0].source, 'healthkit');

const normalized = normalizeHealthConnectActivityRecords([
  { recordType: 'ActiveCaloriesBurnedRecord', id: 'a1', startTime: '2026-11-23T08:00:00Z', endTime: '2026-11-23T09:00:00Z', energyKcal: 250 },
  { recordType: 'TotalCaloriesBurnedRecord', id: 't1', startTime: '2026-11-23T08:00:00Z', endTime: '2026-11-23T09:00:00Z', energyKcal: 420 },
  { recordType: 'ExerciseSessionRecord', id: 's1', startTime: '2026-11-23T08:00:00Z', endTime: '2026-11-23T09:00:00Z' },
]);
assert.equal(normalized.length, 2, 'session metadata without energy is not a calorie contributor');
assert.equal(normalized[0].energyKind, 'active');
assert.equal(normalized[1].energyKind, 'total');
const hc = reconcileActivityEnergyRecords(normalized);
assert.equal(hc.totalActiveKcal, 250);
assert.equal(hc.rejectedGrossOrTotalCount, 1);

const sessionAndChildren = reconcileActivityEnergyRecords([
  baseRecord({ id: 'summary', sourceRecordId: 'workout-main', kind: 'workout_session', energyKcal: 330, parentWorkoutId: 'workout-main' }),
  baseRecord({ id: 'child-1', sourceRecordId: 'sample-1', parentWorkoutId: 'workout-main', energyKcal: 120 }),
  baseRecord({ id: 'child-2', sourceRecordId: 'sample-2', parentWorkoutId: 'workout-main', energyKcal: 90 }),
]);
assert.equal(sessionAndChildren.totalActiveKcal, 330);
assert.equal(sessionAndChildren.accepted.length, 1);
assert.equal(sessionAndChildren.excluded.filter((x) => x.reason.includes('child_sample')).length, 2);

const overlaps = reconcileActivityEnergyRecords([
  baseRecord({ id: 'hc', sourceRecordId: 'hc-summary', source: 'health_connect', energyKcal: 280 }),
  baseRecord({ id: 'hk', sourceRecordId: 'hk-summary', source: 'healthkit', energyKcal: 250 }),
  baseRecord({ id: 'manual', sourceRecordId: 'manual', source: 'manual', quality: 'manual', energyKcal: 260 }),
]);
assert.equal(overlaps.accepted.length, 1, 'same workout imported from multiple apps must not be summed');
assert.equal(overlaps.totalActiveKcal, 280);
assert.ok(overlaps.duplicateCount >= 2);

const separate = reconcileActivityEnergyRecords([
  baseRecord({ id: 'a', sourceRecordId: 'a', endTime: '2026-11-23T09:00:00Z', energyKcal: 100 }),
  baseRecord({ id: 'b', sourceRecordId: 'b', startTime: '2026-11-23T10:00:00Z', endTime: '2026-11-23T10:30:00Z', energyKcal: 150 }),
]);
assert.equal(separate.totalActiveKcal, 250);
assert.equal(separate.accepted.length, 2);

const partialOverlap = reconcileActivityEnergyRecords([
  baseRecord({ id: 'overlap-a', sourceRecordId: 'overlap-a', endTime: '2026-11-23T09:00:00Z', energyKcal: 240 }),
  baseRecord({ id: 'overlap-b', source: 'healthkit', sourceRecordId: 'overlap-b', startTime: '2026-11-23T08:30:00Z', endTime: '2026-11-23T09:30:00Z', energyKcal: 180 }),
  baseRecord({ id: 'independent', sourceRecordId: 'independent', startTime: '2026-11-23T11:00:00Z', endTime: '2026-11-23T11:30:00Z', energyKcal: 90 }),
]);
assert.equal(partialOverlap.conflicted.length, 2, 'both sides of partial overlap must be quarantined for review');
assert.equal(partialOverlap.accepted.length, 1, 'only unambiguous intervals enter the accepted total');
assert.equal(partialOverlap.totalActiveKcal, 90, 'partial overlap calories must never silently inflate the aggregate');

const catalog = {
  schemaVersion: '1.0.0', catalogId: 'sample-met', catalogVersion: '1',
  sourceName: 'TITAN user-supplied pilot', sourceVersion: '1', sourceUrl: 'https://example.org/met', sourceLicense: 'CC-BY-4.0',
  entries: [{ code: 'walk', category: 'walking', label: 'Walking sample', met: 3.5, ageMin: 19, ageMax: 59,
    sourceName: 'TITAN user-supplied pilot', sourceVersion: '1', sourceUrl: 'https://example.org/met', sourceLicense: 'CC-BY-4.0', measurementStatus: 'estimated' }],
};
const goodCatalog = validateVersionedActivityMetCatalog(catalog);
assert.equal(goodCatalog.errors.length, 0);
assert.equal(goodCatalog.catalog.entries.length, 1);
const nonCommercialCatalog = validateVersionedActivityMetCatalog({
  ...catalog, sourceLicense: 'CC-BY-NC-ND-4.0',
  entries: catalog.entries.map((entry) => ({ ...entry, sourceLicense: 'CC-BY-NC-ND-4.0' })),
});
assert.equal(nonCommercialCatalog.catalog, null);
assert.ok(nonCommercialCatalog.errors.includes('license_not_approved_for_redistribution_or_derivatives'));
const mismatchCatalog = validateVersionedActivityMetCatalog({
  ...catalog, entries: catalog.entries.map((entry) => ({ ...entry, sourceVersion: 'wrong-version' })),
});
assert.ok(mismatchCatalog.errors.some((error) => error.includes('source_metadata_mismatch')));
const previousBridge = globalThis.titanHealthBridge;
globalThis.titanHealthBridge = {
  platform: 'android_health_connect',
  isAvailable: async () => true,
  requestReadAuthorization: async () => {},
  readActivityEnergy: async () => [
    { recordType: 'ActiveCaloriesBurnedRecord', id: 'bridge-a', startTime: '2026-11-23T08:00:00Z', endTime: '2026-11-23T09:00:00Z', energyKcal: 190 },
    { recordType: 'TotalCaloriesBurnedRecord', id: 'bridge-t', startTime: '2026-11-23T08:00:00Z', endTime: '2026-11-23T09:00:00Z', energyKcal: 400 },
  ],
};
const synced = await syncNativeActivityEnergy('2026-11-23T00:00:00Z', '2026-11-24T00:00:00Z');
assert.equal(synced.status, 'synced');
assert.equal(synced.reconciliation.totalActiveKcal, 190);
assert.ok(synced.warnings.some((warning) => warning.includes('não são somadas automaticamente ao TDEE')));
if (previousBridge === undefined) delete globalThis.titanHealthBridge; else globalThis.titanHealthBridge = previousBridge;
const unavailable = await syncNativeActivityEnergy('2026-11-23T00:00:00Z', '2026-11-24T00:00:00Z');
assert.equal(unavailable.status, 'bridge_unavailable');
await assert.rejects(() => syncNativeActivityEnergy('bad', '2026-11-24T00:00:00Z'), /intervalo ISO válido/);
console.log('PASS activity reconciliation and versioned MET catalog: source normalization, deduplication, permissions contract and license gate');
