import type { RestingMetabolicRateEstimate } from '../../../profile/domain/rules/resting-metabolic-rate';
import type { BiologicalSex } from '../../../profile/domain/contracts/user-profile';

export type MetMeasurementStatus = 'measured' | 'estimated' | 'unspecified';

const REDISTRIBUTABLE_ACTIVITY_LICENSES = new Set(['CC0-1.0', 'CC-BY-4.0', 'CC-BY-3.0', 'ODC-BY-1.0', 'ODbL-1.0', 'MIT', 'Apache-2.0', 'BSD-2-Clause', 'BSD-3-Clause', 'Unlicense']);

export interface ActivityMetEntry {
  code: string;
  category: string;
  label: string;
  met: number;
  ageMin: number;
  ageMax: number;
  sourceName: string;
  sourceVersion: string;
  sourceUrl: string;
  sourceLicense: string;
  measurementStatus: MetMeasurementStatus;
}

export interface ActivityMetCatalogValidation {
  validEntries: ActivityMetEntry[];
  rejectedEntries: Array<{ index: number; reason: string }>;
}

/** Validate a caller-supplied, properly licensed MET catalogue; no third-party activity table is bundled. */
export function validateActivityMetCatalog(entries: readonly unknown[]): ActivityMetCatalogValidation {
  const validEntries: ActivityMetEntry[] = [];
  const rejectedEntries: Array<{ index: number; reason: string }> = [];
  const seenCodes = new Set<string>();
  entries.forEach((value, index) => {
    if (!value || typeof value !== 'object') { rejectedEntries.push({ index, reason: 'entry_not_object' }); return; }
    const item = value as Partial<ActivityMetEntry>;
    if (typeof item.code !== 'string' || !item.code.trim()) { rejectedEntries.push({ index, reason: 'missing_code' }); return; }
    if (seenCodes.has(item.code.trim().toLowerCase())) { rejectedEntries.push({ index, reason: 'duplicate_code' }); return; }
    if (typeof item.label !== 'string' || !item.label.trim() || typeof item.category !== 'string' || !item.category.trim()) {
      rejectedEntries.push({ index, reason: 'missing_label_or_category' }); return;
    }
    if (!Number.isFinite(item.met) || item.met! < 0.8 || item.met! > 30) { rejectedEntries.push({ index, reason: 'met_out_of_range' }); return; }
    if (!Number.isInteger(item.ageMin) || !Number.isInteger(item.ageMax) || item.ageMin! < 0 || item.ageMax! < item.ageMin!) {
      rejectedEntries.push({ index, reason: 'invalid_age_range' }); return;
    }
    if (typeof item.sourceName !== 'string' || !item.sourceName.trim() || typeof item.sourceVersion !== 'string' || !item.sourceVersion.trim() ||
        typeof item.sourceLicense !== 'string' || !REDISTRIBUTABLE_ACTIVITY_LICENSES.has(item.sourceLicense.trim()) || typeof item.sourceUrl !== 'string' || !/^https:\/\//i.test(item.sourceUrl)) {
      rejectedEntries.push({ index, reason: 'missing_source_provenance_or_redistributable_license' }); return;
    }
    if (!['measured', 'estimated', 'unspecified'].includes(item.measurementStatus ?? '')) {
      rejectedEntries.push({ index, reason: 'invalid_measurement_status' }); return;
    }
    seenCodes.add(item.code.trim().toLowerCase());
    validEntries.push(item as ActivityMetEntry);
  });
  return { validEntries, rejectedEntries };
}

export interface ActivityEnergyInput {
  met?: number;
  activityEntry?: ActivityMetEntry;
  age?: number;
  sex?: BiologicalSex;
  heightCm?: number;
  activityCode?: string;
  activityLabel?: string;
  weightKg: number;
  durationMinutes: number;
  restingMetabolicRate?: RestingMetabolicRateEstimate;
  sourceName?: string;
  sourceVersion?: string;
  sourceLicense?: string;
}

export interface ActivityEnergyEstimate {
  activityCode: string | null;
  activityLabel: string | null;
  standardMet: number;
  compendiumCorrectedMet: number | null;
  personalizedIntensityRatio: number | null;
  grossKcal: number;
  netKcal: number;
  durationMinutes: number;
  method: 'standard_met_energy_equation';
  sourceName: string | null;
  sourceVersion: string | null;
  sourceLicense: string | null;
  measurementStatus: MetMeasurementStatus;
  uncertaintyNote: string;
  warnings: string[];
}

/**
 * Standard MET energy estimate: kcal/min = MET × 3.5 × kg / 200.
 * Net energy subtracts the individual's RMR per minute when available; without
 * an RMR estimate it subtracts the conventional 1-MET resting component.
 * The official Compendium corrected-MET procedure uses Harris–Benedict RMR.
 * A separate personalized ratio can use the app's selected/measured RMR. Neither
 * ratio is multiplied into the standard-MET kcal equation (that would double-normalize RMR).
 */
export function estimateActivityEnergy(input: ActivityEnergyInput): ActivityEnergyEstimate {
  const validatedActivityEntry = input.activityEntry
    ? validateActivityMetCatalog([input.activityEntry]).validEntries[0]
    : undefined;
  if (input.activityEntry && !validatedActivityEntry) throw new RangeError('Atividade MET sem código, faixa, proveniência ou licença declarada válida.');
  const met = validatedActivityEntry?.met ?? input.met;
  if (!Number.isFinite(met) || met! < 0.8 || met! > 30) {
    throw new RangeError('MET deve estar entre 0,8 e 30; informe o valor da fonte selecionada.');
  }
  if (validatedActivityEntry && input.age !== undefined &&
      (!Number.isFinite(input.age) || input.age < validatedActivityEntry.ageMin || input.age > validatedActivityEntry.ageMax)) {
    throw new RangeError('A idade está fora da faixa etária declarada para este MET.');
  }
  if (!Number.isFinite(input.weightKg) || input.weightKg < 30 || input.weightKg > 300 ||
      !Number.isFinite(input.durationMinutes) || input.durationMinutes <= 0 || input.durationMinutes > 1440) {
    throw new RangeError('Peso ou duração fora da faixa válida para estimar energia da atividade.');
  }
  const grossKcal = met! * 3.5 * input.weightKg / 200 * input.durationMinutes;
  const restingKcalPerMinute = input.restingMetabolicRate
    ? input.restingMetabolicRate.kcalPerDay / 1440
    : 3.5 * input.weightKg / 200;
  const netKcal = Math.max(0, grossKcal - restingKcalPerMinute * input.durationMinutes);
  let compendiumCorrectedMet: number | null = null;
  if (input.age !== undefined && input.heightCm !== undefined && input.sex !== undefined) {
    if (!Number.isFinite(input.age) || input.age < 18 || input.age > 105 || !Number.isFinite(input.heightCm) || input.heightCm < 110 || input.heightCm > 245 ||
        (input.sex !== 'male' && input.sex !== 'female')) throw new RangeError('Dados demográficos inválidos para corrected MET do Compendium.');
    const hbRmr = input.sex === 'male'
      ? 66.473 + 5.0033 * input.heightCm + 13.7516 * input.weightKg - 6.755 * input.age
      : 655.0955 + 1.8496 * input.heightCm + 9.5634 * input.weightKg - 4.6756 * input.age;
    const hbVo2MlKgMin = (hbRmr / 1440 / 5) * 1000 / input.weightKg;
    if (hbVo2MlKgMin > 0) compendiumCorrectedMet = met! * 3.5 / hbVo2MlKgMin;
  }
  let personalizedIntensityRatio: number | null = null;
  if (input.restingMetabolicRate) {
    const individualVo2MlKgMin = (input.restingMetabolicRate.kcalPerDay / 1440 / 5) * 1000 / input.weightKg;
    if (individualVo2MlKgMin > 0) personalizedIntensityRatio = met! * 3.5 / individualVo2MlKgMin;
  }
  return {
    activityCode: validatedActivityEntry?.code ?? input.activityCode ?? null,
    activityLabel: validatedActivityEntry?.label ?? input.activityLabel ?? null,
    standardMet: met!,
    compendiumCorrectedMet: compendiumCorrectedMet === null ? null : Number(compendiumCorrectedMet.toFixed(2)),
    personalizedIntensityRatio: personalizedIntensityRatio === null ? null : Number(personalizedIntensityRatio.toFixed(2)),
    grossKcal: Math.round(grossKcal),
    netKcal: Math.round(netKcal),
    durationMinutes: input.durationMinutes,
    method: 'standard_met_energy_equation',
    sourceName: validatedActivityEntry?.sourceName ?? input.sourceName ?? null,
    sourceVersion: validatedActivityEntry?.sourceVersion ?? input.sourceVersion ?? null,
    sourceLicense: validatedActivityEntry?.sourceLicense ?? input.sourceLicense ?? null,
    measurementStatus: validatedActivityEntry?.measurementStatus ?? 'unspecified',
    uncertaintyNote: 'Estimativa populacional por MET, não calorimetria individual; a energia real varia com técnica, eficiência, terreno, temperatura e aptidão.',
    warnings: [
      'O motor não embute a tabela completa do Compendium 2024; informe apenas METs de um catálogo cuja licença permita o uso pretendido.',
      ...(validatedActivityEntry && input.age === undefined ? ['A faixa etária do catálogo não foi conferida porque a idade não foi informada.'] : []),
      ...(compendiumCorrectedMet === null ? ['Corrected MET oficial do Compendium não calculado: informe sexo, idade e altura para aplicar Harris–Benedict.'] : []),
      ...(personalizedIntensityRatio === null ? ['Razão de intensidade individual não calculada: RMR selecionada/medida não informada.'] : []),
      ...(!input.activityEntry && !input.sourceLicense ? ['MET informado manualmente sem licença/fonte rastreável; trate como estimativa não auditada.'] : []),
      'O Compendium 2024 foi desenvolvido para adultos de 19–59 anos; não extrapolar automaticamente para outras idades.',
      'O corrected MET oficial do Compendium usa Harris–Benedict; a razão individual usa o RMR selecionado/medido. São métricas de intensidade e não devem ser multiplicadas novamente na fórmula de kcal.',
    ],
  };
}
