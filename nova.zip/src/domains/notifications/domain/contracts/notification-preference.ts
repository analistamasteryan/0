export interface NotificationPreference {
  hydrationRemindersEnabled: boolean;
  workoutRestAlertsEnabled: boolean;
}
