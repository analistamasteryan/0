import { findExerciseDefinition } from '../../../exercise-library/application/exercise-library-public.ts';
import type { WorkoutExercise, WorkoutPlan, SetRecord } from '../../domain/entities/workout';

function createWorkoutExercise(
  id: string,
  exerciseSlug: string,
  targetRestSeconds: number,
  sets: SetRecord[],
): WorkoutExercise {
  const definition = findExerciseDefinition(exerciseSlug);
  if (!definition) {
    throw new Error(`Workout seed references unknown exercise slug: ${exerciseSlug}`);
  }

  return {
    id,
    exerciseSlug: definition.slug,
    name: definition.name,
    equipment: definition.equipment,
    targetRestSeconds,
    muscles: {
      primary: [...definition.muscles.primary],
      secondary: [...definition.muscles.secondary],
    },
    sets,
  };
}

export const INITIAL_WORKOUT_PLANS: WorkoutPlan[] = [
  {
    id: 'upper-a',
    title: 'UPPER A',
    splitLabel: 'Peito e tríceps · ~55 min',
    status: 'in_progress',
    exercises: [
      createWorkoutExercise('ex-1', 'supino-reto', 90, [
        { id: 's-1', setNumber: 1, targetReps: '8–10', weightKg: 80, reps: 10, repsInReserve: 2, completed: true, completedAtMs: 1795251000000 },
        { id: 's-2', setNumber: 2, targetReps: '8–10', weightKg: 80, reps: 9, repsInReserve: 2, completed: true, completedAtMs: 1795251180000 },
        { id: 's-3', setNumber: 3, targetReps: '8–10', weightKg: 80, reps: 9, repsInReserve: 1, completed: true, completedAtMs: 1795251360000 },
        { id: 's-4', setNumber: 4, targetReps: '8–10', weightKg: 80, reps: 8, repsInReserve: 1, completed: true, completedAtMs: 1795251540000 },
      ]),
      createWorkoutExercise('ex-2', 'supino-inclinado', 90, [
        { id: 's-5', setNumber: 1, targetReps: '10–12', weightKg: 32, reps: 12, repsInReserve: 2, completed: true, completedAtMs: 1795251780000 },
        { id: 's-6', setNumber: 2, targetReps: '10–12', weightKg: 32, reps: 11, repsInReserve: 2, completed: true, completedAtMs: 1795251960000 },
        { id: 's-7', setNumber: 3, targetReps: '10–12', weightKg: 32, reps: 10, completed: false },
      ]),
      createWorkoutExercise('ex-3', 'crucifixo', 60, [
        { id: 's-8', setNumber: 1, targetReps: '12', weightKg: 18, reps: 12, completed: false },
        { id: 's-9', setNumber: 2, targetReps: '12', weightKg: 18, reps: 12, completed: false },
        { id: 's-10', setNumber: 3, targetReps: '12', weightKg: 18, reps: 12, completed: false },
      ]),
      createWorkoutExercise('ex-4', 'desenvolvimento', 90, [
        { id: 's-11', setNumber: 1, targetReps: '8–10', weightKg: 26, reps: 10, completed: false },
        { id: 's-12', setNumber: 2, targetReps: '8–10', weightKg: 26, reps: 9, completed: false },
        { id: 's-13', setNumber: 3, targetReps: '8–10', weightKg: 26, reps: 8, completed: false },
      ]),
      createWorkoutExercise('ex-5', 'elevacao-lateral', 60, [
        { id: 's-14', setNumber: 1, targetReps: '12–15', weightKg: 14, reps: 14, completed: false },
        { id: 's-15', setNumber: 2, targetReps: '12–15', weightKg: 14, reps: 13, completed: false },
        { id: 's-16', setNumber: 3, targetReps: '12–15', weightKg: 14, reps: 12, completed: false },
      ]),
      createWorkoutExercise('ex-6', 'triceps-corda', 60, [
        { id: 's-17', setNumber: 1, targetReps: '12', weightKg: 25, reps: 12, completed: false },
        { id: 's-18', setNumber: 2, targetReps: '12', weightKg: 25, reps: 12, completed: false },
        { id: 's-19', setNumber: 3, targetReps: '12', weightKg: 25, reps: 12, completed: false },
      ]),
    ],
  },
  {
    id: 'lower-a',
    title: 'LOWER A',
    splitLabel: 'Base · Quadríceps, Glúteos e Posteriores · ~60 min',
    status: 'pending',
    exercises: [
      createWorkoutExercise('ex-7', 'agachamento-livre', 120, [
        { id: 's-20', setNumber: 1, targetReps: '6–8', weightKg: 100, reps: 8, completed: false },
        { id: 's-21', setNumber: 2, targetReps: '6–8', weightKg: 100, reps: 8, completed: false },
        { id: 's-22', setNumber: 3, targetReps: '6–8', weightKg: 100, reps: 7, completed: false },
      ]),
      createWorkoutExercise('ex-8', 'stiff-romeno', 90, [
        { id: 's-23', setNumber: 1, targetReps: '8–10', weightKg: 85, reps: 10, completed: false },
        { id: 's-24', setNumber: 2, targetReps: '8–10', weightKg: 85, reps: 9, completed: false },
        { id: 's-25', setNumber: 3, targetReps: '8–10', weightKg: 85, reps: 9, completed: false },
      ]),
    ],
  },
];
