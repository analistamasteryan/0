import assert from 'node:assert/strict';
import { mergeTrainingPersistedState } from '../training-persistence.ts';
import { createCompletedWorkoutSession, resetWorkoutPlanForNextSession } from '../../domain/rules/workout-session.ts';

const defaults = [{
  id: 'upper-a', title: 'UPPER A', splitLabel: 'Peito e tríceps', status: 'in_progress',
  exercises: [{ id: 'ex-1', exerciseSlug: 'supino-reto', name: 'Supino reto', equipment: 'barbell', targetRestSeconds: 90,
    muscles: { primary: ['chest'], secondary: ['triceps'] }, sets: [
      { id: 's-1', setNumber: 1, targetReps: '8-10', weightKg: 80, reps: 10, completed: false },
      { id: 's-2', setNumber: 2, targetReps: '8-10', weightKg: 80, reps: 9, completed: false },
    ] }],
}];
const merged = mergeTrainingPersistedState({
  activePlanId: 'upper-a',
  focusedExerciseId: 'ex-1',
  plans: [{
    id: 'upper-a', status: 'in_progress', title: 'tampered title',
    exercises: [{ id: 'ex-1', sets: [
      { id: 's-1', weightKg: 90, reps: 8, repsInReserve: 2, completed: true, completedAtMs: 123 },
      { id: 'unknown', weightKg: 10, reps: 10, completed: true },
      { id: 's-2', weightKg: Number.NaN, reps: 9, completed: true },
    ] }],
  }],
  restTimer: { active: true, startedAtMs: Date.now(), targetSeconds: 90, exerciseName: 'Supino' },
}, defaults);
const upper = merged.plans.find((plan) => plan.id === 'upper-a');
assert.ok(upper);
assert.equal(upper.title, 'UPPER A');
assert.equal(upper.exercises[0].sets[0].weightKg, 90);
assert.equal(upper.exercises[0].sets[0].completed, true);
assert.equal(upper.exercises[0].sets[0].repsInReserve, 2, 'RIR survives persisted profile recovery');
assert.equal(upper.exercises[0].sets[1].weightKg, defaults[0].exercises[0].sets[1].weightKg);
assert.equal(merged.activePlanId, 'upper-a');
assert.equal(merged.focusedExerciseId, 'ex-1');
assert.equal(merged.restTimer.active, true);
assert.equal(merged.sessionStartedAtMs, null);
assert.deepEqual(merged.completedSessions, []);
const invalid = mergeTrainingPersistedState({ activePlanId: 'missing', plans: 'nope' }, defaults);
assert.equal(invalid.activePlanId, defaults[0].id);
assert.deepEqual(invalid.plans, defaults);
assert.equal(invalid.restTimer, null);
assert.equal(invalid.sessionStartedAtMs, null);
assert.deepEqual(invalid.completedSessions, []);
console.log('Training persistence tests passed.');

const completedPlan = {
  ...defaults[0],
  status: 'completed',
  exercises: [{ ...defaults[0].exercises[0], sets: [
    { id: 's-1', setNumber: 1, targetReps: '8-10', weightKg: 92, reps: 8, repsInReserve: 1, completed: true, completedAtMs: 500 },
    { id: 's-2', setNumber: 2, targetReps: '8-10', weightKg: 90, reps: 9, completed: false },
  ] }],
};
const restarted = resetWorkoutPlanForNextSession(completedPlan);
assert.equal(restarted.status, 'in_progress');
assert.equal(restarted.exercises[0].sets[0].completed, false);
assert.equal(restarted.exercises[0].sets[0].completedAtMs, undefined);
assert.equal(restarted.exercises[0].sets[0].weightKg, 92, 'keep the last load as a progression hint');
assert.equal(restarted.exercises[0].sets[0].reps, 8);
assert.equal(restarted.exercises[0].sets[0].repsInReserve, null, 'previous-session RIR is not prefilled as the new session effort');
const snapshot = createCompletedWorkoutSession(completedPlan, 100, 1000);
assert.equal(snapshot.completedSets, 1);
assert.equal(snapshot.totalSets, 2);
assert.equal(snapshot.sets[0].weightKg, 92);
assert.equal(snapshot.sets[0].repsInReserve, 1, 'session snapshot keeps the reported effort');
assert.equal(snapshot.startedAtMs, 100);
const validHistory = mergeTrainingPersistedState({
  activePlanId: 'upper-a',
  completedSessions: [snapshot],
  sessionStartedAtMs: 900,
}, defaults, 1000);
assert.equal(validHistory.completedSessions.length, 1);
assert.equal(validHistory.completedSessions[0].sets[0].repsInReserve, 1, 'historical RIR survives hydration');
assert.equal(validHistory.sessionStartedAtMs, 900);
const invalidHistory = mergeTrainingPersistedState({
  activePlanId: 'upper-a',
  completedSessions: [{ ...snapshot, dateKey: '2026-02-30' }],
  sessionStartedAtMs: -1,
}, defaults, 1000);
assert.equal(invalidHistory.completedSessions.length, 0, 'invalid calendar dates must be rejected');
assert.equal(invalidHistory.sessionStartedAtMs, null);

const legacySeedProgress = mergeTrainingPersistedState({
  activePlanId: 'upper-a',
  plans: [{ id: 'upper-a', status: 'in_progress', exercises: [{ id: 'ex-1', sets: [
    { id: 's-1', weightKg: 80, reps: 10, completed: true, completedAtMs: 1 },
    { id: 's-2', weightKg: 80, reps: 9, completed: true, completedAtMs: 2 },
  ] }] }],
}, defaults, 1_800_000_000_000);
assert.equal(legacySeedProgress.plans[0].status, 'in_progress', 'legacy plan status is retained only if default current plan asks for it');
assert.equal(legacySeedProgress.plans[0].exercises[0].sets[0].completed, false, 'hard-coded seed completions are discarded');


const customPlan = {
  id: 'custom-push-a', title: 'Push A', splitLabel: 'Personalizado', status: 'pending',
  exercises: [{ id: 'custom-push-a-ex-1', exerciseSlug: 'supino-reto', name: 'Supino reto', equipment: 'barbell', targetRestSeconds: 90,
    muscles: { primary: ['chest'], secondary: ['triceps'] }, sets: [
      { id: 'custom-push-a-ex-1-s-1', setNumber: 1, targetReps: '8-12', weightKg: 40, reps: 10, completed: false },
    ] }],
};
const withCustomPlan = mergeTrainingPersistedState({ activePlanId: customPlan.id, plans: [customPlan] }, defaults);
assert.equal(withCustomPlan.plans.length, 2, 'custom workout plans survive persistence hydration');
assert.equal(withCustomPlan.activePlanId, customPlan.id);
assert.equal(withCustomPlan.plans[1].exercises[0].sets[0].weightKg, 40);
const customWithRir = mergeTrainingPersistedState({ plans: [{ ...customPlan, exercises: [{ ...customPlan.exercises[0], sets: [{ ...customPlan.exercises[0].sets[0], repsInReserve: 3 }] }] }] }, defaults);
assert.equal(customWithRir.plans[1].exercises[0].sets[0].repsInReserve, 3);
const invalidCustomPlan = mergeTrainingPersistedState({ plans: [{ ...customPlan, id: 'custom-invalid', exercises: [{ ...customPlan.exercises[0], sets: [{ ...customPlan.exercises[0].sets[0], weightKg: 900 }] }] }] }, defaults);
assert.equal(invalidCustomPlan.plans.length, 2, 'the custom plan shell is retained');
assert.equal(invalidCustomPlan.plans[1].exercises.length, 0, 'invalid custom exercise data is not hydrated');

const expandedPlan = { ...customPlan, id: 'custom-pull-b', title: 'Pull B', exercises: [{ ...customPlan.exercises[0], id: 'custom-pull-b-ex-1',
  sets: Array.from({ length: 20 }, (_, index) => ({ id: `pull-set-${index + 1}`, setNumber: index + 1, targetReps: '8-12', weightKg: 30, reps: 10, completed: false })) }] };
const expandedHydrated = mergeTrainingPersistedState({ plans: [expandedPlan], activePlanId: expandedPlan.id }, defaults);
assert.equal(expandedHydrated.plans.find((plan) => plan.id === expandedPlan.id).exercises[0].sets.length, 20, 'custom set prescriptions hydrate to the supported limit');

const tamperedCustomPlan = { ...customPlan, id: 'custom-canonical-check', exercises: [
  { ...customPlan.exercises[0], name: 'Injected label', equipment: 'Injected equipment', muscles: { primary: ['admin'], secondary: ['unknown'] } },
  { ...customPlan.exercises[0], id: 'custom-canonical-check-ex-2' },
  { ...customPlan.exercises[0], id: 'custom-canonical-check-ex-3', exerciseSlug: 'not-in-catalog' },
] };
const canonicalized = mergeTrainingPersistedState({ plans: [tamperedCustomPlan], activePlanId: tamperedCustomPlan.id }, defaults);
const canonicalPlan = canonicalized.plans.find((plan) => plan.id === tamperedCustomPlan.id);
assert.equal(canonicalPlan.exercises.length, 1, 'unknown exercise slugs are rejected and duplicate exercise slugs are removed');
assert.equal(canonicalPlan.exercises[0].name, 'Supino reto', 'exercise names are restored from the canonical registry');
assert.deepEqual(canonicalPlan.exercises[0].muscles.primary, ['pectoralis', 'anterior_deltoid'], 'muscle mapping cannot be overridden by persisted data');

const duplicateSetIdsPlan = { ...customPlan, id: 'custom-duplicate-sets', exercises: [{ ...customPlan.exercises[0],
  sets: [customPlan.exercises[0].sets[0], { ...customPlan.exercises[0].sets[0], setNumber: 2 }] }] };
const duplicateSetIds = mergeTrainingPersistedState({ plans: [duplicateSetIdsPlan] }, defaults);
assert.equal(duplicateSetIds.plans.find((plan) => plan.id === duplicateSetIdsPlan.id).exercises.length, 0, 'duplicate set IDs invalidate the malformed exercise');
