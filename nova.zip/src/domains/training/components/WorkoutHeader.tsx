import { ArrowLeft } from 'lucide-react';
import { Button } from '@/src/shared/ui/Button';

interface WorkoutHeaderProps {
  title: string;
  subtitle: string;
  percent: number;
  onBack?: () => void;
  onFinish?: () => void;
}

export function WorkoutHeader({
  title,
  subtitle,
  percent,
  onBack,
  onFinish,
}: WorkoutHeaderProps) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div className="flex items-center gap-2.5 min-w-0">
        {onBack && (
          <button
            type="button"
            onClick={onBack}
            aria-label="Voltar para treinos"
            className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-[var(--titan-surface)] border border-[var(--titan-border)] text-[var(--titan-text-primary)] shrink-0"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
        )}
        <div className="min-w-0">
          <p className="titan-eyebrow">Sessão ativa</p>
          <h1 className="text-xl font-semibold text-[var(--titan-text-primary)] truncate">{title}</h1>
          <p className="text-xs text-[var(--titan-text-secondary)] truncate">
            {subtitle} · <span className="font-mono-metric text-[var(--titan-accent)]">{percent}%</span>
          </p>
        </div>
      </div>

      {onFinish && (
        <Button variant="primary" onClick={onFinish}>
          Concluir
        </Button>
      )}
    </div>
  );
}
