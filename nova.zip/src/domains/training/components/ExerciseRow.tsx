import { memo } from 'react';
import { Check, ChevronRight } from 'lucide-react';
import type { WorkoutExercise } from '../domain/entities/workout';

interface ExerciseRowProps {
  exercise: WorkoutExercise;
  isFocused: boolean;
  onSelect: (exerciseId: string) => void;
}

export const ExerciseRow = memo(function ExerciseRow({ exercise, isFocused, onSelect }: ExerciseRowProps) {
  const completedCount = exercise.sets.filter((s) => s.completed).length;
  const totalCount = exercise.sets.length;
  const allDone = completedCount === totalCount && totalCount > 0;

  return (
    <button
      type="button"
      onClick={() => onSelect(exercise.id)}
      aria-pressed={isFocused}
      className={`w-full min-h-[60px] px-4 py-3 flex items-center justify-between gap-3 text-left rounded-2xl border transition-[background-color,border-color] duration-150 hover:border-[var(--titan-accent)]/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-focus)]/70 ${
        isFocused
          ? 'bg-[var(--titan-surface-raised)] border-[var(--titan-accent)]/60 shadow-[inset_0_1px_0_rgba(241,240,233,0.06)]'
          : 'bg-[var(--titan-surface)] border-[var(--titan-border)]/70'
      }`}
    >
      <div className="flex items-center gap-3 min-w-0">
        <div
          className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${
            allDone
              ? 'bg-[var(--titan-status-success)]/15 border-[var(--titan-status-success)]/45 text-[var(--titan-status-success)]'
              : isFocused
              ? 'bg-[var(--titan-accent-deep)]/50 border-[var(--titan-accent)]/50 text-[var(--titan-accent-strong)]'
              : 'bg-[var(--titan-bg-canvas)] border-[var(--titan-border)] text-[var(--titan-text-secondary)]'
          }`}
        >
          {allDone ? (
            <Check className="w-4 h-4" />
          ) : (
            <span className="text-xs font-mono-metric">
              {completedCount}/{totalCount}
            </span>
          )}
        </div>
        <div className="min-w-0">
          <div className="text-sm font-medium text-[var(--titan-text-primary)] truncate">
            {exercise.name}
          </div>
          <div className="text-xs text-[var(--titan-text-secondary)] truncate">
            {exercise.equipment} · Descanso {exercise.targetRestSeconds}s
          </div>
        </div>
      </div>

      <ChevronRight className="w-4 h-4 text-[var(--titan-text-muted)] shrink-0" />
    </button>
  );
});
