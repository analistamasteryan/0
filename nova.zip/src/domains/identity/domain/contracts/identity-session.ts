export type AuthSessionStatus = 'anonymous' | 'authenticated';

export interface IdentitySession {
  userId: string | null;
  status: AuthSessionStatus;
}
