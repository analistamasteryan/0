import { parseLocaleNumber } from '@/src/shared/utils/formatters';
import { MICRONUTRIENT_CHEMISTRY } from '../data/chemistry/micronutrient-chemistry';
import { RECIPE_CATALOG } from '../data/recipes/recipe-catalog';
import { DRI_REFERENCE_PROFILES } from '../data/references/dri-profiles';
import type {
  MealConsumptionStatus,
  MealFoodPortion,
  MealItem,
  NutrientId,
  RecipeItem,
  ReferenceProfileId,
} from '../domain/entities/nutrient';
import {
  computeDailyMacroAndEnergyBreakdown,
  computeDayPlanSummary,
  type DailyMacroAndEnergyBreakdown,
  type DayPlanSummary,
  type FoodMacroBreakdownItem,
  type MealMacroBreakdownItem,
} from '../domain/rules/nutrition-calculator';
import {
  computeRecipeSummary,
  searchSubstitutionRecipes,
  type ComputedRecipeSummary,
} from '../domain/rules/recipe-engine';
import {
  dailyMacroGoalsSchema,
  portionPercentSchema,
} from '../schemas/nutrition.schema';
import {
  computeNutritionTotals,
  getDailyEnergyIntakeHistory,
  getDailyMicronutrientDisplays,
  getMealMacros,
  useNutritionStore,
} from '../state/nutrition.store';

export type {
  ComputedRecipeSummary,
  DailyMacroAndEnergyBreakdown,
  DayPlanSummary,
  FoodMacroBreakdownItem,
  MealConsumptionStatus,
  MealFoodPortion,
  MealItem,
  MealMacroBreakdownItem,
  NutrientId,
  RecipeItem,
  ReferenceProfileId,
};

export function getNutrientChemistry(nutrientId: NutrientId) {
  return MICRONUTRIENT_CHEMISTRY[nutrientId];
}

export function getDriReferenceProfiles() {
  return DRI_REFERENCE_PROFILES;
}

export function getRecipeCatalog() {
  return RECIPE_CATALOG;
}

export function validateMacroGoals(raw: {
  kcal: string;
  proteinG: string;
  carbsG: string;
  fatG: string;
}):
  | { ok: true; data: { kcal: number; proteinG: number; carbsG: number; fatG: number } }
  | { ok: false; error: string } {
  if (
    raw.kcal.trim() === '' ||
    raw.proteinG.trim() === '' ||
    raw.carbsG.trim() === '' ||
    raw.fatG.trim() === ''
  ) {
    return { ok: false, error: 'Preencha todos os campos numéricos antes de salvar.' };
  }
  const parsed = dailyMacroGoalsSchema.safeParse({
    kcal: parseLocaleNumber(raw.kcal),
    proteinG: parseLocaleNumber(raw.proteinG),
    carbsG: parseLocaleNumber(raw.carbsG),
    fatG: parseLocaleNumber(raw.fatG),
  });
  if (!parsed.success) {
    return {
      ok: false,
      error:
        parsed.error.issues[0]?.message ??
        'Informe metas válidas para calorias e macronutrientes.',
    };
  }
  return {
    ok: true,
    data: {
      kcal: Math.round(parsed.data.kcal),
      proteinG: Math.round(parsed.data.proteinG),
      carbsG: Math.round(parsed.data.carbsG),
      fatG: Math.round(parsed.data.fatG),
    },
  };
}

export function validatePortionPercent(raw: string):
  | { ok: true; factor: number }
  | { ok: false; error: string } {
  if (raw.trim() === '') {
    return { ok: false, error: 'Informe um percentual entre 10% e 200%.' };
  }
  const parsed = portionPercentSchema.safeParse(parseLocaleNumber(raw));
  if (!parsed.success) {
    return {
      ok: false,
      error: parsed.error.issues[0]?.message ?? 'Percentual deve ficar entre 10% e 200%.',
    };
  }
  return { ok: true, factor: parsed.data / 100 };
}

export {
  computeDailyMacroAndEnergyBreakdown,
  computeDayPlanSummary,
  computeNutritionTotals,
  computeRecipeSummary,
  getDailyEnergyIntakeHistory,
  getDailyMicronutrientDisplays,
  getMealMacros,
  searchSubstitutionRecipes,
  useNutritionStore,
};
