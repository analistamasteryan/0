import { memo, useDeferredValue, useMemo, useState } from 'react';
import { Apple, Search } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import { getSharedFoodSearchIndex } from '../data/sources/food-search-index';
import { searchFoodIndex } from '../domain/rules/food-search';
import { useNutritionStore } from '../state/nutrition.store';
import type { FoodDiaryMealTitle } from '../domain/rules/food-diary';

const MEAL_OPTIONS: readonly FoodDiaryMealTitle[] = [
  'Café da manhã',
  'Almoço',
  'Lanche',
  'Jantar',
];

export const FoodCatalogBrowser = memo(function FoodCatalogBrowser() {
  const [query, setQuery] = useState('');
  const [quantityG, setQuantityG] = useState('100');
  const [mealTitle, setMealTitle] = useState<FoodDiaryMealTitle>('Lanche');
  const [feedback, setFeedback] = useState<string | null>(null);
  const deferredQuery = useDeferredValue(query);
  const logFoodToDiary = useNutritionStore((state) => state.logFoodToDiary);
  const foodIndex = useMemo(() => getSharedFoodSearchIndex(), []);
  const filteredFoods = useMemo(
    () => searchFoodIndex(foodIndex, deferredQuery, 60),
    [foodIndex, deferredQuery],
  );
  const isSearching = query !== deferredQuery;
  const normalizedQuantity = Number(quantityG);
  const quantityIsValid = Number.isFinite(normalizedQuantity) && normalizedQuantity >= 1 && normalizedQuantity <= 2000;

  const registerFood = (foodId: string, foodName: string) => {
    if (!quantityIsValid) {
      setFeedback('Informe uma quantidade entre 1 e 2.000 g.');
      return;
    }
    const result = logFoodToDiary(foodId, normalizedQuantity, mealTitle);
    setFeedback(result.ok
      ? `${foodName} registrado (${normalizedQuantity} g) em ${mealTitle.toLocaleLowerCase('pt-BR')}.`
      : result.error);
  };

  return (
    <section className="space-y-3" aria-label="Catálogo de alimentos">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--titan-text-muted)]" aria-hidden="true" />
        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Buscar alimento (sem acento também)"
          aria-label="Buscar alimento no catálogo"
          className="w-full min-h-[44px] pl-9 pr-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm text-[var(--titan-text-primary)]"
        />
      </div>
      <p className="text-[11px] text-[var(--titan-text-muted)]" aria-live="polite">
        {isSearching
          ? 'Atualizando resultados…'
          : `Exibindo ${filteredFoods.length} de ${foodIndex.length.toLocaleString('pt-BR')} alimentos disponíveis. Os dados sem valor analítico permanecem como não analisados, nunca como zero.`}
      </p>
      <Surface className="p-3 space-y-2">
        <p className="text-xs font-semibold text-[var(--titan-text-primary)]">Registrar alimento consumido</p>
        <div className="grid grid-cols-2 gap-2">
          <label className="text-[11px] text-[var(--titan-text-secondary)]">
            Quantidade (g)
            <input
              type="number"
              min="1"
              max="2000"
              step="1"
              value={quantityG}
              onChange={(event) => setQuantityG(event.target.value)}
              aria-invalid={!quantityIsValid}
              className="mt-1 w-full min-h-[42px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm text-[var(--titan-text-primary)]"
            />
          </label>
          <label className="text-[11px] text-[var(--titan-text-secondary)]">
            Refeição
            <select
              value={mealTitle}
              onChange={(event) => setMealTitle(event.target.value as FoodDiaryMealTitle)}
              className="mt-1 w-full min-h-[42px] px-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm text-[var(--titan-text-primary)]"
            >
              {MEAL_OPTIONS.map((option) => <option key={option}>{option}</option>)}
            </select>
          </label>
        </div>
        {!quantityIsValid && <p className="text-[11px] text-[var(--titan-status-warning)]">A quantidade deve estar entre 1 e 2.000 g.</p>}
        {feedback && <p className="text-[11px] text-[var(--titan-text-secondary)]" role="status">{feedback}</p>}
      </Surface>
      {filteredFoods.length === 0 ? (
        <Surface className="p-6 text-center">
          <Apple className="w-5 h-5 mx-auto text-[var(--titan-text-muted)]" aria-hidden="true" />
          <p className="mt-2 text-sm text-[var(--titan-text-primary)]">Nenhum alimento encontrado</p>
          <p className="mt-1 text-xs text-[var(--titan-text-secondary)]">Tente outro nome, sinônimo ou identificador da fonte.</p>
        </Surface>
      ) : filteredFoods.map((food) => (
        <Surface key={food.food_id} className="p-4 titan-virtual-card">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-semibold text-sm text-[var(--titan-text-primary)]">{food.name}</h2>
              <p className="mt-1 text-[11px] text-[var(--titan-text-muted)]">Fonte: {food.source_id} · Registro: {food.source_record_id} · Versão: {food.source_version} · Qualidade: {food.quality_status}</p>
              {food.source_url && /^https?:\/\//i.test(food.source_url) && <a href={food.source_url} target="_blank" rel="noreferrer" className="mt-1 inline-block text-[10px] text-[var(--titan-info)] underline break-all">Abrir fonte original</a>}
              <p className="mt-1 text-[10px] text-[var(--titan-text-muted)]">{food.state ?? food.preparation ?? ''}</p>
            </div>
            <div className="text-right shrink-0">
              <p className="font-mono-metric font-semibold text-[var(--titan-text-primary)]">{food.macros.kcalPerBasis.toFixed(1)} kcal</p>
              <p className="text-[11px] text-[var(--titan-text-secondary)]">por {food.macros.basisQuantityG} g</p>
            </div>
          </div>
          <div className="mt-2 flex flex-wrap gap-3 text-xs font-mono-metric">
            <span className="text-[var(--titan-accent)]">P {food.macros.proteinGPerBasis.toFixed(1)} g</span>
            <span className="text-[var(--titan-info)]">C {food.macros.carbsGPerBasis.toFixed(1)} g</span>
            <span className="text-[var(--titan-copper)]">G {food.macros.fatGPerBasis.toFixed(1)} g</span>
            {food.macros.fiberGPerBasis !== undefined && food.macros.fiberGPerBasis !== null && <span>Fibra {food.macros.fiberGPerBasis.toFixed(1)} g</span>}
          </div>
          <button
            type="button"
            disabled={!quantityIsValid}
            onClick={() => registerFood(food.food_id, food.name)}
            className="mt-3 min-h-[42px] w-full rounded-xl bg-[var(--titan-accent)] px-3 text-xs font-semibold text-[var(--titan-bg-canvas)] disabled:cursor-not-allowed disabled:opacity-45"
          >
            Registrar no dia
          </button>
        </Surface>
      ))}
    </section>
  );
});
