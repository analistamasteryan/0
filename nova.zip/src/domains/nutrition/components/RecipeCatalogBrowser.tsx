import { memo, useDeferredValue, useMemo, useState } from 'react';
import { BookOpen, Search } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import { RECIPE_CATALOG } from '../data/recipes/recipe-catalog';
import { computeRecipeSummary } from '../domain/rules/recipe-engine';
import { createRecipeSearchEntry, searchRecipeIndex } from '../domain/rules/recipe-search';

const RECIPE_INDEX = RECIPE_CATALOG.map((recipe) => {
  const summary = computeRecipeSummary(recipe);
  const searchEntry = createRecipeSearchEntry(recipe, [
    recipe.name,
    recipe.description,
    ...recipe.ingredients.map((ingredient) => ingredient.ingredientId),
    ...summary.ingredientNames,
  ]);
  return { ...searchEntry, summary };
});

export const RecipeCatalogBrowser = memo(function RecipeCatalogBrowser() {
  const [query, setQuery] = useState('');
  const deferredQuery = useDeferredValue(query);
  const filteredRecipes = useMemo(() => {
    const matches = new Set(searchRecipeIndex(RECIPE_INDEX, deferredQuery));
    return RECIPE_INDEX.filter((entry) => matches.has(entry.item));
  }, [deferredQuery]);

  return (
    <section className="space-y-3" aria-label="Catálogo de receitas">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--titan-text-muted)]" aria-hidden="true" />
        <input
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Buscar receita ou ingrediente"
          aria-label="Buscar receita ou ingrediente"
          className="w-full min-h-[44px] pl-9 pr-3 rounded-xl bg-[var(--titan-bg-canvas)] border border-[var(--titan-border)] text-sm text-[var(--titan-text-primary)]"
        />
      </div>
      <p className="text-[11px] text-[var(--titan-text-muted)]" aria-live="polite">
        {filteredRecipes.length} de {RECIPE_INDEX.length} receitas disponíveis. A busca ignora acentos e considera ingredientes.
      </p>
      {filteredRecipes.length === 0 ? (
        <Surface className="p-6 text-center">
          <BookOpen className="w-5 h-5 mx-auto text-[var(--titan-text-muted)]" aria-hidden="true" />
          <p className="mt-2 text-sm text-[var(--titan-text-primary)]">Nenhuma receita encontrada</p>
          <p className="mt-1 text-xs text-[var(--titan-text-secondary)]">Tente o nome de um ingrediente ou uma expressão mais simples.</p>
        </Surface>
      ) : filteredRecipes.map(({ item: recipe, summary }) => (
        <Surface key={recipe.id} className="p-4 titan-virtual-card">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-semibold text-sm text-[var(--titan-text-primary)]">{recipe.name}</h2>
              <p className="mt-1 text-xs text-[var(--titan-text-secondary)]">{summary.ingredientNames.join(' · ')}</p>
              <p className="mt-2 text-[11px] text-[var(--titan-text-muted)]">
                {summary.totalGrams.toFixed(1)} g · {recipe.ingredients.length} ingrediente(s) · dados quantificados {summary.dataCoveragePercent.toFixed(0)}%
              </p>
              {(summary.unresolvedFoodIds.length > 0 || summary.lowConfidenceFoodIds.length > 0) && (
                <p className="mt-1 text-[10px] text-[var(--titan-status-warning)]">
                  {summary.unresolvedFoodIds.length > 0
                    ? `${summary.unresolvedFoodIds.length} ingrediente(s) sem correspondência nutricional`
                    : `${summary.lowConfidenceFoodIds.length} ingrediente(s) com rótulo parcial/baixa confiança`}
                </p>
              )}
            </div>
            <div className="text-right shrink-0">
              <p className="font-mono-metric font-semibold text-[var(--titan-text-primary)]">{Math.round(summary.macros.kcal)} kcal</p>
              <p className="text-[11px] text-[var(--titan-accent)]">{summary.macros.proteinG.toFixed(1)} g proteína</p>
            </div>
          </div>
        </Surface>
      ))}
    </section>
  );
});
