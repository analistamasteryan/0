import { normalizeFoodSearchText } from './food-search.ts';

export interface RecipeSearchEntry<T> {
  item: T;
  normalizedText: string;
}

export function createRecipeSearchEntry<T>(item: T, fields: readonly string[]): RecipeSearchEntry<T> {
  return { item, normalizedText: normalizeFoodSearchText(fields.join(' ')) };
}

/** Multi-term, accent-insensitive search that does not depend on word order. */
export function searchRecipeIndex<T>(
  index: readonly RecipeSearchEntry<T>[],
  query: string,
): T[] {
  const terms = normalizeFoodSearchText(query).split(' ').filter(Boolean);
  if (terms.length === 0) return index.map((entry) => entry.item);
  return index
    .filter((entry) => terms.every((term) => entry.normalizedText.includes(term)))
    .map((entry) => entry.item);
}
