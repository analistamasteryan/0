import type { FoodSourceItem, MealItem } from '../entities/nutrient';
import { isValidLocalDateKey } from '../../../../shared/utils/local-date.ts';

export type FoodDiaryMealTitle = 'Café da manhã' | 'Almoço' | 'Lanche' | 'Jantar';

export function createFoodDiaryMeal(input: {
  food: FoodSourceItem;
  quantityG: number;
  dateKey: string;
  mealTitle: FoodDiaryMealTitle;
  id: string;
  nowMs: number;
}): MealItem | null {
  const { food, quantityG, dateKey, mealTitle, id, nowMs } = input;
  if (!id.trim() || !isValidLocalDateKey(dateKey)) return null;
  if (!Number.isFinite(nowMs) || nowMs < 0) return null;
  if (!Number.isFinite(quantityG) || quantityG < 1 || quantityG > 2000) return null;
  if (!food.food_id || !food.name || !Number.isFinite(food.macros.basisQuantityG) || food.macros.basisQuantityG <= 0) return null;

  const timeDate = new Date(nowMs);
  const time = `${String(timeDate.getHours()).padStart(2, '0')}:${String(timeDate.getMinutes()).padStart(2, '0')}`;
  const portions = [{ foodId: food.food_id, quantityG: Math.round(quantityG * 10) / 10 }];
  return {
    id,
    dateKey,
    time,
    title: mealTitle,
    description: `${food.name} · ${food.source_id} (${food.source_record_id})`,
    planned_quantity: portions[0]!.quantityG,
    consumed_quantity: portions[0]!.quantityG,
    planned_foods: portions,
    consumed_foods: portions.map((portion) => ({ ...portion })),
    status: 'consumed',
  };
}
