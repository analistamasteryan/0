import assert from 'node:assert/strict';
import { createRecipeSearchEntry, searchRecipeIndex } from '../recipe-search.ts';

const recipes = [
  { id: 'frango', name: 'Frango com arroz integral' },
  { id: 'pao', name: 'Pão integral com ovos' },
  { id: 'iogurte', name: 'Iogurte com banana' },
];
const index = recipes.map((recipe) => createRecipeSearchEntry(recipe, [recipe.name]));

assert.deepEqual(searchRecipeIndex(index, 'pao ovos').map((recipe) => recipe.id), ['pao']);
assert.deepEqual(searchRecipeIndex(index, 'ARROZ FRANGO').map((recipe) => recipe.id), ['frango']);
assert.deepEqual(searchRecipeIndex(index, 'iogurte banana').map((recipe) => recipe.id), ['iogurte']);
assert.deepEqual(searchRecipeIndex(index, '').map((recipe) => recipe.id), ['frango', 'pao', 'iogurte']);
assert.deepEqual(searchRecipeIndex(index, 'nao existe'), []);

console.log('recipe-search: PASS');
