import { isValidLocalDateKey } from '../../../shared/utils/local-date.ts';
import type { MealItem, ReferenceProfileId } from '../domain/entities/nutrient';

export interface PersistedNutritionState {
  activeDateKey: string;
  referenceProfileId: ReferenceProfileId;
  dailyGoals: { kcal: number; proteinG: number; carbsG: number; fatG: number };
  meals: MealItem[];
  intakeDayConfirmations: string[];
}

const REFERENCE_PROFILE_IDS: readonly ReferenceProfileId[] = [
  'adult_male_19_30',
  'adult_female_19_30',
  'adult_male_19_50',
  'adult_female_19_50',
  'adult_51_plus',
  'adult_female_51_plus',
  'adult_male_51_70',
  'adult_female_51_70',
  'adult_male_71_plus',
  'adult_female_71_plus',
];
const MEAL_STATUSES = ['planned', 'consumed', 'partial', 'substituted', 'skipped'] as const;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isFiniteInRange(value: unknown, min: number, max: number): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= min && value <= max;
}

function isSafeMealImageUrl(value: unknown): boolean {
  if (value === undefined) return true;
  if (typeof value !== 'string' || value.length > 2048) return false;
  if (value.startsWith('/') && !value.startsWith('//')) return true;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' || url.protocol === 'http:';
  } catch {
    return false;
  }
}

function isMealPortion(value: unknown): boolean {
  return isRecord(value) &&
    typeof value.foodId === 'string' && value.foodId.length > 0 &&
    isFiniteInRange(value.quantityG, 0.1, 100_000);
}

function isMeal(value: unknown): value is MealItem {
  if (!isRecord(value)) return false;
  return (
    typeof value.id === 'string' && value.id.length > 0 &&
    typeof value.dateKey === 'string' && isValidLocalDateKey(value.dateKey) &&
    typeof value.time === 'string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(value.time) &&
    typeof value.title === 'string' && value.title.trim().length > 0 && value.title.length <= 80 &&
    typeof value.description === 'string' && value.description.length <= 500 &&
    (value.recipeId === undefined || (typeof value.recipeId === 'string' && value.recipeId.length <= 120)) &&
    isSafeMealImageUrl(value.imageUrl) &&
    (value.substitutionNote === undefined || (typeof value.substitutionNote === 'string' && value.substitutionNote.length <= 300)) &&
    isFiniteInRange(value.planned_quantity, 0, 100_000) &&
    isFiniteInRange(value.consumed_quantity, 0, 100_000) &&
    Array.isArray(value.planned_foods) && value.planned_foods.length <= 40 && value.planned_foods.every(isMealPortion) &&
    Array.isArray(value.consumed_foods) && value.consumed_foods.length <= 40 && value.consumed_foods.every(isMealPortion) &&
    typeof value.status === 'string' && MEAL_STATUSES.includes(value.status as typeof MEAL_STATUSES[number])
  );
}

export function mergeNutritionPersistedState(
  persisted: unknown,
  current: PersistedNutritionState,
): PersistedNutritionState {
  if (!isRecord(persisted)) return current;
  const activeDateKey = typeof persisted.activeDateKey === 'string' && isValidLocalDateKey(persisted.activeDateKey)
    ? persisted.activeDateKey
    : current.activeDateKey;
  const referenceProfileId = typeof persisted.referenceProfileId === 'string' &&
    REFERENCE_PROFILE_IDS.includes(persisted.referenceProfileId as ReferenceProfileId)
    ? persisted.referenceProfileId as ReferenceProfileId
    : current.referenceProfileId;
  const goals = isRecord(persisted.dailyGoals) ? persisted.dailyGoals : null;
  const dailyGoals = goals &&
    isFiniteInRange(goals.kcal, 500, 10_000) &&
    isFiniteInRange(goals.proteinG, 0, 2_000) &&
    isFiniteInRange(goals.carbsG, 0, 2_000) &&
    isFiniteInRange(goals.fatG, 0, 2_000)
    ? {
        kcal: goals.kcal,
        proteinG: goals.proteinG,
        carbsG: goals.carbsG,
        fatG: goals.fatG,
      }
    : current.dailyGoals;
  const meals = Array.isArray(persisted.meals)
    ? persisted.meals
        .slice(0, 5000)
        .filter(isMeal)
        .filter((meal) => meal.id !== 'meal-prev-1')
        .map((meal) => meal.id === 'meal-1' && meal.title === 'Café da manhã' && meal.recipeId === 'rec-cafe-completo' && meal.status === 'consumed'
          ? { ...meal, status: 'planned' as const, consumed_quantity: 0, consumed_foods: [] }
          : meal)
        .filter((meal, index, list) => list.findIndex((candidate) => candidate.id === meal.id) === index)
        .sort((a, b) => b.dateKey.localeCompare(a.dateKey) || b.time.localeCompare(a.time))
        .slice(0, 2000)
    : current.meals;
  const intakeDayConfirmations = Array.isArray(persisted.intakeDayConfirmations)
    ? [...new Set(persisted.intakeDayConfirmations.filter((dateKey): dateKey is string =>
        typeof dateKey === 'string' && isValidLocalDateKey(dateKey),
      ))]
    : current.intakeDayConfirmations;
  return { activeDateKey, referenceProfileId, dailyGoals, meals, intakeDayConfirmations };
}
