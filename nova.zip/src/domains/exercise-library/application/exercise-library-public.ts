import { EXERCISE_CATALOG, getExerciseBySlug } from '../data/repositories/exercise-catalog.ts';
import { EXERCISE_MUSCLE_MAP } from '../../anatomy/mapping/exercise-muscle-map.ts';
import { filterExerciseCatalog } from './filter-exercises';
import type { ExerciseCatalogFilters } from './filter-exercises';
import type { ExerciseLibraryItem } from '../domain/entities/exercise-item';
import type { MuscleGroupId, MuscleHighlightPayload } from '@/src/shared/types/common';

/** One stable registry is the read boundary for library, workout and anatomy consumers. */
export const ExerciseRegistry = Object.freeze({
  list(): readonly ExerciseLibraryItem[] {
    return EXERCISE_CATALOG;
  },
  find(slug: string): ExerciseLibraryItem | undefined {
    return getExerciseBySlug(slug);
  },
  search(query: string, filters?: ExerciseCatalogFilters): readonly ExerciseLibraryItem[] {
    return filterExerciseCatalog(query, filters);
  },
  forMuscle(muscleId: MuscleGroupId): readonly ExerciseLibraryItem[] {
    return EXERCISE_CATALOG.filter((exercise) =>
      exercise.muscles.primary.includes(muscleId)
      || exercise.muscles.secondary.includes(muscleId)
      || exercise.stabilizers?.includes(muscleId),
    );
  },
  highlights(slug: string): MuscleHighlightPayload | undefined {
    const payload = EXERCISE_MUSCLE_MAP[slug];
    return payload
      ? { primary: [...payload.primary], secondary: [...payload.secondary] }
      : undefined;
  },
});

/** Stable cross-domain compatibility functions. */
export function findExerciseDefinition(slug: string): ExerciseLibraryItem | undefined {
  return ExerciseRegistry.find(slug);
}

export function listExerciseDefinitions(): readonly ExerciseLibraryItem[] {
  return ExerciseRegistry.list();
}
