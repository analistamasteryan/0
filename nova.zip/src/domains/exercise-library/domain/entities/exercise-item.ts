import type { MuscleGroupId, MuscleHighlightPayload } from '@/src/shared/types/common';

export type ExerciseLevel = 'beginner' | 'intermediate' | 'advanced';
export type ExerciseForce = 'push' | 'pull' | 'static' | 'mixed';
export type ExerciseMechanic = 'compound' | 'isolation' | 'isometric' | 'mobility';
export type ExerciseCategory = 'strength' | 'core' | 'mobility' | 'cardio';

export type ExerciseSourceRepository =
  | 'yuhonas/free-exercise-db'
  | 'wger-project/wger'
  | 'hasaneyldrm/exercises-dataset'
  | 'kinetic-place/exercises-db'
  | 'RepDB/exercise-dataset'
  | 'exercemus/exercises'
  | 'wrkout/exercises.json'
  | 'TITAN';

export interface ExerciseSourceReference {
  repository: ExerciseSourceRepository;
  recordId: string;
  /** License of the specific exercise data, not an assumption about associated media. */
  license: string;
  recordUrl: string;
  recordBlobSha?: string;
  attribution?: string;
}

/**
 * Canonical exercise definition shared by the library, workout planner and anatomy overlay.
 * Primary/secondary muscles are restricted to TITAN's selectable anatomy IDs. Stabilizers are
 * descriptive metadata and are not silently promoted to the 3D primary/secondary overlay.
 */
export interface ExerciseLibraryItem {
  slug: string;
  name: string;
  equipment: string;
  pattern: string;
  muscles: MuscleHighlightPayload;
  cue: string;
  level?: ExerciseLevel;
  force?: ExerciseForce;
  mechanic?: ExerciseMechanic;
  category?: ExerciseCategory;
  instructions?: readonly string[];
  tips?: readonly string[];
  commonErrors?: readonly string[];
  breathing?: string;
  stabilizers?: readonly MuscleGroupId[];
  aliases?: readonly string[];
  tempoGuidance?: string;
  progressions?: readonly string[];
  regressions?: readonly string[];
  alternatives?: readonly string[];
  /** Legacy single-source field retained for existing integrations. */
  source?: ExerciseSourceReference;
  /** Additional source records used to corroborate or enrich the canonical item. */
  sources?: readonly ExerciseSourceReference[];
}
