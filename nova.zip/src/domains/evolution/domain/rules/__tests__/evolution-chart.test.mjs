import assert from 'node:assert/strict';
import { buildEvolutionTrendSeries } from '../evolution-chart.ts';

const records = [
  { id: 'one', dateKey: '2026-11-01', dateLabel: '01 NOV', weightKg: 80, waistCm: 90 },
  { id: 'two', dateKey: '2026-11-08', dateLabel: '08 NOV', weightKg: 79.5 },
  { id: 'three', dateKey: '2026-11-15', dateLabel: '15 NOV', weightKg: 79, waistCm: 88 },
];

const empty = buildEvolutionTrendSeries([], 'weightKg');
assert.equal(empty.points.length, 0);
assert.equal(empty.line, '');

const weight = buildEvolutionTrendSeries(records, 'weightKg');
assert.equal(weight.points.length, 3);
assert.equal(weight.points[0].x, 48);
assert.equal(weight.points[2].x, 662);
assert.equal(weight.points[0].value, 80);
assert.equal(weight.points[2].value, 79);
assert.ok(weight.line.startsWith('M '));
assert.ok(weight.area.endsWith('Z'));

const waist = buildEvolutionTrendSeries(records, 'waistCm');
assert.equal(waist.points.length, 2, 'only rows with an observed waist measurement are plotted');
assert.equal(waist.points[0].x, 48, 'sparse metric data begins at the first chart position');
assert.equal(waist.points[1].x, 662, 'sparse metric data ends at the last chart position');
assert.equal(waist.points[0].value, 90);
assert.equal(waist.points[1].value, 88);

const single = buildEvolutionTrendSeries([records[0]], 'waistCm');
assert.equal(single.points.length, 1);
assert.equal(single.points[0].x, 355, 'single point is centered');
assert.equal(single.area, '', 'a single observation has no filled area');

const missing = buildEvolutionTrendSeries(records, 'armCm');
assert.equal(missing.points.length, 0);
console.log('Evolution chart series tests passed.');
