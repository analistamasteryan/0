import type { BodyMeasurementRecord } from '@/src/shared/types/body-measurement';

export type EvolutionChartMetric = 'weightKg' | 'waistCm' | 'armCm' | 'thighCm';

export interface EvolutionTrendPoint {
  x: number;
  y: number;
  value: number;
  date: string;
  id: string;
}

export interface EvolutionTrendSeries {
  points: EvolutionTrendPoint[];
  line: string;
  area: string;
  min: number;
  max: number;
  actualMin: number;
  actualMax: number;
  plotHeight: number;
}

export const EVOLUTION_CHART_WIDTH = 680;
export const EVOLUTION_CHART_HEIGHT = 236;
export const EVOLUTION_CHART_PLOT = { left: 48, right: 18, top: 18, bottom: 40 } as const;

const WIDTH = EVOLUTION_CHART_WIDTH;
const HEIGHT = EVOLUTION_CHART_HEIGHT;
const PLOT = EVOLUTION_CHART_PLOT;

function emptySeries(): EvolutionTrendSeries {
  return {
    points: [],
    line: '',
    area: '',
    min: 0,
    max: 0,
    actualMin: 0,
    actualMax: 0,
    plotHeight: HEIGHT - PLOT.top - PLOT.bottom,
  };
}

/** Build a chart only from observations of the selected measurement. */
export function buildEvolutionTrendSeries(
  records: readonly BodyMeasurementRecord[],
  metricKey: EvolutionChartMetric,
): EvolutionTrendSeries {
  const validRecords = records.filter((record) => Number.isFinite(record[metricKey]));
  if (validRecords.length === 0) return emptySeries();

  let actualMin = Number.POSITIVE_INFINITY;
  let actualMax = Number.NEGATIVE_INFINITY;
  for (const record of validRecords) {
    const value = record[metricKey] as number;
    actualMin = Math.min(actualMin, value);
    actualMax = Math.max(actualMax, value);
  }

  const spread = actualMax - actualMin;
  const padding = spread > 0 ? spread * 0.22 : Math.max(actualMax * 0.025, 0.5);
  const min = Math.max(0, actualMin - padding);
  const max = actualMax + padding;
  const plotWidth = WIDTH - PLOT.left - PLOT.right;
  const plotHeight = HEIGHT - PLOT.top - PLOT.bottom;
  const points = validRecords.map((record, index): EvolutionTrendPoint => {
    const x = validRecords.length === 1
      ? PLOT.left + plotWidth / 2
      : PLOT.left + (index / (validRecords.length - 1)) * plotWidth;
    const value = record[metricKey] as number;
    const y = PLOT.top + ((max - value) / Math.max(0.0001, max - min)) * plotHeight;
    return { x, y, value, date: record.dateLabel, id: record.id };
  });
  const line = points
    .map((point, index) => `${index === 0 ? 'M' : 'L'} ${point.x.toFixed(2)} ${point.y.toFixed(2)}`)
    .join(' ');
  const first = points[0];
  const last = points[points.length - 1];
  const area = points.length > 1 && first && last
    ? `${line} L ${last.x.toFixed(2)} ${(HEIGHT - PLOT.bottom).toFixed(2)} L ${first.x.toFixed(2)} ${(HEIGHT - PLOT.bottom).toFixed(2)} Z`
    : '';

  return { points, line, area, min, max, actualMin, actualMax, plotHeight };
}
