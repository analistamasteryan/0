import { z } from 'zod';

/** Weight can be recorded daily; circumference measurements are independent, optional observations. */
export const measurementEntrySchema = z.object({
  weightKg: z.number().finite().min(30, 'Peso mínimo 30 kg').max(300, 'Peso máximo 300 kg'),
  waistCm: z.number().finite().min(45).max(200).optional(),
  armCm: z.number().finite().min(18).max(75).optional(),
  thighCm: z.number().finite().min(30).max(110).optional(),
  chestCm: z.number().finite().min(55).max(180).optional(),
  hipCm: z.number().finite().min(55).max(200).optional(),
  neckCm: z.number().finite().min(25).max(65).optional(),
  forearmCm: z.number().finite().min(15).max(50).optional(),
  calfCm: z.number().finite().min(25).max(75).optional(),
});

export type MeasurementEntryInput = z.infer<typeof measurementEntrySchema>;
