import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { ArrowRight, ChevronRight } from 'lucide-react';
import {
  computeDailyMacroAndEnergyBreakdown,
  type MealConsumptionStatus,
  useNutritionStore,
} from '@/src/domains/nutrition/application/nutrition-public';
import {
  getSharedFluidEngine,
  interpolateRatio,
  prefersReducedMotion,
  type FluidDrawJob,
} from '@/src/shared/graphics/fluid-shader-engine';
import { BottomSheet } from '@/src/shared/ui/BottomSheet';
import { formatKcal } from '@/src/shared/utils/formatters';

interface EnergySummaryProps {
  consumedKcal: number;
  goalKcal: number;
  plannedRemainingKcal?: number;
  plannedMealsCount?: number;
  isEstimatedGoal?: boolean;
  dataCoveragePercent?: number | null;
  unresolvedFoodCount?: number;
  lowConfidenceFoodCount?: number;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

const BAR_HEIGHT = 34;
const MIN_RENDER_WIDTH = 120;
const INTERPOLATION_TIME_CONSTANT_SECONDS = 0.14;

function drawEnergyFallback(
  canvas: HTMLCanvasElement,
  width: number,
  ratio: number,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const pixelWidth = Math.max(2, Math.round(width * dpr));
  const pixelHeight = Math.max(2, Math.round(BAR_HEIGHT * dpr));
  if (canvas.width !== pixelWidth) canvas.width = pixelWidth;
  if (canvas.height !== pixelHeight) canvas.height = pixelHeight;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, BAR_HEIGHT);
  ctx.save();
  ctx.beginPath();
  ctx.roundRect(0, 0, width, BAR_HEIGHT, BAR_HEIGHT / 2);
  ctx.clip();

  // Smoked obsidian borosilicate glass cavity
  const cavity = ctx.createLinearGradient(0, 0, 0, BAR_HEIGHT);
  cavity.addColorStop(0, '#1B2A26');
  cavity.addColorStop(0.45, '#091210');
  cavity.addColorStop(1, '#040908');
  ctx.fillStyle = cavity;
  ctx.fillRect(0, 0, width, BAR_HEIGHT);

  // Subtle laser-etched optical scale
  ctx.fillStyle = 'rgba(160, 183, 168, 0.14)';
  for (let i = 1; i < 12; i += 1) {
    ctx.fillRect(Math.round((width * i) / 12), 3, 1, 5);
  }

  const fillWidth = Math.max(0, Math.min(width, width * ratio));
  if (fillWidth > 0.5) {
    const fluid = ctx.createLinearGradient(0, 1, 0, BAR_HEIGHT - 1);
    fluid.addColorStop(0, '#80B898');
    fluid.addColorStop(0.24, '#3D735A');
    fluid.addColorStop(0.66, '#1B4433');
    fluid.addColorStop(1, '#0C241A');
    ctx.fillStyle = fluid;
    ctx.fillRect(0, 0, fillWidth, BAR_HEIGHT);

    // Core bio-energy filament ribbon
    const filament = ctx.createLinearGradient(0, BAR_HEIGHT * 0.25, 0, BAR_HEIGHT * 0.78);
    filament.addColorStop(0, 'rgba(182, 236, 204, 0)');
    filament.addColorStop(0.5, 'rgba(196, 246, 214, 0.34)');
    filament.addColorStop(1, 'rgba(182, 236, 204, 0)');
    ctx.fillStyle = filament;
    ctx.fillRect(0, BAR_HEIGHT * 0.25, fillWidth, BAR_HEIGHT * 0.53);

    if (ratio > 0.015 && ratio < 0.99) {
      const edgeX = Math.min(width - 1, fillWidth);
      const meniscus = ctx.createLinearGradient(edgeX - 4, 0, edgeX + 4, 0);
      meniscus.addColorStop(0, 'rgba(177, 211, 190, 0)');
      meniscus.addColorStop(0.45, 'rgba(224, 249, 233, 0.84)');
      meniscus.addColorStop(0.75, 'rgba(4, 10, 8, 0.58)');
      meniscus.addColorStop(1, 'rgba(177, 211, 190, 0)');
      ctx.fillStyle = meniscus;
      ctx.fillRect(edgeX - 4, 1, 8, BAR_HEIGHT - 2);
    }
  }

  // Curved cylindrical glass top softbox reflection + bottom lens bounce
  const topGlare = ctx.createLinearGradient(0, 1, 0, 10);
  topGlare.addColorStop(0, 'rgba(241, 246, 243, 0.36)');
  topGlare.addColorStop(1, 'rgba(241, 246, 243, 0)');
  ctx.fillStyle = topGlare;
  ctx.fillRect(5, 1, Math.max(0, width - 10), 9);

  const botBounce = ctx.createLinearGradient(0, BAR_HEIGHT - 6, 0, BAR_HEIGHT);
  botBounce.addColorStop(0, 'rgba(160, 183, 168, 0)');
  botBounce.addColorStop(1, 'rgba(160, 183, 168, 0.18)');
  ctx.fillStyle = botBounce;
  ctx.fillRect(6, BAR_HEIGHT - 6, Math.max(0, width - 12), 5);

  ctx.restore();
}

const MEAL_STATUS_LABELS: Record<MealConsumptionStatus, string> = {
  planned: 'Planejada',
  consumed: 'Consumida',
  partial: 'Parcial',
  substituted: 'Substituída',
  skipped: 'Pulada',
};

interface EnergyDetailSheetProps {
  open: boolean;
  onClose: () => void;
  consumedKcal: number;
  goalKcal: number;
  hasValidGoal: boolean;
  onOpenNutrition?: (section?: 'cardapio' | 'receitas' | 'alimentos') => void;
}

function EnergyDetailSheet({
  open,
  onClose,
  consumedKcal,
  goalKcal,
  hasValidGoal,
  onOpenNutrition,
}: EnergyDetailSheetProps) {
  const meals = useNutritionStore((s) => s.meals);
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);

  const breakdown = useMemo(
    () => computeDailyMacroAndEnergyBreakdown(meals, activeDateKey),
    [meals, activeDateKey],
  );

  const topFoods = useMemo(
    () =>
      [...breakdown.consumedFoods]
        .filter((f) => f.macros.kcal > 0)
        .sort((a, b) => b.macros.kcal - a.macros.kcal),
    [breakdown.consumedFoods],
  );

  const diff = hasValidGoal ? goalKcal - consumedKcal : null;

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      animateOpen
      title="Análise energética do dia"
      subtitle="Comparativo rigoroso entre planejado, consumido e meta"
    >
      <div className="space-y-4">
        <div className="titan-luxury-group grid grid-cols-3 gap-2.5 p-3.5 text-center font-mono-metric">
          <div>
            <div className="text-[11px] text-[var(--titan-text-muted)]">Consumido</div>
            <div className="text-sm font-semibold text-[var(--titan-text-primary)] mt-0.5">
              {formatKcal(consumedKcal)} kcal
            </div>
          </div>
          <div>
            <div className="text-[11px] text-[var(--titan-text-muted)]">Planejado</div>
            <div className="text-sm font-semibold text-[var(--titan-text-secondary)] mt-0.5">
              {formatKcal(Math.round(breakdown.plannedTotals.kcal))} kcal
            </div>
          </div>
          <div>
            <div className="text-[11px] text-[var(--titan-text-muted)]">
              {diff !== null && diff < 0 ? 'Excedente' : 'Restante'}
            </div>
            <div
              className={`text-sm font-semibold mt-0.5 ${
                diff !== null && diff < 0 ? 'text-[var(--titan-champagne)]' : 'text-[var(--titan-accent)]'
              }`}
            >
              {diff === null ? '—' : `${formatKcal(Math.abs(diff))} kcal`}
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Contribuição por refeição
          </h3>
          {breakdown.meals.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">
              Nenhuma refeição cadastrada nesta data.
            </p>
          ) : (
            <div className="titan-luxury-group divide-y divide-[rgba(193,204,196,0.08)] px-3">
              {breakdown.meals.map((item) => (
                <div key={item.mealId} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {item.time} · {item.title}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)]">
                      {MEAL_STATUS_LABELS[item.status]} · planejado {formatKcal(Math.round(item.planned.kcal))} kcal
                    </div>
                  </div>
                  <span
                    className={`font-mono-metric font-semibold shrink-0 ${
                      item.isRecorded ? 'text-[var(--titan-accent)]' : 'text-[var(--titan-text-muted)]'
                    }`}
                  >
                    {item.isRecorded ? `${formatKcal(Math.round(item.consumed.kcal))} kcal` : '0 kcal reg.'}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
            Alimentos registrados
          </h3>
          {topFoods.length === 0 ? (
            <p className="text-xs text-[var(--titan-text-muted)]">
              Nenhum alimento consumido foi registrado ainda hoje.
            </p>
          ) : (
            <div className="titan-luxury-group max-h-52 overflow-y-auto divide-y divide-[rgba(193,204,196,0.08)] px-3">
              {topFoods.map((food, idx) => (
                <div key={`${food.mealId}-${food.foodId}-${idx}`} className="py-2 flex items-center justify-between gap-2 text-xs">
                  <div className="min-w-0">
                    <div className="font-medium text-[var(--titan-text-primary)] truncate">
                      {food.foodName}
                    </div>
                    <div className="text-[11px] text-[var(--titan-text-muted)] truncate">
                      {food.mealTitle} · {food.quantityG} g
                    </div>
                  </div>
                  <span className="font-mono-metric text-[var(--titan-text-primary)] shrink-0">
                    {formatKcal(Math.round(food.macros.kcal))} kcal
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {onOpenNutrition && (
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenNutrition('cardapio');
            }}
            className="titan-button titan-button--mineral w-full !min-h-[44px] !text-xs"
          >
            <span>Gerenciar refeições no Cardápio</span>
            <ArrowRight className="w-3.5 h-3.5" aria-hidden="true" />
          </button>
        )}
      </div>
    </BottomSheet>
  );
}

export const EnergySummary = memo(function EnergySummary({
  consumedKcal,
  goalKcal,
  onOpenNutrition,
}: EnergySummaryProps) {
  const [detailOpen, setDetailOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const safeConsumed = Number.isFinite(consumedKcal)
    ? Math.max(0, consumedKcal)
    : 0;
  const hasValidGoal = Number.isFinite(goalKcal) && goalKcal > 0;
  const safeGoal = hasValidGoal ? goalKcal : 1;
  const ratio = hasValidGoal
    ? Math.min(1, Math.max(0, safeConsumed / safeGoal))
    : 0;
  const rawPercent = hasValidGoal ? Math.round((safeConsumed / safeGoal) * 100) : 0;
  const progressValue = Math.min(100, Math.max(0, rawPercent));

  const targetRatioRef = useRef(ratio);
  const currentRatioRef = useRef(ratio);
  const lastFrameAtRef = useRef(0);
  const sizeRef = useRef({ w: 280, h: BAR_HEIGHT });
  const isVisibleRef = useRef(true);
  const providerRef = useRef<(() => FluidDrawJob | null) | null>(null);

  useEffect(() => {
    targetRatioRef.current = ratio;
    const engine = getSharedFluidEngine();

    if (
      typeof window !== 'undefined' &&
      prefersReducedMotion()
    ) {
      currentRatioRef.current = ratio;
      lastFrameAtRef.current = 0;
      if (providerRef.current) {
        const rendered = engine.renderSinglePass(providerRef.current);
        if (!rendered && canvasRef.current) {
          drawEnergyFallback(canvasRef.current, sizeRef.current.w, ratio);
        }
      }
      return;
    }

    lastFrameAtRef.current = 0;
    if (providerRef.current) {
      const rendered = engine.renderSinglePass(providerRef.current);
      if (!rendered && canvasRef.current) {
        drawEnergyFallback(canvasRef.current, sizeRef.current.w, ratio);
      }
    }
    engine.wake();
  }, [ratio]);

  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    const engine = getSharedFluidEngine();
    sizeRef.current.w = Math.max(MIN_RENDER_WIDTH, container.clientWidth);

    const provider = (): FluidDrawJob | null => {
      const now = performance.now();
      const elapsed = lastFrameAtRef.current
        ? Math.min(0.05, Math.max(0, (now - lastFrameAtRef.current) / 1000))
        : 1 / 60;
      lastFrameAtRef.current = now;

      currentRatioRef.current = interpolateRatio(
        currentRatioRef.current,
        targetRatioRef.current,
        elapsed,
        INTERPOLATION_TIME_CONSTANT_SECONDS,
      );

      const motionAllowed = typeof window === 'undefined' ? false : !prefersReducedMotion();
      const isFlowActive =
        isVisibleRef.current && motionAllowed && currentRatioRef.current > 0.005;

      return {
        kind: 'energy',
        targetCanvas: canvas,
        width: sizeRef.current.w,
        height: sizeRef.current.h,
        fill: currentRatioRef.current,
        isAnimating:
          isFlowActive ||
          Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005,
        isVisible: isVisibleRef.current,
      };
    };
    providerRef.current = provider;

    const renderCurrent = () => {
      const rendered = engine.renderSinglePass(provider);
      if (!rendered) {
        drawEnergyFallback(canvas, sizeRef.current.w, currentRatioRef.current);
      }
    };

    const resizeObserver =
      typeof ResizeObserver !== 'undefined'
        ? new ResizeObserver(() => {
            sizeRef.current.w = Math.max(MIN_RENDER_WIDTH, container.clientWidth);
            renderCurrent();
          })
        : null;
    resizeObserver?.observe(container);

    const intersectionObserver =
      typeof IntersectionObserver !== 'undefined'
        ? new IntersectionObserver(
            (entries) => {
              isVisibleRef.current = entries[0]?.isIntersecting ?? true;
              if (isVisibleRef.current) {
                renderCurrent();
                if (
                  !prefersReducedMotion() &&
                  (currentRatioRef.current > 0.005 ||
                    Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005)
                ) {
                  engine.wake();
                }
              }
            },
            { threshold: 0.05 },
          )
        : null;
    intersectionObserver?.observe(container);

    renderCurrent();
    const unsubscribe = engine.subscribe(provider, true);
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    const handleMotionPreference = (event: MediaQueryListEvent) => {
      if (event.matches) {
        currentRatioRef.current = targetRatioRef.current;
        lastFrameAtRef.current = 0;
        renderCurrent();
      } else if (
        isVisibleRef.current &&
        (currentRatioRef.current > 0.005 ||
          Math.abs(targetRatioRef.current - currentRatioRef.current) > 0.0005)
      ) {
        lastFrameAtRef.current = 0;
        engine.wake();
      }
    };
    motionQuery.addEventListener('change', handleMotionPreference);

    return () => {
      providerRef.current = null;
      unsubscribe();
      resizeObserver?.disconnect();
      intersectionObserver?.disconnect();
      motionQuery.removeEventListener('change', handleMotionPreference);
    };
  }, []);

  const hasLiquidReadoutRoom = hasValidGoal && rawPercent > 0 && ratio >= 0.16;
  const percentAnchorStyle = hasLiquidReadoutRoom
    ? {
        left: `${(ratio * 100).toFixed(2)}%`,
        transform: 'translate3d(calc(-100% - 10px), -50%, 0)',
      }
    : {
        left: '12px',
        transform: 'translate3d(0, -50%, 0)',
      };

  return (
    <section aria-label="Energia" className="px-0.5 py-1">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-semibold uppercase tracking-[0.08em] text-[var(--titan-text-secondary)]">
          Energia
        </span>
        <button
          type="button"
          onClick={() => setDetailOpen(true)}
          aria-label="Abrir análise energética do dia"
          className="inline-flex items-center gap-0.5 min-h-[28px] px-1.5 -mr-1.5 rounded-lg text-[11px] font-medium text-[var(--titan-text-muted)] hover:text-[var(--titan-text-primary)] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
        >
          <ChevronRight className="w-3.5 h-3.5" aria-hidden="true" />
        </button>
      </div>

      <div className="mt-1 flex items-baseline justify-between gap-2">
        <span className="font-display text-3xl sm:text-4xl font-semibold tabular-nums text-[var(--titan-text-primary)] tracking-tight">
          {formatKcal(safeConsumed)} kcal
        </span>
        <span className="text-sm font-medium font-mono-metric text-[var(--titan-text-muted)] text-right tabular-nums">
          {hasValidGoal ? `${formatKcal(safeGoal)} kcal` : 'Meta não definida'}
        </span>
      </div>

      {/* Cápsula de vidro borossilicato + fluido bioenergético vivo com percentual integrado na ponta do líquido */}
      <div className="mt-3.5 relative">
        <div
          ref={containerRef}
          className="relative h-[34px] w-full rounded-full bg-[#070E0C] border border-white/10 shadow-[inset_0_5px_14px_rgba(0,0,0,0.92),inset_0_-1.5px_2px_rgba(241,240,233,0.14),0_1px_0_rgba(241,240,233,0.09),0_12px_28px_rgba(0,0,0,0.34)] p-[1.5px] overflow-hidden"
          role={hasValidGoal ? 'progressbar' : 'group'}
          aria-valuenow={hasValidGoal ? progressValue : undefined}
          aria-valuemin={hasValidGoal ? 0 : undefined}
          aria-valuemax={hasValidGoal ? 100 : undefined}
          aria-valuetext={
            hasValidGoal
              ? `${formatKcal(safeConsumed)} de ${formatKcal(safeGoal)} quilocalorias; ${rawPercent}% da meta`
              : undefined
          }
          aria-label={
            hasValidGoal
              ? 'Progresso de energia consumida no dia'
              : 'Energia consumida; meta diária não definida'
          }
        >
          <canvas
            ref={canvasRef}
            className="block w-full h-full rounded-full"
            aria-hidden="true"
          />
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-3 top-[2px] h-[6px] rounded-full bg-gradient-to-b from-white/26 to-transparent"
          />
          <span
            aria-hidden="true"
            style={{
              ...percentAnchorStyle,
              textShadow:
                hasValidGoal && rawPercent > 0
                  ? '0 0 10px rgba(138, 240, 188, 0.85), 0 0 22px rgba(72, 198, 134, 0.52), 0 1px 2px rgba(2, 10, 7, 0.96)'
                  : '0 1px 2px rgba(0, 0, 0, 0.9)',
            }}
            className="pointer-events-none absolute top-1/2 z-[1] inline-flex items-center text-[11px] font-bold font-mono-metric tracking-tight text-[#F6FBF7] tabular-nums transition-[left,transform] duration-200 ease-out"
          >
            {hasValidGoal ? `${rawPercent}%` : '—'}
          </span>
        </div>
        <button
          type="button"
          onClick={() => setDetailOpen(true)}
          aria-label="Detalhar consumo energético"
          className="absolute inset-0 z-[1] rounded-full cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
        />
      </div>

      {detailOpen && (
        <EnergyDetailSheet
          open={detailOpen}
          onClose={() => setDetailOpen(false)}
          consumedKcal={safeConsumed}
          goalKcal={safeGoal}
          hasValidGoal={hasValidGoal}
          onOpenNutrition={onOpenNutrition}
        />
      )}
    </section>
  );
});
