import { useState, type FormEvent } from 'react';
import { ChevronDown } from 'lucide-react';
import { calculateExerciseHydration, type ExerciseHydrationEstimate } from '@/src/domains/hydration/application/hydration-actions';
import { AnimatePresence, motion, TITAN_DURATIONS, TITAN_EASE } from '@/src/shared/motion/titan-motion';
import { Surface } from '@/src/shared/ui/Surface';

interface FormValues {
  preWeight: string;
  postWeight: string;
  fluids: string;
  urine: string;
  duration: string;
}

const INITIAL_FORM: FormValues = {
  preWeight: '',
  postWeight: '',
  fluids: '0',
  urine: '0',
  duration: '60',
};

function formatMl(value: number): string {
  return `${Math.round(value).toLocaleString('pt-BR')} ml`;
}

export function ExerciseHydrationCalculator() {
  const [expanded, setExpanded] = useState(false);
  const [form, setForm] = useState<FormValues>(INITIAL_FORM);
  const [result, setResult] = useState<ExerciseHydrationEstimate | null>(null);
  const [error, setError] = useState<string | null>(null);

  const isOpen = expanded || result !== null || error !== null;

  function update(field: keyof FormValues, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
    setError(null);
    setResult(null);
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try {
      const estimate = calculateExerciseHydration({
        preExerciseWeightKg: Number(form.preWeight.replace(',', '.')),
        postExerciseWeightKg: Number(form.postWeight.replace(',', '.')),
        fluidIntakeMl: Number(form.fluids),
        urineOutputMl: Number(form.urine),
        durationMinutes: Number(form.duration),
      });
      setResult(estimate);
      setError(null);
      setExpanded(true);
    } catch (cause) {
      setResult(null);
      setError(cause instanceof Error ? cause.message : 'Não foi possível calcular o balanço hídrico.');
      setExpanded(true);
    }
  }

  return (
    <Surface className="p-4 sm:p-5 space-y-3">
      <button
        type="button"
        onClick={() => setExpanded((prev) => !prev)}
        aria-expanded={isOpen}
        className="w-full min-h-[44px] flex items-center justify-between gap-3 text-left rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--titan-info)]/70"
      >
        <div className="min-w-0">
          <h2 className="text-sm font-semibold text-[var(--titan-text-primary)]">
            Taxa de suor no exercício
          </h2>
        </div>
        <ChevronDown
          className={`w-4 h-4 text-[var(--titan-text-muted)] shrink-0 transition-transform ${
            isOpen ? 'rotate-180' : ''
          }`}
          aria-hidden="true"
        />
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: TITAN_DURATIONS.quick, ease: TITAN_EASE }}
            className="overflow-hidden space-y-3"
          >
            <p className="text-xs text-[var(--titan-text-muted)]">
              Compare o peso antes e depois da sessão. Informe líquidos ingeridos e urina durante o período para estimar a perda de suor.
            </p>

            <form onSubmit={submit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <label className="text-xs text-[var(--titan-text-secondary)]">Peso antes (kg)
                  <input required type="number" inputMode="decimal" min="1" max="400" step="0.01" value={form.preWeight} onChange={(event) => update('preWeight', event.target.value)} className="mt-1 w-full min-h-[42px] rounded-xl border border-[rgba(193,204,196,0.12)] bg-[var(--titan-surface-inset)] px-3 text-sm font-mono-metric text-[var(--titan-text-primary)]" />
                </label>
                <label className="text-xs text-[var(--titan-text-secondary)]">Peso depois (kg)
                  <input required type="number" inputMode="decimal" min="1" max="400" step="0.01" value={form.postWeight} onChange={(event) => update('postWeight', event.target.value)} className="mt-1 w-full min-h-[42px] rounded-xl border border-[rgba(193,204,196,0.12)] bg-[var(--titan-surface-inset)] px-3 text-sm font-mono-metric text-[var(--titan-text-primary)]" />
                </label>
                <label className="text-xs text-[var(--titan-text-secondary)]">Líquidos ingeridos (ml)
                  <input required type="number" inputMode="numeric" min="0" max="20000" step="10" value={form.fluids} onChange={(event) => update('fluids', event.target.value)} className="mt-1 w-full min-h-[42px] rounded-xl border border-[rgba(193,204,196,0.12)] bg-[var(--titan-surface-inset)] px-3 text-sm font-mono-metric text-[var(--titan-text-primary)]" />
                </label>
                <label className="text-xs text-[var(--titan-text-secondary)]">Urina durante a sessão (ml)
                  <input required type="number" inputMode="numeric" min="0" max="10000" step="10" value={form.urine} onChange={(event) => update('urine', event.target.value)} className="mt-1 w-full min-h-[42px] rounded-xl border border-[rgba(193,204,196,0.12)] bg-[var(--titan-surface-inset)] px-3 text-sm font-mono-metric text-[var(--titan-text-primary)]" />
                </label>
              </div>
              <label className="block text-xs text-[var(--titan-text-secondary)]">Duração do exercício (minutos)
                <input required type="number" inputMode="numeric" min="10" max="1440" step="1" value={form.duration} onChange={(event) => update('duration', event.target.value)} className="mt-1 w-full min-h-[42px] rounded-xl border border-[rgba(193,204,196,0.12)] bg-[var(--titan-surface-inset)] px-3 text-sm font-mono-metric text-[var(--titan-text-primary)]" />
              </label>
              <button type="submit" className="titan-button titan-button--mineral w-full !min-h-[44px]">Calcular taxa de suor</button>
            </form>

            {error && <p role="alert" className="text-xs text-[var(--titan-status-error)]">{error}</p>}
            {result && (
              <div aria-live="polite" className="titan-luxury-group p-3.5 space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <p className="text-[10px] text-[var(--titan-text-muted)]">Perda de suor estimada</p>
                    <p className="text-lg font-semibold font-mono-metric text-[var(--titan-text-primary)]">{formatMl(result.estimatedSweatLossMl)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-[var(--titan-text-muted)]">Taxa de suor estimada</p>
                    <p className="text-lg font-semibold font-mono-metric text-[var(--titan-text-primary)]">{formatMl(result.sweatRateMlPerHour)}/h</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-[var(--titan-text-muted)]">Variação líquida de massa</p>
                    <p className="text-sm font-semibold font-mono-metric text-[var(--titan-text-primary)]">{result.netBodyMassLossPercent.toFixed(2)}%</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-[var(--titan-text-muted)]">Reposição pós-exercício · 0–4 h</p>
                    <p className="text-sm font-semibold font-mono-metric text-[var(--titan-text-primary)]">{formatMl(result.postExerciseReplacementRangeMl.lower)}–{formatMl(result.postExerciseReplacementRangeMl.upper)}</p>
                  </div>
                </div>
                <p className="text-[10px] text-[var(--titan-text-muted)]">Referência pré-exercício: {formatMl(result.preExerciseFluidRangeMl.lower)}–{formatMl(result.preExerciseFluidRangeMl.upper)} 2–4 horas antes, somente como orientação esportiva geral.</p>
                {result.warnings.map((warning) => <p key={warning} className="text-[10px] leading-relaxed text-[var(--titan-text-muted)]">{warning}</p>)}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </Surface>
  );
}
