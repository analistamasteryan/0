import { memo, useEffect, useRef } from 'react';
import type SmilesDrawerType from 'smiles-drawer';
import {
  getNutrientChemistry,
  type NutrientId,
} from '@/src/domains/nutrition/application/nutrition-public';
import { enqueueYieldingTask } from '@/src/shared/utils/yield-to-main';

interface MolecularStructureProps {
  nutrientId: NutrientId;
  size?: 'mini' | 'expanded';
}

interface CachedSvgPayload {
  viewBox: string;
  nodes: SVGElement[];
}

const SVG_STRUCTURE_CACHE = new Map<string, CachedSvgPayload>();

const TITAN_MOLECULE_THEME = {
  C: '#D7E2DE',
  O: '#9AB9AE',
  N: '#91AFBE',
  S: '#C5A875',
  P: '#C5A875',
  F: '#8DB8A3',
  CL: '#8DB8A3',
  BR: '#C77E78',
  I: '#B7C1BD',
  H: '#899590',
  BACKGROUND: 'transparent',
};

type SmilesDrawerModule = typeof SmilesDrawerType;
let smilesDrawerPromise: Promise<SmilesDrawerModule> | null = null;
let miniDrawerSingleton: InstanceType<SmilesDrawerModule['SvgDrawer']> | null = null;
let expandedDrawerSingleton: InstanceType<SmilesDrawerModule['SvgDrawer']> | null = null;

function loadSmilesDrawer(): Promise<SmilesDrawerModule> {
  if (!smilesDrawerPromise) {
    smilesDrawerPromise = import('smiles-drawer').then(
      (mod) => ((mod as { default?: SmilesDrawerModule }).default ?? mod) as SmilesDrawerModule,
    );
  }
  return smilesDrawerPromise;
}

function getSvgDrawer(SmilesDrawer: SmilesDrawerModule, compact: boolean) {
  if (compact) {
    if (!miniDrawerSingleton) {
      miniDrawerSingleton = new SmilesDrawer.SvgDrawer({
        width: 44,
        height: 36,
        bondThickness: 1.65,
        bondLength: 11,
        shortBondLength: 0.82,
        bondSpacing: 3.4,
        atomVisualization: 'default',
        isomeric: false,
        debug: false,
        terminalCarbons: false,
        explicitHydrogens: false,
        overlapSensitivity: 0.42,
        compactDrawing: true,
        fontSizeLarge: 4.8,
        fontSizeSmall: 3.2,
        padding: 2,
        themes: {
          titan: TITAN_MOLECULE_THEME,
        },
      });
    }
    return miniDrawerSingleton;
  }

  if (!expandedDrawerSingleton) {
    expandedDrawerSingleton = new SmilesDrawer.SvgDrawer({
      width: 148,
      height: 92,
      bondThickness: 1.35,
      bondLength: 14,
      shortBondLength: 0.82,
      bondSpacing: 4.2,
      atomVisualization: 'default',
      isomeric: true,
      debug: false,
      terminalCarbons: false,
      explicitHydrogens: false,
      overlapSensitivity: 0.42,
      compactDrawing: true,
      fontSizeLarge: 7.5,
      fontSizeSmall: 4.5,
      padding: 10,
      themes: {
        titan: TITAN_MOLECULE_THEME,
      },
    });
  }
  return expandedDrawerSingleton;
}

function renderSmilesToCachedPayload(
  SmilesDrawer: SmilesDrawerModule,
  cacheKey: string,
  smiles: string,
  width: number,
  height: number,
  compact: boolean,
): CachedSvgPayload | null {
  const existing = SVG_STRUCTURE_CACHE.get(cacheKey);
  if (existing) return existing;

  if (typeof document === 'undefined') return null;

  let captured: CachedSvgPayload | null = null;
  try {
    SmilesDrawer.parse(
      smiles,
      (tree) => {
        const tempSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        tempSvg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

        const drawer = getSvgDrawer(SmilesDrawer, compact);
        drawer.draw(tree, tempSvg, 'titan', null, false);
        const viewBox = tempSvg.getAttribute('viewBox') || `0 0 ${width} ${height}`;
        const nodes = Array.from(tempSvg.children).map(
          (el) => el.cloneNode(true) as SVGElement,
        );
        captured = { viewBox, nodes };
        SVG_STRUCTURE_CACHE.set(cacheKey, captured);
      },
      () => {
        captured = null;
      },
    );
  } catch {
    captured = null;
  }

  return captured;
}

function applyPayloadToSvg(svgEl: SVGSVGElement, payload: CachedSvgPayload) {
  svgEl.setAttribute('viewBox', payload.viewBox);
  const cloned = payload.nodes.map((node) => node.cloneNode(true));
  svgEl.replaceChildren(...cloned);
}

export const MolecularStructure = memo(function MolecularStructure({
  nutrientId,
  size = 'mini',
}: MolecularStructureProps) {
  const chem = getNutrientChemistry(nutrientId);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const isExpanded = size === 'expanded';
  const boxW = isExpanded ? 148 : 44;
  const boxH = isExpanded ? 92 : 36;

  useEffect(() => {
    const svgEl = svgRef.current;
    if (chem.isMineral || !chem.smiles || !svgEl) return;

    const cacheKey = `${nutrientId}:${size}:clean`;
    const immediate = SVG_STRUCTURE_CACHE.get(cacheKey);
    if (immediate) {
      applyPayloadToSvg(svgEl, immediate);
      return;
    }

    const signal = { cancelled: false };
    const smiles = chem.smiles;
    let started = false;

    const scheduleRender = () => {
      if (started || signal.cancelled) return;
      started = true;
      void loadSmilesDrawer()
        .then((SmilesDrawer) => {
          if (signal.cancelled) return null;
          return enqueueYieldingTask(
            () => renderSmilesToCachedPayload(SmilesDrawer, cacheKey, smiles, boxW, boxH, !isExpanded),
            signal,
          );
        })
        .then((payload) => {
          if (signal.cancelled || !payload || !svgRef.current) return;
          applyPayloadToSvg(svgRef.current, payload);
        })
        .catch(() => {});
    };

    let observer: IntersectionObserver | null = null;
    if (!isExpanded && typeof IntersectionObserver !== 'undefined') {
      observer = new IntersectionObserver(
        (entries) => {
          if (entries.some((entry) => entry.isIntersecting)) {
            observer?.disconnect();
            observer = null;
            scheduleRender();
          }
        },
        { rootMargin: '160px' },
      );
      observer.observe(svgEl);
    } else {
      scheduleRender();
    }

    return () => {
      signal.cancelled = true;
      observer?.disconnect();
    };
  }, [nutrientId, size, chem.isMineral, chem.smiles, boxW, boxH, isExpanded]);

  if (chem.isMineral) {
    return (
      <div
        className={`flex items-center justify-center font-mono-metric font-semibold text-[var(--titan-accent-strong)] select-none shrink-0 ${
          isExpanded ? 'w-24 h-16 text-lg' : 'w-[44px] h-[36px] text-xs'
        }`}
        role="img"
        aria-label={`Íon ${chem.fullName} (${chem.ionicSymbol})`}
      >
        {chem.ionicSymbol}
      </div>
    );
  }

  return (
    <div
      className={`flex items-center justify-center shrink-0 overflow-hidden ${
        isExpanded ? 'w-[156px] h-[96px] p-1' : 'w-[44px] h-[36px]'
      }`}
      aria-label={`Estrutura molecular 2D de ${chem.compoundName}`}
    >
      <svg
        ref={svgRef}
        width={boxW}
        height={boxH}
        className="w-full h-full block"
        role="img"
        aria-label={`Fórmula estrutural de ${chem.compoundName}`}
      />
    </div>
  );
});
