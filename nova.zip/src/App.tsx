/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Toaster } from 'sonner';
import { MotionConfig } from './shared/motion/titan-motion';
import { AppProviders } from './app-core/providers/AppProviders';
import { AppShell } from './app-core/navigation/AppShell';

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <AppProviders>
        <AppShell />
        <Toaster
          position="top-center"
          theme="dark"
          offset={16}
          mobileOffset={{ top: 'max(12px, env(safe-area-inset-top))' }}
          toastOptions={{
            duration: 2400,
            style: {
              background: 'linear-gradient(160deg, #1B2420, #121815)',
              color: '#F1F0E8',
              border: '1px solid rgba(200, 173, 122, 0.24)',
              borderRadius: '14px',
              boxShadow: '0 16px 36px rgba(0, 0, 0, 0.45), inset 0 1px 0 rgba(241, 240, 232, 0.08)',
              fontSize: '13px',
              fontFamily: 'var(--font-body)',
            },
          }}
        />
      </AppProviders>
    </MotionConfig>
  );
}
