import { create } from 'zustand';
import type { MainDestination, MuscleGroupId, SubViewDestination } from '@/src/shared/types/common';

export type NutritionSection = 'cardapio' | 'receitas' | 'alimentos';

interface NavigationState {
  activeTab: MainDestination;
  subView: SubViewDestination;
  actionSheetOpen: boolean;
  nutritionSection: NutritionSection;
  libraryMuscleFilter: MuscleGroupId | 'all';
  setTab: (tab: MainDestination) => void;
  openNutrition: (section?: NutritionSection) => void;
  setNutritionSection: (section: NutritionSection) => void;
  openExerciseLibrary: (muscle?: MuscleGroupId | 'all') => void;
  setLibraryMuscleFilter: (muscle: MuscleGroupId | 'all') => void;
  openSubView: (view: Exclude<SubViewDestination, null>) => void;
  closeSubView: () => void;
  setActionSheetOpen: (open: boolean) => void;
}

export const useNavigationStore = create<NavigationState>((set) => ({
  activeTab: 'cockpit',
  subView: null,
  actionSheetOpen: false,
  nutritionSection: 'cardapio',
  libraryMuscleFilter: 'all',
  setTab: (tab) => set({ activeTab: tab, subView: null }),
  openNutrition: (section = 'cardapio') =>
    set({
      activeTab: 'cardapio',
      subView: null,
      actionSheetOpen: false,
      nutritionSection: section,
    }),
  setNutritionSection: (section) => set({ nutritionSection: section }),
  openExerciseLibrary: (muscle = 'all') =>
    set({
      subView: 'exercise-library',
      actionSheetOpen: false,
      libraryMuscleFilter: muscle,
    }),
  setLibraryMuscleFilter: (muscle) => set({ libraryMuscleFilter: muscle }),
  openSubView: (view) =>
    set({
      subView: view,
      actionSheetOpen: false,
      ...(view === 'exercise-library' ? { libraryMuscleFilter: 'all' } : {}),
    }),
  closeSubView: () => set({ subView: null }),
  setActionSheetOpen: (open) => set({ actionSheetOpen: open }),
}));
