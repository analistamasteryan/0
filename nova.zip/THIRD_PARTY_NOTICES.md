# Third-party notices

## Exercise data — Yuhonas Free Exercise DB

The exercise catalog includes selected text-only records adapted from [yuhonas/free-exercise-db](https://github.com/yuhonas/free-exercise-db), whose repository identifies its dataset as Unlicense/public-domain material. The current catalog retains the source repository, record ID, source URL and Git blob SHA on each imported record. No upstream images or GIFs are bundled or fetched by TITAN. The Unlicense data declaration is not treated as a blanket license for separately hosted third-party media.

## Exercise repositories reviewed but not bulk-copied

- [hasaneyldrm/exercises-dataset](https://github.com/hasaneyldrm/exercises-dataset): exercise data/text is declared MIT in the repository license. Its image/GIF media is © Gym visual, has separate terms and attribution/resolution requirements, and is not bundled.
- [wger-project/wger](https://github.com/wger-project/wger): application code is AGPL-3.0-or-later. Exercise and ingredient data use Creative Commons licenses per entry; verify each entry and its media separately. No wger application code is copied into TITAN.
- [wrkout/exercises.json](https://github.com/wrkout/exercises.json): repository declares Unlicense; reviewed as an alternate source, but not bulk-copied in this release.
- [exercemus/exercises](https://github.com/exercemus/exercises): per-record author/license metadata must be preserved; consulted for schema design only.
- [kinetic-place/exercises-db](https://github.com/kinetic-place/exercises-db): repository declares MIT; guide structure was used as a design reference. No external YouTube video is bundled.
- [RepDB/exercise-dataset](https://github.com/RepDB/exercise-dataset): README states attribution terms, but GitHub does not identify a recognized SPDX license. No dataset or media is bundled pending further license verification.

## Existing runtime dependencies

See `package.json` for runtime dependencies and each upstream package for its license. V11.6 adds no runtime dependency and copies no third-party application code.

## Human Atlas / BodyParts3D

Human Atlas code is MIT, while the BodyParts3D anatomy geometry is CC BY 4.0. No Human Atlas or BodyParts3D mesh is included in this package.

## TBCA 7.2 food composition extract

The nutrition catalog includes 5,830 eligible and complete records extracted from the user's supplied `Planejamento_Nutricional_Final.xlsx` workbook (sheet `TBCA`). Per-food source codes and source URLs are retained. The workbook identifies the data as TBCA 7.2. Review TBCA's current terms and attribution requirements before redistributing this extracted dataset outside the user's project. The app does not represent unavailable nutrients as zero.

## React ecosystem repository review

- Zustand, Zod, React Hook Form, Recharts, TanStack Query and TanStack Table are MIT-licensed upstream projects. Zustand and Zod are already used by this application; other libraries were evaluated but not added because no current requirement justified extra runtime dependencies.
- SparkyFitness is source-available under a non-commercial-only license. No code from it is copied or bundled.
