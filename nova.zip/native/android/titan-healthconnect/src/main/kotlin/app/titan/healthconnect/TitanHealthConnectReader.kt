package app.titan.healthconnect

import android.content.Context
import androidx.activity.result.contract.ActivityResultContract
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.ExerciseSessionRecord
import androidx.health.connect.client.records.TotalCaloriesBurnedRecord
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant

/** Minimal native adapter. The host app owns UI, permission rationale and JS bridge lifecycle. */
class TitanHealthConnectReader(context: Context) {
    private val client = HealthConnectClient.getOrCreate(context)

    companion object {
        val requiredPermissions = setOf(
            "android.permission.health.READ_EXERCISE",
            "android.permission.health.READ_ACTIVE_CALORIES_BURNED",
            "android.permission.health.READ_TOTAL_CALORIES_BURNED",
        )
        const val backgroundReadPermission = "android.permission.health.READ_HEALTH_DATA_IN_BACKGROUND"
    }

    /** The host Activity launches this contract and handles the returned permission set. */
    fun permissionRequestContract(): ActivityResultContract<Set<String>, Set<String>> =
        PermissionController.createRequestPermissionResultContract()

    suspend fun grantedPermissions(): Set<String> = client.permissionController.getGrantedPermissions()

    suspend fun grantedReadPermissions(): Set<String> =
        client.permissionController.getGrantedPermissions().intersect(requiredPermissions)

    suspend fun readActivityEnergy(start: Instant, end: Instant): List<Map<String, Any?>> {
        require(start < end) { "start must be before end" }
        val range = TimeRangeFilter.between(start, end)
        val active = client.readRecords(
            ReadRecordsRequest(
                recordType = ActiveCaloriesBurnedRecord::class,
                timeRangeFilter = range,
            ),
        ).records.map { record ->
            mapOf(
                "recordType" to "ActiveCaloriesBurnedRecord",
                "id" to record.metadata.id,
                "sourceRecordId" to record.metadata.id,
                "startTime" to record.startTime.toString(),
                "endTime" to record.endTime.toString(),
                "energyKcal" to record.energy.inKilocalories,
                "updatedAt" to record.metadata.lastModifiedTime.toString(),
            )
        }
        val total = client.readRecords(
            ReadRecordsRequest(
                recordType = TotalCaloriesBurnedRecord::class,
                timeRangeFilter = range,
            ),
        ).records.map { record ->
            mapOf(
                "recordType" to "TotalCaloriesBurnedRecord",
                "id" to record.metadata.id,
                "sourceRecordId" to record.metadata.id,
                "startTime" to record.startTime.toString(),
                "endTime" to record.endTime.toString(),
                "energyKcal" to record.energy.inKilocalories,
                "updatedAt" to record.metadata.lastModifiedTime.toString(),
            )
        }
        val sessions = client.readRecords(
            ReadRecordsRequest(
                recordType = ExerciseSessionRecord::class,
                timeRangeFilter = range,
            ),
        ).records.map { record ->
            mapOf(
                "recordType" to "ExerciseSessionRecord",
                "id" to record.metadata.id,
                "sourceRecordId" to record.metadata.id,
                "startTime" to record.startTime.toString(),
                "endTime" to record.endTime.toString(),
                "activityCode" to record.exerciseType.toString(),
                "updatedAt" to record.metadata.lastModifiedTime.toString(),
            )
        }
        return active + total + sessions
    }
}
