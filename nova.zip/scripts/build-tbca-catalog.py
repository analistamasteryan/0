#!/usr/bin/env python3
"""Build the compact runtime TBCA catalog from the user's final nutrition workbook.

Requires: python -m pip install openpyxl
Example:
  python scripts/build-tbca-catalog.py --input Planejamento_Nutricional_Final.xlsx
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

NUTRIENT_COLUMNS = [
    'Vitamina A (RAE) (mcg)', 'Vitamina C (mg)', 'Vitamina D (mcg)',
    'Alfa-tocoferol (Vitamina E) (mg)', 'Tiamina (mg)', 'Riboflavina (mg)',
    'Niacina (mg)', 'Vitamina B6 (mg)', 'Equivalente de folato (mcg)',
    'Vitamina B12 (mcg)', 'Cálcio (mg)', 'Cobre (mg)', 'Ferro (mg)',
    'Fósforo (mg)', 'Magnésio (mg)', 'Manganês (mg)', 'Potássio (mg)',
    'Selênio (mcg)', 'Sódio (mg)', 'Zinco (mg)',
]
MACRO_COLUMNS = [
    'Energia (kcal)', 'Proteína (g)', 'Carboidrato total (g)', 'Lipídios (g)',
    'Fibra alimentar (g)', 'Ácidos graxos saturados (g)', 'Colesterol (mg)', 'Sódio (mg)',
]


def numeric(value: Any) -> float | None:
    return float(value) if isinstance(value, (int, float)) else None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help='Path to Planejamento_Nutricional_Final.xlsx')
    parser.add_argument('--output', default='src/domains/nutrition/data/sources/tbca-catalog.compact.json')
    parser.add_argument('--sheet', default='TBCA')
    parser.add_argument('--manifest-output', default='src/domains/nutrition/data/sources/tbca-catalog.manifest.json')
    args = parser.parse_args()

    try:
        import openpyxl
    except ImportError as exc:
        raise SystemExit('Install openpyxl first: python -m pip install openpyxl') from exc

    workbook = openpyxl.load_workbook(args.input, data_only=True, read_only=True)
    if args.sheet not in workbook.sheetnames:
        raise SystemExit(f'Sheet {args.sheet!r} not found. Available: {workbook.sheetnames}')
    sheet = workbook[args.sheet]
    headers = [cell.value for cell in next(sheet.iter_rows(min_row=1, max_row=1))]
    index = {header: i for i, header in enumerate(headers) if header is not None}
    required = [
        'codigo_tbca', 'nome_alimento_original', 'Elegivel_Calculo', 'Status_Dados',
        'grupo_alimento', 'tipo_alimento', 'estado_alimento', 'metodo_preparo', 'detail_url',
        *MACRO_COLUMNS, *NUTRIENT_COLUMNS,
    ]
    missing = [column for column in required if column not in index]
    if missing:
        raise SystemExit(f'Missing required TBCA columns: {missing}')

    foods: list[list[Any]] = []
    codes: set[str] = set()
    for row in sheet.iter_rows(min_row=2, values_only=True):
        code = row[index['codigo_tbca']]
        if not code or row[index['Elegivel_Calculo']] != 'SIM' or row[index['Status_Dados']] != 'OK':
            continue
        code = str(code)
        if code in codes:
            raise SystemExit(f'Duplicate TBCA source code: {code}')
        codes.add(code)

        macro_values = [numeric(row[index[column]]) for column in MACRO_COLUMNS]
        kcal, protein, carbs, fat, fiber, saturated_fat, cholesterol, sodium = macro_values
        if any(value is None or value < 0 for value in (kcal, protein, carbs, fat)):
            raise SystemExit(f'Eligible row {code} has incomplete energy/macronutrient data')
        nutrient_values = [numeric(row[index[column]]) for column in NUTRIENT_COLUMNS]
        foods.append([
            code,
            row[index['nome_alimento_original']],
            row[index['grupo_alimento']],
            row[index['tipo_alimento']],
            row[index['estado_alimento']],
            row[index['metodo_preparo']],
            row[index['detail_url']],
            [kcal, protein, carbs, fat, 100, fiber, saturated_fat, cholesterol, sodium],
            nutrient_values,
        ])

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    serialized = json.dumps(foods, ensure_ascii=False, separators=(',', ':'))
    output.write_text(serialized, encoding='utf-8')
    manifest = {
        'schema_version': 1,
        'source_filename': Path(args.input).name,
        'source_sha256': hashlib.sha256(Path(args.input).read_bytes()).hexdigest(),
        'source_version': 'TBCA 7.2',
        'source_sheet': args.sheet,
        'selection_rule': "Elegivel_Calculo == 'SIM' and Status_Dados == 'OK'",
        'record_count': len(foods),
        'basis_grams': 100,
        'runtime_file': output.name,
        'runtime_file_sha256': hashlib.sha256(serialized.encode('utf-8')).hexdigest(),
        'nutrients_from_source': NUTRIENT_COLUMNS,
        'nutrients_not_published_in_this_sheet': ['vitamin_k', 'vitamin_b5', 'vitamin_b7'],
        'missing_numeric_values': 'null/not_analyzed; numeric zero remains quantified zero',
    }
    manifest_path = Path(args.manifest_output)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f'Generated {len(foods):,} eligible TBCA records: {output} ({output.stat().st_size:,} bytes)')
    print(f'Generated provenance manifest: {manifest_path}')
    print('Blank nutrient values are preserved as null; numeric zero values remain zero.')


if __name__ == '__main__':
    main()
