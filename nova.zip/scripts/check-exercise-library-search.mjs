import assert from 'node:assert/strict';
import { filterExerciseCatalog, normalizeExerciseSearchText } from '../src/domains/exercise-library/application/filter-exercises.ts';
import { ExerciseRegistry } from '../src/domains/exercise-library/application/exercise-library-public.ts';

assert.equal(normalizeExerciseSearchText('ELEVAÇÃO LATERAL'), 'elevacao lateral');
assert.equal(filterExerciseCatalog('elevacao lateral').some((item) => item.slug === 'elevacao-lateral'), true);
assert.equal(filterExerciseCatalog('BÍCEPS').some((item) => item.slug === 'rosca-direta-barra'), true);
assert.equal(filterExerciseCatalog('deltoide posterior').some((item) => item.slug === 'remada-deltoide-posterior'), true);
assert.equal(filterExerciseCatalog('antebraços').some((item) => item.slug === 'rosca-direta-barra'), true);
assert.equal(filterExerciseCatalog('barra').length > 0, true);
assert.equal(filterExerciseCatalog('peito').some((item) => item.muscles.primary.includes('pectoralis') || item.muscles.secondary.includes('pectoralis')), true);
assert.equal(filterExerciseCatalog('panturrilha').some((item) => item.muscles.primary.includes('calves') || item.muscles.secondary.includes('calves')), true);
assert.equal(filterExerciseCatalog('pushup').some((item) => item.slug === 'flexao-de-bracos'), true);
assert.equal(filterExerciseCatalog('coluna neutra').some((item) => item.slug === 'remada-curvada'), true);
assert.equal(filterExerciseCatalog('erro comum').length, 0);
assert.equal(filterExerciseCatalog('termo que nao existe').length, 0);
assert.equal(filterExerciseCatalog('  ').length, 32);

assert.equal(filterExerciseCatalog('', { muscle: 'latissimus' }).every((item) => item.muscles.primary.includes('latissimus') || item.muscles.secondary.includes('latissimus') || item.stabilizers?.includes('latissimus')), true);
assert.equal(filterExerciseCatalog('', { equipment: 'Polia alta' }).every((item) => item.equipment === 'Polia alta'), true);
assert.equal(filterExerciseCatalog('', { level: 'advanced' }).every((item) => item.level === 'advanced'), true);
assert.equal(filterExerciseCatalog('', { category: 'core' }).every((item) => item.category === 'core'), true);
assert.equal(filterExerciseCatalog('', { mechanic: 'isometric' }).every((item) => item.mechanic === 'isometric'), true);
assert.equal(ExerciseRegistry.search('supino').length, filterExerciseCatalog('supino').length);
assert.equal(ExerciseRegistry.forMuscle('pectoralis').length > 0, true);
console.log('Exercise library search/filter tests passed (accent-insensitive text, guides, aliases, equipment, muscle, level, category and mechanic).');
