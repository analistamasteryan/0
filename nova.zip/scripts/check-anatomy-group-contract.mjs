import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const read = (path) => readFileSync(new URL(path, import.meta.url), 'utf8');
const registry = read('../src/domains/anatomy/mapping/muscle-registry.ts');
const identifiers = read('../src/domains/anatomy/mapping/anatomy-identifiers.ts');
const builder = read('../src/domains/anatomy/engine/scene/build-anatomy-body.ts');
const viewport = read('../src/domains/anatomy/components/AnatomyViewport.tsx');
const picker = read('../src/domains/anatomy/engine/picking/muscle-picking.ts');
const shader = read('../src/domains/anatomy/engine/shaders/anatomy-material-shader.ts');
const store = read('../src/domains/anatomy/state/anatomy.store.ts');

const expected = [
  'pectoralis', 'anterior_deltoid', 'lateral_deltoid', 'posterior_deltoid',
  'biceps', 'triceps', 'forearms', 'abdominals', 'latissimus', 'trapezius',
  'glutes', 'quadriceps', 'hamstrings', 'calves',
];
const registryIds = [...registry.matchAll(/^  ([a-z_]+): \{/gm)].map((match) => match[1]);
assert.deepEqual(registryIds, expected, 'the workout muscle registry must retain exactly the 14 stable IDs');
for (const id of expected) {
  assert.match(identifiers, new RegExp(`\\b${id}:`), `shader index mapping missing ${id}`);
  if (id !== 'abdominals') {
    assert.ok(builder.includes(`'${id}'`), `body geometry has no reference for ${id}`);
  }
}
assert.match(builder, /attachMuscleIdAttribute\(geo, MUSCLE_ID_TO_SHADER_INDEX\.abdominals, numericSide\)/);
assert.match(builder, /muscleEntries\.push\(\{ muscleId: 'abdominals'/);
assert.match(builder, /\(\[-1, 1\] as const\)\.forEach/);
assert.match(builder, /const torsoAndHeadSlices/);
assert.match(builder, /const skullGeo = new THREE\.SphereGeometry/);
assert.match(builder, /trapezius/);
assert.match(viewport, /MUSCLE_LIST\.map/);
assert.match(picker, /MUSCLE_SHADER_INDEX_TO_ID\[numericId\]/);
assert.match(picker, /aMuscleSide/);
assert.match(picker, /occlusionTargets/);
assert.match(builder, /occlusionMeshes\.push\(shellMesh\)/);
assert.match(builder, /occlusionMeshes,/);
assert.doesNotMatch(shader + store + identifiers, /uMorphFactor|morphFactor/, 'the decorative pseudo-morph control must not be mistaken for a real body-shape model.');
console.log('Anatomy group contract tests passed (14 training IDs, geometry coverage, head retained, and picker/list linkage).');
