import assert from 'node:assert/strict';
import { isOccludedByBodySurface } from '../src/domains/anatomy/engine/picking/picking-occlusion.ts';

assert.equal(isOccludedByBodySurface(1, 1.01), true, 'front body shell blocks a rear muscle');
assert.equal(isOccludedByBodySurface(1.01, 1), false, 'raised muscle relief remains selectable');
assert.equal(isOccludedByBodySurface(1, 1.001), false, 'small surface tolerance avoids edge flicker');
assert.equal(isOccludedByBodySurface(Number.POSITIVE_INFINITY, 1), false, 'no occluder is not a block');
assert.equal(isOccludedByBodySurface(1, Number.POSITIVE_INFINITY), false, 'missing muscle hit is not a block');
assert.equal(isOccludedByBodySurface(1, 1.1, -1), false, 'invalid tolerance is rejected');
console.log('Muscle picking occlusion tests passed (front/back ordering, relief tolerance and invalid inputs).');
