import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';

const path = new URL('../src/domains/nutrition/data/sources/tbca-catalog.compact.json', import.meta.url);
const catalogText = readFileSync(path, 'utf8');
const rows = JSON.parse(catalogText);
const manifestPath = new URL('../src/domains/nutrition/data/sources/tbca-catalog.manifest.json', import.meta.url);
const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
assert.equal(manifest.record_count, rows.length);
assert.equal(manifest.runtime_file_sha256, createHash('sha256').update(catalogText).digest('hex'));
assert.equal(manifest.source_version, 'TBCA 7.2');
assert.equal(rows.length, 5830, 'Only the 5,830 eligible, complete TBCA records should be bundled');
const ids = new Set();
for (const row of rows) {
  assert.equal(row.length, 9, 'Compact row schema must remain stable');
  assert.ok(row[0] && row[1], 'Every food needs a source code and name');
  assert.ok(!ids.has(row[0]), `Duplicate TBCA code ${row[0]}`);
  ids.add(row[0]);
  assert.equal(row[7].length, 9, 'Macro vector schema');
  assert.equal(row[7][4], 100, 'TBCA basis must be 100 g');
  assert.ok(row[7].slice(0, 4).every((value) => Number.isFinite(value) && value >= 0));
  assert.equal(row[8].length, 20, 'Micronutrient vector schema');
  assert.ok(row[8].every((value) => value === null || (Number.isFinite(value) && value >= 0)));
}
const avocado = rows.find((row) => row[0] === 'BRC0001C');
assert.ok(avocado, 'Known TBCA reference food must exist');
assert.equal(avocado[7][0], 76);
assert.equal(avocado[8][2], 0, 'A true analytical zero must remain zero');
assert.ok(rows.some((row) => row[8].some((value) => value === null)), 'Missing nutrient values must remain null, not zero');
console.log(`PASS TBCA catalog: ${rows.length} eligible unique foods, 100 g basis, null/zero semantics preserved`);
