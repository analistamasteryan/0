import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import {
  computeBodyIdentitySignature,
  createDefaultDualBodyInput,
  deriveDualBodyInput,
} from '../src/domains/anatomy/domain/body-identity.ts';
import { getAnatomicalSubstructuresForGroup } from '../src/domains/anatomy/mapping/anatomical-structure-map.ts';
import { createAnatomyMaterials } from '../src/domains/anatomy/engine/materials/anatomy-materials.ts';
import { buildAnatomyBody } from '../src/domains/anatomy/engine/scene/build-anatomy-body.ts';
import { useAnatomyStore } from '../src/domains/anatomy/state/anatomy.store.ts';
import { registerWorkoutSet } from '../src/domains/training/application/register-set.ts';
import { startWorkoutSession } from '../src/domains/training/application/start-workout.ts';
import {
  computePlanMuscleHighlights,
  focusWorkoutExercise,
  useTrainingSessionStore,
} from '../src/domains/training/application/training-public.ts';

// 1. Calibration provenance & non-uniform GoalBody phenotype
const estimated = deriveDualBodyInput({
  sex: 'male',
  goal: 'gain_muscle',
  currentWeightKg: 78,
  targetWeightKg: 84,
  heightCm: 178,
  profileConfigured: false,
  hasObservedMeasurements: false,
});
assert.equal(estimated.current.calibrationStatus, 'estimated');
assert.ok(estimated.goal.phenotype.muscle > estimated.current.phenotype.muscle);
assert.ok(estimated.goal.localChanges.shoulderWidth > estimated.current.localChanges.shoulderWidth);
assert.ok(estimated.goal.regionalMorphs.pectoralis > estimated.current.regionalMorphs.pectoralis);

const calibrated = deriveDualBodyInput({
  sex: 'female',
  goal: 'recomposition',
  currentWeightKg: 64,
  targetWeightKg: 63,
  heightCm: 166,
  waistCm: 71,
  bodyFatPercent: 22,
  profileConfigured: true,
  hasObservedMeasurements: true,
});
assert.equal(calibrated.current.calibrationStatus, 'calibrated');
assert.notEqual(
  computeBodyIdentitySignature(estimated.current),
  computeBodyIdentitySignature(calibrated.current),
);

// 2. Real dual 3D geometry verification: exact overlay at (0,0,0), shared topology, non-uniform regional volume gain
const materials = createAnatomyMaterials(1);
try {
  const dual = createDefaultDualBodyInput();
  const currentRig = buildAnatomyBody(materials, { role: 'current', identity: dual.current, lod: 'mid' });
  const goalRig = buildAnatomyBody(materials, { role: 'goal', identity: dual.goal, lod: 'mid' });

  assert.deepEqual(currentRig.root.position.toArray(), [0, 0, 0]);
  assert.deepEqual(goalRig.root.position.toArray(), [0, 0, 0]);
  assert.equal(currentRig.muscleEntries.length, goalRig.muscleEntries.length);

  const currMuscleMesh = currentRig.superficialGroup.children[0];
  const goalMuscleMesh = goalRig.superficialGroup.children[0];
  assert.ok(currMuscleMesh && 'geometry' in currMuscleMesh);
  assert.ok(goalMuscleMesh && 'geometry' in goalMuscleMesh);

  const currPos = currMuscleMesh.geometry.getAttribute('position');
  const goalPos = goalMuscleMesh.geometry.getAttribute('position');
  const currNorm = currMuscleMesh.geometry.getAttribute('normal');
  const goalNorm = goalMuscleMesh.geometry.getAttribute('normal');
  assert.equal(currPos.count, goalPos.count, 'current and goal topologies must stay 1:1 aligned');
  assert.ok(currNorm && goalNorm, 'recomputed normals must exist on both bodies');

  // Verify GoalBody is NOT a uniform scale of CurrentBody by comparing radial ratios at chest vs waist/ankle
  let chestRatioSum = 0;
  let chestCount = 0;
  let ankleRatioSum = 0;
  let ankleCount = 0;
  for (let i = 0; i < currPos.count; i += 1) {
    const y = currPos.getY(i);
    const rCurr = Math.hypot(currPos.getX(i), currPos.getZ(i));
    const rGoal = Math.hypot(goalPos.getX(i), goalPos.getZ(i));
    if (rCurr < 0.02) continue;
    const ratio = rGoal / rCurr;
    if (y >= 1.24 && y <= 1.38) {
      chestRatioSum += ratio;
      chestCount += 1;
    } else if (y >= 0.08 && y <= 0.16) {
      ankleRatioSum += ratio;
      ankleCount += 1;
    }
  }
  assert.ok(chestCount > 20 && ankleCount > 10);
  const avgChestRatio = chestRatioSum / chestCount;
  const avgAnkleRatio = ankleRatioSum / ankleCount;
  assert.ok(
    avgChestRatio > avgAnkleRatio + 0.03,
    `Goal chest/torso hypertrophy ratio (${avgChestRatio.toFixed(3)}) must significantly exceed anchored ankle ratio (${avgAnkleRatio.toFixed(3)})`,
  );

  currentRig.dispose();
  goalRig.dispose();
} finally {
  materials.dispose();
}

// 3. Independent Goal regional morph update leaves Current untouched
{
  const store = useAnatomyStore.getState();
  const prevCurrentSig = computeBodyIdentitySignature(store.dualBody.current);
  store.updateGoalRegionalMorph('pectoralis', 0.98);
  const after = useAnatomyStore.getState();
  assert.equal(computeBodyIdentitySignature(after.dualBody.current), prevCurrentSig);
  assert.equal(after.dualBody.goal.regionalMorphs.pectoralis, 0.98);
}

// 4. Anatomical substructure mapping returns substructures for all 14 canonical IDs
assert.ok(getAnatomicalSubstructuresForGroup('pectoralis').length >= 2);
assert.ok(getAnatomicalSubstructuresForGroup('quadriceps').length >= 1);

// 5. Full workout day muscle aggregation across startWorkoutSession, focusWorkoutExercise, registerWorkoutSet
{
  const training = useTrainingSessionStore.getState();
  const plan = training.plans[0];
  assert.ok(plan && plan.exercises.length >= 2);
  const expectedUnion = computePlanMuscleHighlights(plan);

  startWorkoutSession(plan.id);
  assert.deepEqual(useAnatomyStore.getState().workoutHighlights, expectedUnion);

  const secondEx = plan.exercises[1];
  assert.ok(secondEx);
  focusWorkoutExercise(secondEx.id);
  assert.deepEqual(useAnatomyStore.getState().workoutHighlights, expectedUnion);

  const pendingSet = secondEx.sets.find((s) => !s.completed);
  if (pendingSet) {
    const res = registerWorkoutSet(secondEx.id, pendingSet.id, 60, 10, 2);
    assert.equal(res.ok, true);
    assert.deepEqual(useAnatomyStore.getState().workoutHighlights, expectedUnion);
  }
}

// 6. Lighting from circle below and behind + dual-body compositor contract
{
  const rendererSrc = readFileSync(new URL('../src/domains/anatomy/engine/renderer/anatomy-renderer.ts', import.meta.url), 'utf8');
  assert.match(rendererSrc, /rearEmitterCircle/);
  assert.match(rendererSrc, /rearBelowLight/);
  assert.match(rendererSrc, /DualBodyCompositor/);
  assert.match(rendererSrc, /rearEmitterCircle\.position\.set\(0,\s*0\.004,\s*-0\.34\)/);
  assert.match(rendererSrc, /rearBelowLight\.position\.set\(0,\s*0\.14,\s*-0\.65\)/);
  assert.match(rendererSrc, /rearBelowLight\.target\.position\.set\(0,\s*1\.05,\s*0\)/);
}

console.log('Dual-body anatomy tests passed (shared-topology non-uniform hypertrophy, calibration status, workout union, rear-below circle lighting).');
