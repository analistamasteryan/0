# V11.14 — motor de cálculos e evidência

- Ampliada a cobertura de testes e validações em runtime para os oito ramos de EER adulto NASEM 2023, cuja implementação já existia na base V11.12.
- Corrigidas referências de magnésio com a divisão etária 19–30 / 31–50 anos, mantendo compatibilidade com IDs antigos.
- Ajustada calibração adaptativa: média de ingestão diária por dias únicos, deduplicação da mesma data e rejeição de resultados implausíveis em vez de truncamento.
- Adicionada coleta opcional de RIR 0–5 por série, com persistência e histórico; RIR da sessão anterior não é pré-preenchido na próxima.
- Estimativa de 1RM exibe se o RIR foi informado ou se o método presumiu falha.
- RFM (já existente na base) agora valida a faixa adulta quando a idade está disponível; tela Evolução protege dados legados inválidos.
- Auditada e documentada a cobertura efetiva de nutrientes dos 5.830 alimentos TBCA e as lacunas de vitamina K, B5 e B7. A taxa de suor e a hidratação por sessão já existiam na base e foram revalidadas, não reconstruídas nesta revisão.
- Pesquisa e backlog: `docs/REPOSITORY_RESEARCH_V11_14.md`, `docs/CALCULATION_ENGINE_V11_14.md`, `docs/IMPLEMENTATION_PRIORITY_V11_14.md`.
