# Repository research — V11.12

Snapshot consultado em 23/11/2026. Stars são sinais de adoção, não prova de adequação ou qualidade. Valores arredondados, com ranking público atualizado em 22/11/2026.

| Finalidade | Repositórios de referência | Decisão para TITAN |
|---|---|---|
| Browser E2E | [Playwright](https://github.com/microsoft/playwright) (~100.8k); [Puppeteer](https://github.com/puppeteer/puppeteer) (~95.9k) | Playwright preferido por cobrir Chromium, Firefox e WebKit com runner integrado. |
| Componentes React | [Storybook](https://github.com/storybookjs/storybook) (~91.7k); [React Testing Library](https://github.com/testing-library/react-testing-library) (~19.7k) | RTL preferido para testar interação real de componentes; Storybook é opção de documentação/isolamento, não substituto de E2E. |
| Unit/integration | [Jest](https://github.com/jestjs/jest) (~45.5k); [Vitest](https://github.com/vitest-dev/vitest) | Vitest preferido pela integração nativa com Vite; Jest tem mais estrelas, mas duplicaria configuração no stack atual. |
| Network mocking | [MSW](https://github.com/mswjs/msw) | Adotar quando houver contratos HTTP reais; hoje não há API de produto definida. |
| Accessibility | [axe-core](https://github.com/dequelabs/axe-core) (~7.8k); [Pa11y](https://github.com/pa11y/pa11y) (~4.5k); [Lighthouse](https://github.com/GoogleChrome/lighthouse) (~31.2k) | axe-core em testes automatizados, Lighthouse para auditoria de performance/acessibilidade em browser. Ferramentas automatizadas não substituem teclado/leitor de tela. |
| Navigation | [React Router](https://github.com/remix-run/react-router) | Preferido para URL, histórico e deep links; integração aguarda dependência e lockfile reproduzível. |
| Server state | [TanStack Query](https://github.com/TanStack/query) | Aguardar endpoint/consumidor remoto. Não aplicar a estado local Zustand. |
| Forms | [React Hook Form](https://github.com/react-hook-form/react-hook-form) + [Zod](https://github.com/colinhacks/zod) | Manter formulários pequenos sem biblioteca adicional; usar em formulários longos e schemas compartilhados. |
| Offline database | [Dexie](https://github.com/dexie/Dexie.js) | Não migrar enquanto limites de persistência local e backup síncrono atenderem; migração exige desenho de backup async. |

## Evidência de ranking

A lista pública de repositórios de teste atualizada em 22/11/2026 posiciona `nodebestpractices` em 105.8k, Playwright 100.8k, Puppeteer 95.9k, Storybook 91.7k, Jest 45.5k e React Testing Library 19.7k. Fonte: https://maal.top/charts/github-testing/. O ranking geral TypeScript também registra Playwright em ~100.8k: https://pato.is-a.dev/top100/languages/typescript.html.

## Regra de adoção

1. Escolher uma ferramenta por responsabilidade; evitar concorrentes instalados em paralelo.
2. Validar licença, release/atividade, compatibilidade com Vite 8/React 19 e manutenção antes de instalar.
3. Não alterar `bun.lock` manualmente. Instalação deve ser feita com Bun e conferida por `bun install --frozen-lockfile`.
4. A indisponibilidade DNS do npm nesta execução bloqueou a instalação. Por isso esta versão adiciona hardening de domínio sem alterar dependências.
