# TITAN Anatomy V.MAX V11.1 — revisão e validação

**Base:** pacote V11 `TITAN_HYDRATION_VMAX_V11_HOLOGRAM.zip`, construído sobre o projeto V10 existente.  
**Escopo:** melhorar a renderização corporal e o holograma sem reconstruir a aplicação, trocar de engine ou alterar o contrato de seleção.

## Contratos preservados

- Figura corporal completa permanece visível: cabeça, pescoço, tronco, braços, mãos, pernas e pés.
- O mapa funcional do treino continua contendo exatamente 14 IDs: `pectoralis`, `anterior_deltoid`, `lateral_deltoid`, `posterior_deltoid`, `biceps`, `triceps`, `forearms`, `abdominals`, `latissimus`, `trapezius`, `glutes`, `quadriceps`, `hamstrings`, `calves`.
- Permanecem `aMuscleId`, `aMuscleSide`, máscaras inteiras de músculos, lateralidade, seleção manual, realce primário/secundário, vistas e camadas existentes.
- Nenhuma malha de terceiros, textura externa, pacote de pós-processamento ou engine foi adicionado.

## Auditoria e correções adicionais da revisão V11.1

### 1. Costura UV de superfícies loftadas

- A topologia é construída por `createLoftTopology()` e mantém a duplicação U=0/U=1 em superfícies fechadas.
- As tampas têm seus dois vértices centrais efetivamente preenchidos por `writeLoftCapPositions()`. Isso evita deixar os índices das tampas apontando para a origem.
- `averageClosedLoftSeamNormals()` faz a média normalizada dos dois lados da costura; a função foi extraída para teste direto.
- O merge preserva UVs somente no batch muscular, que usa o normal map. Shell, plano profundo e esqueleto continuam eliminando UVs não utilizados para reduzir memória e largura de banda.

### 2. Normal map muscular

- `createMuscleFiberNormalPixels()` gera uma textura tangente 256×256 determinística em memória, sem buscar assets ou malhas externas.
- A textura só é aplicada ao material muscular; usa `NoColorSpace`, repetição e mipmaps.
- A intensidade é moderada (`normalScale` 0.16 × 0.055) para sugerir fibra sem criar estrias plásticas.
- O `DataTexture` é liberado com o material.

### 3. Holograma e contrato de shader

- O holograma usa o `MeshStandardMaterial` já existente: Fresnel, scanlines e emissão teal/champagne. O sweep existente reforça a seleção.
- O toggle Holograma/Natural alimenta `uHologramMode`; os cálculos específicos de Fresnel/scanline/emissão ficam condicionados a esse uniform.
- Não há `EffectComposer`, bloom seletivo, DoF, segundo render target ou nova passagem de pós-processamento.
- A coordenada Y é calculada antes de `project_vertex` por `(modelMatrix * vec4(transformed, 1.0)).y`. Não se referencia `worldPosition`, que no shader do Three.js só é declarada quando determinados recursos de ambiente/sombra/transmissão são definidos.
- `replaceShaderChunk()` exige exatamente uma ocorrência de cada chunk-alvo e lança erro se o contrato de shader mudar, evitando substituições silenciosas incompletas.

## Repositórios de referência e decisão

Estrelas consultadas no GitHub em 22/11/2026 (contagens variam). Nenhum código ou asset foi copiado sem necessidade; as referências orientaram a implementação já integrada ao stack existente.

| Repositório | Estrelas aproximadas | Licença do código | Uso / decisão |
|---|---:|---|---|
| [Three.js](https://github.com/mrdoob/three.js) | 119,2k | MIT | Engine mantida; shader chunks oficiais, `MeshStandardMaterial`, `DataTexture`, UVs, PMREM e lifecycle. |
| [ektogamat/threejs-holographic-material](https://github.com/ektogamat/threejs-holographic-material) | 256 | MIT | Referência para Fresnel, scanlines e emissão holográfica sem post-processing obrigatório. |
| [ektogamat/threejs-vanilla-holographic-material](https://github.com/ektogamat/threejs-vanilla-holographic-material) | 115 | MIT | Referência de integração vanilla Three.js e uniforms. |
| [meshoptimizer](https://github.com/zeux/meshoptimizer) | 8,9k | MIT | Candidato para futura otimização offline se o projeto passar a distribuir GLB estático. Não necessário na geometria procedural atual. |
| [Human Atlas](https://github.com/ashemag/human-atlas) | 4,6k | MIT para código; dados BodyParts3D CC BY 4.0 | Comparação de arquitetura de atlas e seleção. Não importado: requer mapear 402 componentes musculares para 14 IDs TITAN e validar lateralidade, anatomia, oclusão e custo. |
| [Google Filament](https://github.com/google/filament) | 20,8k | Apache-2.0 | Benchmark arquitetural para PBR mobile nativo. Não adotado: trocar engine exigiria portar renderer/integração e não é uma melhoria aditiva do código existente. |

A CC BY 4.0 do dataset BodyParts3D permite uso comercial mediante atribuição e indicação das modificações, mas não é uma licença de “malha sem obrigações”. A V11.1 não distribui nem depende desses dados.

## Testes executados nesta revisão

### Aprovados neste workspace

| Teste | Resultado | O que cobre |
|---|---|---|
| `node scripts/check-fluid-shaders.mjs` | PASS | Contratos estáticos dos shaders fluidos e caminho de alocação. |
| `node scripts/check-cockpit-visual-semantics.mjs` | PASS | Estados de cockpit, precisão, ARIA e canvas. |
| `node scripts/check-titan-design-system.mjs` | PASS | Tokens, contraste e semântica de componentes. |
| `node scripts/check-anatomy-v9.mjs` | PASS | Gate WebGL2, lazy init, PMREM, orçamento de pixels, batching e lifecycle. |
| `node scripts/check-materials-v10.mjs` | PASS | PBR e orçamentos visuais da V10, sem adicionar `MeshPhysicalMaterial` caro. |
| `node scripts/check-anatomy-vmax-v11.mjs` | PASS | UVs, buffers, material, shader, modo holográfico e 14 IDs. |
| `node scripts/check-anatomy-group-contract.mjs` | PASS | Os 14 IDs, presença de geometria, cabeça preservada, lista e picking. |
| Teste direto de `anatomy-identifiers.ts` com Node 22 type stripping | PASS | 14 IDs únicos, mapa reverso, máscara de 14 bits e idempotência de duplicatas. |
| `node --experimental-strip-types scripts/check-anatomy-geometry.mjs` | PASS | UV seam, caps, malhas abertas, índices 16/32 bits e normais médias na costura. |
| `node --experimental-strip-types scripts/check-muscle-normal-map.mjs` | PASS | Dimensão, variação tangente, valores limitados e parâmetros inválidos. |
| `node --experimental-strip-types scripts/check-anatomy-shader-injection.mjs` | PASS | Injeção para os dois materiais, uniforms, `modelMatrix` e falha segura para chunks ausentes/duplicados. |
| TypeScript `transpileModule` (TS global 5.8.3) | PASS sintático | Os oito arquivos TS/TSX alterados são sintaticamente válidos. |
| `tsc --noEmit --strict ...` nos dois módulos puros | PASS | Tipos e contratos de `loft-topology.ts` e `muscle-fiber-normal.ts`. |
| `unzip -t` no pacote final | PASS | Integridade do ZIP gerado. |

### Não executados / bloqueados pelo ambiente

| Teste | Estado | Motivo |
|---|---|---|
| `npm test` | BLOCKED | `tsx: not found`; `node_modules` não existe. |
| `npm run lint` no projeto inteiro | BLOCKED | `@types/vite/client` ausente porque as dependências não foram instaladas. |
| `npm run build` | BLOCKED | `vite: not found`. |
| Shader GLSL compilado no Three.js real/WebGL2 | NOT RUN | Three.js não está instalado neste workspace e não foi possível criar o ambiente de integração real. Os testes de injeção usam mocks do objeto shader. |
| Captura visual, FPS, temperatura e memória em iOS/Android | NOT RUN | Exigem build/runtime e aparelhos físicos. |

A tentativa de instalação não conseguiu completar porque o ambiente não resolveu o host do registry npm (`registry.npmjs.org`). O ZIP mantém o `package.json` e `bun.lock` originais, sem incluir `node_modules` ou dependências geradas. Portanto, esta revisão não afirma build integral nem “100% funcional” validado em dispositivos. O que foi efetivamente testado está discriminado acima.

## Como completar a validação fora deste ambiente

Com Node.js 22+ e acesso ao registry, na raiz do projeto:

```bash
npm install
npm test
npm run lint
npm run build
```

Depois executar o viewer em Chromium/Safari/Android/iOS, registrar erro de shader/console, capturas frontal/posterior/lateral, toques nos 14 grupos, alternância Natural/Holograma, seleção de lado, mudanças de camada, perda/restauração do contexto, reduced motion, frame time, temperatura e pico de memória.

## Limites visuais

A V11.1 melhora a leitura do volume, fibra e apresentação holográfica, mas a geometria corporal e os grupos musculares continuam sendo a escultura procedural da base. O normal map não cria anatomia profunda nem substitui uma malha escultural de alta fidelidade. Não prometer fotorealismo extremo, valores de 60 FPS ou uma nota visual sem teste em GPU/dispositivo real.
