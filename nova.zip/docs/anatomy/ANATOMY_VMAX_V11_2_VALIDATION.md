# TITAN Anatomy V.MAX V11.2 — relatório de revisão e validação

**Base:** `TITAN_HYDRATION_VMAX_V11_1_HOLOGRAM_REVIEWED.zip`  
**Escopo:** revisão do corpo 3D e da viewport de anatomia; sem recomeçar o projeto, sem troca de engine, sem remover partes do boneco e sem ampliar o catálogo funcional além dos 14 grupos musculares de treino.

## 1. Resultado da revisão

A V11.2 é uma continuação aditiva sobre a V11.1. A revisão encontrou e corrigiu um defeito de contrato TypeScript nas injeções de shader que os verificadores anteriores não cobriam: a função `replaceShaderChunk` exige quatro argumentos (`source`, `chunkName`, `replacement`, `stage`), mas as duas primeiras chamadas do vertex shader ainda tinham apenas três. Agora as nove injeções informam seu estágio de forma explícita: três `vertex` e seis `fragment`.

Também foram mantidas/corrigidas as melhorias de periodicidade do normal map muscular e de liberação de recursos em falhas de inicialização/compilação.

## 2. Alterações efetivas no código

| Arquivo | Revisão |
|---|---|
| `src/domains/anatomy/engine/shaders/anatomy-material-shader.ts` | Todas as nove chamadas declaram `vertex`/`fragment`; chave de cache do programa atualizada para invalidar shaders compilados com o contrato anterior. |
| `src/domains/anatomy/engine/materials/muscle-fiber-normal.ts` | Frequências U/V periódicas para que o normal map procedural possa repetir nos dois eixos sem descontinuidade vertical. |
| `src/domains/anatomy/engine/renderer/anatomy-renderer.ts` | Referências anuláveis explícitas para materiais/rig, limpeza centralizada de fallback, proteção contra RAF obsoleto e descarte de canvas, observers, listeners, geometria, textura, PMREM e contexto. O caminho em que `new WebGLRenderer()` falha também desconecta observers/listeners de montagem. |
| `scripts/check-anatomy-shader-injection.mjs` | Verifica os dois perfis de material, uniforms, origem do world-Y, falhas de chunk ausente/duplicado e os nove argumentos de estágio com distribuição 3 vertex / 6 fragment. |
| `scripts/check-muscle-normal-map.mjs` | Verifica dimensão, canais/variação, magnitude normalizada, validação de entrada e diferenças dos pixels nas bordas U/V. |
| `scripts/check-anatomy-v9.mjs` | Atualizado para testar a inicialização lazy após o `WebGLRenderer` usando o fluxo de criação local de materiais e sua atribuição ao controller. |
| `scripts/check-anatomy-vmax-v11.mjs` | Atualiza o contrato da chave de cache e mantém testes dos 14 IDs, UVs, mapa normal e holograma single-pass. |
| `README.md`, `docs/anatomy/ANATOMY_3D.md` | Atualizados para V11.2, com matriz de repositórios/licenças e limites de validação. |

## 3. Pesquisa de repositórios e decisões

As estrelas são valores aproximados observados na consulta ao GitHub em 22/11/2026. Podem variar. Não foram importados ativos de terceiros nem adicionadas dependências de runtime nesta revisão.

| Função | Repositório | Estrelas aprox. | Licença declarada | Decisão |
|---|---|---:|---|---|
| Engine PBR/WebGL | [mrdoob/three.js](https://github.com/mrdoob/three.js) | 119,1k | MIT | Manter como engine existente; usar os seus materiais PBR, PMREM, shaders e ciclo de vida. |
| Referência PBR mobile nativo | [google/filament](https://github.com/google/filament) | 20,8k | Apache-2.0 | Benchmark arquitetural; não migrar agora porque isso descartaria controller, integração e contratos existentes. |
| Otimização de geometria | [zeux/meshoptimizer](https://github.com/zeux/meshoptimizer) | 8,9k | MIT | Referência de pipeline; sem ativo GLB estático no projeto que justifique introduzir pipeline/dependência agora. |
| Atlas muscular estruturado | [ashemag/human-atlas](https://github.com/ashemag/human-atlas) | 4,6k | Código MIT; dados CC BY 4.0 | Melhor referência pesquisada para estrutura anatômica, batching e seleção. Não importar agora: referência masculina, ~33 MB, 402 estruturas musculares e trabalho de mapping/atribuição/QA para os 14 IDs. |
| Aceleração de picking | [gkjohnson/three-mesh-bvh](https://github.com/gkjohnson/three-mesh-bvh) | 3,6k | MIT | Não adicionar: um raycast por toque na malha muscular combinada atual não demonstra necessidade; reconsiderar após atlas de alta resolução ou medida de latência. |
| Pipeline glTF | [donmccurdy/glTF-Transform](https://github.com/donmccurdy/glTF-Transform) | 2,1k | MIT | Reservar para futuro pipeline de exportação de GLB; sem necessidade no corpo procedural atual. |
| Holograma R3F | [ektogamat/threejs-holographic-material](https://github.com/ektogamat/threejs-holographic-material) | 256 | MIT | Referência visual de Fresnel, scanline e emissão; não incorporar a dependência R3F no controller imperativo atual. |
| Holograma Three.js puro | [ektogamat/threejs-vanilla-holographic-material](https://github.com/ektogamat/threejs-vanilla-holographic-material) | 115 | MIT | Referência mais próxima da integração atual; manter shader/uniforms próprios. |
| Corpo paramétrico | [facebookresearch/MHR](https://github.com/facebookresearch/MHR), [NVlabs/SOMA-X](https://github.com/NVlabs/SOMA-X), [naver/anny](https://github.com/naver/anny) | 910 / 903 / 655 | Apache-2.0 para o código | Candidatos para identidade/deformação do corpo, não substitutos dos grupos musculares selecionáveis. Assets/opcionais exigem auditoria separada; não integrados. |
| Anatomia share-alike | [LluisV/Z-Anatomy](https://github.com/LluisV/Z-Anatomy) | 418 | CC BY-SA 4.0 | Não incorporar ao app comercial fechado sem aceitar ShareAlike e auditar os direitos dos ativos de terceiros. |

### Ativos / licenças

- O bundle V11.2 não contém as malhas Human Atlas, Z-Anatomy, SOMA-X, MHR ou Anny.
- A licença MIT/Apache do código não deve ser confundida com licença dos assets/modelos descarregados separadamente.
- O Human Atlas declara os seus dados de anatomia BodyParts3D sob CC BY 4.0, com atribuição e indicação de adaptações; isso pode permitir distribuição comercial com obrigações de atribuição, mas não é um asset “sem condições”.
- Z-Anatomy declara CC BY-SA 4.0. Foi deliberadamente excluído.
- Nenhuma malha paga, textura comercial, dependência nova de runtime ou asset third-party foi adicionado nesta revisão.

## 4. Testes executados com sucesso

### Suíte de anatomia — 7 scripts

| Script | O que verifica | Resultado |
|---|---|---|
| `scripts/check-anatomy-geometry.mjs` | UVs de costura, normais de seam, caps, patches abertos, bounds e largura de índice 16/32-bit | PASS |
| `scripts/check-muscle-normal-map.mjs` | Dimensões, variação, limites dos vetores, periodicidade U/V e entradas inválidas | PASS |
| `scripts/check-anatomy-shader-injection.mjs` | Perfis body/muscle, uniforms, world-Y, chunks ausentes/duplicados e 9 estágios explícitos (3 vertex / 6 fragment) | PASS |
| `scripts/check-anatomy-group-contract.mjs` | 14 IDs estáveis, cobertura de geometria, cabeça preservada e ligação picker/lista | PASS |
| `scripts/check-anatomy-lifecycle.mjs` | Fallback, dispose de recursos/listeners/observers, proteção de RAF obsoleto | PASS |
| `scripts/check-anatomy-v9.mjs` | Gate WebGL2, criação lazy, PMREM, orçamento de pixels, batching, bounds e fallback | PASS |
| `scripts/check-anatomy-vmax-v11.mjs` | UVs, textura de fibras, holograma single-pass e 14 IDs | PASS |

Comando executado: `npm run test:anatomy` — todos os sete scripts acima passaram, incluindo a nova verificação do fallback quando o contexto WebGL nem chega a ser criado.

### Verificações estáticas do restante do app — 4 scripts

| Script | Resultado |
|---|---|
| `scripts/check-fluid-shaders.mjs` | PASS |
| `scripts/check-cockpit-visual-semantics.mjs` | PASS |
| `scripts/check-titan-design-system.mjs` | PASS |
| `scripts/check-materials-v10.mjs` | PASS |

### Verificações adicionais

- TypeScript/TSX: 122 arquivos analisados com `transpileModule` usando TypeScript 5.8.3; **0 erros de sintaxe**. Isto não equivale a type-check semântico do projeto.
- Shader injector: `tsc --noEmit --strict` executado isoladamente com uma declaração local mínima de `three`; a assinatura/quantidade de argumentos do módulo de injeção passou. Não equivale ao type-check do app completo.
- ZIP final: `unzip -t` passou; o arquivo foi extraído em diretório separado e a suíte `npm run test:anatomy` + quatro verificadores estáticos foi repetida na extração, todos com PASS. SHA-256 acompanha a entrega.

## 5. Verificações que NÃO foram concluídas

| Verificação | Estado | Motivo |
|---|---|---|
| `npm test` completo | BLOCKED | `tsx: not found`; `node_modules` não existe neste ambiente. |
| `npm run build` (Vite) | BLOCKED | `vite: not found`; `node_modules` não existe. |
| `tsc --noEmit` completo | BLOCKED | Falta `vite/client` e tipos/dependências do projeto. |
| Instalação de dependências | BLOCKED | Tentativa de instalação excedeu o limite de execução; não ficou um `node_modules` funcional. |
| Compilação GLSL em Three.js real | NOT RUN | O pacote Three.js não está instalado neste ambiente. |
| Teste gráfico WebGL2 em Chromium/Safari | NOT RUN | Sem dependências do app carregadas; não houve execução da cena. |
| FPS, frame time, temperatura e memória em aparelhos | NOT RUN | Não há dispositivo iOS/Android conectado; nenhum benchmark é inferido. |

## 6. Escopo preservado e conclusão

- A cabeça não foi removida. A silhueta de corpo completo permanece.
- A funcionalidade muscular continua estritamente limitada aos 14 IDs de treino existentes, sem expandir para um catálogo anatômico completo.
- O picking, as máscaras primária/secundária, os lados e o vínculo com exercícios continuam usando os mesmos identificadores.
- O modo holográfico permanece no mesmo `MeshStandardMaterial` e numa única passagem; não foi introduzido bloom, `EffectComposer`, Unity, Filament, BVH ou outra engine. O `morphFactor` existente continua sendo somente um offset superficial muito pequeno, não uma simulação antropométrica de evolução corporal.
- O corpo continua procedural e de alta-levelidade. A revisão melhora a confiabilidade da engenharia e o material, mas não converte a geometria em uma escultura muscular anatomicamente validada/fotorealista.

**Veredito:** V11.2 passa os testes independentes executáveis disponíveis e as verificações de sintaxe. Não é correto afirmar “100% funcional” enquanto o build Vite, o type-check integral, a compilação GLSL real e os testes de GPU/dispositivo ainda não forem executados. Para fechar esse último gate, o mesmo ZIP precisa ser instalado e compilado num ambiente com registry/dependências disponíveis e depois executado em browsers e aparelhos alvo.
