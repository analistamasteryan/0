# TITAN — Visão de Produto

## Propósito
O TITAN é um aplicativo mobile-first de treinamento de força, anatomia 3D interativa, nutrição, hidratação e acompanhamento físico baseado em registros observados.

## Regra Central
O **Corpo 3D** é o protagonista da experiência. Treino, Evolução e Biblioteca de Exercícios comunicam-se com o subsistema anatômico por contratos explícitos, sem competir visualmente e sem transformar o renderer no dono das regras de negócio.

## Escopo da Fundação (Fase 1 & 2)
- **Cockpit**: resumo do dia, energia/macros, corpo 3D interativo, hidratação, progresso do treino atual e próxima refeição.
- **Corpo 3D**: exploração anatômica (Frontal, Posterior, Lateral, Foco Regional), seleção muscular independente do treino e fallback acessível.
- **Treino em execução**: registro de séries com validação, início automático do descanso e cronômetro real inclusive após ultrapassar o alvo.
- **Cardápio**: controle de refeições e consistência de macros.
- **Evolução**: medições observadas (peso e circunferências), sem inferências não comprovadas de hipertrofia.
