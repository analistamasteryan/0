# V11.11 — acceptance and remaining gates

## Completed in code

1. Workout plan editor: per-exercise rest, per-set load/reps/target reps, add/remove set, reorder exercises.
2. Custom nutrition meal editor: create, rename, time, food search, quantity, remove ingredient, consume, skip, delete.
3. Provenance: source/source record/source version/quality/source URL visible in food discovery and meal composition.
4. Persistence: custom meal validation, ingredient-count bound, retained history bound; custom plan and expanded set persistence tests.

## Blocked by environment / external architecture

- Dependency-backed browser testing (Playwright) and component testing (Vitest + Testing Library + MSW + axe-core): package registry timed out and no dependencies are installed. Do not change `bun.lock` manually.
- React Router migration: target selected, but must be installed with a regenerated lockfile and route fallback verified against the Express server.
- TanStack Query: requires a real API contract and server-state consumers.
- Authentication/sync: requires backend, identity provider, tenant model, authorization matrix, data ownership, conflict strategy, encryption/session policy and recovery tests.
- Dexie: requires asynchronous persistence migration, backup/restore redesign and measured evidence that bounded localStorage is insufficient.
- Lighthouse/browser profiling: requires a reproducible production build and browser E2E environment.

## Acceptance gates before production

- Clean dependency install from committed lockfile.
- Full semantic TypeScript check and production build.
- Playwright flows for custom workout CRUD, workout session completion, custom meal CRUD, persistence reload, backup/restore and mobile navigation.
- RTL tests for custom editor validation and keyboard behavior.
- axe-core on all four primary destinations and modal/sheet states; manual keyboard/screen-reader review.
- Lighthouse mobile and desktop baseline; compare LCP, INP, CLS, JS transfer and long tasks.
- Backend security review before enabling identity or cross-device sync.
