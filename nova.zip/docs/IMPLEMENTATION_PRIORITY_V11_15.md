# Prioridades do motor de cálculos — V11.15

## Implementado nesta revisão

1. Equações RMR selecionáveis: Mifflin–St Jeor, Pavlidou 2023, Cunningham, Katch–McArdle, Ten Haaf 2014 e override de calorimetria indireta informada.
2. Proveniência de FFM e validação de faixas/unidades; Cunningham/Katch não executam sem FFM ou percentual de gordura e origem declarada.
3. O cálculo de perfil usa a mesma função Mifflin já utilizada, mas a UI agora rotula o resultado como RMR estimada.
4. Motor MET genérico com validação de catálogos externos, proveniência e licença; energia bruta, líquida e corrected MET oficial (Harris–Benedict) e razão individual com RMR selecionada/medida, ambos separados do cálculo de kcal. A tabela do Compendium 2024 não foi embutida por restrição CC BY-NC-ND.
5. TDEE adaptativo com Theil–Sen + Kalman escalar, janela de 28 dias, atualização semanal, deduplicação por data, limites de cobertura, gate de outlier e faixa de incerteza do filtro.
6. Contrato para integrar potência OpenMetabolics produzida por provedor nativo validado; conversão W·s → kcal e subtração do baseline em pé enviado pelo mesmo modelo fixado.
7. Testes de regressão para equações, FFM, MET, integração de potência, convergência sintética de 84 dias e robustez a pesagem duplicada.

## Ainda não implementado — bloqueios reais

| Prioridade | Trabalho | Por que não foi declarado pronto |
|---|---|---|
| P0 | Port nativo do OpenMetabolics XGBoost + correção de artefatos | O repo publica pickle/Python; precisa exportar modelo para ONNX/JSON, reimplementar feature extraction e provar paridade. O app React/Vite no preview web não captura sensores 50 Hz em background com garantia. |
| P0 | Teste de campo contra calorimetria indireta/água duplamente marcada | Sem dados de referência não existe evidência de MAE/RMSE ou calibração do intervalo do filtro no TITAN. |
| P0 | Backtesting do Kalman com dados reais anonimizados e parâmetros versionados | Os parâmetros foram ajustados em simulação sintética de 200 perfis; ainda não foram ajustados nem validados por coorte real. |
| P1 | Modelo dinâmico Hall/NIDDK completo | O módulo atual ainda usa aproximação local 7.000 kcal/kg; não simula compartimentos corporais e adaptação ao longo de meses. |
| P1 | Catálogo licenciado de atividades (incluindo a edição 2024, se houver autorização) | Nenhum MET do Compendium foi embutido; direitos de redistribuição/uso comercial precisam ser confirmados ou deve ser usada outra base com licença compatível. |
| P1 | UI para escolher equação RMR e informar FFM com origem | API de domínio está pronta; tela de perfil ainda não expõe seleção de método ou FFM. |
| P1 | Orquestração para evitar dupla contagem | O cálculo por sessão está disponível; integração ao TDEE diário precisa deduplicar exercício manual, Health Connect e sensores no mesmo intervalo. |
| P2 | Health Connect / Apple Health nativos | Requer wrapper/app nativo, permissões e revisão de privacidade. |
| P2 | EER/RMR específico para condições especiais e faixas fora de adulto saudável | Requer evidência específica e fluxo de segurança; não extrapolar equações atuais. |

## Gate para afirmar “precisão máxima”

Não usar esse rótulo até medir, em conjunto independente: MAE, RMSE, viés, MAPE (com cautela perto de zero), Bland–Altman/limites de concordância, calibração de intervalos, erro por sexo/idade/IMC/FFM/nível de atividade e desempenho por aparelho/posição. Para gasto diário total, priorizar água duplamente marcada; para RMR, calorimetria indireta protocolada.
