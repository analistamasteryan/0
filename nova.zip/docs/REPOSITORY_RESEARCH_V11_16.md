# Pesquisa de repositórios — V11.16

Snapshot de estrelas e metadados observado em 2026-11-23. Estrelas são um sinal de adoção, não evidência de validade clínica nem motivo isolado para adicionar dependências. Licenças foram verificadas no metadado/repositório; não foi copiado código nem dataset de terceiros.

| Repositório | Estrelas aproximadas no snapshot | Licença reportada | Aplicação/decisão |
|---|---:|---|---|
| [wger-project/wger](https://github.com/wger-project/wger) | 7.312 | AGPL-3.0 | Produto amplo de treino/nutrição/peso; arquitetura e fluxos avaliados. Não incorporado por ser um sistema completo e AGPL, sem necessidade de importar esse acoplamento ao app. |
| [hasaneyldrm/exercises-dataset](https://github.com/hasaneyldrm/exercises-dataset) | 23.983 | NOASSERTION | Maior adoção entre catálogos candidatos analisados; rejeitado para ingestão porque a licença não está declarada e os dados não constituem um catálogo MET científico. |
| [rlabbe/filterpy](https://github.com/rlabbe/filterpy) | 3.903 | MIT | Referência algorítmica para filtros de Kalman, suavizadores e estimação ótima. Não importado porque é biblioteca Python e o motor de execução é TypeScript; o filtro escalar atual permanece pequeno e especializado. |
| [yuhonas/free-exercise-db](https://github.com/yuhonas/free-exercise-db) | 2.172 | Unlicense | Base aberta de exercícios para taxonomia e metadados. Não usada como fonte de MET: os registros de exercícios não substituem valores de gasto energético validados. |
| [ShuchirJ/HCGateway](https://github.com/ShuchirJ/HCGateway) | 421 | GPL-3.0 | Bridge REST para Health Connect. Estudado como padrão de integração; não copiado por GPL e porque o app precisa de bridge fina, não de gateway externo. |
| [android/health-samples](https://github.com/android/health-samples) | 350 | Apache-2.0 | Exemplo oficial Android utilizado como referência para Health Connect, permissões e leitura de registros. Scaffolds nativos foram escritos de forma independente. |
| [vitoksmile/HealthKMP](https://github.com/vitoksmile/HealthKMP) | 93 | Apache-2.0 | Referência multiplataforma para HealthKit + Health Connect e normalização de tipos de saúde. Não adicionado como dependência; o host nativo ainda não existe. |
| [Hale-MTU/OpenVitals](https://github.com/Hale-MTU/OpenVitals) | 68 | AGPL-3.0 | Referência de privacidade/local-first em Health Connect; não copiado devido à licença e ao escopo do projeto. |
| [Harvard-Slade-Lab/A-smartphone-activity-monitor-that-accurately-estimates-energy-expenditure](https://github.com/Harvard-Slade-Lab/A-smartphone-activity-monitor-that-accurately-estimates-energy-expenditure) | 14 | MIT no código | Referência científica do pipeline OpenMetabolics; pesos/dados não foram incluídos porque a licença do código não prova direito de redistribuição dos artefatos científicos. |

## Decisões

### Por que não escolher só o repo com mais estrelas

- `hasaneyldrm/exercises-dataset` é o mais estrelado nesta lista, mas o GitHub retorna `NOASSERTION` de licença e o dataset é de exercícios, não um compêndio de MET. Embutir seria uma decisão juridicamente e cientificamente fraca.
- `wger` é muito adotado, mas AGPL-3.0 e grande demais para o objetivo. Foi referência para padrões de domínio e proveniência, não dependência nem fork.
- `FilterPy` é uma referência madura e MIT, mas Python adicionaria um serviço/bridge sem benefício suficiente para um filtro escalar em TypeScript. O algoritmo continua implementado no motor atual; novos métodos só entram após backtesting comparativo.
- `android/health-samples` é o padrão mais confiável para o scaffold Android por ser oficial, apesar de ter menos estrelas que gateways genéricos.
- `free-exercise-db` é Unlicense e pode servir a biblioteca de exercício, mas não fornece METs suficientes para ser usado como fonte energética.

### Licenças de catálogo aceitas pelo importador

O importador V11.16 aceita apenas identificadores da allowlist no código (`CC0-1.0`, CC BY 3.0/4.0, ODC-BY-1.0, ODbL-1.0, MIT, Apache-2.0, BSD-2-Clause, BSD-3-Clause e Unlicense). Licenças NC/ND, customizadas, comerciais não autorizadas e desconhecidas são recusadas. ODbL gera aviso de obrigações adicionais. A allowlist é uma barreira técnica conservadora, não parecer jurídico.

Nenhum código, peso de ML ou conjunto de dados dos repositórios foi copiado para o projeto.
