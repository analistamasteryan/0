# Pesquisa de repositórios — motor de cálculos V11.14

**Snapshot consultado:** 23/11/2026. Estrelas são dinâmicas e refletem o momento da consulta.

| Repositório | Estrelas observadas | Licença | O que foi analisado | Decisão |
|---|---:|---|---|---|
| [wger-project/wger](https://github.com/wger-project/wger) | ~6,9 mil | AGPL-3.0-or-later (app); dados/exercícios têm licenças próprias | Modelo aberto de treino, exercícios, nutrição, peso e auto-hospedagem; separação de entidades e histórico | Referência de domínio e rastreabilidade; não importar código AGPL para este app |
| [simonoppowa/OpenNutriTracker](https://github.com/simonoppowa/OpenNutriTracker) | ~3,0 mil | GPL-3.0 | Tracker de alimentação/energia; documentação pública das equações, fontes científicas, testes de valores publicados, privacidade e tratamento de incerteza | Referência de auditabilidade e metodologia; não copiar código GPL |

## Como as referências foram usadas

- Priorizei estrelas como sinal de adoção e maturidade, não como prova de precisão fisiológica.
- Para valores biomédicos, a fonte primária (NASEM, ISSN, consensus, revisão/meta-análise) prevalece sobre qualquer implementação de GitHub.
- O cálculo não foi substituído pela implementação do OpenNutriTracker: seu material documenta cuidadosamente IOM 2005 e inclusive registra correções dessa implementação. O TITAN passa a usar NASEM 2023 para estimativa adulta inicial e mantém calibração adaptativa observada.
- Nenhuma dependência foi adicionada. Não houve cópia de código copyleft; apenas análise de arquitetura, testes e rastreabilidade.

## Principais achados de engenharia

1. Cada fórmula precisa declarar fonte, versão, população, unidade, faixa válida e natureza do resultado.
2. Equações populacionais são início da estimativa; tendência de peso e ingestão completa ajudam a calibrar, mas não são medição metabólica.
3. Tabelas de referência devem ser testadas contra valores publicados, não apenas contra expectativas criadas a partir da própria implementação.
4. Dados ausentes precisam permanecer ausentes e com proveniência explícita; não se devem substituir `null/not_analyzed` por zero.
5. Persistência de histórico de treino precisa manter RIR por série, mas RIR de um treino anterior não deve ser copiado para a sessão nova.
6. Sensores de velocidade só devem ser promovidos a padrão quando o erro for validado por exercício e dispositivo; média de correlação alta não garante acordo individual.
