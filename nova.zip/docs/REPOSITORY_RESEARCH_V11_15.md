# Pesquisa de repositórios e evidência — V11.15

Snapshot de estrelas observado em 23/11/2026. Estrelas medem adoção no GitHub, não qualidade fisiológica nem validação clínica.

| Repositório | Estrelas observadas | Licença | Decisão |
|---|---:|---|---|
| `wger-project/wger` | 7,3 mil | AGPL-3.0 | Maior referência de produto/organização para treino, nutrição, peso e API; não copiamos código nem incorporamos dependência AGPL. |
| `android/health-samples` | 350 | Apache-2.0 | Melhor referência mais popular para Health Connect e Health Services nativos; não é modelo de gasto energético. |
| `sztyler/sensordatacollector` | 53 | GPL-2.0 | Referência para coleta multissensor Android/Wear; não incorporado porque é apenas coletor, GPL-2.0 e requer app nativo. |
| `Harvard-Slade-Lab/A-smartphone-activity-monitor-that-accurately-estimates-energy-expenditure` | 14 | MIT (código) | Referência científica/algorítmica para sensores. Não portado: modelo XGBoost em pickle e pipeline Python; o app React/Vite não oferece execução de sensor 50 Hz em background. |
| `SilverCrocus/OpenMacro` | 8 | MIT | Referência de RMR, TDEE por janela, variância e Kalman. A documentação registra que o smoother local-linear + RTS é planejado para v2; não presumir que já esteja implementado. A simulação própria do projeto reporta RMS 115 kcal em 200 perfis sintéticos, com parâmetros diferentes dos nossos. |
| `ddarmon/llmn` | 1 | MIT | Referência do filtro escalar de Kalman e EMA; adaptamos o padrão ao domínio TS, não copiamos o código. |
| `emiluzelac/caloric` | 1 | Campo `license: MIT` declarado no package.json; arquivo LICENSE não localizado | Referência para Pavlidou 2023, mas a fórmula foi implementada diretamente a partir do artigo; repo tem baixa adoção. |
| `andyreagan/compendium-of-physical-activity` | 0 | Sem licença explícita identificada no repo | Não usado como fonte da base local: contém o Compendium 2011, está desatualizado frente à edição 2024 e a licença não é clara. |
| `Harvard-Slade-Lab/OpenMetabolics_Application_Code` | 0 | Sem licença no nível raiz identificada | Não incorporado: fork separado, app Flutter com AWS Amplify/Cognito e sem licença explícita no repo. |

## Por que não escolhemos só o repositório com mais estrelas

O projeto de cálculo precisa de fórmulas validadas e dados adequados, não de dependências populares. Repositórios pequenos são usados apenas quando contêm o algoritmo diretamente relevante e a licença é clara. `wger` (7,3 mil estrelas) e `android/health-samples` (350) foram priorizados como referências de produto e integração; `sensordatacollector` (53) foi avaliado para coleta, mas não incorporado por licença GPL-2.0 e por exigir Android nativo. O código de produção permanece TypeScript puro, sem nova dependência runtime.

## Evidência que altera a decisão

- Pavlidou 2023: 722 adultos caucasianos, com forte desequilíbrio de sexo (549 mulheres/173 homens); o R² do estudo não prova generalização para a população brasileira.
- Revisão sistemática/meta-análise de equações de RMR em atletas: heterogeneidade elevada; Ten Haaf teve desempenho médio forte em grupos de atletas, mas a equação deve ser escolhida conforme população semelhante.
- Cunningham: requer massa livre de gordura confiável; o erro da composição corporal passa diretamente à estimativa.
- Compendium 2024: 1.114 atividades, 912 com MET medido e 202 estimado; adultos 19–59. Nenhum valor MET do Compendium foi embarcado; o motor aceita catálogo externo com licença e proveniência validadas.
- OpenMetabolics: modelo de bolso usa dados de sensores a 50 Hz e ML; a licença MIT do repositório de pesquisa não torna automaticamente o app Flutter forkado MIT.
- OpenMacro: o código de gasto adaptativo implementa Kalman escalar; o smoother RTS descrito no documento de algoritmos é explicitamente planejado, não atual.

## Compendium 2024 e licenciamento

A edição 2024 contém 1.114 atividades (912 com MET medido e 202 estimado) para adultos de 19–59 anos. O artigo é CC BY-NC-ND 4.0; não embutimos a tabela completa nem uma versão derivada no app. O motor recebe catálogos externos com licença declarada por entrada e preserva se o MET foi medido, estimado ou não especificado; a validação confirma presença de metadados, não faz parecer jurídico de licença.

## Simulação do filtro adaptativo

O script determinístico `scripts/simulate-adaptive-energy.mjs` simula 200 perfis, ruído de peso 0,6 kg, ruído de ingestão 350 kcal e redução gradual de 200 kcal/dia no TDEE. Resultado: período estável n=600, RMSE 90,7 kcal, viés −0,2 kcal e cobertura 99,8%; pós-adaptação n=400, RMSE 83,8 kcal, viés +29 kcal e cobertura 100%. É uma verificação sintética do comportamento do algoritmo, não uma validação clínica/externa.

## Dependências

Nenhuma dependência foi adicionada. A implementação usa TypeScript puro para manter bundle e lockfile estáveis e evitar instalações sem rede.
