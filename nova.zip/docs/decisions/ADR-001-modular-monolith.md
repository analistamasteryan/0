# ADR-001: Monólito Modular por Domínios na Aplicação Web Mobile-First

## Contexto
O TITAN requer isolamento claro entre domínios (Treino, Anatomia 3D, Nutrição, Evolução) sem sobrecarga prematura de múltiplos pacotes ou microserviços.

## Decisão
Adotar um monólito modular dentro de `src/domains/` com fronteiras explícitas (`domain`, `application`, `data`, `state`, `schemas`, `components`, `screens`) e contratos compartilhados em `src/shared/types/`.

## Consequências
Permite extração futura para pacotes independentes quando houver múltiplos clientes, mantendo simplicidade operacional imediata.
