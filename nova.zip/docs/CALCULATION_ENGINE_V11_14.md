# TITAN — Auditoria do motor de cálculos V11.14

**Data de revisão:** 23/11/2026  
**Escopo:** energia, metas calóricas, macros, referências de micronutrientes, composição corporal, hidratação esportiva e força.  
**Natureza:** ferramenta de estimativa e acompanhamento; não é dispositivo médico nem substitui avaliação clínica.

## Princípios do motor

1. Distinguir valores medidos, valores registrados e estimativas de equação.
2. Identificar fórmula, população, unidades, versão da fonte e limites de aplicação.
3. Usar a equação populacional como ponto de partida e calibrar com tendência longitudinal quando houver registros completos.
4. Não transformar falta de dados em zero, nem valores implausíveis em resultados aparentemente válidos.
5. Exibir incerteza e limitações junto do resultado, não apenas em documentação técnica.
6. Não somar calorias de exercício a um TDEE que já incorpora atividade física sem comprovar que a atividade está fora da categoria usada na equação.

## 1. Energia diária — NASEM 2023

O gasto energético inicial é calculado pelas equações adultas de Estimated Energy Requirement (EER) da NASEM 2023, Table S-3. Idade em anos, altura em centímetros, peso em quilogramas; resultado em kcal/dia.

| Sexo da equação | Categoria inativa | Pouco ativa | Ativa | Muito ativa |
|---|---|---|---|---|
| Masculina | `753.07 − 10.83×idade + 6.50×altura + 14.10×peso` | `581.47 − 10.83×idade + 8.30×altura + 14.94×peso` | `1004.82 − 10.83×idade + 6.52×altura + 15.91×peso` | `−517.88 − 10.83×idade + 15.61×altura + 19.11×peso` |
| Feminina | `584.90 − 7.01×idade + 5.72×altura + 11.71×peso` | `575.77 − 7.01×idade + 6.60×altura + 12.14×peso` | `710.25 − 7.01×idade + 6.54×altura + 12.34×peso` | `511.83 − 7.01×idade + 9.07×altura + 12.56×peso` |

As categorias PAL adultas publicadas são: inativa `1.00 ≤ PAL < 1.53`; pouco ativa `1.53 ≤ PAL < 1.68`; ativa `1.68 ≤ PAL < 1.85`; muito ativa `1.85 ≤ PAL < 2.50`. Passos por dia e frequência de treino não são, isoladamente, uma medição de PAL.

### Compatibilidade com o cadastro atual

O app preserva cinco opções legadas para não quebrar perfis existentes e mapeia-as às quatro categorias NASEM:

| Opção armazenada | Categoria usada pela equação | Observação |
|---|---|---|
| Sedentário | Inativa | Proxy inicial |
| Leve | Pouco ativa | Proxy inicial |
| Moderado | Ativa | Proxy inicial |
| Alto | Ativa | Não há quinta equação NASEM; a distinção do cadastro não cria um quinto multiplicador |
| Muito alto | Muito ativa | Deve ser revisto por rotina real, não só pelo número de treinos |

**Limitação conhecida:** o mapeamento continua dependente da auto-classificação. A melhoria seguinte é recolher atividade ocupacional, deslocamento, treino semanal e, quando disponível, dados de wearable para estimar a categoria com mais evidência — sem apresentar passos como PAL medido.

### TMB auxiliar

Mifflin–St Jeor continua como estimativa auxiliar de TMB exibida/consumida em componentes já existentes; não é multiplicada por um fator de atividade para substituir a equação NASEM. TMB e EER/TEE são conceitos diferentes.

## 2. Calibração adaptativa por dados observados

`estimateAdaptiveTdee` infere o gasto a partir da **média aritmética da ingestão diária completa em dias únicos** e da tendência robusta de peso (Theil–Sen). Duplicatas do mesmo dia são consolidadas pela mediana antes da média entre dias, evitando contar importações repetidas como dias extras.

Critérios atuais: janela entre 21 e 90 dias; mínimo de 14 dias alimentares completos e pelo menos 60% de cobertura; pelo menos três observações de peso ao longo de 14 dias. A confiança é reduzida quando a cobertura ou a duração do histórico é baixa. Valores fora dos limites plausíveis são rejeitados em vez de truncados para parecerem válidos.

| Parâmetro | Valor atual | Significado |
|---|---:|---|
| Densidade energética baixa | 4.500 kcal/kg | Cenário de sensibilidade |
| Central | 7.000 kcal/kg | Centro de planejamento |
| Alta | 9.500 kcal/kg | Cenário de sensibilidade |

A faixa resultante é **análise de sensibilidade**, não intervalo de confiança estatístico. Água, glicogênio, conteúdo intestinal, erro de pesagem e sub-registro alimentar ainda podem deslocar a estimativa. O app só prefere a estimativa adaptativa quando os limites e a confiança passam pela validação.

## 3. Metas de ganho/perda de peso

O ajuste por prazo é limitado por velocidade semanal e por percentagem do TDEE. Limites atuais: ganho até 0,25% do peso corporal por semana e perda até 0,75% por semana; além disso, há teto de 10% do TDEE/300 kcal para ganho e 20% do TDEE/500 kcal para perda. Se o prazo pedir mais, o ajuste é limitado e o aviso explica que a data-alvo pode não ser alcançada.

A densidade de 7.000 kcal/kg é uma aproximação de planejamento, não uma lei fixa. Um modelo dinâmico de peso (Hall/NIDDK) ainda não foi implementado; permanece como prioridade futura para previsões de vários meses e adaptação metabólica.

## 4. Macronutrientes

- Proteína de manutenção: faixa de referência atual de 1,2–1,6 g/kg/dia.
- Com treino de resistência, ganho, perda ou recomposição: alvo atual de 1,6–2,2 g/kg/dia; os centros usados variam com o objetivo.
- A gordura usa piso operacional de 0,6 g/kg e referência de 25% da energia; carboidrato recebe a energia residual.
- Se os pisos de proteína/gordura não couberem na meta calórica, a meta é elevada e o conflito é informado. Se os carboidratos residuais zerarem, a tela apresenta aviso.
- IMC ≥ 30 gera aviso de que proteína calculada pelo peso atual pode superestimar a necessidade; não se inventa automaticamente um “peso ideal”.

A posição da ISSN de 2026 sustenta 1,2–1,6 g/kg/dia para a população geral e 1,6–2,2 g/kg/dia combinados ao treino de resistência; distribuição por refeição é secundária à ingestão total. Ainda falta coletar preferência alimentar, restrições, ingestão energética real e massa livre de gordura para individualizar além do peso corporal.

## 5. Composição corporal

| Indicador | Método atual | Interpretação |
|---|---|---|
| IMC | peso / altura² | Triagem populacional; não mede gordura ou músculo |
| Cintura/altura | cintura ÷ altura | Indicador antropométrico de triagem |
| Gordura corporal | Circunferências US Navy | Estimativa de campo; depende da técnica e das medidas |
| Relative Fat Mass (RFM) | equação baseada em cintura/altura e sexo | Segunda estimativa de campo, desenvolvida/validada contra DXA em adultos; não substitui DXA |
| Massa gorda, massa magra, FFMI | Derivados do peso e do percentual Navy | Dependem da estimativa Navy; não combinar métodos como se fossem medidas diretas |

RFM é exibida separadamente e só é calculada como referência adulta a partir dos 20 anos. A diferença entre Navy e RFM é diferença entre métodos, não erro-padrão nem intervalo de confiança.

## 6. Hidratação

A referência diária de 32 mL/kg é mantida como ponto inicial do app, sem bônus arbitrário fixo por treino. Não é apresentada como recomendação universal ou como ingestão total de água da DRI.

A calculadora de sessão, já presente na base anterior e revalidada nesta revisão, utiliza:

`perda estimada de suor (mL) = (peso pré − peso pós) × 1.000 + líquido ingerido − urina`

`taxa de suor (mL/h) = perda estimada ÷ duração em horas`

Ela calcula variação percentual da massa corporal, referência pré-exercício de 5–10 mL/kg 2–4 h antes e reposição pós-exercício de 100–150% do déficit líquido estimado em 0–4 h. Sinaliza ganho de massa durante a sessão e perda ≥2%. Não calcula necessidade de sódio: para isso seria preciso medir a concentração de sódio no suor ou usar um protocolo profissional individual.

A medição só é comparável sob condições semelhantes de roupa, balança, clima, modalidade e intensidade. Sessões curtas amplificam erro de balança e roupa molhada.

## 7. Força e treino

O motor mantém sete fórmulas de estimativa de 1RM (Epley, Brzycki, Lombardi, Mayhew, O'Conner, Wathan e Lander), usa mediana entre fórmulas e limita extrapolação a até 10 repetições. A tabela de carga é gerada em passos de 5% de 100% a 50% do 1RM.

**V11.14 acrescenta registro opcional de RIR (0–5) por série.** Quando informado, a estimativa ajusta repetições realizadas + RIR. Quando ausente, o cálculo legado ainda pode ser mostrado, mas é marcado como esforço não verificado e assume falha — não deve ser interpretado como estimativa igualmente confiável. RIR é subjetivo; a revisão sistemática de 2025 encontrou maior acurácia perto da falha e em cargas relativas maiores, com queda de acurácia em séries de mais repetições/cargas menores.

O 1RM por velocidade com sensor não foi ativado: a meta-análise de 2026 encontrou boa validade média, mas heterogeneidade importante por exercício, sensor, intensidade e modelo; é necessário armazenar velocidade e calibrar modelo por exercício/sensor antes de oferecer um resultado como mais preciso.

## 8. Referências nutricionais e catálogo TBCA

Os perfis DRI continuam diferenciando sexo e faixas etárias e agora separam 19–30 de 31–50 anos para refletir a RDA de magnésio (homens 400 vs. 420 mg; mulheres 310 vs. 320 mg). IDs legados continuam aceitos na persistência.

### Cobertura observada no catálogo TBCA 7.2

Contagem recalculada diretamente no `tbca-catalog.compact.json` (5.830 alimentos elegíveis, base de 100 g):

| Campo | Registros com valor numérico | Cobertura |
|---|---:|---:|
| Energia, proteína, carboidrato, gordura total e base | 5.830 cada | 100% |
| Fibra | 5.721 | 98,1% |
| Gordura saturada | 5.760 | 98,8% |
| Colesterol | 5.744 | 98,5% |
| Sódio | 5.812 | 99,7% |
| Vitamina A | 5.537 | 95,0% |
| Vitamina C | 5.749 | 98,6% |
| Vitamina D | 5.246 | 90,0% |
| Vitamina E | 5.427 | 93,1% |
| Tiamina (B1) | 5.804 | 99,6% |
| Riboflavina (B2) | 5.803 | 99,5% |
| Niacina (B3) | 5.780 | 99,1% |
| B6 | 5.767 | 98,9% |
| Folato (B9) | 5.542 | 95,1% |
| B12 | 5.682 | 97,5% |
| Cálcio | 5.823 | 99,9% |
| Cobre | 5.628 | 96,5% |
| Ferro | 5.823 | 99,9% |
| Fósforo | 5.806 | 99,6% |
| Magnésio | 5.816 | 99,8% |
| Manganês | 5.556 | 95,3% |
| Potássio | 5.822 | 99,9% |
| Selênio | 4.823 | 82,7% |
| Zinco | 5.817 | 99,8% |

Vitamina K, B5 e B7 não são publicadas na planilha de origem: permanecem `not_analyzed`/nulas. Valores nulos não são convertidos para zero. A presença de um RDA no painel não significa que o catálogo possua análise daquele nutriente para todos os alimentos.

## 9. O que ainda falta para um motor de nível superior

| Prioridade | Lacuna | Por que importa | Próximo passo correto |
|---|---|---|---|
| P0 | Modelo dinâmico de peso Hall/NIDDK | A aproximação kcal/kg não representa totalmente adaptação e mudanças de composição ao longo de meses | Implementar como módulo separado, reproduzir casos de referência e comparar previsão vs. peso observado antes de substituir a regra atual |
| P0 | Medição/integração de RMR e TEE | Equações populacionais não são calorimetria nem água duplamente marcada | Importar resultados laboratoriais/manual e usar como âncora observada, preservando origem, data e protocolo |
| P0 | Categoria de atividade mais objetiva | A seleção atual pode errar PAL e deslocar EER centenas de kcal | Coletar atividade ocupacional, deslocamento, treino e métricas de wearable; permitir ajuste manual com explicação |
| P1 | Modelos de energia por grupo e condição fisiológica | Atletas, idade avançada, gestação/lactação e doenças podem não seguir o perfil geral | Criar perfis só com equações validadas, fontes primárias e fluxo seguro de não aplicabilidade |
| P1 | Recomendação de proteína por massa livre de gordura e fase de treino | Peso corporal pode superestimar em obesidade ou ser inadequado em atletas magros em déficit | Adicionar composição confiável, objetivo, experiência e período de déficit; não inferir FFM a partir de uma única fórmula de cintura |
| P1 | Prescrição de fibra e qualidade global da dieta | Catálogo traz valores, mas metas/qualidade da dieta ainda não são totalmente personalizadas | Adicionar referências por idade/sexo/energia e indicadores de qualidade sem imputar nutrientes ausentes |
| P1 | Dados adicionais para K, B5 e B7 | A fonte TBCA atual não os publica | Adicionar fonte secundária com licença, versão, unidade, equivalência e linhagem; não preencher TBCA com zero |
| P1 | Estimativa de força por velocidade | Pode ser útil quando há sensor, mas depende de equipamento/exercício | Só integrar dados de dispositivo após calibração por exercício e análise de erro |
| P2 | Modelagem de ciclo menstrual, sono, fadiga e prontidão | Pode contextualizar variação de desempenho e peso, mas evidência e coleta variam | Deixar opt-in, separar observação de inferência e não automatizar prescrição clínica |
| P2 | Validação externa contínua | Testes unitários garantem implementação, não validade clínica | Criar dataset anonimizável consentido, golden cases, análise de erro por subgrupo e revisão profissional |

## 10. Referências científicas principais

- National Academies of Sciences, Engineering, and Medicine. *Dietary Reference Intakes for Energy* (2023). DOI: [10.17226/26818](https://doi.org/10.17226/26818). EER e acompanhamento do peso como passo de validação: [Resumo NCBI](https://www.ncbi.nlm.nih.gov/books/NBK591034/), [capítulo de aplicação](https://www.nationalacademies.org/read/26818/chapter/9), [equações e categorias PAL — Health Canada](https://www.canada.ca/en/health-canada/services/food-nutrition/healthy-eating/dietary-reference-intakes/tables/equations-estimate-energy-requirement.html).
- International Society of Sports Nutrition. *Position stand: diets for body weight reduction* (2026). DOI: [10.1080/15502783.2026.2740266](https://doi.org/10.1080/15502783.2026.2740266).
- Xin et al. *Hydration management for athletes* (2026). DOI: [10.1016/j.smhs.2026.09.004](https://doi.org/10.1016/j.smhs.2026.09.004).
- Casanova et al. *Factors influencing the accuracy of the repetition in reserve scale in resistance training: a systematic review* (2025). DOI: [10.1080/10833196.2025.2564026](https://doi.org/10.1080/10833196.2025.2564026).
- Claassen et al. *Reliability, Device Agreement and Validity of Load–Velocity Profiles: A Systematic Review with Meta-analysis* (2026). DOI: [10.1186/s40798-026-01102-0](https://doi.org/10.1186/s40798-026-01102-0).
- Woolcott & Bergman. *Relative Fat Mass (RFM) as a new estimator of whole-body fat percentage* (2018). DOI: [10.1016/j.cmet.2018.06.005](https://doi.org/10.1016/j.cmet.2018.06.005).
