# Exercise Library — Research and Implementation V11.6

**Research date:** 2026-11-23  
**Scope:** catalog quality, exercise-to-muscle mapping, coaching guides, alternatives/progression, source provenance and redistribution rights.

## 1. Baseline and corrected audit

The V11.5 worktree contains **17 actual canonical exercise records**, not six. The earlier six-record count from a previous audit note is stale and should not be repeated. The catalog already included the ten initial TITAN workout movements and seven text records attributed to Yuhonas. This release adds 15 selected records and enriches the existing 17, resulting in **32 canonical exercises**.

The original V11.5 architecture already had an important correct decision: `EXERCISE_MUSCLE_MAP` was derived from `EXERCISE_CATALOG`. V11.6 preserves this and formalizes an `ExerciseRegistry` public read boundary. It does not create a second manually maintained exercise-to-muscle table.

## 2. Repository comparison

Star counts are a GitHub snapshot checked on 2026-11-23. They indicate adoption, not scientific accuracy, exercise completeness or redistribution rights.

| Repository | Stars (approx.) | Dataset/platform claims | License finding | V11.6 decision |
|---|---:|---|---|---|
| [hasaneyldrm/exercises-dataset](https://github.com/hasaneyldrm/exercises-dataset) | 23,979 | 1,324 exercises; thumbnails, GIFs, 10-language instruction maps and JSON Schema | Exercise data/text MIT; Gym visual media has separate terms and attribution/resolution restrictions | Top candidate by stars and breadth; no media copied. Full bulk import deferred until each source field and translation provenance is reviewed. |
| [wger-project/wger](https://github.com/wger-project/wger) | 7,312 | Mature workout/nutrition platform, exercise wiki, API, translations, equipment and progress tracking | Application code AGPL-3.0-or-later; exercise/ingredient data Creative Commons by individual entry | Use as platform/API design reference. No AGPL application code is integrated. No unqualified bulk exercise import. |
| [yuhonas/free-exercise-db](https://github.com/yuhonas/free-exercise-db) | 2,170 | 800+ records; force, level, mechanic, equipment, primary/secondary muscles and step instructions | Repository declares Unlicense/public-domain dataset; source file and blob SHA retained per selected record | Imported 15 additional selected text-only records and retained the earlier seven. No image/GIF files copied. |
| [wrkout/exercises.json](https://github.com/wrkout/exercises.json) | 650 | 800+ public-domain-oriented exercise records | Repository declares Unlicense | Secondary source/schema review only; substantial overlap with Yuhonas. |
| [RepDB/exercise-dataset](https://github.com/RepDB/exercise-dataset) | 152 | 708 exercises, 1,231 flat illustrations, target/secondary muscles, equipment, MET values and EN/DE/ES text | Attribution described in README, but GitHub does not report a recognized SPDX license; media rights require separate confirmation | Not imported. Promising media/MET candidate, but terms are not clear enough for bundling. |
| [exercemus/exercises](https://github.com/exercemus/exercises) | 53 | Aggregated exercise catalog with aliases, instructions, tips, tempo, `variation_on`, authors and per-record license data | Per-exercise license metadata must be preserved | Schema reference for aliases, relationships and record-level provenance; data not bulk copied. |
| [kinetic-place/exercises-db](https://github.com/kinetic-place/exercises-db) | 5 | 908 exercises, 814 guides, 906 YouTube links, 17 muscle groups and 44 equipment types | Repository declares MIT | Used only as a guide-structure reference: detailed steps, tips, common errors and progression relationships. No external video copied. |

## 3. Why the result is a composition rather than a wholesale replacement

- **Yuhonas** is the best immediate import source among the examined repositories because its exercise records are already structured and its declared Unlicense makes text adaptation simpler than entry-by-entry Creative Commons checks. Fifteen unique entries were selected for current muscle coverage and useful movement variety.
- **wger** is a mature product/API reference, not merely a list of exercises. Copying its application code would bring AGPL obligations into the app; per-entry data licenses also must not be treated as one blanket license.
- **hasaneyldrm** wins on stars and advertised dataset size, but the media exception is explicit. The repository's MIT data license does not grant Gym visual image/GIF rights. The app therefore avoids bundling its media and does not pretend the full 1,324-item dataset is already imported.
- **Kinetic** has far fewer stars, so it is not selected as the main data source. Its guide model is useful: instructions, tips, errors and related exercises are first-class fields. Those capabilities are implemented in TITAN's own data model instead of adding its runtime package.
- **RepDB** includes MET values and higher-resolution illustrations, but the repository's GitHub license metadata is `NOASSERTION`; it is excluded until legal terms are clearer.

## 4. Implemented canonical data model

`ExerciseLibraryItem` now supports:

- Identity: stable TITAN `slug`, display name and aliases.
- Classification: category, difficulty/level, force and mechanic.
- Training context: equipment and movement pattern.
- Anatomy: primary and secondary TITAN muscle groups plus an optional separate stabilizer list.
- Coaching: short cue, ordered execution instructions, technique tips, common errors, breathing and optional tempo guidance.
- Planning links: alternative, regression and progression slugs.
- Provenance: one legacy source plus an array of additional source references, each with repository, record ID, source URL, data-license label and Git blob SHA when applicable.

All anatomy mappings remain within the original 14 `MuscleGroupId` contract. Stabilizers are not silently promoted into the 3D primary/secondary overlay. No activation percentages are invented.

## 5. UI changes

The exercise library now offers:

- Accent-insensitive full-text search across names, aliases, anatomy, equipment, movement patterns, instructions, tips, common errors and linked movements.
- Filters by muscle, equipment, level, category and mechanic.
- Expandable guide cards with execution steps, breathing, tips, common errors, regressions, progressions, alternatives and source/license links.
- A collapsed source/rights panel summarizing the reviewed datasets.
- The existing "Ver no 3D" action, using only the canonical primary/secondary muscle mapping.

## 6. Validation and acceptance

The following executable checks passed in this environment:

- 32 unique catalog slugs.
- All 14 existing anatomy muscle IDs represented by at least one exercise.
- All required guide fields present on the 32 records.
- Every source record has an allowed repository, URL and license label; Yuhonas records also have a valid 40-character Git blob SHA.
- All alternatives, regressions and progressions resolve to existing catalog slugs.
- All exercises referenced by the initial workout plans resolve and preserve names, equipment and muscle mappings.
- `EXERCISE_MUSCLE_MAP` is derived from the 32 canonical records and exposes copied arrays.
- Accent-insensitive search, alias lookup, guide-text search, muscle/equipment/level/category/mechanic filtering and the registry boundary pass targeted tests.

Commands used:

```bash
node --experimental-strip-types --loader ./scripts/ts-extension-loader.mjs scripts/check-exercise-muscle-contract.mjs
node --experimental-strip-types --loader ./scripts/ts-extension-loader.mjs scripts/check-exercise-library-search.mjs
```

## 7. Remaining data-quality gate

Bulk importing 1,324 items from hasaneyldrm or the full wger API should be a separate controlled ingestion step, not an automatic append. It must:

1. retain per-record source/license and translation provenance;
2. separate exercise text rights from image/GIF/video rights;
3. deduplicate by normalized exercise concept and variation, not only by name;
4. map only anatomically supported groups into the current 14 TITAN muscle IDs;
5. keep unrecognized source muscle groups as raw source metadata rather than forcing them into a false 3D mapping;
6. validate translations and step order before exposing records in the default catalog;
7. keep media disabled until commercial redistribution rights are documented.

The current 32-record library is fully integrated and validated; the remaining bulk source inventories are research candidates, not falsely represented as imported runtime data.
