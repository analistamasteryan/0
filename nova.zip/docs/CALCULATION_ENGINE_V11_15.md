# Motor de cálculos V11.15 — evidência, equações e limites

## Escopo desta revisão

Esta versão fortalece três áreas implementadas no código: (1) seleção explícita de equações de RMR, (2) gasto energético por MET com catálogo externo validado e proveniência/licença obrigatórias, e (3) calibração adaptativa por regressão robusta + filtro de Kalman. Também cria um contrato de integração para saídas de potência do OpenMetabolics, sem fingir que o modelo de sensores já está portado para o app React.

O TDEE inicial continua baseado no EER adulto NASEM 2023, pois EER é uma estimativa de necessidade energética diária que inclui atividade; RMR/BMR não deve ser multiplicado por fatores de atividade e apresentado como se fosse a mesma grandeza. A tela passou a rotular o valor Mifflin como `RMR est.`.

## 1. RMR inicial — equações selecionáveis

API: `estimateRestingMetabolicRate(input, method)` em `src/domains/profile/domain/rules/resting-metabolic-rate.ts`.

| Método | Fórmula kcal/dia | População / regra de uso |
|---|---|---|
| Mifflin–St Jeor | `10W + 6.25H − 5A + s` (`s=+5` masc.; `−161` fem.) | Padrão geral para adulto quando não há composição corporal confiável. |
| Pavlidou 2023 | Masc.: `9.65W + 573H(m) − 5.08A + 260`; fem.: `7.38W + 607H(m) − 2.31A + 43` | Estudo original: 722 adultos caucasianos, 173 homens e 549 mulheres. R² 0,95/0,86 no estudo não equivale a precisão individual nem validação externa para toda a população brasileira. Disponibilizada como opção, não como substituta universal de Mifflin. |
| Cunningham 1980 | `500 + 22 × FFM(kg)` | Requer FFM ou percentual de gordura informado, com origem da composição corporal declarada. Mais útil quando a composição corporal é medida com método identificado; não usar RFM/Navy como se fosse DXA/BodPod. |
| Katch–McArdle | `370 + 21.6 × FFM(kg)` | Também requer FFM ou percentual de gordura e origem declarada. |
| Ten Haaf 2014 | `11.936W + 587.728H(m) − 8.129A + 191.027S + 29.279` (`S=1` masc., `0` fem.) | Alternativa específica para adultos recreacionalmente ativos de 18–35 anos; não generalizar a sedentários ou atletas masters. |
| Calorimetria indireta | Valor informado no laudo | Sobrepõe qualquer equação quando o usuário fornece medição e unidade plausíveis; o app não realiza a medição. |

**Distinção:** Mifflin, Pavlidou, Cunningham e Ten Haaf estimam RMR/REE em contextos diferentes; não são medições de BMR em condições basais estritas. O motor não usa uma equação baseada em FFM sem FFM/percentual de gordura e origem declarada.

## 2. Exercícios manuais — motor MET com catálogo externo

API: `estimateActivityEnergy` em `src/domains/activity/domain/rules/activity-energy.ts`.

- O motor recebe MET e metadados da atividade; `validateActivityMetCatalog` valida código, faixa MET, idade, fonte, versão, URL HTTPS, presença do identificador de licença e status medido/estimado. A presença do identificador não é uma análise jurídica da licença; a compatibilidade precisa ser confirmada antes da distribuição.
- O Compendium 2024 não está embarcado: o artigo é CC BY-NC-ND 4.0, não MIT. O estudo lista 1.114 atividades (912 medidas, 202 estimadas) para adultos de 19–59 anos; uso/redistribuição comercial ou criação de derivados exige autorização adequada.
- Para embutir um catálogo no produto, selecionar fonte com licença compatível (CC0, CC BY ou licença comercial explícita) e preservar proveniência por linha.
- Energia bruta convencional: `kcal = MET × 3.5 × peso(kg) / 200 × minutos`.
- Energia líquida: energia bruta menos o RMR individual por minuto, quando disponível; sem RMR, subtrai o componente convencional de 1 MET.
- `compendiumCorrectedMet` reproduz o procedimento oficial da página do Compendium: ajusta o MET padrão pela RMR estimada com Harris–Benedict. `personalizedIntensityRatio` usa o RMR escolhido/medido no TITAN. Ambos são razões de intensidade, não são multiplicados novamente na equação de kcal. A própria página registra controvérsia sobre o nome “MET corrigido” e alerta que nem o MET padrão nem o corrigido substituem a medição direta.
- A estimativa continua populacional. MET não é calorimetria individual; técnica, terreno, eficiência, pausas, temperatura e aptidão podem alterar o gasto.

O motor não inventa valores MET nem distribui uma cópia transformada de um catálogo cuja licença não é compatível com o uso pretendido. Quando um catálogo licenciado for fornecido, a validação mantém a distinção entre valores medidos e estimados.

## 3. TDEE adaptativo — filtro robusto

API: `estimateAdaptiveTdee` em `src/domains/profile/domain/rules/adaptive-energy.ts`.

Pipeline:
1. Filtra dias de ingestão completos e valores plausíveis; dias explicitamente marcados como jejum completo entram como 0 kcal, dias parciais e dias sem registro são ignorados.
2. Consolida duplicatas do mesmo dia por mediana; dias diferentes entram na média aritmética.
3. Consolida pesagens do mesmo dia por mediana.
4. Usa janelas móveis de 28 dias, atualizadas a cada 7 dias.
5. Exige pelo menos 14 dias completos de ingestão, cobertura mínima de 60%, 4 dias de peso e amplitude de pelo menos 14 dias.
6. Estima a inclinação do peso por Theil–Sen para reduzir sensibilidade a pesagens extremas.
7. Estima TDEE observado: `ingestão média − 7.000 × inclinação de peso (kg/dia)`.
8. Atualiza um filtro escalar de Kalman; o ruído de processo permite deriva gradual e a variância da medição considera dispersão da ingestão, ruído residual do peso, piso sistemático e sobreposição das janelas.
9. Rejeita janelas extremamente discrepantes (gate de 4σ), registra aviso e mantém a estimativa anterior.
10. Devolve faixa baseada na variância interna do filtro, explicitamente marcada como não calibrada externamente. A classificação `confidence` representa cobertura/adequação dos dados, não confiança estatística ou clínica.

**Parâmetros de engenharia iniciais:** janela 28 dias; atualização semanal; 7.000 kcal/kg como aproximação local; ruído de ingestão de 250 kcal/dia; piso sistemático de 90 kcal/dia; piso de ruído de peso de 0,25 kg; ruído de processo de 80 kcal/√dia; inflação de variância 2× para janelas sobrepostas. Estes parâmetros são hipóteses de engenharia ajustadas por simulação sintética, não constantes fisiológicas universais. A referência OpenMacro usa janela de 14 dias, mínimo de 3 dias de ingestão, ruído de peso 0,6 kg, ruído de ingestão 350 kcal, processo 40 kcal/dia e overlap 0,5; reporta RMS 115 kcal em simulação própria de 200 perfis. Nosso filtro usa janela de 28 dias e atualizações semanais, portanto seu ruído de processo por raiz de dia não é diretamente comparável ao parâmetro diário deles.

**Simulação determinística:** `scripts/simulate-adaptive-energy.mjs` testa 200 perfis sintéticos, com ruído de peso de 0,6 kg, ruído de ingestão de 350 kcal e queda gradual de 200 kcal/dia no TDEE. Em 600 estimativas no período estável: RMSE 90,7 kcal, viés −0,2 kcal e cobertura da faixa 99,8%. Em 400 estimativas após a adaptação: RMSE 83,8 kcal, viés +29 kcal e cobertura 100%. As meias-larguras médias da faixa foram 385 e 319 kcal, respectivamente. Isso valida o comportamento sob as hipóteses simuladas, não a acurácia em pessoas reais.

**Limitações:** a faixa de 95% é uma banda de incerteza do modelo, ainda não calibrada contra calorimetria indireta ou água duplamente marcada. O filtro aprende gasto total observado e não separa automaticamente metabolismo basal, NEAT, exercício e termogênese adaptativa. O termo de 7.000 kcal/kg é uma aproximação; este módulo não implementa o modelo dinâmico completo Hall/NIDDK.

## 4. OpenMetabolics — contrato nativo, não ativação de sensor

O artigo/repositório de pesquisa OpenMetabolics usa acelerômetro + giroscópio, 50 Hz, smartphone no bolso, janelas de 4 s, filtro Butterworth de 4ª ordem com corte de 6 Hz, detecção de marcha e modelo XGBoost, além de correção de artefatos do bolso. O repositório de código declara MIT, mas o artigo científico está sob CC BY-NC-ND 4.0 (não comercial, sem obras derivadas). Antes de distribuir ou adaptar pesos/modelos treinados com os dados do estudo, é necessária análise de direitos; não presumimos que a licença MIT do código resolva a licença dos dados/modelos. O modelo está serializado em pickle/XGBoost e o pipeline depende de Python/NumPy/SciPy/scikit-learn/XGBoost. O treinamento foi feito com 36 participantes; a validação de caminhada real usou 28 pessoas e o piloto de uma semana, 10 pessoas.

A API `integrateOpenMetabolicsPower` valida e integra saídas de potência (W) vindas de um provedor nativo validado, converte `W × s / 4.184 (J por kcal)` em kcal e subtrai o baseline em pé fornecido pelo mesmo modelo/perfil fixado (o pipeline publicado usa Mifflin RMR × 1,41) para obter energia líquida. Ela **não** contém o modelo XGBoost, não captura sensores e não produz estimativa a partir de aceleração crua.

Por que não foi ativado como se estivesse pronto:
- O app atual é React/Vite web, não Flutter/Android nativo; o navegador não garante sensores de 50 Hz em background nem execução contínua com a tela bloqueada.
- O artigo reporta 18% de erro cumulativo em atividades reais e 13% em caminhada real (n=28); não significa 18% de erro para qualquer exercício ou população. O app Android de monitoramento foi usado em 10 participantes por uma semana. O repositório `OpenMetabolics_Application_Code` é um fork separado, tem 0 estrelas e não apresenta licença no nível raiz; seu `pubspec` inclui Amplify/Cognito/AWS e não foi incorporado.
- O repositório de código MIT disponibiliza modelos Python/pickle; não há artefato ONNX/JS validado para este app, e os direitos dos pesos/dados do estudo precisam ser avaliados separadamente.
- Um port requer teste de paridade de features e predições no mesmo conjunto de referência, validação por aparelho/posição e E2E em dispositivos físicos.

Portanto, o pilar de sensores fica preparado para integração nativa, mas não é apresentado como gasto energético já calculado pelo celular nesta versão.

## 5. Segurança e limites de uso

- Adultos apenas no fluxo atual; não aplicar equações a menores, gestantes ou lactantes.
- Não interpretar estimativas como diagnóstico ou prescrição clínica.
- RMR medido exige laudo e protocolo; FFM exige origem identificada.
- Não somar gasto de atividade manual com gasto do sensor para o mesmo intervalo; a camada de orquestração deve deduplicar sessões antes de consolidar TDEE.
- Não somar MET bruto ao TDEE inicial NASEM sem política explícita de contabilização de exercício, pois o EER já incorpora categoria de atividade. A camada atual entrega estimativas por sessão; não altera automaticamente a meta diária.

## Referências científicas e técnicas

1. Pavlidou E et al. (2023). *Revised Harris-Benedict Equation: New Human Resting Metabolic Rate Equation*. Metabolites 13(2):189. https://pmc.ncbi.nlm.nih.gov/articles/PMC9967803/
2. Frankenfield D et al. (2005). Mifflin-St Jeor validation literature; see original equation and subsequent systematic reviews.
3. ten Haaf T, Weijs PJM (2014). *Resting energy expenditure prediction in recreational athletes of 18–35 years*. PLOS ONE 9(10):e108460. https://pmc.ncbi.nlm.nih.gov/articles/PMC4183531/
4. *Accuracy of Resting Metabolic Rate Prediction Equations in Athletes: A Systematic Review with Meta-analysis* (2023). https://pmc.ncbi.nlm.nih.gov/articles/PMC10687135/
5. 2024 Adult Compendium of Physical Activities. https://pacompendium.com/adult-compendium/
6. Compendium corrected MET explanation (Harris–Benedict procedure and limitations). https://pacompendium.com/corrected-mets/
7. Hall KD et al. (2011). *Quantification of the effect of energy imbalance on bodyweight*. Lancet 378:826–837; NIDDK model overview https://www.niddk.nih.gov/research-funding/at-niddk/labs-branches/laboratory-biological-modeling/integrative-physiology-section/research/body-weight-planner
8. OpenMetabolics research code (MIT). https://github.com/Harvard-Slade-Lab/A-smartphone-activity-monitor-that-accurately-estimates-energy-expenditure
9. OpenMacro algorithms (MIT). https://github.com/SilverCrocus/OpenMacro/blob/main/docs/ALGORITHMS.md
10. llmn adaptive TDEE filter (MIT). https://github.com/ddarmon/llmn/blob/main/src/llmn/tracking/tdee_filter.py
