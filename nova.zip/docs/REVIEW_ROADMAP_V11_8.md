# TITAN HYDRATION V.MAX — Revisão de código e roadmap V11.8

**Base:** V11.7  
**Entrega:** V11.8 — correções funcionais e hardening local  
**Revisão:** 23/11/2026  
**Critério:** corrigir falsos dados e fluxos quebrados primeiro; adicionar dependências somente quando uma necessidade observável justificar a complexidade.

## 1. Veredito

A base técnica deve ser preservada. React 19, Vite, TypeScript strict, Zustand, Zod e Three.js formam uma stack coerente com o produto atual. A aplicação já separa domínios, usa lazy loading para telas e carrega o renderer 3D sob demanda. A prioridade não é uma reescrita de UI, migração de estado ou adoção imediata de React Three Fiber.

As principais lacunas de produto e qualidade são: estado inicial com dados fictícios, fluxo de treino sem histórico/reinício consistente, catálogo nutricional sem registro direto no diário, ausência de backup restaurável, cobertura insuficiente de testes de interface e falta de medições reais de performance.

## 2. O que foi corrigido nesta entrega — P0

| Área | Problema encontrado | Alteração V11.8 | Evidência local |
|---|---|---|---|
| Perfil | Valores hardcoded podiam parecer dados pessoais | `profileConfigured` explícito; botão e estado inicial informam configuração pendente | `profile-persistence.test.mjs` |
| Hidratação | Registros seed apareciam como ingestão real | Seed vazio e remoção de IDs demo antigos na migração | `hydration-persistence.test.mjs` |
| Evolução | Pesagens e circunferências fictícias alimentavam KPIs | Histórico inicial vazio, limpeza de IDs demo e estado vazio sem tendências fabricadas | `evolution-persistence.test.mjs` |
| Treino | O plano inicial possuía séries marcadas como concluídas e não reiniciava corretamente | Sementes neutras, reinício de ciclo e snapshots de sessões concluídas | `training-persistence.test.mjs` |
| Nutrição | Catálogo de alimentos era essencialmente consulta | Ação para registrar alimento, quantidade e refeição no dia selecionado | `food-diary.test.mjs` |
| Recuperação de dados | Sem cópia local restaurável no produto | Exportar/importar JSON com whitelist e rollback best-effort | `titan-backup.test.mjs` |
| Evolução | O gráfico de tendência referenciava sua própria variável durante a inicialização e podia falhar assim que havia dados; também espaçava métricas esparsas incorretamente | Regra pura de série extraída, referência circular removida, pontos posicionados conforme observações válidas e contagem contextualizada por métrica | `evolution-chart.test.mjs` |
| Arquitetura de domínio | Regras de Evolução/Perfil importavam tipos de um store Zustand | Contratos de medição e objetivo compartilhados; verificação de fronteira bloqueia dependência de regras sobre implementação do estado | `check-domain-boundaries.mjs` |
| Performance | Nenhuma forma simples de detectar renders caros por tela | `React.Profiler` em DEV, com limiar diagnóstico de 16,7 ms | verificação estática + callback revisado |

### Limites importantes desta implementação

- Os parâmetros iniciais de perfil ainda existem para manter compatibilidade com a lógica de metas, mas não são apresentados como medições observadas. A interface deixa claro que o usuário precisa configurá-los.
- O backup é manual e local. Não sincroniza, criptografa ou envia dados para um servidor. O usuário deve manter o JSON fora do dispositivo.
- O registro direto de alimentos não é ainda um editor completo de receitas/refeições com múltiplos ingredientes e templates.
- O histórico de treino guarda snapshot de até 100 sessões no dispositivo atual; ainda não é um histórico sincronizado ou um sistema completo de periodização.
- O Profiler só fornece diagnóstico de duração do render. Não substitui medição de carregamento, interação, memória, FPS ou benchmark em dispositivos reais.

## 3. Próxima implementação, em ordem de prioridade

| Prioridade | Implementação | Por que agora | Critério de aceite |
|---|---|---|---|
| **P0 — próxima** | Testes de UI e E2E dos fluxos críticos | As regressões mais perigosas atravessam telas, store, navegação e persistência; testes puros não exercitam essas integrações | Playwright testa perfil, diário, treino, evolução, exportação/restauração e refresh; CI roda Chromium e ao menos um segundo engine em nightly |
| **P0 — próxima** | Testes de componentes e acessibilidade | BottomSheet e interações de formulário precisam ser testados como usuário, inclusive teclado e leitores de tela | RTL + axe-core nos componentes críticos; zero violações WCAG A/AA automáticas sem exceção documentada |
| **P1** | Editor de fichas de treino | Hoje existem apenas duas rotinas iniciais e não há fluxo completo para montar, duplicar, ordenar ou editar exercícios e séries | CRUD de planos/exercícios/séries; validação Zod; teste de progressão; histórico imutável |
| **P1** | Editor de refeições e receitas | Registrar um alimento resolve a entrada básica, mas não permite montar refeições compostas nem ajustar ingredientes/porções em lote | adicionar/remover ingrediente, quantidade em gramas, recalcular nutrientes, duplicar refeição, salvar receita pessoal e aplicar no diário |
| **P1** | Qualidade dos dados de perfil e medição | Os indicadores dependem de dados corretos e precisam distinguir valores observados, metas e estimativas | proveniência por campo, datas de medição, confirmação de perfil e rótulos de estimativa em todo o produto |
| **P2** | Persistência IndexedDB para crescimento offline | localStorage é síncrono, limitado e pouco adequado a histórico crescente e grandes catálogos | só migrar quando benchmark/cotas justificarem; transações, versionamento, migração reversível, teste de corrupção e recuperação |
| **P2** | Rotas URL, deep links e browser history | A navegação atual é estado local Zustand, sem URLs recuperáveis ou navegação nativa de voltar/avançar | rotas estáveis para cada tela, refresh seguro, back/forward e testes E2E; evitar adicionar router se a navegação continuar simples e sem demanda |
| **P2** | Observabilidade e recuperação | Error reporter é apenas memória local; não há telemetria persistente/operacional conectada | captura de erro com consentimento, redaction, contexto da versão, fila offline com retry e política de retenção; dashboards e alertas |
| **P2 — condicional** | Conta e sincronização entre dispositivos | Só faz sentido após modelo de identidade, privacidade, consentimento, conflitos e política de backup | autenticação, RLS obrigatória, criptografia em trânsito, resolução de conflitos, exportação e exclusão de conta/dados testadas |
| **P2** | Consolidar integrações API atualmente sem consumidor | `http-client`, `sync-queue`, `event-tracker` e rotas de API existem como scaffolding sem fluxo de produto integral | ou conectar a caso de uso com contrato/testes, ou remover; não manter infraestrutura sem consumidor |
| **P3** | Atlas anatômico com malhas reais | O modelo atual é procedural e útil à interação, mas não é atlas médico validado | subset com proveniência, direitos/licença, atribuição, correspondência aos 14 grupos e QA visual/móvel antes de integrar |
| **P3** | Otimização estrutural de módulos grandes | Arquivos longos não provam lentidão; separar sem medir pode aumentar acoplamento e retrabalho | perfis React/Vite, chunks, memória e FPS antes/depois; refatorar apenas onde há gargalo ou fronteira de domínio real |

## 4. Repositórios recomendados por função

Os números de estrelas abaixo são snapshots aproximados de GitHub em 23/11/2026. Estrelas indicam adoção, não qualidade, segurança ou compatibilidade. A licença deve ser revisada para cada uso; nenhum código externo foi copiado para esta entrega.

| Repositório | Stars aprox. | Licença | Usar para | Decisão |
|---|---:|---|---|---|
| [microsoft/playwright](https://github.com/microsoft/playwright) | 100,8k | Apache-2.0 | E2E cross-browser e fluxo real da aplicação | **Adotar P0** |
| [alan2207/bulletproof-react](https://github.com/alan2207/bulletproof-react) | 36k | MIT | Organização de features, fronteiras, estado, testes e práticas React | **Usar como referência**, não copiar a estrutura indiscriminadamente |
| [testing-library/react-testing-library](https://github.com/testing-library/react-testing-library) | 19,7k | MIT | Testes de componentes próximos ao uso real | **Adotar P0** |
| [vitest-dev/vitest](https://github.com/vitest-dev/vitest) | 17,4k | MIT | Testes unitários/componentes integrados ao Vite | **Adotar com RTL no P0**, após ambiente de dependências/lock |
| [dequelabs/axe-core](https://github.com/dequelabs/axe-core) | 7,9k | MPL-2.0 | Auditoria automatizada de acessibilidade | **Adotar P0**, revisar obrigações MPL antes de distribuir integração |
| [dexie/Dexie.js](https://github.com/dexie/Dexie.js) | 14,7k | Apache-2.0 | Abstração e transações IndexedDB | **P2**, só após benchmark provar necessidade |
| [react-hook-form/react-hook-form](https://github.com/react-hook-form/react-hook-form) | 44,9k | MIT | Formulários complexos e subscriptions por campo | **P1 condicional**, ao criar builder com vários campos; manter Zod |
| [TanStack/query](https://github.com/TanStack/query) | 50,6k | MIT | Cache, retries e invalidação de server state | **P2 condicional**, quando houver API remota de verdade |
| [pmndrs/zustand](https://github.com/pmndrs/zustand) | 59k | MIT | Estado local e stores por domínio | **Manter**; já está instalado e adequado |
| [remix-run/react-router](https://github.com/remix-run/react-router) | 56,6k | MIT | URL, rotas aninhadas e browser history | **P2 condicional**, quando deep links forem requisito |
| [TanStack/router](https://github.com/TanStack/router) | 15,3k | MIT | Alternativa tipada para roteamento | Não instalar em paralelo com React Router |
| [react-scan](https://github.com/aidenybai/react-scan) | 21,9k | MIT | Diagnóstico de re-render no desenvolvimento | Ferramenta de diagnóstico opcional; primeiro usar React Profiler e medir |

### Por que não adicionar algumas bibliotecas agora

- **Não trocar Zustand:** já resolve o estado client-side. TanStack Query trata server state, não é substituto.
- **Não adicionar TanStack Query:** as rotas Express e `http-client` não têm consumidores no cliente; não há fluxo remoto ativo que justifique cache/mutation orchestration.
- **Não trocar a navegação por router imediatamente:** quatro destinos de topo e subviews locais não justificam migração isolada; fazer quando URL/deep links forem requisito.
- **Não adicionar React Hook Form já:** o perfil e os formulários atuais ainda podem usar o fluxo validado com Zod. O builder de rotina/receita é o gatilho para reavaliar.
- **Não migrar Three.js para React Three Fiber:** renderer imperativo já tem carregamento lazy e ciclo de vida controlado. Uma mudança teria custo alto sem evidência de ganho.
- **Não aplicar `memo`, `useMemo` ou React Compiler globalmente:** medir renders/commits primeiro. Profiler tem overhead; serve para localizar problemas, não é benchmark de produção.

## 5. Plano de performance mensurável

Antes de refatorar componentes grandes, recolher baseline no mesmo dispositivo e perfil de build:

1. Lighthouse em mobile (cold start e navegação após cache): LCP, INP, CLS e tamanho dos chunks.
2. React DevTools Profiler / `<Profiler>`: componentes com `actualDuration` elevada e commits repetidos; registrar interações representativas.
3. Três cenários 3D: entrada inicial, troca de grupo muscular, interação contínua; medir FPS mediano/p10, memória e tempo de dispose.
4. Vite `--profile` e análise de bundle: transformação, plugins, imports e chunks; lazy-load de rotas pesadas.
5. Critério: otimização só entra se melhora uma métrica, sem regressão visual, de acessibilidade, comportamento ou bundle relevante.

Arquivos extensos já identificados para análise focada: `fluid-shader-engine.ts`, `tbca-adapter.ts`, `HydrationSummary.tsx`, `anatomy-renderer.ts`, `build-anatomy-body.ts` e `EvolutionScreen.tsx`. Comprimento isolado não é defeito nem justificativa para fragmentação.

## 6. Cobertura e limites desta validação

### Passou nesta sessão

- Testes puros de data local, safe storage, calendário, perfil, evolução, hidratação, treino, diário de alimentos, backup e persistência nutricional.
- Teste de validação de séries de treino.
- Verificações estáticas de fronteiras de domínio, semântica do cockpit, design system, contrato de 14 grupos anatômicos e hardening React/runtime.

### Não foi possível homologar nesta sessão

- `npm test`, `npm run lint`, `npm run build` e testes em browser: a cópia de trabalho não contém `node_modules`, e Bun não está instalado neste ambiente. O projeto usa Bun lockfile e TypeScript 7.0.2; o compilador global disponível é 5.8.3, portanto não é substituto válido para o typecheck da versão declarada.
- Não há baseline Lighthouse/FPS de dispositivo real.
- Não houve teste de assistive technology real nem E2E visual.

A entrega está **validada pelos testes de domínio/persistência e verificações estáticas executáveis**, mas não deve ser descrita como build de produção ou release homologada antes do CI completo e dos testes de browser.

## 7. Referências principais

- React Profiler: https://react.dev/reference/react/Profiler
- Vite performance guide: https://vite.dev/guide/performance
- Playwright: https://github.com/microsoft/playwright
- React Testing Library: https://github.com/testing-library/react-testing-library
- Vitest: https://github.com/vitest-dev/vitest
- Bulletproof React: https://github.com/alan2207/bulletproof-react
- axe-core: https://github.com/dequelabs/axe-core
- Dexie: https://github.com/dexie/Dexie.js
- React Hook Form: https://github.com/react-hook-form/react-hook-form
- TanStack Query: https://github.com/TanStack/query
- Zustand: https://github.com/pmndrs/zustand
- React Router: https://github.com/remix-run/react-router
