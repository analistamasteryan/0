# TITAN V.MAX — Product Visual Direction & Component Audit V7

**Direction:** quiet luxury, anatomical intelligence and measurable performance.

**Implementation base:** V6, with its training, nutrition, hydration, anatomy store, fluid shader engine and on-demand 3D controller preserved.

## 1. The product's visual promise

TITAN should not resemble a generic workout tracker, a clinical patient portal, a sci-fi hologram console or a financial dashboard. It is a body-performance system that helps users understand their body, execute training, make nutrition decisions, hydrate and inspect real changes over time.

The visual hierarchy follows the product's information hierarchy:

1. **Body understanding:** anatomy is the cockpit's protagonist.
2. **Daily state:** energy and macros explain the nutritional state.
3. **Action:** workout and hydration make the next useful action easy to find.
4. **Context:** next meal and micronutrients support better decisions.
5. **Evidence:** evolution presents the measurements actually recorded.

The same hierarchy must survive responsive layouts; on mobile the model remains prominent, with controls outside the canvas and the bottom navigation kept in the thumb zone.

## 2. Psychological and perceptual color decisions

The current research supports careful, contextual use of color, not universal claims that a particular hue always causes a fixed feeling. A 2025 systematic review of 132 studies across 42,266 participants and 64 countries found systematic color–emotion associations, moderated by hue, lightness and saturation. It also stresses that abstract associations are not proof of emotional effects in a particular interface or health context.

| Color family | Product job | Desired perceptual role | Constraint |
|---|---|---|---|
| Obsidian | Page canvas and deep inset | Visual focus and material depth | Dark backgrounds are not automatically calming; maintain high-value foreground contrast |
| Graphite | Card/surface layering | Quiet grouping without heavy outlines | Surfaces must remain distinguishable at a glance |
| Ceramic | Main metrics, titles and body text | Clarity and editorial prominence | Do not use pure white everywhere |
| Mist | Supporting copy | Calm secondary hierarchy | Never make essential instructions too dim |
| Mineral Sage | Primary identity and primary action | Low-saturation brand anchor, visually coherent with the health/performance domain | Do not overload every positive or active state with Sage |
| Mineral Blue | Hydration and information | Cool informational category distinct from brand | Don't use for non-informational selection or macro fat |
| Copper | Fat macro category | Warm data-category distinction | Not a warning color |
| Champagne | Small brand/detail accent | Distinctive finish and focal detail | Not a universal status color; avoid broad gold gradients |
| Coral/error | Genuine error or exceeded limit | Urgency and correction | Always pair with text/icon/state, never color alone |

### Practical conclusion

The Obsidian + Champagne direction is preserved, but Sage remains the main interface accent. Champagne is sparse. Mineral Blue stays assigned to hydration/information; Copper becomes the fat-macro category. The water renderer has its own deep/mid/light/edge material palette. Scientific molecular colors remain a separate domain palette.

## 3. What changed in V7

### 3.1 Design system

- Rebuilt the primitive/semantic palette around Obsidian, Graphite, Ceramic, Mist, Sage, Champagne, Mineral Blue and Copper.
- Added separate water material tokens, data-category roles and status roles.
- Added typography, spacing, radius, elevation and motion token groups.
- Distinguished resting, raised, elevated, hero and inset surfaces.
- Kept 2D UI colors separate from anatomy shader colors.
- Added a contrast gate for primary/secondary/muted and semantic text colors against each dark surface.

### 3.2 Cockpit and anatomy

- Promoted the anatomy viewport to the first and largest cockpit region.
- Removed the bright projector cone and reduced the plinth to two quiet mineral rings plus its low-cost contact shadow.
- Replaced neon cyan shell/rim and high-frequency scanline emphasis with mineral-sage materials, quieter line work, reduced fiber modulation and a fixed low-cost directional/specular response.
- Kept the existing procedural geometry, shared material resources, merge/batch architecture, shader mask and demand rendering.
- Connected direct pointer picking to the existing `MusclePicker` and `onMusclePick` state callback; a six-pixel movement threshold avoids treating camera drags as taps.
- The picker ignores hidden ancestor layers so a hidden structure cannot be selected through a visible layer.
- Kept the accessible muscle list as the keyboard/screen-reader selection path.
- Selection remains a one-shot bounded sweep and respects reduced-motion preference.

**Honest fidelity boundary:** this improves lighting, material response and interaction, but does not convert the current procedural lofted body into a detailed atlas. A licensed BodyParts3D/Z-Anatomy pipeline is a separate asset and mapping project. No third-party anatomy mesh is bundled in V7 because mesh provenance, per-asset license, commercial compatibility, file size and mesh-to-muscle mapping must all be reviewed before shipping.

### 3.3 Energy, macros and hydration

- Energy's main numeric value receives a display hierarchy; the fluid bar remains supporting context.
- Macro values are enlarged slightly while arcs remain subordinate; Copper now identifies fat, not brand or warning status.
- Water-specific variables distinguish deep fluid, reflected midtone, highlight and edge.
- Existing fluid renderer, wave math, differential caustics and shared render context remain unchanged.

### 3.4 Nutrition and meal imagery

- Increased next-meal and cardápio thumbnails from small utility squares to editorial-scale images.
- Added lazy loading and asynchronous decoding to list images.
- Kept the full meal image in the detail sheet.
- Kept nutrition macro colors semantically distinct: protein Sage, carbs Blue, fat Copper, energy Ceramic.

### 3.5 Workout

- The current plan in the training home receives a clear raised/focus treatment, while other plans remain resting surfaces.
- Active exercise presentation receives stronger content hierarchy without changing set/session behavior.
- The existing isolated rest-timer subtree remains isolated; frequent timer ticks do not rerender the entire exercise list.

### 3.6 Evolution

- Added a native SVG time-series selector for weight, waist, arm and thigh.
- The chart uses only saved records and shows source date labels, real values and the actual range. It does not smooth, interpolate or project values.
- Newly submitted measurements receive a local date label rather than a permanent “HOJE” label.
- Arm/thigh deltas are no longer automatically green; direction alone is not evidence of improvement.

## 4. Component intention matrix

| Component | Primary intention | Visual hierarchy | Main risk removed / reduced |
|---|---|---|---|
| HomeHeader | Orient the day and expose date/goals | Date and brand first; controls second | Utility header competing with app identity |
| AnatomyViewport | Spatially explore muscle/body structures | Anatomical figure first; controls and list outside canvas | Sci-fi HUD, over-bright cyan, unselectable canvas meshes |
| EnergySummary | Understand energy against goal | Large consumed value, goal/difference, then fluid bar | Progress decoration overpowering the value |
| MacroOverview | Compare three nutrient categories | Values/remaining first; metallic arcs second | Arc visual dominates actual grams, fat color confused with warning |
| HydrationSummary | Record and inspect water | Volume and amount first; fluid tank as representation | Hard-coded water color spread and excessive decorative gradients |
| TodayWorkout | Execute the planned session | Plan title, action, completed sets, timer | List density and rest timer rerender noise |
| NextMeal | Choose/confirm the next meal | Food image and meal title first; macros second | Tiny image fails to communicate the food visually |
| MicronutrientSummary | Review adequacy/limits | Nutrient name/amount/status first; chemistry and contributions expanded | Warm macro brand accent used as nutrient warning by accident |
| MolecularStructure | Add useful molecular context | Nutrient identity and chemistry | Molecule treated as unrelated decoration; palette remains scientific/domain-specific |
| CardapioScreen | Plan and record meals | Day summary then meal imagery/actions | Small thumbnails and weak page-level hierarchy |
| TrainingHomeScreen | Choose/continue program | Current plan receives clearer focus | All programs appearing equally important |
| ActiveWorkoutScreen | Execute sets without distraction | Current exercise, set editor, timer, sequence | Secondary exercise rows competing with execution |
| ExerciseLibraryScreen | Find movement and inspect target muscles | Search, movement name, muscles, 3D action | Search and 3D action lack consistent focus treatment |
| EvolutionScreen | Inspect measured changes over time | Comparative state, observed trend, KPIs, recording/history | Delta colors implying improvement without contextual evidence |
| ActionSheet/BottomSheet | Complete contextual action | One primary action, concise options | Gradient-heavy surfaces and unclear surface hierarchy |
| AppShell navigation | Orient and move between main areas | Current tab marked discreetly | Pill-heavy or decorative navigation competing with content |

## 5. What is deliberately not added

- No new React component framework.
- No Recharts or Visx dependency for a single line-chart family.
- No motion framework migration; Motion is already available, but no decorative stagger pass was added.
- No full Three.js postprocessing, bloom, depth-of-field or shadow-map stack.
- No full-scene MeshTransmissionMaterial.
- No unverified anatomical GLB or licensed dataset baked into the app.
- No claims of 9.5/10 before GPU screenshots, device review and user-level visual approval.

## 6. Remaining gates to call the product 9.5/10

1. GPU/browser screenshots at 390, 768 and 1440 CSS px, including reduced-motion and WebGL fallback.
2. Human visual review of anatomy silhouette and lighting; V7 shader cannot compensate for the current procedural geometry's anatomical detail ceiling.
3. Real source photography quality and crop review across the complete meal catalog.
4. Full screen review of active workout, cardápio, exercise library, micronutrients, sheets and navigation—not only cockpit.
5. axe-core/browser accessibility run and keyboard/touch manual pass.
6. If a detailed atlas is required, asset-level license/provenance, mesh segmentation, memory/file-size and draw-call benchmark before integration.

V7 is a significant visual-system and interaction upgrade, not a certified 9.5 visual approval. The quality score remains a target until these gates are passed.

## 7. Ajustes de acabamento após a primeira implementação

- A navegação inferior, os controles segmentados e os rótulos do gráfico usam agora uma base legível de 12 px; 10 px fica reservado a pequenos eyebrows/status que não carregam instruções essenciais.
- Os deltas de peso e cintura permanecem neutros no KPI: a direção numérica isolada não demonstra sucesso ou fracasso. A indicação semântica de meta fica no resumo comparativo, onde há contexto explícito.
- O `body` deixou de carregar cores de seleção antigas hardcoded no HTML e passa a respeitar o contrato do CSS global.
- O componente de anatomia mantém instruções acessíveis e lista alternativa; o canvas 3D não é a única forma de selecionar um grupo muscular.
- Surface hierarchy now has three distinct states: inset/flat (`elevation=0`) for dense KPI groups, resting (`elevation=1`) for ordinary content, and raised (`elevation=2`) for the active plan, workout focus and anatomical hero.
- Bottom sheets and the water-registration action now use solid semantic surfaces rather than a decorative gradient; the remaining fluid gradients are kept because they depict optical depth/reflection, not generic card decoration.
- Date cells, rest-timer actions and set confirmation controls retain a 44 px touch target and visible keyboard focus.
