# Walkthrough — Motor Nutricional TITAN & Componente de Hidratação (V11.36)

# Security Summary

- **Sanitização de entrada e persistência JSON**: Tanto o módulo de restauração de backup (`src/app-core/backup/titan-backup.ts`) quanto o script de importação USDA (`scripts/import-usda-fdc.mjs`) utilizam parsing defensivo que descarta propriedades reservadas (`__proto__`, `constructor`, `prototype`) antes de hidratar objetos em memória.
- **Validação de parâmetros CLI e integridade de dados**: O importador USDA rejeita marcadores isolados de fim de flags (`--`), valida compatibilidade de unidades/identificadores de vitamina B3/NE e bloqueia overflows ou incompatibilidades numéricas antes de gravar no catálogo.
- **Isolamento do solver em Web Worker e segurança de concorrência**: O cliente de otimização (`composer-optimizer-client.ts`) aplica timeout, trata falhas de desserialização (`onmessageerror`) e evita estado travado; no componente React (`CardapioComposer.tsx`), um contador sequencial descarta respostas obsoletas de otimizações anteriores.
- **Limites explícitos de elegibilidade e exposição clínica**: Preparações compostas não são aceitas como ingredientes de novas receitas no solver, nas substituições discretas nem nos seletores de interface, e limites superiores (UL) distinguem exposição alimentar total de exposição restrita a suplementação.

## PoC Verification

1. **Verificação real do solver HiGHS WASM (QP + MIP)**:
   - Comando: `npx tsx src/domains/nutrition/components/cardapio-composer/__tests__/highs-solver.test.ts`
   - Resultado: `PASSED { qpEngine: 'HiGHS QP (WASM)', certificate: 'optimal', durationMs: 107.58, mipSwaps: 1 }`
2. **Auditorias e testes de endurecimento nutricional**:
   - `npm run test:nutrition-hardening` → passou (incluindo `ul-scope`, `supplement-intake`, `food-ingredient-policy`, `tbca-ingredient-integrity`, `tbca-recipe-guard` e auditoria `5830 TBCA: 2717 ALIMENTO / 3113 PREPARACAO_COMPOSTA`).
   - `npm run test:review` e `bun run test:usda-import-cli` → concluídos com status 0.
3. **Hidratação Liquid Glass (layout, shaders e estabilidade mobile)**:
   - Botões de desfazer e `+` reposicionados internamente no cabeçalho superior direito do cartão, mantendo área clicável `44x44` e `aria-label="Registrar água"`.
   - `npx tsx src/domains/hydration/__tests__/hydration-store.test.ts`, `npx tsx src/domains/cockpit/__tests__/cockpit-integration.test.ts`, `npx tsx src/shared/graphics/__tests__/fluid-shader-engine.test.ts`, `node scripts/check-fluid-shaders.mjs` e `npm run test:rendering-v11-23` → todos aprovados com status 0.
4. **Typecheck e build de produção**:
   - `bun run typecheck:calculations` e `bun run build` (`vite build`) → concluídos sem erros em `1.44s`.
