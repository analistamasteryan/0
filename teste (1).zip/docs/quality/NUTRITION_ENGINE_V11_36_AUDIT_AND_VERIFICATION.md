# Auditoria e Verificação — Motor Nutricional TITAN & Cena Liquid Glass (V11.36)

## 1. Baseline Real e Identidade (SHA-256)
- **Pacote**: `titan-hydration-vmax`
- **Versão (`package.json`)**: `11.35.0` (sem repositório Git anexado no ambiente; validação feita sobre a árvore ativa)
- **Checksums SHA-256 verificados em disco**:
  - `package.json`: `f1ad2c49c28dff2bf8f3807b2bce23152cac304d583bd7aab207f016c6c8e763`
  - `bun.lock`: `564960afea4368eebba7402c1376d0c43d1b1af0ef07614d0b41df9fbaf3709e`
  - `src/domains/nutrition/data/sources/tbca-catalog.compact.json`: `10a83ac4d079a37fdfa5ee43ba3eeac8ee37716c2aaa416b272869051d5ced3e`
  - `src/domains/nutrition/data/sources/tbca-catalog.manifest.json`: `f5967562e593e1ed0884f4f4eb9e81275a0f5d5f33f01e40685be8f2a9660376`
  - `src/domains/nutrition/data/sources/usda-fdc-catalog.foundation.generated.ts`: `4e51f787045fb694a1985a19f21b72a85b20c8e0866bb23c5a171096601e58d11`

## 2. Inventário Técnico do Catálogo e Elegibilidade
- **Cobertura consolidada (`docs/research/NUTRIENT_COVERAGE_ALL_SOURCES_V11_35.json`)**:
  - Total de registros no catálogo runtime: **6.199** (`TBCA`: 5.830, `USDA_FDC`: 364 Foundation imported, `OPEN_FOOD_FACTS`: 2, `TITAN_LEGACY`: 3).
- **Auditoria TBCA (`docs/research/TBCA_INGREDIENT_ELIGIBILITY_AUDIT_V11_35.json`)**:
  - Total TBCA: **5.830**; `ALIMENTO`: **2.717**; `PREPARACAO_COMPOSTA`: **3.113** (53,4%); `UNKNOWN`: **0**.
- **Catálogo de receitas (`audit-recipe-catalog-eligibility.mjs`)**:
  - **2 de 8** templates elegíveis; **6** bloqueados por conterem preparações legadas (`rec-cafe-completo`, `rec-almoco-frango`, `rec-jantar-salmao`, `rec-sub-frango-leve`, `rec-sub-salmao-power`, `rec-sub-sanduiche-ovos`).

## 3. Alterações Implementadas neste Ciclo (V11.36)

### 3.1 Motor Nutricional, Solver e Hardening de Runtime
1. **Elegibilidade `isEligibleRecipeTemplate` ponta a ponta**:
   - Aplicado no solver HiGHS (`src/domains/nutrition/application/highs-nutrition-solver.ts`), nas substituições discretas (`src/domains/nutrition/domain/rules/cardapio-composer-engine.ts`), nos seletores de receitas (`MealCompositionLanes.tsx`, `RecipeProportionMatrix.tsx`).
2. **Escopo de UL e exposição por suplementação**:
   - Subtração de suplementação compatível quando `upperLimitScope === 'total_intake'` em `nutrition-calculator.ts` e preservação de `upperLimitScope === null` sem assumir `'supplements_only'` por padrão.
   - Passagem explícita de `upperLimitScope ?? 'total_intake'` em `SupplementMicronutrientPanel.tsx`.
   - Passagem de `supplementMicronutrientIntakes` no `CardapioComposer.tsx`.
3. **Confiabilidade do Worker HiGHS e concorrência React**:
   - Timeout explícito, handler `onmessageerror`, recuperação não-pegajosa (`workerUnavailable`) e utilitário de reset em `composer-optimizer-client.ts`.
   - Sequenciador monotônico de requisições (`optimizationRequestSeqRef`) e reset limpo de `isOptimizing` em `CardapioComposer.tsx`.
4. **Sanitização de JSON / importação e backup**:
   - `safeJsonParse` com bloqueio de chaves reservadas (`__proto__`, `constructor`, `prototype`) em `src/app-core/backup/titan-backup.ts`.
   - Rejeição de `--` isolado e reviver protetor de chaves em `scripts/import-usda-fdc.mjs`.
5. **Alinhamento do teste de integração do Cockpit**:
   - Atualização de `src/domains/cockpit/__tests__/cockpit-integration.test.ts` para refletir o alias canônico TBCA 7.2 `tbca-ovo-mexido -> tbca:BRC0065J` (`vitamin_c = 0 mg quantified`, `vitamin_k = not_analyzed` distinto de `missing` do Open Food Facts).

### 3.2 Hidratação Liquid Glass (Layout, Realismo Óptico e Performance Mobile)
1. **Botões internos no cabeçalho superior direito e CTA `+` puro**:
   - Botões de desfazer e registro movidos para dentro do cartão `HydrationSummary.tsx` no canto superior direito (`z-[3]`), com botão quadrado `44x44` contendo apenas o ícone `<Plus />` (mantendo `aria-label="Registrar água"`).
2. **Realismo da água na gota 3D e na barra de cristal**:
   - Ajuste da absorção espectral Beer-Lambert (`attenuationColor: [0.10, 0.62, 0.88]`), redução de fontes de luz brancas saturadas no estúdio óptico e calibragem de Fresnel/menisco para eliminar aspecto esbranquiçado na gota e tornar o volume líquido dentro da barra claramente visível mesmo em repouso.
   - Preservação de ondulação contínua e energia de partículas sem teletransporte de gotículas (`hydration-fluid-solver.ts`).
3. **Estabilidade visual e performance mobile**:
   - Remoção de `desynchronized: true` no canvas 2D e substituição do blit por `globalCompositeOperation = 'copy'` para eliminar piscadas de composição; redução de `backdrop-filter` pesado, remoção de `blur-xl` decorativo redundante, teto de DPR mobile (`1.5`), guarda de `ResizeObserver` por dimensões alteradas e redução de taps de bloom no tonemap.

## 4. Matriz de Verificação Real (Comandos e Saídas Observadas)

| Verificação | Comando executado | Resultado observado | Status |
| :--- | :--- | :--- | :--- |
| Solver HiGHS WASM real | `npx tsx src/domains/nutrition/components/cardapio-composer/__tests__/highs-solver.test.ts` | `PASSED { qpEngine: 'HiGHS QP (WASM)', certificate: 'optimal', durationMs: 107.58, mipSwaps: 1 }` | `runtime-verified` |
| Endurecimento nutricional & TBCA/USDA/UL | `npm run test:nutrition-hardening` | Todos os subtestes (`ul-scope`, `supplement-intake`, `food-ingredient-policy`, `tbca-ingredient-integrity`, `tbca-recipe-guard`, `usda-fdc-adapter`, auditorias) com saída 0 | `tested` |
| Qualidade de dados & macros (5.833 TBCA) | `npm run test:nutrition-data-quality` | 5.833 entradas verificadas, 1 registro quarentenado, políticas e busca OK | `tested` |
| Domínio de energia (1.071.840 combinações) | `npm run test:energy-budget-boundaries` | `minimum TDEE-RMR margin 167 kcal`; exit 0 | `tested` |
| Suíte de revisão completa (`test:review`) | `npm run test:review` | Persistência, backup, calendário, calorimetria adaptativa, simulações Hall 2011, Kalman, METs, hardening React e nutrição passaram (exit 0) | `tested` |
| CLI USDA (fixture sintética) | `bun run test:usda-import-cli` | `USDA FDC CLI integration tests passed (synthetic fixture only; no production dataset imported).` | `tested` |
| Cockpit, Hidratação e Shaders V11.23 | `tsx hydration-store.test.ts && cockpit-integration.test.ts && fluid-shader-engine.test.ts && check-fluid-shaders.mjs && check-cockpit-visual-semantics.mjs && npm run test:rendering-v11-23` | Menisco Young–Laplace, conservação de massa das gotas, projeção IC(0)-PCG, semântica de meta e contratos GLSL passaram (exit 0) | `tested` |
| Typecheck estrito de cálculos | `bun run typecheck:calculations` | `tsc -p tsconfig.calc-review.json` concluído com exit 0 | `runtime-verified` |
| Build de produção Vite | `bun run build` | `✓ built in 1.44s`, bundle WASM HiGHS e chunks gerados (exit 0) | `runtime-verified` |

> **Observação sobre script legado pré-existente**: `scripts/check-titan-design-system.mjs` (não alterado neste ciclo) ainda verifica nomes internos antigos do construtor procedural de anatomia (`smoothCrossSections`/`addShellEllipsoid`) que já foram substituídos anteriormente no módulo de anatomia por malha esculpida canônica (`buildEvaluatedHumanMeshGeometries`).

## 5. Classificação P0 / P1 / P2 e Bloqueios Externos
- **P0 — Concluído no código e testado**: elegibilidade de ingredientes (`ALIMENTO` vs `PREPARACAO_COMPOSTA`), preservação de aliases e proveniência, importador e validação de B3/NE, regras UL e suplementação, Worker HiGHS e sanitização de JSON.
- **Bloqueios externos mantidos (sem contorno indevido)**:
  1. **Licenciamento TBCA 7.3**: mantida base local **TBCA 7.2** até autorização formal de uso e redistribuição para 7.3.
  2. **USDA SR Legacy / FNDDS / Branded em volume completo**: CLI pronta e testada em fixture sintética; o catálogo runtime atual contém 364 alimentos **USDA Foundation** já validados, aguardando decisão de escopo/volume para ingestão completa de SR Legacy/FNDDS.
  3. **Validação clínica por nutricionista (RDN) e auditoria de acessibilidade/tela em dispositivo físico**: pendente fora deste ambiente automatizado.

## 6. Auto-revisão (Self-Review)
Esta auditoria e as correções aplicadas passaram exclusivamente por **auto-revisão do agente executor** apoiada por suítes determinísticas automatizadas, checagem de tipos e build de produção; **não houve revisão independente por terceiro**.
