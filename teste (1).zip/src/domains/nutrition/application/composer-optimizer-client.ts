import type {
  ComposerDayPlan,
  DiscreteCombinationProposal,
  DiscreteSubstitutionProposal,
  NutritionTargets,
  OptimizationProposal,
} from '../domain/entities/nutrient';
import {
  proposeDiscreteSubstitutions,
  solveNutritionalBalanceQP,
  type OptimizeBalanceOptions,
} from '../domain/rules/cardapio-composer-engine';
import type {
  OptimizerWorkerRequest,
  OptimizerWorkerResponse,
} from './composer-optimizer.worker';

const DEFAULT_OPTIMIZER_TIMEOUT_MS = 12_000;

let sharedWorker: Worker | null = null;
let workerUnavailable = false;
let nextRequestId = 1;

const pendingRequests = new Map<
  number,
  {
    resolve: (result: Omit<OptimizerWorkerResponse, 'requestId'>) => void;
    reject: (reason: Error) => void;
    timer: ReturnType<typeof setTimeout>;
  }
>();

function teardownWorkerWithError(worker: Worker, message: string): void {
  for (const [, pending] of pendingRequests) {
    clearTimeout(pending.timer);
    pending.reject(new Error(message));
  }
  pendingRequests.clear();
  try {
    worker.terminate();
  } catch {
    // Worker already terminated
  }
  if (sharedWorker === worker) {
    sharedWorker = null;
  }
}

export function resetComposerOptimizerClientForTests(): void {
  for (const [, pending] of pendingRequests) {
    clearTimeout(pending.timer);
    pending.reject(new Error('Worker reiniciado para testes.'));
  }
  pendingRequests.clear();
  if (sharedWorker) {
    try {
      sharedWorker.terminate();
    } catch {
      // Ignore cleanup failure
    }
    sharedWorker = null;
  }
  workerUnavailable = false;
}

function getOrCreateWorker(): Worker | null {
  if (workerUnavailable || typeof Worker === 'undefined') return null;
  if (sharedWorker) return sharedWorker;

  try {
    const worker = new Worker(
      new URL('./composer-optimizer.worker.ts', import.meta.url),
      { type: 'module' },
    );
    worker.onmessage = (event: MessageEvent<OptimizerWorkerResponse>) => {
      const data = event.data;
      if (!data || typeof data.requestId !== 'number') return;
      const entry = pendingRequests.get(data.requestId);
      if (!entry) return;
      pendingRequests.delete(data.requestId);
      clearTimeout(entry.timer);
      entry.resolve({
        proposal: data.proposal,
        substitutions: data.substitutions,
        jointCombination: data.jointCombination ?? null,
      });
    };
    worker.onerror = () => {
      teardownWorkerWithError(worker, 'Falha no worker de otimização nutricional.');
    };
    worker.onmessageerror = () => {
      teardownWorkerWithError(worker, 'Erro ao desserializar resposta do worker nutricional.');
    };
    sharedWorker = worker;
    return worker;
  } catch {
    workerUnavailable = true;
    return null;
  }
}

export async function runComposerOptimizationAsync(
  dayPlan: ComposerDayPlan,
  targets: NutritionTargets,
  options: OptimizeBalanceOptions & { timeoutMs?: number } = {},
  includeSubstitutions = true,
): Promise<{
  proposal: OptimizationProposal;
  substitutions: DiscreteSubstitutionProposal[];
  jointCombination: DiscreteCombinationProposal | null;
}> {
  const { timeoutMs: requestedTimeoutMs, ...solverOptions } = options;
  const runSyncFallback = () => ({
    proposal: solveNutritionalBalanceQP(dayPlan, targets, solverOptions),
    substitutions: includeSubstitutions ? proposeDiscreteSubstitutions(dayPlan, targets, 4) : [],
    jointCombination: null,
  });

  const worker = getOrCreateWorker();
  if (!worker) {
    return runSyncFallback();
  }

  const timeoutMs =
    typeof requestedTimeoutMs === 'number' &&
    Number.isFinite(requestedTimeoutMs) &&
    requestedTimeoutMs > 0
      ? requestedTimeoutMs
      : DEFAULT_OPTIMIZER_TIMEOUT_MS;

  const requestId = nextRequestId++;
  return new Promise<Omit<OptimizerWorkerResponse, 'requestId'>>((resolve, reject) => {
    const timer = setTimeout(() => {
      const pending = pendingRequests.get(requestId);
      if (!pending) return;
      pendingRequests.delete(requestId);
      teardownWorkerWithError(worker, 'Tempo limite excedido no worker de otimização nutricional.');
      reject(new Error('Tempo limite excedido no worker de otimização nutricional.'));
    }, timeoutMs);

    pendingRequests.set(requestId, { resolve, reject, timer });
    const payload: OptimizerWorkerRequest = {
      requestId,
      dayPlan,
      targets,
      options: solverOptions,
      includeSubstitutions,
    };
    try {
      worker.postMessage(payload);
    } catch {
      const pending = pendingRequests.get(requestId);
      if (pending) {
        clearTimeout(pending.timer);
        pendingRequests.delete(requestId);
      }
      teardownWorkerWithError(worker, 'Falha ao enviar carga para o worker nutricional.');
      reject(new Error('Falha ao enviar carga para o worker nutricional.'));
    }
  }).catch(() => runSyncFallback());
}
