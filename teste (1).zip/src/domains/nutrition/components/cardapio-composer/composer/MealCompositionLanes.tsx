import { memo, useState } from 'react';
import { Check, Plus, RotateCcw, SkipForward, Trash2, Utensils } from 'lucide-react';
import { Surface } from '@/src/shared/ui/Surface';
import { RECIPE_CATALOG } from '../../../data/recipes/recipe-catalog';
import type {
  ComposerDayPlan,
  MealItem,
  MealTargetAllocation,
  NutritionTargets,
} from '../../../domain/entities/nutrient';
import {
  computeSlotNutrition,
  evaluateMealAllocations,
} from '../../../domain/rules/cardapio-composer-engine';
import { isEligibleRecipeTemplate } from '../../../domain/rules/recipe-engine';

interface MealCompositionLanesProps {
  dayPlan: ComposerDayPlan;
  dayMeals: readonly MealItem[];
  targets: NutritionTargets;
  allocations: readonly MealTargetAllocation[];
  selectedSlotId: string;
  isActivePlan: boolean;
  onSelectSlot: (slotId: string) => void;
  onAddSlot: (title: string, time: string, recipeId?: string) => void;
  onRemoveSlot: (slotId: string) => void;
  onConfirmMealConsumed: (mealId: string) => void;
  onSetMealPartial: (mealId: string, factor: number) => void;
  onSkipMeal: (mealId: string) => void;
  onRestoreMealPlanned: (mealId: string) => void;
}

const STATUS_LABELS: Record<MealItem['status'], string> = {
  planned: 'Planejada',
  consumed: 'Consumida',
  partial: 'Parcial 50%',
  substituted: 'Substituída',
  skipped: 'Pulada',
};

export const MealCompositionLanes = memo(function MealCompositionLanes({
  dayPlan,
  dayMeals,
  targets,
  allocations,
  selectedSlotId,
  isActivePlan,
  onSelectSlot,
  onAddSlot,
  onRemoveSlot,
  onConfirmMealConsumed,
  onSetMealPartial,
  onSkipMeal,
  onRestoreMealPlanned,
}: MealCompositionLanesProps) {
  const eligibleRecipes = RECIPE_CATALOG.filter(isEligibleRecipeTemplate);
  const [addingSlot, setAddingSlot] = useState(false);
  const [newTitle, setNewTitle] = useState('Ceia / Pós-treino');
  const [newTime, setNewTime] = useState('22:00');
  const [newRecipeId, setNewRecipeId] = useState<string>(eligibleRecipes[0]?.id ?? '');

  const allocationSummary = evaluateMealAllocations(dayPlan, targets, allocations);
  const allocBySlotId = new Map(allocationSummary.slots.map((s) => [s.slotId, s]));

  const handleAdd = () => {
    const clean = newTitle.trim();
    if (!clean) return;
    onAddSlot(clean, newTime, newRecipeId || undefined);
    setAddingSlot(false);
    setNewTitle('Ceia / Pós-treino');
  };

  return (
    <section aria-label="Composição das refeições" className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-base font-semibold text-[var(--titan-text-primary)]">
            Composição das refeições
          </h2>
          <p className="text-xs text-[var(--titan-text-muted)] font-mono-metric">
            {dayPlan.slots.length} horários · Selecione uma refeição para ajustar proporções e ingredientes
          </p>
        </div>

        <button
          type="button"
          onClick={() => setAddingSlot((prev) => !prev)}
          aria-expanded={addingSlot}
          className="titan-button titan-button--secondary !min-h-[44px] !px-3.5 !text-xs"
        >
          <Plus className="w-4 h-4" aria-hidden="true" />
          <span>Adicionar horário</span>
        </button>
      </div>

      {addingSlot && (
        <Surface data-elevation="2" className="p-4 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-[1fr_120px] gap-3">
            <label className="text-xs text-[var(--titan-text-secondary)]">
              Nome da refeição
              <input
                type="text"
                maxLength={80}
                value={newTitle}
                onChange={(event) => setNewTitle(event.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 text-[var(--titan-text-primary)]"
              />
            </label>
            <label className="text-xs text-[var(--titan-text-secondary)]">
              Horário
              <input
                type="time"
                value={newTime}
                onChange={(event) => setNewTime(event.target.value)}
                className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-2 text-[var(--titan-text-primary)]"
              />
            </label>
          </div>
          <label className="block text-xs text-[var(--titan-text-secondary)]">
            Receita inicial (opcional)
            <select
              value={newRecipeId}
              onChange={(event) => setNewRecipeId(event.target.value)}
              className="mt-1 w-full rounded-xl border border-[var(--titan-border)] bg-[var(--titan-surface-inset)] px-3 text-[var(--titan-text-primary)]"
            >
              <option value="">Composição em branco</option>
              {eligibleRecipes.map((rec) => (
                <option key={rec.id} value={rec.id}>
                  {rec.name}
                </option>
              ))}
            </select>
          </label>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setAddingSlot(false)}
              className="titan-button titan-button--ghost !min-h-[44px] !px-3 !text-xs"
            >
              Cancelar
            </button>
            <button
              type="button"
              disabled={!newTitle.trim()}
              onClick={handleAdd}
              className="titan-button titan-button--primary !min-h-[44px] !px-4 !text-xs disabled:opacity-45"
            >
              Criar horário
            </button>
          </div>
        </Surface>
      )}

      <Surface className="divide-y divide-[var(--titan-border-subtle)] overflow-hidden">
        {dayPlan.slots.map((slot) => {
          const isSelected = slot.id === selectedSlotId;
          const summary = computeSlotNutrition(slot);
          const alloc = allocBySlotId.get(slot.id);
          const linkedMeal = dayMeals.find(
            (m) => m.id === (slot.linkedMealId ?? slot.id),
          );
          const ingredientCount = slot.recipes.reduce(
            (sum, rec) => sum + rec.ingredients.length,
            0,
          );

          return (
            <div
              key={slot.id}
              className={`p-3.5 sm:px-4 sm:py-3.5 transition-colors ${
                isSelected
                  ? 'bg-[var(--titan-surface-raised)]/85 border-l-2 border-l-[var(--titan-champagne)]'
                  : 'hover:bg-[rgba(241,240,232,0.02)]'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <button
                  type="button"
                  onClick={() => onSelectSlot(slot.id)}
                  aria-pressed={isSelected}
                  className="min-w-0 flex-1 text-left focus-visible:outline-none"
                >
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
                    <span className={isSelected ? 'text-[var(--titan-champagne)] font-semibold' : 'text-[var(--titan-text-secondary)]'}>
                      {slot.time}
                    </span>
                    <span>·</span>
                    <span className="uppercase tracking-[0.08em]">{slot.title}</span>
                    {alloc && (
                      <>
                        <span>·</span>
                        <span>
                          Meta {alloc.sharePercent}% ({alloc.targetKcal} kcal)
                        </span>
                      </>
                    )}
                    {isActivePlan && linkedMeal && (
                      <>
                        <span>·</span>
                        <span
                          className={
                            linkedMeal.status === 'consumed'
                              ? 'text-[var(--titan-status-success)]'
                              : linkedMeal.status === 'skipped'
                                ? 'text-[var(--titan-status-error)]'
                                : 'text-[var(--titan-text-secondary)]'
                          }
                        >
                          {STATUS_LABELS[linkedMeal.status]}
                        </span>
                      </>
                    )}
                  </div>

                  <div className="mt-1 flex items-baseline justify-between gap-3">
                    <div className="min-w-0 flex items-center gap-2">
                      <Utensils
                        className={`w-3.5 h-3.5 shrink-0 ${
                          isSelected ? 'text-[var(--titan-champagne)]' : 'text-[var(--titan-accent)]'
                        }`}
                        aria-hidden="true"
                      />
                      <span className="text-sm sm:text-base font-semibold text-[var(--titan-text-primary)] truncate">
                        {slot.recipes[0]?.name ?? slot.title}
                        {slot.recipes.length > 1 ? ` + ${slot.recipes.length - 1}` : ''}
                      </span>
                    </div>
                    <span className="text-sm font-semibold font-mono-metric text-[var(--titan-text-primary)] shrink-0">
                      {Math.round(summary.macros.kcal)} kcal
                    </span>
                  </div>

                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-[11px] font-mono-metric text-[var(--titan-text-muted)]">
                    <span className="text-[var(--titan-accent)]">
                      P {summary.macros.proteinG.toFixed(0)} g
                    </span>
                    <span className="text-[var(--titan-info)]">
                      C {summary.macros.carbsG.toFixed(0)} g
                    </span>
                    <span className="text-[var(--titan-copper)]">
                      G {summary.macros.fatG.toFixed(0)} g
                    </span>
                    <span>
                      {slot.recipes.length} {slot.recipes.length > 1 ? 'receitas' : 'receita'} · {ingredientCount} componentes
                      {summary.weightedDeviationPercent > 0
                        ? ` · D ${summary.weightedDeviationPercent.toFixed(1)}%`
                        : ''}
                    </span>
                  </div>
                </button>

                {/* Consumption Logging & Slot Controls shown cleanly on active selection */}
                {isSelected && (
                  <div className="flex flex-wrap items-center gap-1.5 shrink-0 pt-1 sm:pt-0">
                    {isActivePlan && linkedMeal && (
                      <>
                        {linkedMeal.status !== 'consumed' ? (
                          <button
                            type="button"
                            onClick={() => onConfirmMealConsumed(linkedMeal.id)}
                            className="titan-button titan-button--primary !min-h-[40px] !px-3 !text-xs"
                          >
                            <Check className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Consumida</span>
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onRestoreMealPlanned(linkedMeal.id)}
                            className="titan-button titan-button--mineral !min-h-[40px] !px-3 !text-xs"
                          >
                            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                            <span>Desfazer</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => onSetMealPartial(linkedMeal.id, 0.5)}
                          className={`titan-button !min-h-[40px] !px-2.5 !text-xs font-mono-metric ${
                            linkedMeal.status === 'partial'
                              ? 'titan-button--mineral'
                              : 'titan-button--secondary'
                          }`}
                        >
                          50%
                        </button>

                        <button
                          type="button"
                          onClick={() => onSkipMeal(linkedMeal.id)}
                          aria-label={`Pular ${slot.title}`}
                          className={`titan-button !min-h-[40px] !px-2.5 !text-xs ${
                            linkedMeal.status === 'skipped'
                              ? 'titan-button--secondary !border-[var(--titan-status-error)]/60 !text-[var(--titan-status-error)]'
                              : 'titan-button--ghost'
                          }`}
                        >
                          <SkipForward className="w-3.5 h-3.5" aria-hidden="true" />
                        </button>
                      </>
                    )}

                    {dayPlan.slots.length > 1 && (
                      <button
                        type="button"
                        onClick={() => onRemoveSlot(slot.id)}
                        aria-label={`Remover horário ${slot.title}`}
                        className="min-w-[40px] min-h-[40px] inline-flex items-center justify-center rounded-xl text-[var(--titan-text-muted)] hover:text-[var(--titan-status-error)]"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </Surface>
    </section>
  );
});
