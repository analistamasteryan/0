import { startTransition, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  buildComposerDayFromMeals,
  cloneDayPlan,
  computeDayNutrition,
  scaleDayPlanProportionallyToMealTargets,
} from '../../domain/rules/cardapio-composer-engine';
import type {
  ComposerDayPlan,
  DiscreteCombinationProposal,
  DiscreteSubstitutionProposal,
  OptimizationProposal,
} from '../../domain/entities/nutrient';
import { runComposerOptimizationAsync } from '../../application/composer-optimizer-client';
import { buildDailyMicronutrientTargets } from '../../domain/rules/nutrition-calculator';
import { useNutritionStore } from '../../state/nutrition.store';
import { ComposerHeader } from './composer/ComposerHeader';
import { ComposerDayRail } from './composer/ComposerDayRail';
import { MealCompositionLanes } from './composer/MealCompositionLanes';
import { RecipeProportionMatrix } from './composer/RecipeProportionMatrix';
import { LiveBalancePanel } from './composer/LiveBalancePanel';
import { ComposerActionDock } from './composer/ComposerActionDock';
import {
  IntegratedCatalogDrawer,
  type CatalogMode,
} from './composer/IntegratedCatalogDrawer';
import { OptimizationPreview } from './variants/OptimizationPreview';
import { CompositionComparison } from './variants/CompositionComparison';

export interface CardapioComposerProps {
  initialCatalogScope?: 'cardapio' | 'receitas' | 'alimentos';
  onResetCatalogScope?: () => void;
}

export function CardapioComposer({
  initialCatalogScope,
  onResetCatalogScope,
}: CardapioComposerProps = {}) {
  const activeDateKey = useNutritionStore((s) => s.activeDateKey);
  const meals = useNutritionStore((s) => s.meals);
  const intakeDayConfirmations = useNutritionStore((s) => s.intakeDayConfirmations);
  const composerPlans = useNutritionStore((s) => s.composerPlans);
  const activeComposerPlanId = useNutritionStore((s) => s.activeComposerPlanId);
  const activeComposerSlotId = useNutritionStore((s) => s.activeComposerSlotId);
  const referenceProfileId = useNutritionStore((s) => s.referenceProfileId);
  const supplementMicronutrientIntakes = useNutritionStore((s) => s.supplementMicronutrientIntakes);

  const setActiveDateKey = useNutritionStore((s) => s.setActiveDateKey);
  const setActiveComposerSlotId = useNutritionStore((s) => s.setActiveComposerSlotId);
  const selectComposerPlan = useNutritionStore((s) => s.selectComposerPlan);
  const createComposerPlan = useNutritionStore((s) => s.createComposerPlan);
  const deleteComposerPlan = useNutritionStore((s) => s.deleteComposerPlan);
  const updateComposerPlanMeta = useNutritionStore((s) => s.updateComposerPlanMeta);
  const updateComposerPlanTargets = useNutritionStore((s) => s.updateComposerPlanTargets);
  const updateComposerMealAllocations = useNutritionStore((s) => s.updateComposerMealAllocations);
  const setComposerSlotRecipeYield = useNutritionStore((s) => s.setComposerSlotRecipeYield);
  const setComposerRecipeAdjustmentMode = useNutritionStore((s) => s.setComposerRecipeAdjustmentMode);
  const updateComposerIngredient = useNutritionStore((s) => s.updateComposerIngredient);
  const addIngredientToComposerRecipe = useNutritionStore((s) => s.addIngredientToComposerRecipe);
  const removeIngredientFromComposerRecipe = useNutritionStore((s) => s.removeIngredientFromComposerRecipe);
  const replaceCompositeWithSeparateFoods = useNutritionStore((s) => s.replaceCompositeWithSeparateFoods);
  const addRecipeToComposerSlot = useNutritionStore((s) => s.addRecipeToComposerSlot);
  const removeRecipeFromComposerSlot = useNutritionStore((s) => s.removeRecipeFromComposerSlot);
  const swapComposerSlotRecipe = useNutritionStore((s) => s.swapComposerSlotRecipe);
  const addComposerMealSlot = useNutritionStore((s) => s.addComposerMealSlot);
  const removeComposerMealSlot = useNutritionStore((s) => s.removeComposerMealSlot);
  const applyOptimizationProposal = useNutritionStore((s) => s.applyOptimizationProposal);
  const replaceComposerDayPlan = useNutritionStore((s) => s.replaceComposerDayPlan);
  const applyDiscreteCombinationProposal = useNutritionStore((s) => s.applyDiscreteCombinationProposal);
  const restoreComposerDayBaseline = useNutritionStore((s) => s.restoreComposerDayBaseline);
  const restoreComposerDaySnapshot = useNutritionStore((s) => s.restoreComposerDaySnapshot);
  const saveCompositionVariant = useNutritionStore((s) => s.saveCompositionVariant);
  const activateCompositionVariant = useNutritionStore((s) => s.activateCompositionVariant);
  const deleteCompositionVariant = useNutritionStore((s) => s.deleteCompositionVariant);

  const confirmMealConsumed = useNutritionStore((s) => s.confirmMealConsumed);
  const setMealPartial = useNutritionStore((s) => s.setMealPartial);
  const skipMeal = useNutritionStore((s) => s.skipMeal);
  const restoreMealPlanned = useNutritionStore((s) => s.restoreMealPlanned);
  const confirmIntakeDay = useNutritionStore((s) => s.confirmIntakeDay);
  const logFoodToDiary = useNutritionStore((s) => s.logFoodToDiary);

  const activePlan = useMemo(
    () => composerPlans.find((p) => p.id === activeComposerPlanId) ?? composerPlans[0]!,
    [composerPlans, activeComposerPlanId],
  );

  const dayMeals = useMemo(
    () => meals.filter((m) => m.dateKey === activeDateKey),
    [meals, activeDateKey],
  );

  const activeDay = useMemo(
    () => activePlan.days[activeDateKey] ?? buildComposerDayFromMeals(activeDateKey, dayMeals),
    [activePlan.days, activeDateKey, dayMeals],
  );

  const [selectedSlotId, setSelectedSlotId] = useState<string>(
    () => activeComposerSlotId ?? activeDay.slots[0]?.id ?? '',
  );
  const [goalFocus, setGoalFocus] = useState<'balanced' | 'energy' | 'protein'>('balanced');
  const [isOptimizing, setIsOptimizing] = useState(false);
  const [proposal, setProposal] = useState<OptimizationProposal | null>(null);
  const [substitutions, setSubstitutions] = useState<DiscreteSubstitutionProposal[]>([]);
  const [jointCombination, setJointCombination] = useState<DiscreteCombinationProposal | null>(null);
  const [undoSnapshot, setUndoSnapshot] = useState<{ dateKey: string; day: ComposerDayPlan } | null>(null);
  const [compareOpen, setCompareOpen] = useState(false);
  const [catalogMode, setCatalogMode] = useState<CatalogMode>(() =>
    initialCatalogScope === 'receitas'
      ? 'recipes'
      : initialCatalogScope === 'alimentos'
        ? 'foods'
        : 'none',
  );
  const [intakeFeedback, setIntakeFeedback] = useState<string | null>(null);
  const [proportionalFeedback, setProportionalFeedback] = useState<string | null>(null);
  const balancePanelRef = useRef<HTMLDivElement | null>(null);
  const optimizationRequestSeqRef = useRef(0);

  useEffect(() => {
    if (initialCatalogScope === 'receitas') {
      setCatalogMode('recipes');
    } else if (initialCatalogScope === 'alimentos') {
      setCatalogMode('foods');
    }
  }, [initialCatalogScope]);

  const handleChangeCatalogMode = useCallback(
    (next: CatalogMode) => {
      setCatalogMode(next);
      if (next === 'none') {
        onResetCatalogScope?.();
      }
    },
    [onResetCatalogScope],
  );

  // Sync valid selectedSlotId across day/plan switches & store cursor
  useEffect(() => {
    const valid = activeDay.slots.some((slot) => slot.id === selectedSlotId);
    const nextId = valid ? selectedSlotId : (activeDay.slots[0]?.id ?? '');
    if (nextId !== selectedSlotId) {
      setSelectedSlotId(nextId);
    }
    if (nextId && nextId !== activeComposerSlotId) {
      setActiveComposerSlotId(nextId);
    }
  }, [activeComposerSlotId, activeDay.slots, selectedSlotId, setActiveComposerSlotId]);

  const activeSlot = useMemo(
    () => activeDay.slots.find((slot) => slot.id === selectedSlotId) ?? activeDay.slots[0],
    [activeDay.slots, selectedSlotId],
  );

  const daySummary = useMemo(() => computeDayNutrition(activeDay), [activeDay]);
  const isIntakeDayConfirmed = intakeDayConfirmations.includes(activeDateKey);
  const canConfirmIntakeDay =
    dayMeals.length > 0 && dayMeals.every((meal) => meal.status !== 'planned');

  const handleSelectDateKey = useCallback(
    (nextDate: string) => {
      optimizationRequestSeqRef.current += 1;
      startTransition(() => {
        setActiveDateKey(nextDate);
        setProposal(null);
        setJointCombination(null);
        setIntakeFeedback(null);
        setIsOptimizing(false);
      });
    },
    [setActiveDateKey],
  );

  const handleSelectPlan = useCallback(
    (planId: string) => {
      optimizationRequestSeqRef.current += 1;
      startTransition(() => {
        selectComposerPlan(planId);
        setProposal(null);
        setJointCombination(null);
        setUndoSnapshot(null);
        setIsOptimizing(false);
      });
    },
    [selectComposerPlan],
  );

  const handleSelectSlot = useCallback(
    (slotId: string) => {
      startTransition(() => {
        setSelectedSlotId(slotId);
        setActiveComposerSlotId(slotId);
      });
    },
    [setActiveComposerSlotId],
  );

  const handleApplyProportionalMealTargets = useCallback(() => {
    try {
      const result = scaleDayPlanProportionallyToMealTargets(
        activeDay,
        activePlan.targets,
        activePlan.mealAllocations,
      );
      setUndoSnapshot({ dateKey: activeDateKey, day: cloneDayPlan(activeDay) });
      replaceComposerDayPlan(activeDateKey, result.proposedDayPlan);
      const limited = result.slots.filter((slot) => slot.status === 'limited_by_serving_or_mass_bounds').length;
      const unscalable = result.slots.filter((slot) => slot.status === 'no_scalable_energy').length;
      const unquantified = result.slots.reduce((sum, slot) => sum + slot.unquantifiedIngredientCount, 0);
      const lowConfidence = result.slots.reduce((sum, slot) => sum + slot.lowConfidenceIngredientCount, 0);
      setProportionalFeedback(
        `Distribuição aplicada: ${Math.round(result.afterMacros.kcal)} / ${activePlan.targets.kcal} kcal no dia. ` +
        `${result.slots.length} refeições calculadas${limited > 0 ? `; ${limited} limitadas por rendimento/massa ou energia fixa` : ''}` +
        `${unscalable > 0 ? `; ${unscalable} sem energia quantificável para escalar` : ''}` +
        `${unquantified > 0 ? `; ${unquantified} ingrediente(s) sem composição/quantidade completa` : ''}` +
        `${lowConfidence > 0 ? `; ${lowConfidence} ingrediente(s) têm dados de baixa confiança` : ''}.`,
      );
      setProposal(null);
      setJointCombination(null);
    } catch (error) {
      setProportionalFeedback(error instanceof Error ? error.message : 'Não foi possível calcular as porções proporcionais.');
    }
  }, [activeDateKey, activeDay, activePlan.mealAllocations, activePlan.targets, replaceComposerDayPlan]);

  const handleSimulateBalance = useCallback(
    async (scope: 'day' | 'slot') => {
      const reqSeq = ++optimizationRequestSeqRef.current;
      setIsOptimizing(true);
      try {
        const result = await runComposerOptimizationAsync(
          activeDay,
          activePlan.targets,
          {
            scopeSlotId: scope === 'slot' ? activeSlot?.id : undefined,
            goalFocus,
            mealAllocations: scope === 'day' ? activePlan.mealAllocations : undefined,
            micronutrientTargets: scope === 'day'
              ? buildDailyMicronutrientTargets(
                  referenceProfileId,
                  supplementMicronutrientIntakes,
                  activeDateKey,
                )
              : undefined,
          },
          true,
        );
        if (reqSeq !== optimizationRequestSeqRef.current) return;
        setProposal(result.proposal);
        setSubstitutions(result.substitutions);
        setJointCombination(result.jointCombination);
      } finally {
        if (reqSeq === optimizationRequestSeqRef.current) {
          setIsOptimizing(false);
        }
      }
    },
    [
      activeDateKey,
      activeDay,
      activePlan.mealAllocations,
      activePlan.targets,
      activeSlot?.id,
      goalFocus,
      referenceProfileId,
      supplementMicronutrientIntakes,
    ],
  );

  return (
    <div className="space-y-5 pb-20 lg:pb-4">
      <ComposerHeader
        plans={composerPlans}
        activePlan={activePlan}
        compareOpen={compareOpen}
        catalogMode={catalogMode}
        onSelectPlan={handleSelectPlan}
        onCreatePlan={createComposerPlan}
        onDeletePlan={deleteComposerPlan}
        onUpdatePlanMeta={updateComposerPlanMeta}
        onUpdateTargets={updateComposerPlanTargets}
        onToggleCompare={() => setCompareOpen((prev) => !prev)}
        onToggleCatalog={() =>
          handleChangeCatalogMode(catalogMode === 'none' ? 'recipes' : 'none')
        }
      />

      <ComposerDayRail
        plan={activePlan}
        activeDateKey={activeDateKey}
        onSelectDateKey={handleSelectDateKey}
      />

      {catalogMode !== 'none' && (
        <IntegratedCatalogDrawer
          mode={catalogMode}
          activeSlot={activeSlot}
          activeDateKey={activeDateKey}
          onChangeMode={handleChangeCatalogMode}
          onSwapSlotRecipe={(slotId, currentRecipeId, catalogRecipeId) =>
            swapComposerSlotRecipe(activeDateKey, slotId, currentRecipeId, catalogRecipeId)
          }
          onAddSlotRecipe={(slotId, catalogRecipeId) => {
            addRecipeToComposerSlot(activeDateKey, slotId, catalogRecipeId);
          }}
          onAddFoodToSlot={(slotId, recipeId, foodId, quantityG) =>
            addIngredientToComposerRecipe(activeDateKey, slotId, recipeId, foodId, quantityG)
          }
          onLogFoodToDiary={logFoodToDiary}
        />
      )}

      {compareOpen && (
        <CompositionComparison
          plans={composerPlans}
          activePlan={activePlan}
          activeDay={activeDay}
          activeDateKey={activeDateKey}
          onClose={() => setCompareOpen(false)}
        />
      )}

      {proposal && (
        <OptimizationPreview
          proposal={proposal}
          substitutions={substitutions}
          jointCombination={jointCombination}
          onApplyProposal={() => {
            setUndoSnapshot({ dateKey: activeDateKey, day: cloneDayPlan(activeDay) });
            applyOptimizationProposal(activeDateKey, proposal);
            setProposal(null);
            setJointCombination(null);
          }}
          onSaveAsVariant={(name) => {
            saveCompositionVariant(
              activeDateKey,
              name,
              proposal.proposedDayPlan,
              proposal.explanation,
            );
            setProposal(null);
            setJointCombination(null);
          }}
          onApplyDiscreteSubstitution={(sub) => {
            setUndoSnapshot({ dateKey: activeDateKey, day: cloneDayPlan(activeDay) });
            swapComposerSlotRecipe(
              activeDateKey,
              sub.slotId,
              sub.currentRecipeId,
              sub.candidateRecipeId,
            );
            setProposal(null);
            setJointCombination(null);
          }}
          onApplyJointCombination={(combo) => {
            setUndoSnapshot({ dateKey: activeDateKey, day: cloneDayPlan(activeDay) });
            applyDiscreteCombinationProposal(activeDateKey, combo);
            setProposal(null);
            setJointCombination(null);
          }}
          onDiscard={() => {
            setProposal(null);
            setJointCombination(null);
          }}
        />
      )}

      {/* Dual-Reading Studio: ~64% Composition Stage | ~36% Persistent Live Balance */}
      <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1.72fr)_minmax(340px,1fr)] gap-5 items-start">
        <div className="space-y-5 min-w-0">
          <MealCompositionLanes
            dayPlan={activeDay}
            dayMeals={dayMeals}
            targets={activePlan.targets}
            allocations={activePlan.mealAllocations}
            selectedSlotId={activeSlot?.id ?? ''}
            isActivePlan={activePlan.status === 'active'}
            onSelectSlot={handleSelectSlot}
            onAddSlot={(title, time, recipeId) => {
              const id = addComposerMealSlot(activeDateKey, title, time, recipeId);
              if (id) {
                setSelectedSlotId(id);
                setActiveComposerSlotId(id);
              }
            }}
            onRemoveSlot={(slotId) => removeComposerMealSlot(activeDateKey, slotId)}
            onConfirmMealConsumed={confirmMealConsumed}
            onSetMealPartial={setMealPartial}
            onSkipMeal={skipMeal}
            onRestoreMealPlanned={restoreMealPlanned}
          />

          {activeSlot && (
            <RecipeProportionMatrix
              slot={activeSlot}
              onChangeYield={(recipeId, targetServings) =>
                setComposerSlotRecipeYield(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  targetServings,
                )
              }
              onChangeAdjustmentMode={(recipeId, mode, resetToScaled) =>
                setComposerRecipeAdjustmentMode(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  mode,
                  resetToScaled,
                )
              }
              onUpdateIngredient={(recipeId, ingredientId, patch) =>
                updateComposerIngredient(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  ingredientId,
                  patch,
                )
              }
              onAddIngredient={(recipeId, foodId, quantityG) =>
                addIngredientToComposerRecipe(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  foodId,
                  quantityG,
                )
              }
              onRemoveIngredient={(recipeId, ingredientId) =>
                removeIngredientFromComposerRecipe(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  ingredientId,
                )
              }
              onReplaceComposite={(recipeId, ingredientId, replacements) =>
                replaceCompositeWithSeparateFoods(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  ingredientId,
                  replacements,
                )
              }
              onSwapRecipe={(recipeId, newCatalogRecipeId) =>
                swapComposerSlotRecipe(
                  activeDateKey,
                  activeSlot.id,
                  recipeId,
                  newCatalogRecipeId,
                )
              }
              onAddRecipeToSlot={(catalogRecipeId) =>
                addRecipeToComposerSlot(activeDateKey, activeSlot.id, catalogRecipeId)
              }
              onRemoveRecipeFromSlot={(recipeId) =>
                removeRecipeFromComposerSlot(activeDateKey, activeSlot.id, recipeId)
              }
            />
          )}
        </div>

        <div ref={balancePanelRef} className="lg:sticky lg:top-24">
          <LiveBalancePanel
            plan={activePlan}
            dayPlan={activeDay}
            selectedSlotId={activeSlot?.id ?? ''}
            goalFocus={goalFocus}
            isOptimizing={isOptimizing}
            canUndoOptimization={Boolean(undoSnapshot && undoSnapshot.dateKey === activeDateKey)}
            isIntakeDayConfirmed={isIntakeDayConfirmed}
            canConfirmIntakeDay={canConfirmIntakeDay}
            intakeFeedback={intakeFeedback}
            proportionalFeedback={proportionalFeedback}
            onApplyProportionalMealTargets={handleApplyProportionalMealTargets}
            onChangeGoalFocus={setGoalFocus}
            onSimulateBalance={handleSimulateBalance}
            onRestoreDayBaseline={() => {
              setUndoSnapshot({ dateKey: activeDateKey, day: cloneDayPlan(activeDay) });
              restoreComposerDayBaseline(activeDateKey);
            }}
            onUndoOptimization={() => {
              if (!undoSnapshot || undoSnapshot.dateKey !== activeDateKey) return;
              restoreComposerDaySnapshot(activeDateKey, undoSnapshot.day);
              setUndoSnapshot(null);
            }}
            onUpdateAllocations={(next) => updateComposerMealAllocations(activePlan.id, next)}
            onSaveVariant={(name) => saveCompositionVariant(activeDateKey, name)}
            onActivateVariant={(variantId) => activateCompositionVariant(activeDateKey, variantId)}
            onDeleteVariant={deleteCompositionVariant}
            onConfirmIntakeDay={() => {
              const result = confirmIntakeDay(activeDateKey);
              setIntakeFeedback(
                result.ok
                  ? 'Dia confirmado. Será usado quando houver histórico suficiente.'
                  : result.error,
              );
            }}
          />
        </div>
      </div>

      <ComposerActionDock
        planned={daySummary.macros}
        targets={activePlan.targets}
        isOptimizing={isOptimizing}
        onSimulateBalance={() => void handleSimulateBalance('day')}
        onJumpToBalance={() =>
          balancePanelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
        }
      />
    </div>
  );
}
