import { createSpringArray, interpolateRatio, type SpringNode } from './fluid-shader-engine.ts';
import {
  CardDropletSim,
  FluidVorticityGrid,
  type CardDropletImpactEvent,
} from './hydration-fluid-solver.ts';

export class HydrationVisualScene {
  readonly dropletWave: SpringNode[] = createSpringArray(24);
  readonly dropletGrid = new FluidVorticityGrid(48, 24);
  dropletSoliton: [number, number, number, number] = [0.5, 0.5, 0, 0];

  readonly tankWave: SpringNode[] = createSpringArray(24);
  readonly tankGrid = new FluidVorticityGrid(48, 24);
  tankSoliton: [number, number, number, number] = [0.5, 0.5, 0, 0];

  readonly cardSim = new CardDropletSim();

  tilt: [number, number] = [0, 0];
  targetTilt: [number, number] = [0, 0];
  tiltSettlingUntil = 0;

  dropletTargetFill = 0;
  dropletCurrentFill = 0;
  tankTargetFill = 0;
  tankCurrentFill = 0;

  /** Visual-only mass absorbed from microdroplets (never mutates hydration.store ml). */
  dropletVisualMass = 0;
  tankVisualMass = 0;
  dropletVisualSwell = 0;
  tankVisualSwell = 0;

  private lastTiltX = 0;
  private lastTiltY = 0;

  private lastDropletFrameNow = 0;
  private lastDropletInterpNow = 0;
  private lastDropletSolverNow = 0;

  private lastTankFrameNow = 0;
  private lastTankInterpNow = 0;
  private lastTankSolverNow = 0;

  setTiltTarget(tx: number, ty: number, now = performance.now()): void {
    this.targetTilt[0] = Math.max(-0.35, Math.min(0.35, tx));
    this.targetTilt[1] = Math.max(-0.35, Math.min(0.35, ty));
    this.tiltSettlingUntil = Math.max(this.tiltSettlingUntil, now + 260);
  }

  syncStoreFillTargets(dropletFill: number, tankFill: number): void {
    this.dropletTargetFill = Math.min(1, Math.max(0, Number.isFinite(dropletFill) ? dropletFill : 0));
    this.tankTargetFill = Math.min(1, Math.max(0, Number.isFinite(tankFill) ? tankFill : 0));
  }

  snapForReducedMotion(dropletFill: number, tankFill: number): void {
    this.dropletTargetFill = dropletFill;
    this.dropletCurrentFill = dropletFill;
    this.tankTargetFill = tankFill;
    this.tankCurrentFill = tankFill;
    this.dropletVisualSwell = 0;
    this.tankVisualSwell = 0;
    this.dropletSoliton = [0.5, 0.5, 0, 0];
    this.tankSoliton = [0.5, 0.5, 0, 0];
    this.tilt = [0, 0];
    this.targetTilt = [0, 0];
    this.tiltSettlingUntil = 0;
    this.lastDropletInterpNow = 0;
    this.lastDropletSolverNow = 0;
    this.lastTankInterpNow = 0;
    this.lastTankSolverNow = 0;
    this.cardSim.resetCalmDew();
  }

  applyDropletImpulse(
    normX = 0.5,
    normY = 0.55,
    vx = 0,
    vy = -3.2,
    spawnSoliton = false,
    aeration = 0.92,
  ): void {
    const cx = Math.min(1, Math.max(0, normX));
    const cy = Math.min(1, Math.max(0, normY));
    const idx = Math.min(23, Math.max(0, Math.round(cx * 23)));
    const wave = this.dropletWave;
    if (wave[idx - 2]) wave[idx - 2]!.velocity += vy * 0.22;
    if (wave[idx - 1]) wave[idx - 1]!.velocity += vy * 0.56;
    if (wave[idx]) wave[idx]!.velocity += vy;
    if (wave[idx + 1]) wave[idx + 1]!.velocity += vy * 0.56;
    if (wave[idx + 2]) wave[idx + 2]!.velocity += vy * 0.22;
    if (spawnSoliton) {
      this.dropletSoliton = [cx, cy, 0.015, Math.min(1.25, Math.max(0.75, Math.abs(vy) * 0.28))];
    }
    this.dropletGrid.injectImpulse(cx, cy, vx + (cx - 0.5) * 2.2, vy * 0.72, aeration);
  }

  applyTankImpulse(
    normX = this.tankTargetFill,
    normY = 0.5,
    vx = 0,
    vy = -3.4,
    spawnSoliton = false,
    aeration = 0.92,
  ): void {
    const cx = Math.min(1, Math.max(0, normX));
    const cy = Math.min(1, Math.max(0, normY));
    const idx = Math.min(23, Math.max(0, Math.round(cx * 23)));
    const wave = this.tankWave;
    if (wave[idx - 2]) wave[idx - 2]!.velocity += vy * 0.25;
    if (wave[idx - 1]) wave[idx - 1]!.velocity += vy * 0.58;
    if (wave[idx]) wave[idx]!.velocity += vy;
    if (wave[idx + 1]) wave[idx + 1]!.velocity += vy * 0.58;
    if (wave[idx + 2]) wave[idx + 2]!.velocity += vy * 0.25;
    if (spawnSoliton) {
      this.tankSoliton = [cx, cy, 0.015, Math.min(1.25, Math.max(0.72, Math.abs(vy) * 0.28))];
    }
    this.tankGrid.injectImpulse(cx, cy, vx + (cx - 0.5) * 2.1, vy * 0.68, aeration);
  }

  receiveMicrodropletTransfer(event: CardDropletImpactEvent): void {
    const mass = Math.max(0, event.massTransferred ?? 0);
    const isMerge = event.stage === 'merge';
    const impulseStrength = isMerge ? -Math.max(1.2, event.strength * 0.9) : -Math.max(1.6, event.strength * 1.05);
    const aeration = isMerge ? 0.55 : 0.85;

    if (event.target === 'droplet') {
      this.dropletVisualMass += mass;
      // Bounded visual surface swell (purely cosmetic, decays back to store fill)
      this.dropletVisualSwell = Math.min(0.024, this.dropletVisualSwell + Math.min(0.012, mass * 160 + 0.004));
      this.applyDropletImpulse(
        event.normX,
        0.74,
        (event.normX - 0.5) * 1.6,
        impulseStrength,
        !isMerge && event.strength > 1.85,
        aeration,
      );
    } else {
      this.tankVisualMass += mass;
      this.tankVisualSwell = Math.min(0.022, this.tankVisualSwell + Math.min(0.010, mass * 150 + 0.0035));
      this.applyTankImpulse(
        event.normX,
        0.35,
        (event.normX - 0.5) * 1.4,
        impulseStrength,
        !isMerge && event.strength > 1.85,
        aeration,
      );
    }
  }

  private trackTiltActivity(now: number, motionAllowed: boolean): boolean {
    if (
      motionAllowed &&
      (Math.abs(this.tilt[0] - this.lastTiltX) > 0.0008 ||
        Math.abs(this.tilt[1] - this.lastTiltY) > 0.0008)
    ) {
      this.lastTiltX = this.tilt[0];
      this.lastTiltY = this.tilt[1];
      this.tiltSettlingUntil = now + 260;
    }
    return motionAllowed && now < this.tiltSettlingUntil;
  }

  stepDroplet(
    now: number,
    targetFill: number,
    motionAllowed: boolean,
    isVisible: boolean,
    advanceSim = true,
  ): {
    fill: number;
    isAnimating: boolean;
    idleAnimating: boolean;
  } {
    this.dropletTargetFill = targetFill;

    if (!motionAllowed) {
      this.dropletCurrentFill = targetFill;
      this.dropletVisualSwell = 0;
      this.dropletSoliton = [0.5, 0.5, 0, 0];
      this.lastDropletInterpNow = 0;
      this.lastDropletSolverNow = 0;
      return { fill: targetFill, isAnimating: false, idleAnimating: false };
    }

    // Deduplicate when both card & BottomSheet gauges read the shared scene in the same frame
    if (!advanceSim || now - this.lastDropletFrameNow < 4) {
      const displayFill = Math.min(1, Math.max(0, this.dropletCurrentFill + this.dropletVisualSwell));
      const isTilting = now < this.tiltSettlingUntil;
      return {
        fill: displayFill,
        isAnimating:
          Math.abs(this.dropletTargetFill - this.dropletCurrentFill) > 0.0005 ||
          this.dropletGrid.isActive() ||
          this.dropletSoliton[3] > 0.001 ||
          isTilting ||
          this.dropletVisualSwell > 0.0005,
        idleAnimating: isVisible && displayFill > 0.004,
      };
    }
    this.lastDropletFrameNow = now;

    const diff = this.dropletTargetFill - this.dropletCurrentFill;
    const isInterpolating = Math.abs(diff) > 0.0005;
    if (isInterpolating) {
      const dt = this.lastDropletInterpNow
        ? Math.min(0.05, Math.max(0, (now - this.lastDropletInterpNow) / 1000))
        : 1 / 60;
      this.dropletCurrentFill = interpolateRatio(this.dropletCurrentFill, this.dropletTargetFill, dt, 1 / 10.5);
      this.lastDropletInterpNow = now;
    } else {
      this.dropletCurrentFill = this.dropletTargetFill;
      this.lastDropletInterpNow = 0;
    }

    const solverDt = this.lastDropletSolverNow
      ? Math.min(0.033, Math.max(0.004, (now - this.lastDropletSolverNow) / 1000))
      : 1 / 60;
    this.lastDropletSolverNow = now;

    if (this.dropletVisualSwell > 0.0002) {
      this.dropletVisualSwell *= Math.exp(-solverDt * 1.45);
    } else {
      this.dropletVisualSwell = 0;
    }

    const isTilting = this.trackTiltActivity(now, motionAllowed);
    if (isVisible && this.dropletCurrentFill > 0.004) {
      if (this.dropletGrid.isActive() || isInterpolating || isTilting) {
        this.dropletGrid.step(solverDt, this.tilt[0], this.tilt[1]);
      }
    }

    let hasSoliton = false;
    if (this.dropletSoliton[3] > 0.001) {
      const nextAge = this.dropletSoliton[2] + solverDt;
      if (nextAge > 1.85) {
        this.dropletSoliton[2] = 0;
        this.dropletSoliton[3] = 0;
      } else {
        this.dropletSoliton[2] = nextAge;
        hasSoliton = true;
      }
    }

    const displayFill = Math.min(1, Math.max(0, this.dropletCurrentFill + this.dropletVisualSwell));
    return {
      fill: displayFill,
      isAnimating:
        isInterpolating ||
        this.dropletGrid.isActive() ||
        hasSoliton ||
        isTilting ||
        this.dropletVisualSwell > 0.0005,
      idleAnimating: isVisible && displayFill > 0.004,
    };
  }

  stepTank(
    now: number,
    targetFill: number,
    motionAllowed: boolean,
    isVisible: boolean,
    advanceSim = true,
  ): {
    fill: number;
    isAnimating: boolean;
    idleAnimating: boolean;
  } {
    this.tankTargetFill = targetFill;

    if (!motionAllowed) {
      this.tankCurrentFill = targetFill;
      this.tankVisualSwell = 0;
      this.tankSoliton = [0.5, 0.5, 0, 0];
      this.lastTankInterpNow = 0;
      this.lastTankSolverNow = 0;
      return { fill: targetFill, isAnimating: false, idleAnimating: false };
    }

    if (!advanceSim || now - this.lastTankFrameNow < 4) {
      const displayFill = Math.min(1, Math.max(0, this.tankCurrentFill + this.tankVisualSwell));
      const isTilting = now < this.tiltSettlingUntil;
      return {
        fill: displayFill,
        isAnimating:
          Math.abs(this.tankTargetFill - this.tankCurrentFill) > 0.0005 ||
          this.tankGrid.isActive() ||
          this.tankSoliton[3] > 0.001 ||
          isTilting ||
          this.tankVisualSwell > 0.0005,
        idleAnimating: isVisible && displayFill > 0.004,
      };
    }
    this.lastTankFrameNow = now;

    const diff = this.tankTargetFill - this.tankCurrentFill;
    const isInterpolating = Math.abs(diff) > 0.0005;
    if (isInterpolating) {
      const dt = this.lastTankInterpNow
        ? Math.min(0.05, Math.max(0, (now - this.lastTankInterpNow) / 1000))
        : 1 / 60;
      this.tankCurrentFill = interpolateRatio(this.tankCurrentFill, this.tankTargetFill, dt, 1 / 10.5);
      this.lastTankInterpNow = now;
    } else {
      this.tankCurrentFill = this.tankTargetFill;
      this.lastTankInterpNow = 0;
    }

    const solverDt = this.lastTankSolverNow
      ? Math.min(0.033, Math.max(0.004, (now - this.lastTankSolverNow) / 1000))
      : 1 / 60;
    this.lastTankSolverNow = now;

    if (this.tankVisualSwell > 0.0002) {
      this.tankVisualSwell *= Math.exp(-solverDt * 1.45);
    } else {
      this.tankVisualSwell = 0;
    }

    const isTilting = this.trackTiltActivity(now, motionAllowed);
    if (isVisible && this.tankCurrentFill > 0.004) {
      if (this.tankGrid.isActive() || isInterpolating || isTilting) {
        this.tankGrid.step(solverDt, this.tilt[0], this.tilt[1]);
      }
    }

    let hasSoliton = false;
    if (this.tankSoliton[3] > 0.001) {
      const nextAge = this.tankSoliton[2] + solverDt;
      if (nextAge > 1.85) {
        this.tankSoliton[2] = 0;
        this.tankSoliton[3] = 0;
      } else {
        this.tankSoliton[2] = nextAge;
        hasSoliton = true;
      }
    }

    const displayFill = Math.min(1, Math.max(0, this.tankCurrentFill + this.tankVisualSwell));
    return {
      fill: displayFill,
      isAnimating:
        isInterpolating ||
        this.tankGrid.isActive() ||
        hasSoliton ||
        isTilting ||
        this.tankVisualSwell > 0.0005,
      idleAnimating: isVisible && displayFill > 0.004,
    };
  }
}
